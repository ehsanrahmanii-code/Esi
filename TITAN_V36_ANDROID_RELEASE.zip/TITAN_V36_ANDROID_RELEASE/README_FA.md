# TITAN V36 Android Release

این پروژه هسته `TITAN_V36_ANDROID_FINAL (1).py` را با Chaquopy داخل Android اجرا می‌کند و داشبورد Flask فعلی را در WebView نمایش می‌دهد.

## چهار بخش انجام‌شده
- بسته‌بندی Android/Chaquopy
- پوسته UI بومی Android + داشبورد موجود TITAN
- self-test و کنترل خطای startup/server probe
- buildهای debug/release و آیکون TITAN

## Build
1. Android Studio 2026.1.x یا محیط Gradle با JDK 17 و Android SDK API 37.
2. پروژه را باز کنید.
3. Sync Gradle.
4. `assembleDebug` برای تست یا `assembleRelease` برای APK قابل نصب.

Chaquopy 17.0 از Python 3.13 و minSdk 24 پشتیبانی می‌کند.

## نکته Release
نسخه release فعلی با debug signing قابل نصب است. برای انتشار واقعی، signingConfig خصوصی خودتان را جایگزین کنید.

## داده و کلیدها
موتور اصلی همچنان کلیدهای API را فقط از فایل‌های secrets/data می‌خواند. هیچ کلیدی در پروژه قرار داده نشده است.

## محدودیت محیط فعلی
این محیط اجرای من Android SDK/Gradle کامل ندارد؛ بنابراین پروژه و اسکریپت build آماده شده‌اند، اما APK باینری نهایی در همین محیط قابل تولید/تأیید نیست.
