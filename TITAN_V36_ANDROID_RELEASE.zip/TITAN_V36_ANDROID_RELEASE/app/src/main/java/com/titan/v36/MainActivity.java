package com.titan.v36;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

public class MainActivity extends AppCompatActivity {
    private static final String URL = "http://127.0.0.1:8080/";
    private WebView webView;
    private ProgressBar progress;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean engineStarted = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(com.titan.v36.R.layout.activity_main);
        webView = findViewById(R.id.web);
        progress = findViewById(R.id.progress);
        status = findViewById(R.id.status);
        configureWebView();
        requestStorageAccessIfNeeded();
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setBackgroundColor(0xFF020711);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("127.0.0.1".equals(u.getHost()) || "localhost".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                status.setVisibility(View.GONE);
            }
        });
    }

    private void requestStorageAccessIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            status.setText("برای ذخیره‌سازی TITAN، دسترسی فایل را فعال کنید…");
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(this, "برای ذخیره‌سازی TITAN دسترسی فایل را فعال کنید.", Toast.LENGTH_LONG).show();
            } catch (Exception ignored) {
                status.setText("دسترسی فایل لازم است.");
            }
        } else {
            startEngineOncePermissionsReady();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) startEngineOncePermissionsReady();
    }

    private void startEngineOncePermissionsReady() {
        if (android.os.Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
            return;
        }
        if (!engineStarted) {
            startPythonEngine();
            waitForServer(0);
        }
    }

    private void startPythonEngine() {
        if (engineStarted) return;
        engineStarted = true;
        status.setText("TITAN V36 در حال راه‌اندازی موتور تحلیل…");
        new Thread(() -> {
            try {
                Python py = Python.getInstance();
                PyObject module = py.getModule("titan_engine");
                module.callAttr("run_titan", false);
            } catch (Throwable t) {
                engineStarted = false;
                handler.post(() -> status.setText("خطای راه‌اندازی موتور: " + t.getMessage()));
            }
        }, "titan-python-start").start();
    }

    private void waitForServer(final int attempt) {
        if (attempt > 90) {
            status.setText("سرور TITAN آماده نشد؛ دوباره تلاش کنید.");
            progress.setVisibility(View.GONE);
            return;
        }
        handler.postDelayed(() -> new Thread(() -> {
            boolean ok = false;
            java.net.HttpURLConnection c = null;
            try {
                java.net.URL u = new java.net.URL("http://127.0.0.1:8080/api/dashboard-status");
                c = (java.net.HttpURLConnection) u.openConnection();
                c.setConnectTimeout(700);
                c.setReadTimeout(700);
                c.setRequestMethod("GET");
                ok = c.getResponseCode() > 0;
            } catch (Exception ignored) {
            } finally { if (c != null) c.disconnect(); }
            final boolean ready = ok;
            handler.post(() -> {
                if (ready) {
                    progress.setVisibility(View.VISIBLE);
                    webView.loadUrl(URL);
                } else {
                    status.setText("در حال آماده‌سازی TITAN… " + (attempt + 1));
                    waitForServer(attempt + 1);
                }
            });
        }, "titan-server-probe").start(), 400);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
