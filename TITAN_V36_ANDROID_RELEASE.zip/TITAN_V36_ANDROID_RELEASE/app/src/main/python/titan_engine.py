from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import sqlite3
import statistics
import sys
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from logging.handlers import RotatingFileHandler

import numpy as np
import pandas as pd
import requests
from flask import Flask, jsonify, redirect, render_template_string, request, url_for
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

try:
    import websocket as _websocket_client
except Exception:
    _websocket_client = None

# ============================================================
# TITAN
# Technical layers: Fibonacci / Support-Resistance / Multi TF scoring integrated ENTERPRISE V32 Desktop edition
# Analysis only. No order execution.
# Persistent files remain under APP_HOME.
# ============================================================

# Android/Desktop production storage roots are deterministic and do not depend on
# the current working directory, executable location, profile directory, or a
# caller-supplied TITAN_HOME variable. TITAN data/cache/memory/logs/secrets are
# intentionally kept together under one user-visible folder.
# Android-first single-root storage. This build intentionally has NO desktop
# fallback: if shared storage is unavailable, TITAN stops instead of silently
# writing into the script directory, /tmp, the current working directory, or
# another application cache.
TITAN_ANDROID_HOME = Path("/storage/emulated/0/AI TAITAN AI")

def _select_app_home() -> Path:
    """Prefer Android shared storage; optional TITAN_HOME; safe desktop fallback for lab use.

    Production Android still hard-locks under /storage/emulated/0/AI TAITAN AI.
    On non-Android hosts (desktop/CI), TITAN_HOME or ./AI_TAITAN_AI is used so the
    engine can start without crashing, while never silently writing into /tmp.
    """
    if Path("/storage/emulated/0").exists():
        return TITAN_ANDROID_HOME
    env_home = (os.environ.get("TITAN_HOME") or "").strip()
    if env_home:
        return Path(env_home).expanduser().resolve()
    lab = Path(__file__).resolve().parent / "AI_TAITAN_AI"
    return lab

APP_HOME = _select_app_home()
DATA_DIR = APP_HOME / "data"
CACHE_DIR = APP_HOME / "cache"
MEMORY_DIR = APP_HOME / "memory"
SECRETS_DIR = APP_HOME / "secrets"
LOG_DIR = DATA_DIR

for directory in (APP_HOME, DATA_DIR, CACHE_DIR, MEMORY_DIR, SECRETS_DIR):
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError as _mkdir_exc:
        print(f"TITAN mkdir warning: {directory} -> {_mkdir_exc}")

DB_PATH = DATA_DIR / "titan_enterprise.db"
LOG_PATH = LOG_DIR / "titan_engine.log"
AI_CACHE_PATH = CACHE_DIR / "ai_responses.json"
MARKET_CACHE_PATH = CACHE_DIR / "market_cache.json"
USER_SETTINGS_PATH = DATA_DIR / "user_settings.json"
MODEL_SETTINGS_PATH = DATA_DIR / "model_settings.json"
AI_SYMBOL_CACHE_PATH = CACHE_DIR / "ai_symbol_responses.json"


def _startup_storage_audit() -> dict[str, Any]:
    """Verify and enforce the single Android storage root before services start."""
    root = APP_HOME.resolve()
    required = (DATA_DIR, CACHE_DIR, MEMORY_DIR, SECRETS_DIR)
    root.mkdir(parents=True, exist_ok=True)
    for directory in required:
        directory.mkdir(parents=True, exist_ok=True)
        try:
            directory.resolve().relative_to(root)
        except ValueError:
            raise RuntimeError(f"TITAN storage escape: {directory}")
    probe = root / ".titan_storage_probe"
    try:
        probe.write_text("TITAN_STORAGE_OK", encoding="utf-8")
        if probe.read_text(encoding="utf-8") != "TITAN_STORAGE_OK":
            raise OSError("storage verification mismatch")
    finally:
        try:
            probe.unlink()
        except OSError:
            pass
    persistent = (DB_PATH, LOG_PATH, AI_CACHE_PATH, MARKET_CACHE_PATH,
                  USER_SETTINGS_PATH, MODEL_SETTINGS_PATH, AI_SYMBOL_CACHE_PATH)
    for path in persistent:
        try:
            path.resolve().relative_to(root)
        except ValueError:
            raise RuntimeError(f"Persistent path escaped TITAN root: {path}")
    return {"root": str(root), "writable": True, "persistent_paths_locked": True}


STARTUP_STORAGE_AUDIT = _startup_storage_audit()

# V29 autonomous loop:
# - live prices are streamed/polled continuously;
# - the expensive multi-timeframe scan runs automatically in the background;
# - outcome/performance learning is maintained independently of page requests;
# - Gemini enrichment is asynchronous and is fed back into the next scan.
AUTO_SCAN_INTERVAL_SECONDS = 45
AUTO_MAINTENANCE_INTERVAL_SECONDS = 20
AUTO_AI_TOP_N = 6
AUTO_AI_REFRESH_SECONDS = 180

MARKET_CACHE_TTL = 40
# Fast dashboard scan: skip external LLM calls during bulk market refresh (biggest latency win).
# Detail endpoints can still request AI on demand.
DASHBOARD_FAST_SCAN = True
RENDER_PERF_LOG = True
AI_CACHE_TTL = 180
LIVE_PRICE_POLL_SECONDS = 2
MAX_BACKTEST_CANDLES = 5000
SIGNAL_COOLDOWN_SECONDS = 2400
MIN_DIRECTIONAL_QUALITY = 46
MIN_PRECISION_SCORE = 44
MIN_TREND_STABILITY = 0.35
MAX_STRETCH_ATR = 3.2
MIN_EFFECTIVE_RR = 1.02
HTTP_TIMEOUT = 15
FEE_RATE = 0.0004
SPREAD_RATE = 0.0002
SLIPPAGE_RATE = 0.0002
TOTAL_ENTRY_BUFFER = FEE_RATE + SPREAD_RATE + SLIPPAGE_RATE

# --- V8 Professional confidence gates ---
# V28.5: deep audit — residual WAIT kills softened, hero board fixed,
# refine_bias balanced, neural demotion only on real conflict.
TITAN_PARAM_VERSION = "V36.0-ANDROID-QUANTUM-RESONANCE"
MAX_LIVE_PRICE_AGE_SEC = 8.0
MIN_CLOSED_CANDLES_1H = 48
MIN_CLOSED_CANDLES_15M = 35
MIN_DATA_QUALITY_SCORE = 50
ENTRY_LADDER_MIN_HTF_SCORE = 46
ENTRY_LADDER_MIN_MTF_SCORE = 46
ENTRY_LADDER_MIN_LTF_ALIGN = 0.0  # soft; hard check is direction match
MAX_PORTFOLIO_SAME_SIDE = 5
FORECAST_TRACK_PATH = None  # set after APP_HOME exists
CALIB_MIN_SAMPLES_FULL = 20
CALIB_CAP_LOW_N = 62.0
CALIB_CAP_MID_N = 72.0
CALIB_CAP_HIGH_N = 86.0

sys.dont_write_bytecode = True

# ============================================================
# LOGGING / SAFETY
# ============================================================

LOGGER = logging.getLogger("TITAN")
LOGGER.setLevel(logging.INFO)
LOGGER.propagate = False
if not LOGGER.handlers:
    _file_handler = RotatingFileHandler(
        LOG_PATH, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    _file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    LOGGER.addHandler(_file_handler)


def _now_iso() -> str:
    """Return a timezone-aware UTC timestamp for dashboard/cache metadata."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

CACHE_LOCK = threading.RLock()
DB_LOCK = threading.RLock()
JSON_LOCK = threading.RLock()
_HTTP_LOCAL = threading.local()
KEY_LOCK = threading.RLock()
OI_LOCK = threading.RLock()
UPDATE_LOCK = threading.Lock()

# --- V9 Performance: shared pools + short-TTL kline/derivative memory cache ---
KLINE_CACHE: dict[str, tuple[float, "pd.DataFrame"]] = {}
KLINE_CACHE_LOCK = threading.RLock()
KLINE_CACHE_TTL = 28.0          # seconds — closed candles change slowly
KLINE_CACHE_MAX = 240           # hard cap entries (symbols × TFs)
DERIV_CACHE: dict[str, tuple[float, dict]] = {}
DERIV_CACHE_TTL = 30.0
_ANALYSIS_POOL: Optional[ThreadPoolExecutor] = None
_ANALYSIS_POOL_LOCK = threading.Lock()
_KLINE_POOL: Optional[ThreadPoolExecutor] = None
_KLINE_POOL_LOCK = threading.Lock()


def _get_analysis_pool(size: int = 6) -> ThreadPoolExecutor:
    global _ANALYSIS_POOL
    with _ANALYSIS_POOL_LOCK:
        if _ANALYSIS_POOL is None:
            # Cap workers: network-bound; too many just fight DNS/SSL on mobile.
            n = max(3, min(int(size), 6))
            _ANALYSIS_POOL = ThreadPoolExecutor(max_workers=n, thread_name_prefix="titan-an")
        return _ANALYSIS_POOL


def _get_kline_pool(size: int = 4) -> ThreadPoolExecutor:
    global _KLINE_POOL
    with _KLINE_POOL_LOCK:
        if _KLINE_POOL is None:
            _KLINE_POOL = ThreadPoolExecutor(max_workers=max(2, min(int(size), 4)), thread_name_prefix="titan-kl")
        return _KLINE_POOL


_AI_POOL: Optional[ThreadPoolExecutor] = None
_AI_POOL_LOCK = threading.Lock()
DERIV_CACHE_MAX = 80


def _append_capped(target: list, value: Any, max_items: int = 256) -> None:
    """Append to an in-memory history without allowing unbounded growth."""
    target.append(value)
    overflow = len(target) - int(max_items)
    if overflow > 0:
        del target[:overflow]


def _get_ai_pool(size: int = 2) -> ThreadPoolExecutor:
    """Reuse one AI thread pool across symbols (avoids create/destroy per coin)."""
    global _AI_POOL
    with _AI_POOL_LOCK:
        if _AI_POOL is None:
            _AI_POOL = ThreadPoolExecutor(max_workers=size, thread_name_prefix="titan-ai")
        return _AI_POOL


def _kline_cache_key(symbol: str, tf: str, limit: int, start_ms: Optional[int], end_ms: Optional[int]) -> str:
    return f"{_binance_symbol(symbol)}|{tf}|{limit}|{start_ms or 0}|{end_ms or 0}"


def _kline_cache_get(key: str) -> Optional["pd.DataFrame"]:
    with KLINE_CACHE_LOCK:
        row = KLINE_CACHE.get(key)
        if not row:
            return None
        ts, df = row
        if time.time() - ts > KLINE_CACHE_TTL:
            KLINE_CACHE.pop(key, None)
            return None
        # Never hand out the mutable cached frame itself; one consumer must not
        # be able to corrupt another concurrent analysis.
        return df.copy(deep=False)


def _kline_cache_put(key: str, df: "pd.DataFrame") -> None:
    with KLINE_CACHE_LOCK:
        # Keep a private immutable-by-convention snapshot. Consumers receive a
        # shallow copy on read, preventing accidental index/column mutations.
        KLINE_CACHE[key] = (time.time(), df.copy(deep=False))
        if len(KLINE_CACHE) > KLINE_CACHE_MAX:
            # drop oldest ~20%
            items = sorted(KLINE_CACHE.items(), key=lambda x: x[1][0])
            for k, _ in items[: max(1, len(items) // 5)]:
                KLINE_CACHE.pop(k, None)



def _safe_app_path(path: Path) -> Path:
    candidate = Path(path).resolve()
    root = APP_HOME.resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise RuntimeError(f"TITAN path escaped APP_HOME: {candidate}")
    return candidate


def _http_session() -> requests.Session:
    """Return one requests.Session per worker thread.

    requests.Session is not guaranteed to be safely mutable across concurrent
    workers; TITAN performs many parallel market/API calls. Thread-local sessions
    preserve connection pooling without sharing mutable session state.
    """
    session = getattr(_HTTP_LOCAL, "session", None)
    if session is None:
        session = requests.Session()
        session.headers.update({"User-Agent": "TITAN-ENTERPRISE/3.0", "Accept": "application/json"})
        retry = Retry(
            total=3, connect=3, read=3, backoff_factor=0.6,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET", "HEAD", "OPTIONS"]),
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=48, pool_maxsize=48)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        _HTTP_LOCAL.session = session
    return session

# ============================================================
# API KEYS - FILE ONLY
# ============================================================

OPENAI_API_KEY = ""
GEMINI_API_KEY = ""
GROK_API_KEY = ""
CLAUDE_API_KEY = ""
DEEPSEEK_API_KEY = ""
COINGLASS_API_KEY = ""

KEY_FILES = {
    "OPENAI_API_KEY": ["openai_api_key.txt", "chatgpt_api_key.txt", "titan_llm_key.txt"],
    "GEMINI_API_KEY": ["gemini_api_key.txt", "gemini_key.txt", "api gemini_key.txt"],
    "GROK_API_KEY": ["grok_api_key.txt", "xai_api_key.txt", "grok_key.txt"],
    "CLAUDE_API_KEY": ["claude_api_key.txt", "anthropic_api_key.txt", "claude_key.txt"],
    "DEEPSEEK_API_KEY": ["deepseek_api_key.txt", "deepseek_key.txt"],
    "COINGLASS_API_KEY": ["coinglass_api_key.txt", "coinglass_key.txt"],
}


def _clean_key(value: str) -> str:
    value = (value or "").lstrip("\ufeff").strip()
    if not value:
        return ""
    if "=" in value and "\n" not in value:
        left, right = value.split("=", 1)
        normalized = left.strip().upper().replace("_", "").replace("-", "")
        if normalized.endswith("APIKEY"):
            value = right.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1].strip()
    return value


def _read_key(name: str) -> str:
    for filename in KEY_FILES.get(name, []):
        for base in (SECRETS_DIR, APP_HOME, DATA_DIR):
            path = base / filename
            try:
                if path.is_file():
                    value = _clean_key(path.read_text(encoding="utf-8"))
                    if value:
                        return value
            except OSError as exc:
                LOGGER.warning("Key read failed for %s: %s", filename, exc)
    return ""


def reload_keys() -> None:
    global OPENAI_API_KEY, GEMINI_API_KEY, GROK_API_KEY, CLAUDE_API_KEY, DEEPSEEK_API_KEY, COINGLASS_API_KEY
    with KEY_LOCK:
        OPENAI_API_KEY = _read_key("OPENAI_API_KEY")
        GEMINI_API_KEY = _read_key("GEMINI_API_KEY")
        GROK_API_KEY = _read_key("GROK_API_KEY")
        CLAUDE_API_KEY = _read_key("CLAUDE_API_KEY")
        DEEPSEEK_API_KEY = _read_key("DEEPSEEK_API_KEY")
        COINGLASS_API_KEY = _read_key("COINGLASS_API_KEY")

reload_keys()

# ============================================================
# DEFAULTS / HELPERS
# ============================================================

DEFAULT_COINS = [
    "BTC/USDT",
    "ETH/USDT",
    "BNB/USDT",
    "XRP/USDT",
    "SOL/USDT",
    "ADA/USDT",
    "DOGE/USDT",
    "AVAX/USDT",
    "LINK/USDT",
    "NEAR/USDT",
    "SUI/USDT",
    "TAO/USDT",
    "AAVE/USDT",
    "BCH/USDT",
    "XLM/USDT",
    "TRX/USDT",
    "SHIB/USDT",
    "PEPE/USDT",
    "WIF/USDT",
    "FLOKI/USDT",
    "CAKE/USDT",
    "HYPE/USDT",
    "ZEC/USDT",
    "XAUT/USDT",
]
LIVE_PRICE_URL = "https://data-api.binance.vision/api/v3/ticker/price"
BINANCE_REST_HOSTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
]
LIVE_PRICE_URLS = [f"{h}/api/v3/ticker/price" for h in BINANCE_REST_HOSTS]
KLINES_URLS = [f"{h}/api/v3/klines" for h in BINANCE_REST_HOSTS]


def _safe_startup_check():
    """Basic production startup validation."""
    try:
        APP_HOME.mkdir(parents=True, exist_ok=True)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        init_db()
        return True
    except Exception as exc:
        LOGGER.exception("Startup validation failed: %s", exc)
        return False
TF_CFG = {
    "15m": {"horizon": 60, "weight": 0.15},
    "1h": {"horizon": 240, "weight": 0.25},
    "4h": {"horizon": 720, "weight": 0.30},
    "1d": {"horizon": 2880, "weight": 0.30},
}

USER_SETTINGS = {"risk_multiplier": 1.2, "active_coins": DEFAULT_COINS.copy()}
CACHE = {"timestamp": 0.0, "data": [], "gemini_summary": "", "macro": {}}
OI_HISTORY: dict[str, tuple[float, float, str]] = {}
LIVE_PRICES: dict[str, dict[str, Any]] = {}
LIVE_LOCK = threading.RLock()
LIVE_STOP = threading.Event()
LIVE_THREADS: list[threading.Thread] = []

COIN_META = {
    "BTC": ("Bitcoin", "₿"), "ETH": ("Ethereum", "Ξ"), "XRP": ("XRP", "✕"),
    "SOL": ("Solana", "◎"), "SHIB": ("Shiba Inu", "🐕"), "BNB": ("BNB", "◆"),
    "ZEC": ("Zcash", "ⓩ"), "ADA": ("Cardano", "₳"), "TRX": ("TRON", "⚡"),
    "HYPE": ("Hyperliquid", "🌊"), "DOGE": ("Dogecoin", "Ð"), "WIF": ("dogwifhat", "🐶"),
    "PEPE": ("Pepe", "🐸"), "AVAX": ("Avalanche", "🔺"), "FLOKI": ("Floki", "🐺"),
    "CAKE": ("PancakeSwap", "🥞"), "BCH": ("Bitcoin Cash", "Ƀ"), "XLM": ("Stellar", "✦"),
    "AAVE": ("Aave", "👻"), "SUI": ("Sui", "💧"), "TAO": ("Bittensor", "🧠"),
    "LINK": ("Chainlink", "⬡"), "NEAR": ("NEAR", "Ⓝ"), "XAUT": ("Tether Gold", "🥇"),
}


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default




# === TITAN ULTRA TECHNICAL LAYER ===

def calculate_auto_fibonacci(high, low):
    diff=float(high)-float(low)
    return {
        "0.236": round(float(high)-diff*0.236,8),
        "0.382": round(float(high)-diff*0.382,8),
        "0.500": round(float(high)-diff*0.500,8),
        "0.618": round(float(high)-diff*0.618,8),
        "0.786": round(float(high)-diff*0.786,8),
    }

def calculate_support_resistance(closes, window=20):
    vals=list(map(float, closes[-window:])) if closes else []
    if not vals:
        return {"support":None,"resistance":None}
    return {"support":min(vals),"resistance":max(vals)}

def technical_layers(df):
    close=df["close"].astype(float)
    mid=close.rolling(20).mean()
    std=close.rolling(20).std()
    high=float(df["high"].max()); low=float(df["low"].min())
    return {
        "bollinger": {"upper":float((mid+2*std).iloc[-1]), "middle":float(mid.iloc[-1]), "lower":float((mid-2*std).iloc[-1])},
        "fibonacci": calculate_auto_fibonacci(high,low),
        "support_resistance": calculate_support_resistance(close.tolist())
    }

# === TITAN V6 ADVANCED TECHNICAL SUITE ===
def calc_macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> dict[str, float]:
    """MACD line, signal, histogram — fail-safe."""
    try:
        c = close.astype(float)
        if len(c) < slow + signal:
            return {"macd": 0.0, "signal": 0.0, "hist": 0.0, "cross": "none"}
        ema_f = c.ewm(span=fast, adjust=False).mean()
        ema_s = c.ewm(span=slow, adjust=False).mean()
        macd = ema_f - ema_s
        sig = macd.ewm(span=signal, adjust=False).mean()
        hist = macd - sig
        h0, h1 = float(hist.iloc[-1]), float(hist.iloc[-2]) if len(hist) > 1 else 0.0
        cross = "bull" if h1 <= 0 < h0 else "bear" if h1 >= 0 > h0 else "none"
        return {"macd": round(float(macd.iloc[-1]), 8), "signal": round(float(sig.iloc[-1]), 8),
                "hist": round(h0, 8), "cross": cross}
    except Exception:
        return {"macd": 0.0, "signal": 0.0, "hist": 0.0, "cross": "none"}


def calc_stoch_rsi(close: pd.Series, rsi_period: int = 14, stoch_period: int = 14, k: int = 3, d: int = 3) -> dict[str, float]:
    """Stochastic RSI for timing entries on oversold/overbought extremes."""
    try:
        rsi = wilder_rsi(close, rsi_period)
        if len(rsi) < stoch_period + d:
            return {"k": 50.0, "d": 50.0, "zone": "mid"}
        rmin = rsi.rolling(stoch_period).min()
        rmax = rsi.rolling(stoch_period).max()
        stoch = 100 * (rsi - rmin) / (rmax - rmin).replace(0, np.nan)
        k_line = stoch.rolling(k).mean().fillna(50)
        d_line = k_line.rolling(d).mean().fillna(50)
        kv, dv = float(k_line.iloc[-1]), float(d_line.iloc[-1])
        zone = "oversold" if kv < 20 else "overbought" if kv > 80 else "mid"
        return {"k": round(kv, 2), "d": round(dv, 2), "zone": zone}
    except Exception:
        return {"k": 50.0, "d": 50.0, "zone": "mid"}


def calc_pivot_points(df: pd.DataFrame) -> dict[str, float]:
    """Classic daily pivots from last closed candle high/low/close."""
    try:
        if df is None or len(df) < 2:
            return {}
        row = df.iloc[-1]
        h, l, c = float(row["high"]), float(row["low"]), float(row["close"])
        pp = (h + l + c) / 3.0
        r1 = 2 * pp - l
        s1 = 2 * pp - h
        r2 = pp + (h - l)
        s2 = pp - (h - l)
        r3 = h + 2 * (pp - l)
        s3 = l - 2 * (h - pp)
        return {k: round(v, 8) for k, v in (("pp", pp), ("r1", r1), ("r2", r2), ("r3", r3), ("s1", s1), ("s2", s2), ("s3", s3))}
    except Exception:
        return {}


def calc_volume_delta(df: pd.DataFrame, lookback: int = 24) -> dict[str, float]:
    """Proxy CVD from candle body direction * volume (no tick data required)."""
    try:
        x = df.tail(lookback).copy()
        if x.empty:
            return {"delta": 0.0, "buy_vol": 0.0, "sell_vol": 0.0, "delta_pct": 0.0}
        body_up = (x["close"] >= x["open"]).astype(float)
        buy_v = float((x["vol"] * body_up).sum())
        sell_v = float((x["vol"] * (1 - body_up)).sum())
        total = buy_v + sell_v
        delta = buy_v - sell_v
        return {
            "delta": round(delta, 4),
            "buy_vol": round(buy_v, 4),
            "sell_vol": round(sell_v, 4),
            "delta_pct": round((delta / total * 100) if total > 0 else 0.0, 2),
        }
    except Exception:
        return {"delta": 0.0, "buy_vol": 0.0, "sell_vol": 0.0, "delta_pct": 0.0}


def market_session_utc() -> dict[str, Any]:
    """Current major session and overlap (analysis-only context)."""
    hour = datetime.now(timezone.utc).hour
    if 0 <= hour < 8:
        name, risk_mult = "Asia", 0.95
    elif 8 <= hour < 13:
        name, risk_mult = "London", 1.05
    elif 13 <= hour < 17:
        name, risk_mult = "London-NY Overlap", 1.12
    elif 17 <= hour < 21:
        name, risk_mult = "New York", 1.05
    else:
        name, risk_mult = "Off-hours", 0.88
    return {"session": name, "hour_utc": hour, "liquidity_boost": risk_mult}




# === TITAN PATTERN + FUTURE CANDLE FORECAST ENGINE ===
PATTERN_GUIDE = {
    "سرشانه": {
        "name_en": "Head & Shoulders",
        "meaning": "الگوی بازگشتی نزولی: سه قله که قله میانی (سر) بالاتر از دو شانه است. خط گردن اتصال کف‌های بین شانه و سر است.",
        "expect": "با شکست معتبر خط گردن به سمت پایین، انتظار ادامه نزول تا اندازه ارتفاع سر تا خط گردن وجود دارد. حد ضرر بالای شانه راست.",
        "bias": "نزولی",
    },
    "سرشانه معکوس": {
        "name_en": "Inverse Head & Shoulders",
        "meaning": "الگوی بازگشتی صعودی: سه کف که کف میانی (سر) پایین‌تر از دو شانه است.",
        "expect": "با شکست خط گردن به بالا، انتظار رشد تا اندازه ارتفاع الگو. حد ضرر زیر شانه راست.",
        "bias": "صعودی",
    },
    "سقف دوقلو": {
        "name_en": "Double Top",
        "meaning": "دو قله تقریباً هم‌تراز پس از روند صعودی؛ نشانه ضعف خریداران.",
        "expect": "شکست کف میانی (خط گردن) معمولاً ادامه نزول را تقویت می‌کند. هدف تقریبی: فاصله قله تا گردن.",
        "bias": "نزولی",
    },
    "کف دوقلو": {
        "name_en": "Double Bottom",
        "meaning": "دو کف تقریباً هم‌تراز پس از روند نزولی؛ نشانه ضعف فروشندگان.",
        "expect": "شکست سقف میانی معمولاً ادامه صعود را تقویت می‌کند. هدف تقریبی: فاصله کف تا گردن.",
        "bias": "صعودی",
    },
    "واگرایی صعودی": {
        "name_en": "Bullish Divergence",
        "meaning": "قیمت کف پایین‌تر می‌سازد اما RSI/MACD کف بالاتر می‌سازد — ضعف فروش.",
        "expect": "احتمال واکنش صعودی یا پایان موقت نزول؛ تأیید با برگشت قیمت و حجم لازم است.",
        "bias": "صعودی",
    },
    "واگرایی نزولی": {
        "name_en": "Bearish Divergence",
        "meaning": "قیمت سقف بالاتر می‌سازد اما RSI/MACD سقف پایین‌تر می‌سازد — ضعف خرید.",
        "expect": "احتمال اصلاح یا برگشت نزولی؛ تأیید با شکست ساختار لازم است.",
        "bias": "نزولی",
    },
    "مثلث فشرده": {
        "name_en": "Symmetrical / Tight Range",
        "meaning": "نوسان در حال فشرده شدن؛ انرژی برای شکست انباشته می‌شود.",
        "expect": "شکست با حجم می‌تواند حرکت جهت‌دار ایجاد کند؛ جهت از ساختار چندتایم‌فریمی خوانده شود.",
        "bias": "خنثی",
    },
}


def _find_swing_points(series: pd.Series, order: int = 3) -> tuple[list[tuple[int, float]], list[tuple[int, float]]]:
    """Local swing highs/lows as (index_position, value)."""
    vals = series.astype(float).tolist()
    highs, lows = [], []
    n = len(vals)
    for i in range(order, n - order):
        window = vals[i - order:i + order + 1]
        if vals[i] == max(window) and vals[i] > vals[i - 1] and vals[i] > vals[i + 1]:
            highs.append((i, vals[i]))
        if vals[i] == min(window) and vals[i] < vals[i - 1] and vals[i] < vals[i + 1]:
            lows.append((i, vals[i]))
    return highs, lows


def detect_chart_patterns(df: pd.DataFrame, rsi_series: Optional[pd.Series] = None) -> dict[str, Any]:
    """Detect standard patterns: H&S, double top/bottom, RSI divergence, tight range."""
    patterns: list[dict[str, Any]] = []
    try:
        if df is None or len(df) < 40:
            return {"patterns": [], "primary": None, "score_bias": 0.0}
        high = df["high"].astype(float)
        low = df["low"].astype(float)
        close = df["close"].astype(float)
        swing_highs, _ = _find_swing_points(high, 3)
        _, swing_lows = _find_swing_points(low, 3)

        # Double Top
        if len(swing_highs) >= 2:
            (i1, h1), (i2, h2) = swing_highs[-2], swing_highs[-1]
            if i2 > i1 and abs(h1 - h2) / max(h1, 1e-12) < 0.015:
                mid_low = float(low.iloc[i1:i2 + 1].min()) if i2 > i1 else float(low.iloc[-1])
                if float(close.iloc[-1]) < (h1 + h2) / 2:
                    conf = 62 + (10 if float(close.iloc[-1]) < mid_low else 0)
                    patterns.append({
                        "id": "سقف دوقلو", "confidence": min(88, conf),
                        "levels": {"peak1": round(h1, 8), "peak2": round(h2, 8), "neck": round(mid_low, 8)},
                        "guide": PATTERN_GUIDE["سقف دوقلو"],
                    })

        # Double Bottom
        if len(swing_lows) >= 2:
            (i1, l1), (i2, l2) = swing_lows[-2], swing_lows[-1]
            if i2 > i1 and abs(l1 - l2) / max(abs(l1), 1e-12) < 0.015:
                mid_high = float(high.iloc[i1:i2 + 1].max()) if i2 > i1 else float(high.iloc[-1])
                if float(close.iloc[-1]) > (l1 + l2) / 2:
                    conf = 62 + (10 if float(close.iloc[-1]) > mid_high else 0)
                    patterns.append({
                        "id": "کف دوقلو", "confidence": min(88, conf),
                        "levels": {"trough1": round(l1, 8), "trough2": round(l2, 8), "neck": round(mid_high, 8)},
                        "guide": PATTERN_GUIDE["کف دوقلو"],
                    })

        # Head & Shoulders (3 highs: L-shoulder, head, R-shoulder)
        if len(swing_highs) >= 3:
            (i0, s0), (i1, head), (i2, s1) = swing_highs[-3], swing_highs[-2], swing_highs[-1]
            if head > s0 and head > s1 and abs(s0 - s1) / max(head, 1e-12) < 0.04 and i0 < i1 < i2:
                neck = float(low.iloc[i0:i2 + 1].min())
                conf = 70 if float(close.iloc[-1]) < neck * 1.01 else 58
                patterns.append({
                    "id": "سرشانه", "confidence": conf,
                    "levels": {"left": round(s0, 8), "head": round(head, 8), "right": round(s1, 8), "neck": round(neck, 8)},
                    "guide": PATTERN_GUIDE["سرشانه"],
                })

        # Inverse H&S
        if len(swing_lows) >= 3:
            (i0, s0), (i1, head), (i2, s1) = swing_lows[-3], swing_lows[-2], swing_lows[-1]
            if head < s0 and head < s1 and abs(s0 - s1) / max(abs(head), 1e-12) < 0.04 and i0 < i1 < i2:
                neck = float(high.iloc[i0:i2 + 1].max())
                conf = 70 if float(close.iloc[-1]) > neck * 0.99 else 58
                patterns.append({
                    "id": "سرشانه معکوس", "confidence": conf,
                    "levels": {"left": round(s0, 8), "head": round(head, 8), "right": round(s1, 8), "neck": round(neck, 8)},
                    "guide": PATTERN_GUIDE["سرشانه معکوس"],
                })

        # RSI divergence
        rsi = rsi_series if rsi_series is not None else wilder_rsi(close)
        if len(close) >= 30 and len(rsi) >= 30:
            c_tail = close.tail(30)
            r_tail = rsi.tail(30)
            price_ll = float(c_tail.min()) == float(c_tail.iloc[-1]) or (
                float(c_tail.iloc[-1]) <= float(c_tail.iloc[:-5].min()) * 1.002
            )
            price_hh = float(c_tail.iloc[-1]) >= float(c_tail.iloc[:-5].max()) * 0.998
            rsi_now = float(r_tail.iloc[-1])
            rsi_prev_min = float(r_tail.iloc[:-5].min())
            rsi_prev_max = float(r_tail.iloc[:-5].max())
            if price_ll and rsi_now > rsi_prev_min + 3:
                patterns.append({
                    "id": "واگرایی صعودی", "confidence": 65,
                    "levels": {"rsi": round(rsi_now, 1)},
                    "guide": PATTERN_GUIDE["واگرایی صعودی"],
                })
            if price_hh and rsi_now < rsi_prev_max - 3:
                patterns.append({
                    "id": "واگرایی نزولی", "confidence": 65,
                    "levels": {"rsi": round(rsi_now, 1)},
                    "guide": PATTERN_GUIDE["واگرایی نزولی"],
                })

        # Tight range / triangle proxy
        recent = close.tail(20)
        atr_pct = float((high.tail(20) - low.tail(20)).mean() / close.iloc[-1] * 100) if float(close.iloc[-1]) else 0
        if atr_pct < 1.4 and float(recent.max() / recent.min() - 1) * 100 < 3.5:
            patterns.append({
                "id": "مثلث فشرده", "confidence": 55,
                "levels": {"range_high": round(float(recent.max()), 8), "range_low": round(float(recent.min()), 8)},
                "guide": PATTERN_GUIDE["مثلث فشرده"],
            })

        patterns.sort(key=lambda x: -x.get("confidence", 0))
        primary = patterns[0] if patterns else None
        score_bias = 0.0
        if primary:
            g = primary.get("guide") or {}
            b = g.get("bias", "خنثی")
            conf = primary.get("confidence", 50) / 100.0
            if b == "صعودی":
                score_bias = 4.0 * conf
            elif b == "نزولی":
                score_bias = -4.0 * conf
        return {"patterns": patterns[:5], "primary": primary, "score_bias": round(score_bias, 2)}
    except Exception as exc:
        LOGGER.debug("pattern detect failed: %s", exc)
        return {"patterns": [], "primary": None, "score_bias": 0.0}


def forecast_future_candles(
    df: pd.DataFrame,
    horizon: int = 12,
    patterns: Optional[dict] = None,
    *,
    macd: Optional[dict] = None,
    stoch: Optional[dict] = None,
    structure: Optional[dict] = None,
    regime: Optional[dict] = None,
) -> dict[str, Any]:
    """Multi-factor probabilistic path for the next N candles (default 12).

    Blends: historical return distribution, short/medium momentum, EMA structure,
    MACD/Stoch tilt, chart-pattern bias, analogue matching, and soft mean-reversion
    over longer horizons. Analysis-only — not a guarantee of future prices.
    """
    try:
        horizon = int(clamp(horizon, 3, 24))
        if df is None or len(df) < 50:
            return {"ok": False, "candles": [], "narrative": "داده کافی برای پیش‌بینی نیست", "horizon": horizon}
        close = df["close"].astype(float)
        high = df["high"].astype(float)
        low = df["low"].astype(float)
        vol = df["vol"].astype(float) if "vol" in df.columns else pd.Series([1.0] * len(df))
        rets = close.pct_change().dropna().tail(160)
        if len(rets) < 20:
            return {"ok": False, "candles": [], "narrative": "تاریخچه بازده ناکافی", "horizon": horizon}

        mu = float(rets.mean())
        sigma = float(rets.std()) or 1e-6
        # Multi-horizon momentum
        mom3 = float(close.iloc[-1] / close.iloc[-4] - 1) if len(close) > 4 else 0.0
        mom5 = float(close.iloc[-1] / close.iloc[-6] - 1) if len(close) > 6 else 0.0
        mom12 = float(close.iloc[-1] / close.iloc[-13] - 1) if len(close) > 13 else 0.0
        ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
        ema50 = float(close.ewm(span=50, adjust=False).mean().iloc[-1]) if len(close) >= 50 else ema20
        ema_gap = (ema20 / ema50 - 1.0) if ema50 > 0 else 0.0
        price_vs_ema = (float(close.iloc[-1]) / ema20 - 1.0) if ema20 > 0 else 0.0

        # Base drift: recent mean + momentum blend + structure
        mu_adj = mu * 0.28 + mom3 * 0.18 + mom5 * 0.22 + mom12 * 0.12 + ema_gap * 0.20
        # Soft mean-reversion when stretched vs EMA20
        if abs(price_vs_ema) > 0.025:
            mu_adj -= price_vs_ema * 0.15

        # Pattern tilt
        pbias = safe_float((patterns or {}).get("score_bias"), 0) / 100.0
        mu_adj += pbias * abs(sigma) * 2.2

        # MACD / Stoch confirmation
        macd = macd or {}
        stoch = stoch or {}
        if macd.get("cross") == "bull":
            mu_adj += abs(sigma) * 0.35
        elif macd.get("cross") == "bear":
            mu_adj -= abs(sigma) * 0.35
        hist = safe_float(macd.get("hist"), 0)
        if hist != 0:
            last_px = float(close.iloc[-1])
            mu_adj += float(np.clip(hist / max(last_px * 0.01, 1e-12), -0.8, 0.8)) * abs(sigma) * 0.25
        zone = str(stoch.get("zone") or "mid")
        if zone == "oversold":
            mu_adj += abs(sigma) * 0.20
        elif zone == "overbought":
            mu_adj -= abs(sigma) * 0.20

        # Regime / structure soft bias
        regime_name = str((regime or {}).get("regime", "")).lower()
        if "up" in regime_name or "bull" in regime_name:
            mu_adj += abs(sigma) * 0.12
        elif "down" in regime_name or "bear" in regime_name:
            mu_adj -= abs(sigma) * 0.12
        struct_bias = str((structure or {}).get("bias", "") or "")
        if struct_bias == "صعودی":
            mu_adj += abs(sigma) * 0.10
        elif struct_bias == "نزولی":
            mu_adj -= abs(sigma) * 0.10

        # Volume confirmation of last move
        try:
            v_tail = vol.tail(8)
            c_tail = close.tail(8)
            if len(v_tail) >= 4 and float(v_tail.mean()) > 0:
                up_vol = float(v_tail[c_tail.diff() > 0].sum())
                dn_vol = float(v_tail[c_tail.diff() < 0].sum())
                if up_vol + dn_vol > 0:
                    vol_skew = (up_vol - dn_vol) / (up_vol + dn_vol)
                    mu_adj += vol_skew * abs(sigma) * 0.18
        except Exception:
            pass

        last = float(close.iloc[-1])
        atr = float((high - low).tail(14).mean()) or last * 0.01

        # Historical analogue (longer window for 12-step path)
        analogue_note = ""
        best_corr, best_fwd = 0.0, None
        try:
            window = 12 if len(close) > 80 else 8
            target = close.pct_change().dropna().tail(window).values
            rets_all = close.pct_change().dropna().values
            # Stride search for speed (dashboard scans many symbols)
            _step = 2 if len(rets_all) > 80 else 1
            for i in range(window, max(window + 1, len(rets_all) - horizon - 1), _step):
                seg = rets_all[i - window:i]
                if len(seg) != window:
                    continue
                if float(np.std(seg)) < 1e-12 or float(np.std(target)) < 1e-12:
                    continue
                corr = float(np.corrcoef(seg, target)[0, 1])
                if math.isfinite(corr) and corr > best_corr and corr > 0.50:
                    best_corr = corr
                    best_fwd = rets_all[i:i + horizon]
            if best_fwd is not None and len(best_fwd) >= 1:
                fwd_sum = float(np.sum(best_fwd))
                analogue_note = (
                    f"نزدیک‌ترین الگوی تاریخی با همبستگی {best_corr:.0%} در ادامه "
                    f"{'مثبت' if fwd_sum > 0 else 'منفی'} حدود {abs(fwd_sum)*100:.2f}% حرکت داشته است."
                )
        except Exception:
            pass

        candles = []
        px = last
        # Confidence decays slower for short steps, faster for far steps
        for step in range(1, horizon + 1):
            # Dampen drift with horizon (uncertainty + mean reversion)
            damp = 1.0 / (1.0 + 0.045 * (step - 1))
            step_mu = mu_adj * damp
            drift = step_mu * step
            # Wider bands for longer horizon
            band = sigma * (step ** 0.55) * (1.45 + 0.04 * step)
            mid = last * (1 + drift)
            # Blend analogue path if available
            if best_fwd is not None and step <= len(best_fwd):
                ana = last * (1 + float(np.sum(best_fwd[:step])))
                mid = 0.62 * mid + 0.38 * ana
            lo = mid * (1 - band) - 0.12 * atr * (1 + 0.03 * step)
            hi = mid * (1 + band) + 0.12 * atr * (1 + 0.03 * step)
            o = px
            c = mid
            h = max(o, c, hi * 0.35 + mid * 0.65)
            l = min(o, c, lo * 0.35 + mid * 0.65)
            direction = "صعودی" if c >= o else "نزولی"
            conf = clamp(78 - step * 3.2 + abs(pbias) * 70 + (best_corr * 12 if best_corr else 0), 22, 82)
            candles.append({
                "step": step,
                "open": round(float(o), 8),
                "high": round(float(h), 8),
                "low": round(float(l), 8),
                "close": round(float(c), 8),
                "mid": round(float(mid), 8),
                "band_low": round(float(lo), 8),
                "band_high": round(float(hi), 8),
                "direction": direction,
                "confidence": round(conf, 1),
                "analogue_corr": round(best_corr, 3) if best_corr else None,
            })
            px = float(c)

        primary = (patterns or {}).get("primary")
        if primary:
            pname = primary.get("id", "")
            guide = primary.get("guide") or {}
            narrative = (
                f"پیش‌بینی احتمالی {horizon} کندل بعدی با مدل چندعاملی (بازده، مومنتوم چندافق، EMA، MACD/Stoch، "
                f"الگوی «{pname}» و آنالوگ تاریخی). {guide.get('expect', '')} "
                f"{analogue_note} این خروجی سناریویی است و تضمین سود نیست."
            )
        else:
            narrative = (
                f"پیش‌بینی احتمالی {horizon} کندل با توزیع بازده، مومنتوم، ساختار EMA و شباهت الگویی. "
                f"{analogue_note} خروجی سناریویی است، نه قطعی."
            )
        up_steps = sum(1 for c in candles if c["direction"] == "صعودی")
        overall = "صعودی" if up_steps > horizon * 0.55 else "نزولی" if up_steps < horizon * 0.45 else "خنثی"
        # Path conviction: magnitude of expected move vs sigma
        expected_move = (candles[-1]["close"] / last - 1.0) if candles else 0.0
        path_strength = float(clamp(abs(expected_move) / max(sigma * (horizon ** 0.5), 1e-9) * 25, 0, 40))
        return {
            "ok": True,
            "horizon": horizon,
            "overall_bias": overall,
            "candles": candles,
            "narrative": narrative,
            "last_price": round(last, 8),
            "mu": round(mu_adj, 6),
            "sigma": round(sigma, 6),
            "expected_move_pct": round(expected_move * 100, 3),
            "path_strength": round(path_strength, 1),
            "analogue_corr": round(best_corr, 3) if best_corr else None,
            "components": {
                "mom3": round(mom3, 6), "mom5": round(mom5, 6), "mom12": round(mom12, 6),
                "ema_gap": round(ema_gap, 6), "pattern_bias": round(pbias, 4),
            },
        }
    except Exception as exc:
        LOGGER.debug("forecast_future_candles failed: %s", exc)
        return {"ok": False, "candles": [], "narrative": str(exc)[:200], "horizon": horizon}


def fetch_binance_long_short_ratio(symbol: str) -> dict[str, Any]:
    """Global long/short account ratio from Binance Futures (free public endpoint)."""
    pair = _binance_symbol(symbol)
    out: dict[str, Any] = {"long_ratio": None, "short_ratio": None, "long_short_ratio": None, "source": "N/A"}
    try:
        r = _http_session().get(
            "https://fapi.binance.com/futures/data/globalLongShortAccountRatio",
            params={"symbol": pair, "period": "1h", "limit": 1},
            timeout=8,
        )
        if r.ok:
            data = r.json()
            if isinstance(data, list) and data:
                row = data[-1]
                lr = safe_float(row.get("longAccount"))
                sr = safe_float(row.get("shortAccount"))
                ratio = safe_float(row.get("longShortRatio"))
                out.update({
                    "long_ratio": round(lr * 100, 2) if lr else None,
                    "short_ratio": round(sr * 100, 2) if sr else None,
                    "long_short_ratio": round(ratio, 4) if ratio else None,
                    "source": "Binance-LSR",
                })
    except Exception as exc:
        LOGGER.debug("LSR fetch failed %s: %s", symbol, exc)
    try:
        r = _http_session().get(
            "https://fapi.binance.com/futures/data/topLongShortAccountRatio",
            params={"symbol": pair, "period": "1h", "limit": 1},
            timeout=8,
        )
        if r.ok:
            data = r.json()
            if isinstance(data, list) and data:
                row = data[-1]
                out["top_long_ratio"] = round(safe_float(row.get("longAccount")) * 100, 2)
                out["top_short_ratio"] = round(safe_float(row.get("shortAccount")) * 100, 2)
                out["top_long_short_ratio"] = round(safe_float(row.get("longShortRatio")), 4)
                out["source"] = (out.get("source") or "") + "+TopTrader"
    except Exception as exc:
        LOGGER.debug("Top trader ratio failed %s: %s", symbol, exc)
    return out


def fetch_binance_taker_buy_sell(symbol: str) -> dict[str, Any]:
    """Taker buy/sell volume ratio — real order-flow proxy."""
    pair = _binance_symbol(symbol)
    try:
        r = _http_session().get(
            "https://fapi.binance.com/futures/data/takerlongshortRatio",
            params={"symbol": pair, "period": "1h", "limit": 1},
            timeout=8,
        )
        if r.ok:
            data = r.json()
            if isinstance(data, list) and data:
                row = data[-1]
                buy = safe_float(row.get("buyVol"))
                sell = safe_float(row.get("sellVol"))
                ratio = safe_float(row.get("buySellRatio"))
                total = buy + sell
                return {
                    "buy_vol": buy, "sell_vol": sell,
                    "buy_sell_ratio": round(ratio, 4) if ratio else None,
                    "buy_pct": round(buy / total * 100, 1) if total > 0 else 50.0,
                    "sell_pct": round(sell / total * 100, 1) if total > 0 else 50.0,
                    "source": "Binance-Taker",
                }
    except Exception as exc:
        LOGGER.debug("Taker ratio failed %s: %s", symbol, exc)
    return {"buy_pct": 50.0, "sell_pct": 50.0, "buy_sell_ratio": None, "source": "N/A"}


def _ls_bias(ls: dict[str, Any], direction_wanted: int) -> tuple[float, str]:
    """Crowd positioning bias: extreme long crowding is short-friendly and vice versa."""
    ratio = safe_float(ls.get("long_short_ratio"), 1.0)
    if ratio <= 0:
        return 0.0, "فاقد داده L/S"
    if ratio >= 1.8:
        return (-5.0 if direction_wanted >= 0 else 4.0), "ازدحام شدید لانگ (ضدجمعیت نزولی)"
    if ratio >= 1.35:
        return (-2.5 if direction_wanted >= 0 else 2.0), "فشار لانگ بالا"
    if ratio <= 0.55:
        return (5.0 if direction_wanted <= 0 else -4.0), "ازدحام شدید شورت (ضدجمعیت صعودی)"
    if ratio <= 0.75:
        return (2.5 if direction_wanted <= 0 else -2.0), "فشار شورت بالا"
    return 0.0, "نسبت لانگ/شورت متعادل"



def clamp(value: float, lo: float, hi: float) -> float:
    return float(max(lo, min(hi, value)))


# ============================================================
# TITAN V8 — CONFIDENCE ENGINE (Entry Ladder · DQ · Forecast Track · Portfolio)
# Analysis-only. Raises bar for LONG/SHORT; never invents edge.
# ============================================================

_FORECAST_TRACK_LOCK = threading.RLock()
_PORTFOLIO_SIGNAL_LOCK = threading.RLock()
_RECENT_DIRECTIONAL_SIGNALS: list[dict[str, Any]] = []


def _forecast_track_path() -> Path:
    return MEMORY_DIR / "forecast_path_accuracy.json"


def _load_forecast_track() -> dict[str, Any]:
    data = _load_json(_forecast_track_path(), {})
    return data if isinstance(data) else {}


def _save_forecast_track(data: dict[str, Any]) -> None:
    _save_json(_forecast_track_path(), data)


def assess_data_quality(
    *,
    symbol: str,
    price: float,
    live_age_sec: Optional[float],
    df15: Optional[pd.DataFrame],
    df1h: Optional[pd.DataFrame],
    derivatives: dict[str, Any],
    frames: Optional[dict] = None,
) -> dict[str, Any]:
    """Hard data-quality score + veto reasons. Low quality forces WAIT."""
    reasons: list[str] = []
    score = 100.0
    n15 = len(df15) if df15 is not None else 0
    n1h = len(df1h) if df1h is not None else 0
    if price <= 0:
        reasons.append("invalid_price")
        score -= 40
    if live_age_sec is None:
        score -= 8
        reasons.append("no_live_ts")
    elif live_age_sec > MAX_LIVE_PRICE_AGE_SEC:
        score -= min(25.0, 8 + (live_age_sec - MAX_LIVE_PRICE_AGE_SEC) * 0.8)
        reasons.append(f"stale_live_{live_age_sec:.0f}s")
    if n1h < MIN_CLOSED_CANDLES_1H:
        score -= 20
        reasons.append(f"thin_1h_{n1h}")
    if n15 < MIN_CLOSED_CANDLES_15M:
        score -= 12
        reasons.append(f"thin_15m_{n15}")
    if frames:
        missing = [tf for tf in ("15m", "1h", "4h", "1d") if tf not in frames or frames[tf] is None or len(frames[tf]) < 30]
        if missing:
            score -= 6 * len(missing)
            reasons.append("missing_tf:" + ",".join(missing))
    fund = derivatives.get("funding_value")
    if fund is None and str(derivatives.get("funding", "N/A")) == "N/A":
        score -= 6
        reasons.append("no_funding")
    if safe_float(derivatives.get("raw_oi"), 0) <= 0 and str(derivatives.get("oi", "N/A")) == "N/A":
        score -= 5
        reasons.append("no_oi")
    score = float(clamp(score, 0, 100))
    # Hard veto only for truly unusable data — borderline quality is soft penalty.
    hard_veto = (
        "invalid_price" in reasons
        or n1h < 25
        or score < 32
    )
    return {
        "score": round(score, 1),
        "hard_veto": hard_veto,
        "reasons": reasons,
        "live_age_sec": live_age_sec,
        "candles_1h": n1h,
        "candles_15m": n15,
        "param_version": TITAN_PARAM_VERSION,
    }


def entry_ladder_gate(
    tf_scores: dict[str, float],
    tf_results: dict[str, str],
    decision_tag: str,
    bias: str,
) -> dict[str, Any]:
    """Mandatory HTF→MTF→LTF alignment before directional signal.

    4h/1d = macro direction, 1h = setup, 15m = trigger lean.
    """
    s15 = safe_float(tf_scores.get("15m"), 50)
    s1h = safe_float(tf_scores.get("1h"), 50)
    s4h = safe_float(tf_scores.get("4h"), 50)
    s1d = safe_float(tf_scores.get("1d"), 50)
    htf = 0.55 * s4h + 0.45 * s1d
    mtf = s1h
    ltf = s15

    def _side(sc: float) -> str:
        if sc >= 54:
            return "LONG"
        if sc <= 46:
            return "SHORT"
        return "WAIT"

    htf_side, mtf_side, ltf_side = _side(htf), _side(mtf), _side(ltf)
    wanted = decision_tag if decision_tag in {"LONG", "SHORT"} else (
        "LONG" if bias == "صعودی" else "SHORT" if bias == "نزولی" else "WAIT"
    )
    passed = True
    reasons: list[str] = []
    if wanted == "LONG":
        if htf < ENTRY_LADDER_MIN_HTF_SCORE:
            passed = False
            reasons.append(f"HTF_weak_{htf:.0f}")
        if mtf < ENTRY_LADDER_MIN_MTF_SCORE:
            passed = False
            reasons.append(f"MTF_weak_{mtf:.0f}")
        if htf_side == "SHORT" or mtf_side == "SHORT":
            passed = False
            reasons.append("HTF/MTF_against_long")
        # LTF should not be strongly opposite
        if ltf <= 40:
            passed = False
            reasons.append(f"LTF_against_{ltf:.0f}")
    elif wanted == "SHORT":
        if htf > (100 - ENTRY_LADDER_MIN_HTF_SCORE):
            passed = False
            reasons.append(f"HTF_weak_short_{htf:.0f}")
        if mtf > (100 - ENTRY_LADDER_MIN_MTF_SCORE):
            passed = False
            reasons.append(f"MTF_weak_short_{mtf:.0f}")
        if htf_side == "LONG" or mtf_side == "LONG":
            passed = False
            reasons.append("HTF/MTF_against_short")
        if ltf >= 60:
            passed = False
            reasons.append(f"LTF_against_{ltf:.0f}")
    else:
        reasons.append("no_directional_want")

    strength = float(clamp(
        (abs(htf - 50) * 0.4 + abs(mtf - 50) * 0.4 + abs(ltf - 50) * 0.2),
        0, 50,
    ))
    return {
        "passed": passed if wanted in {"LONG", "SHORT"} else True,
        "wanted": wanted,
        "htf_score": round(htf, 1),
        "mtf_score": round(mtf, 1),
        "ltf_score": round(ltf, 1),
        "htf_side": htf_side,
        "mtf_side": mtf_side,
        "ltf_side": ltf_side,
        "strength": round(strength, 1),
        "reasons": reasons,
        "tf_results": tf_results,
    }


def forecast_path_accuracy_stats(symbol: str = "") -> dict[str, Any]:
    """Recent directional accuracy of 12-candle path from tracked outcomes."""
    try:
        with _FORECAST_TRACK_LOCK:
            data = _load_forecast_track()
        rows = data.get("events") or []
        if symbol:
            rows = [r for r in rows if r.get("symbol") == symbol]
        rows = rows[-200:]
        if len(rows) < 5:
            return {"samples": len(rows), "dir_acc": 0.5, "weight_scale": 0.35, "mae_pct": None}
        hits = sum(1 for r in rows if r.get("dir_hit"))
        acc = hits / max(1, len(rows))
        # Weight scale: only trust path when accuracy clearly above coin-flip
        if len(rows) < 12:
            scale = 0.40
        elif acc >= 0.58:
            scale = min(1.15, 0.7 + (acc - 0.5) * 2.0)
        elif acc >= 0.52:
            scale = 0.55
        else:
            scale = 0.20
        maes = [safe_float(r.get("mae_pct"), 0) for r in rows if r.get("mae_pct") is not None]
        return {
            "samples": len(rows),
            "dir_acc": round(acc, 3),
            "weight_scale": round(scale, 3),
            "mae_pct": round(float(sum(maes) / len(maes)), 3) if maes else None,
        }
    except Exception as exc:
        LOGGER.debug("forecast track stats: %s", exc)
        return {"samples": 0, "dir_acc": 0.5, "weight_scale": 0.35, "mae_pct": None}


def record_forecast_path_outcome(
    symbol: str,
    predicted_bias: str,
    predicted_move_pct: float,
    actual_move_pct: float,
) -> None:
    """Append path accuracy event for self-weighting of forecast layer."""
    try:
        pred_sign = 1 if predicted_bias == "صعودی" else -1 if predicted_bias == "نزولی" else 0
        act_sign = 1 if actual_move_pct > 0.05 else -1 if actual_move_pct < -0.05 else 0
        dir_hit = bool(pred_sign and act_sign and pred_sign == act_sign)
        mae = abs(predicted_move_pct - actual_move_pct)
        with _FORECAST_TRACK_LOCK:
            data = _load_forecast_track()
            ev = data.setdefault("events", [])
            ev.append({
                "ts": time.time(),
                "symbol": symbol,
                "predicted_bias": predicted_bias,
                "pred_move_pct": round(predicted_move_pct, 4),
                "actual_move_pct": round(actual_move_pct, 4),
                "dir_hit": dir_hit,
                "mae_pct": round(mae, 4),
                "version": TITAN_PARAM_VERSION,
            })
            data["events"] = ev[-500:]
            _save_forecast_track(data)
    except Exception as exc:
        LOGGER.debug("record forecast path: %s", exc)


def calibrate_success_probability_v8(
    symbol: str = "",
    direction: str = "",
    raw_prob: float = 50.0,
    regime: str = "",
) -> dict[str, Any]:
    """Regime- and side-aware calibration with honest sample caps."""
    base = calibrate_success_probability(symbol=symbol, direction=direction, raw_prob=raw_prob)
    n = int(base.get("samples") or 0)
    cal = safe_float(base.get("calibrated"), raw_prob)
    # Conservative certainty caps by sample size
    if n < 8:
        cap = CALIB_CAP_LOW_N
        method = "prior_capped"
    elif n < CALIB_MIN_SAMPLES_FULL:
        cap = CALIB_CAP_MID_N
        method = str(base.get("method") or "mid_n") + "+cap"
    else:
        cap = CALIB_CAP_HIGH_N
        method = str(base.get("method") or "full")
    # Mild regime shrink when high-vol (harder to be sure)
    reg = str(regime or "").lower()
    if "high_vol" in reg or "high_volatility" in reg:
        cal = 50.0 + (cal - 50.0) * 0.85
        cap = min(cap, 70.0)
    cal = float(clamp(cal, 5.0, cap))
    base["calibrated"] = round(cal, 1)
    base["cap"] = cap
    base["method"] = method
    base["regime"] = regime or "unknown"
    base["direction"] = direction
    base["param_version"] = TITAN_PARAM_VERSION
    base["honest_label"] = (
        f"کالیبره {cal:.0f}% · n={n} · سقف {cap:.0f}% · {method}"
    )
    return base


def portfolio_side_pressure(decision_tag: str, symbol: str) -> dict[str, Any]:
    """Limit clustered same-side alt signals (correlation risk proxy)."""
    if decision_tag not in {"LONG", "SHORT"}:
        return {"ok": True, "same_side": 0, "penalty": 0.0, "reason": ""}
    now = time.time()
    with _PORTFOLIO_SIGNAL_LOCK:
        global _RECENT_DIRECTIONAL_SIGNALS
        _RECENT_DIRECTIONAL_SIGNALS = [
            s for s in _RECENT_DIRECTIONAL_SIGNALS
            if now - safe_float(s.get("ts"), 0) < 3600 and s.get("symbol") != symbol
        ]
        same = [s for s in _RECENT_DIRECTIONAL_SIGNALS if s.get("side") == decision_tag]
        count = len(same)
        penalty = 0.0
        ok = True
        reason = ""
        if count >= MAX_PORTFOLIO_SAME_SIDE:
            ok = False
            penalty = 15.0
            reason = f"سبد اشباع {decision_tag}: {count}+ سیگنال هم‌جهت در ۱ ساعت"
        elif count >= MAX_PORTFOLIO_SAME_SIDE - 1:
            penalty = 8.0
            reason = f"فشار سبد {decision_tag}: {count} سیگنال هم‌جهت"
        return {"ok": ok, "same_side": count, "penalty": penalty, "reason": reason}


def register_portfolio_signal(symbol: str, decision_tag: str) -> None:
    if decision_tag not in {"LONG", "SHORT"}:
        return
    with _PORTFOLIO_SIGNAL_LOCK:
        _RECENT_DIRECTIONAL_SIGNALS.append({
            "symbol": symbol, "side": decision_tag, "ts": time.time(), "v": TITAN_PARAM_VERSION,
        })
        if len(_RECENT_DIRECTIONAL_SIGNALS) > 80:
            del _RECENT_DIRECTIONAL_SIGNALS[:-60]


def extract_structured_ai_vote(text: str) -> dict[str, Any]:
    """Parse free-text or JSON-ish AI reply into side + confidence."""
    t = str(text or "").strip()
    if not t:
        return {"side": "WAIT", "confidence": 0, "raw": ""}
    # Try JSON fragment
    try:
        if "{" in t and "}" in t:
            frag = t[t.find("{"): t.rfind("}") + 1]
            obj = json.loads(frag)
            side = str(obj.get("side") or obj.get("decision") or obj.get("bias") or "WAIT").upper()
            if side in {"صعودی", "LONG", "BUY"}:
                side = "LONG"
            elif side in {"نزولی", "SHORT", "SELL"}:
                side = "SHORT"
            else:
                side = "WAIT"
            conf = safe_float(obj.get("confidence", obj.get("prob", 50)), 50)
            return {"side": side, "confidence": float(clamp(conf, 0, 100)), "raw": t[:200]}
    except Exception:
        pass
    low = t.lower()
    # Prefer an explicit final decision over incidental words such as
    # "کاهش ریسک" or "رشد هزینه" that are not a market-direction vote.
    final_markers = (
        ("نتیجه نهایی", "fa"), ("final result", "en"),
        ("decision", "en"), ("تصمیم", "fa"),
    )
    final_chunk = ""
    for marker, _ in final_markers:
        pos = low.rfind(marker.lower()) if marker.isascii() else t.rfind(marker)
        if pos >= 0:
            final_chunk = t[pos:pos + 140]
            break
    final_low = final_chunk.lower()
    if final_chunk:
        if any(k in final_low or k in final_chunk for k in ("نزولی", "فروش", "short", "sell")):
            side = "SHORT"
        elif any(k in final_low or k in final_chunk for k in ("صعودی", "خرید", "long", "buy")):
            side = "LONG"
        elif any(k in final_low or k in final_chunk for k in ("انتظار", "wait", "خنثی", "neutral", "no trade")):
            side = "WAIT"
        else:
            side = "WAIT"
    else:
        # Fallback lexical parser. Keep phrases with explicit direction rather
        # than generic words like "کاهش" which frequently describe risk/volatility.
        short_keys = ("short", "sell", "نزولی", "فروش", "ریزش", "نزول")
        long_keys = ("long", "buy", "صعودی", "خرید", "رشد", "صعود")
        wait_keys = ("wait", "خنثی", "انتظار", "no trade", "حاشیه‌نشین")
        side = "WAIT"
        if any(k in low or k in t for k in short_keys):
            side = "SHORT"
        elif any(k in low or k in t for k in long_keys):
            side = "LONG"
        if any(k in low or k in t for k in wait_keys) and side != "WAIT":
            if t.count("انتظار") + low.count("wait") >= 1 and ("اما" in t or "but" in low):
                side = "WAIT"
    conf = 55.0
    for token in ("90", "85", "80", "75", "70", "65", "60"):
        if token in t:
            conf = float(token)
            break
    if side == "WAIT":
        conf = min(conf, 50)
    return {"side": side, "confidence": conf, "raw": t[:200]}


def meta_label_v8(
    *,
    confluence_score: float,
    precision_score: float,
    alignment: float,
    success_prob: float,
    ai_conflict: bool,
    stretch_atr: float,
    ladder_passed: bool,
    data_quality: float,
    hist_wr: float,
) -> dict[str, Any]:
    """Second-stage accept/reject: only ACCEPT enables high-conviction tags."""
    score = (
        0.22 * safe_float(confluence_score, 50)
        + 0.20 * safe_float(precision_score, 50)
        + 0.15 * safe_float(alignment, 50)
        + 0.18 * safe_float(success_prob, 50)
        + 0.12 * safe_float(data_quality, 50)
        + 0.08 * safe_float(hist_wr, 50)
        + 0.05 * (70 if ladder_passed else 30)
    )
    if ai_conflict:
        score -= 5
    if stretch_atr > 3.4:
        score -= min(12.0, (stretch_atr - 3.4) * 4)
    score = float(clamp(score, 0, 100))
    if score >= 62 and data_quality >= (MIN_DATA_QUALITY_SCORE - 4) and not ai_conflict:
        label = "ACCEPT"
    elif score < 42 or data_quality < 42:
        label = "REJECT"
    else:
        label = "WATCH"
    return {
        "label": label,
        "probability": round(score, 1),
        "param_version": TITAN_PARAM_VERSION,
        "gates": {
            "ladder": ladder_passed,
            "dq": data_quality >= MIN_DATA_QUALITY_SCORE,
            "ai_conflict": ai_conflict,
        },
    }



def smart_format(value: Any) -> str:
    try:
        number = float(value)
        if not math.isfinite(number):
            return "N/A"
    except (TypeError, ValueError):
        return "N/A"
    if abs(number) >= 100:
        return f"{number:,.2f}"
    if abs(number) >= 1:
        return f"{number:,.4f}"
    if abs(number) >= 0.0001:
        return f"{number:,.6f}"
    return f"{number:.8f}"


def _normalize_symbol(symbol: str) -> str:
    value = str(symbol or "").upper().replace("-", "/").replace(" ", "")
    if not value:
        return ""
    if "/" not in value:
        value += "/USDT"
    return value


def _normalize_symbol_for_binance(symbol: str) -> str:
    value = str(symbol or "").upper().replace("/", "").replace("-", "")
    if value.endswith("USDT"):
        return value
    if value.endswith("USD"):
        return value[:-3] + "USDT"
    return value + "USDT"


def _binance_symbol(symbol: str) -> str:
    return _normalize_symbol(symbol).replace("/", "")


def tf_to_ms(tf: str) -> int:
    units = {"m": 60_000, "h": 3_600_000, "d": 86_400_000}
    if not tf or tf[-1] not in units:
        raise ValueError(f"Invalid timeframe: {tf}")
    n = int(tf[:-1])
    if n <= 0:
        raise ValueError(f"Invalid timeframe: {tf}")
    return n * units[tf[-1]]

# ============================================================
# JSON / SQLITE
# ============================================================


def _load_json(path: Path, default: Any) -> Any:
    with JSON_LOCK:
        try:
            path = _safe_app_path(path)
            if not path.is_file():
                return default
            text = path.read_text(encoding="utf-8")
            if not text.strip():
                return default
            return json.loads(text)
        except (OSError, json.JSONDecodeError, RuntimeError) as exc:
            LOGGER.warning("JSON read failed %s: %s", path, exc)
            return default


def _save_json(path: Path, data: Any) -> bool:
    with JSON_LOCK:
        try:
            path = _safe_app_path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(data, ensure_ascii=False, indent=2, default=str)
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(payload, encoding="utf-8")
            tmp.replace(path)
            return True
        except (OSError, TypeError, ValueError, RuntimeError) as exc:
            LOGGER.error("JSON write failed %s: %s", path, exc)
            return False


def db_conn() -> sqlite3.Connection:
    con = sqlite3.connect(str(DB_PATH), timeout=60, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=10000")
    return con


def init_db() -> None:
    with DB_LOCK, db_conn() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS forecasts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
            created_at REAL NOT NULL, direction TEXT NOT NULL, score REAL NOT NULL,
            alignment REAL NOT NULL DEFAULT 0, price REAL NOT NULL, sl REAL, tp1 REAL, tp2 REAL,
            horizon_minutes INTEGER NOT NULL, outcome TEXT DEFAULT 'PENDING', evaluated_at REAL,
            hit_type TEXT, source TEXT DEFAULT 'quant', ai_majority TEXT DEFAULT '',
            ai_agreement REAL DEFAULT 0, fused_score REAL DEFAULT 0, success_prob REAL DEFAULT 0,
            predicted_move_pct REAL DEFAULT 0)""")
        for _col, _typ in (
            ("ai_majority", "TEXT DEFAULT ''"),
            ("ai_agreement", "REAL DEFAULT 0"),
            ("fused_score", "REAL DEFAULT 0"),
            ("success_prob", "REAL DEFAULT 0"),
            ("predicted_move_pct", "REAL DEFAULT 0"),
        ):
            try:
                con.execute(f"ALTER TABLE forecasts ADD COLUMN {_col} {_typ}")
            except Exception:
                pass
        con.execute("CREATE INDEX IF NOT EXISTS idx_forecasts_pending ON forecasts(outcome, created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS paper_trades(
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
            created_at REAL NOT NULL, decision TEXT NOT NULL, entry REAL NOT NULL, sl REAL, tp1 REAL,
            tp2 REAL, quantity REAL DEFAULT 0, risk_pct REAL DEFAULT 0, status TEXT DEFAULT 'OPEN',
            exit_price REAL, pnl_pct REAL, r_multiple REAL, closed_at REAL, reason TEXT DEFAULT 'signal',
            success_prob REAL DEFAULT 0)""")
        try:
            con.execute("ALTER TABLE paper_trades ADD COLUMN success_prob REAL DEFAULT 0")
        except Exception:
            pass
        con.execute("CREATE INDEX IF NOT EXISTS idx_paper_open ON paper_trades(status, created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS data_quality(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT, source TEXT,
            latency_ms REAL, candles_ok INTEGER, volume_ok INTEGER, funding_ok INTEGER, oi_ok INTEGER,
            macro_ok INTEGER, overall_ok INTEGER, details TEXT)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_quality_time ON data_quality(created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS ai_votes(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL,
            provider TEXT NOT NULL, direction TEXT, titan_direction TEXT, aligned INTEGER, latency_ms REAL)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_ai_votes_symbol ON ai_votes(symbol, created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS alerts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, severity TEXT,
            symbol TEXT, category TEXT, message TEXT, acknowledged INTEGER DEFAULT 0)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_alerts_time ON alerts(created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS performance_snapshots(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            created_at REAL NOT NULL,
            trades INTEGER DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            win_rate REAL DEFAULT 0,
            expectancy REAL DEFAULT 0,
            profit_factor REAL,
            max_drawdown REAL DEFAULT 0,
            sharpe REAL DEFAULT 0,
            sortino REAL DEFAULT 0,
            oos_status TEXT DEFAULT '',
            metrics_json TEXT DEFAULT ''
        )""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_perf_snap ON performance_snapshots(symbol,timeframe,created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS setup_stats(
            setup_key TEXT PRIMARY KEY, trades INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0, pnl_r REAL DEFAULT 0, updated_at REAL DEFAULT 0)""")

init_db()


def load_settings() -> None:
    global USER_SETTINGS
    data = _load_json(USER_SETTINGS_PATH, {})
    if not isinstance(data, dict):
        return
    risk = clamp(safe_float(data.get("risk_multiplier"), 1.2), 0.2, 5.0)
    normalized: list[str] = []
    for coin in data.get("active_coins", []) if isinstance(data.get("active_coins"), list) else []:
        symbol = _normalize_symbol(coin)
        if symbol and symbol not in normalized:
            normalized.append(symbol)
    USER_SETTINGS = {"risk_multiplier": risk, "active_coins": normalized or DEFAULT_COINS.copy()}


def save_settings() -> bool:
    return _save_json(USER_SETTINGS_PATH, USER_SETTINGS)

load_settings()

# ============================================================
# HTTP / MARKET DATA
# ============================================================


def _request_json(method: str, url: str, **kwargs) -> Optional[Any]:
    try:
        response = _http_session().request(method, url, **kwargs)
        if not response.ok:
            LOGGER.warning("HTTP %s %s -> %s", method, url, response.status_code)
            return None
        payload = response.json()
        # Binance and other APIs can legitimately return either an object or a
        # list. Keep the transport layer lossless and let callers validate shape.
        return payload
    except (requests.RequestException, ValueError) as exc:
        LOGGER.warning("HTTP request failed %s: %s", url, exc)
        return None


def _fetch_live_prices(symbols: list[str]) -> dict[str, float]:
    """Fetch all requested Binance spot prices in one batch call.

    The old implementation made one HTTP request per symbol every polling cycle.
    That created avoidable latency/rate-limit pressure and could leave cards on
    different timestamps.  Batch ticker data gives one coherent market snapshot.
    """
    requested = {_normalize_symbol(s): _normalize_symbol_for_binance(s) for s in symbols if s}
    if not requested:
        return {}
    wanted_pairs = set(requested.values())
    hosts = LIVE_PRICE_URLS if "LIVE_PRICE_URLS" in globals() else [LIVE_PRICE_URL]
    last_error = None
    for url in hosts:
        try:
            response = _http_session().get(url, timeout=5)
            if not response.ok:
                last_error = RuntimeError(f"HTTP {response.status_code} from {url}")
                continue
            payload = response.json()
            if not isinstance(payload, list):
                last_error = RuntimeError("Invalid Binance ticker payload")
                continue
            by_pair = {}
            for row in payload:
                if not isinstance(row, dict):
                    continue
                pair = str(row.get("symbol") or "").upper()
                if pair not in wanted_pairs:
                    continue
                px = safe_float(row.get("price"), 0.0)
                if px > 0:
                    by_pair[pair] = px
            result = {}
            for sym, pair in requested.items():
                px = by_pair.get(pair)
                if px is not None and px > 0:
                    result[sym] = px
            if result:
                return result
        except Exception as exc:
            last_error = exc
            LOGGER.debug("Batch live price unavailable via %s: %s", url, exc)
    if last_error:
        LOGGER.debug("All batch live price hosts failed: %s", last_error)
    return {}


def fetch_klines(symbol: str, tf: str, limit: int = 150, start_ms: Optional[int] = None, end_ms: Optional[int] = None) -> pd.DataFrame:
    """Fetch closed OHLCV with short TTL memory cache + fast numeric path.

    Cache key includes symbol/tf/limit/range so historical backtests stay uncached
    when start/end are set; live dashboard hits are almost free within TTL.
    """
    limit = min(max(int(limit), 1), 1000)
    cacheable = start_ms is None and end_ms is None
    ckey = _kline_cache_key(symbol, tf, limit, start_ms, end_ms) if cacheable else ""
    if cacheable:
        hit = _kline_cache_get(ckey)
        if hit is not None and len(hit) >= 10:
            return hit

    params: dict[str, Any] = {"symbol": _binance_symbol(symbol), "interval": tf, "limit": limit}
    if start_ms is not None:
        params["startTime"] = int(start_ms)
    if end_ms is not None:
        params["endTime"] = int(end_ms)
    raw = None
    last_err = None
    # Prefer data-api first; shorter timeout on failover hosts for snappy mobile UX
    hosts = KLINES_URLS if "KLINES_URLS" in globals() else ["https://data-api.binance.vision/api/v3/klines"]
    for i, kurl in enumerate(hosts):
        try:
            to = 5 if i == 0 else 3
            response = _http_session().get(kurl, params=params, timeout=to)
            if not response.ok:
                last_err = RuntimeError(f"HTTP {response.status_code} from {kurl}")
                continue
            raw = response.json()
            break
        except Exception as exc:
            last_err = exc
            LOGGER.debug("klines fail %s: %s", kurl, exc)
    if raw is None:
        raise RuntimeError(f"All kline hosts failed: {last_err}")
    if not isinstance(raw, list) or not raw:
        raise RuntimeError("Invalid Binance kline response")

    # Fast path: build from list-of-lists without per-column to_numeric loops
    # Columns: 0=t 1=o 2=h 3=l 4=c 5=v 6=T
    try:
        arr = np.asarray(raw, dtype=object)
        t = arr[:, 0].astype(np.float64)
        o = arr[:, 1].astype(np.float64)
        h = arr[:, 2].astype(np.float64)
        l = arr[:, 3].astype(np.float64)
        c = arr[:, 4].astype(np.float64)
        v = arr[:, 5].astype(np.float64)
        T = arr[:, 6].astype(np.float64)
        now_ms = time.time() * 1000.0
        mask = (T < now_ms) & np.isfinite(o) & np.isfinite(h) & np.isfinite(l) & np.isfinite(c) & np.isfinite(v)
        t, o, h, l, c, v, T = t[mask], o[mask], h[mask], l[mask], c[mask], v[mask], T[mask]
        # sort + dedupe by t (keep last)
        order = np.argsort(t, kind="mergesort")
        t, o, h, l, c, v, T = t[order], o[order], h[order], l[order], c[order], v[order], T[order]
        if len(t) > 1:
            uniq = np.empty(len(t), dtype=bool)
            uniq[:-1] = t[:-1] != t[1:]
            uniq[-1] = True
            # keep last of each duplicate group: reverse mark
            rev = np.empty(len(t), dtype=bool)
            rev[0] = True
            rev[1:] = t[1:] != t[:-1]
            # actually keep last: mark where next differs or last
            keep = np.ones(len(t), dtype=bool)
            keep[:-1] = t[:-1] != t[1:]
            t, o, h, l, c, v, T = t[keep], o[keep], h[keep], l[keep], c[keep], v[keep], T[keep]
        df = pd.DataFrame({"t": t, "open": o, "high": h, "low": l, "close": c, "vol": v, "T": T})
    except Exception:
        columns = ["t", "open", "high", "low", "close", "vol", "T", "qav", "n", "tbb", "tbq", "ign"]
        df = pd.DataFrame(raw, columns=columns)
        for col in ["open", "high", "low", "close", "vol", "t", "T"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.dropna(subset=["t", "open", "high", "low", "close", "vol"])
        now_ms = int(time.time() * 1000)
        df = df[df["T"] < now_ms].sort_values("t").drop_duplicates(subset=["t"], keep="last").reset_index(drop=True)

    if len(df) < 10:
        raise RuntimeError(f"Insufficient closed candles for {symbol} {tf}")
    if cacheable:
        _kline_cache_put(ckey, df)
    return df


def _binance_futures_funding(symbol: str) -> Optional[float]:
    try:
        r = _http_session().get(
            "https://fapi.binance.com/fapi/v1/premiumIndex",
            params={"symbol": _binance_symbol(symbol)}, timeout=8,
        )
        if not r.ok:
            return None
        payload = r.json()
        if not isinstance(payload, dict):
            return None
        return safe_float(payload.get("lastFundingRate")) * 100
    except Exception:
        return None


def _binance_futures_oi(symbol: str) -> Optional[float]:
    try:
        r = _http_session().get(
            "https://fapi.binance.com/fapi/v1/openInterest",
            params={"symbol": _binance_symbol(symbol)}, timeout=8,
        )
        if not r.ok:
            return None
        payload = r.json()
        if not isinstance(payload, dict):
            return None
        value = safe_float(payload.get("openInterest"))
        return value if value > 0 else None
    except Exception:
        return None


def fetch_derivatives(symbol: str) -> dict[str, Any]:
    # Short TTL cache — funding/OI rarely need sub-20s refresh during one scan
    _sym_key = _normalize_symbol(symbol)
    with KLINE_CACHE_LOCK:
        _hit = DERIV_CACHE.get(_sym_key)
        if _hit and (time.time() - _hit[0]) < DERIV_CACHE_TTL:
            return _hit[1]
    clean = _binance_symbol(symbol)
    base = clean.replace("USDT", "")
    raw_oi = 0.0
    oi_kind = "unknown"
    funding: Optional[float] = None
    cg_usd = cg_qty = cg_delta = None
    source_parts: list[str] = []

    if COINGLASS_API_KEY:
        headers = {"CG-API-KEY": COINGLASS_API_KEY}
        try:
            res = _http_session().get(
                "https://open-api-v4.coinglass.com/api/futures/open-interest/exchange-list",
                params={"symbol": base}, headers=headers, timeout=10,
            ).json()
            if str(res.get("code")) in {"0", "200"}:
                rows = res.get("data") or []
                row = next((r for r in rows if str(r.get("exchange", "")).lower() == "all"), rows[0] if rows else None)
                if row:
                    cg_qty = safe_float(row.get("open_interest_quantity"), 0)
                    cg_usd = safe_float(row.get("open_interest_usd"), 0)
                    cg_delta = safe_float(row.get("open_interest_change_percent_5m"), 0)
                    if cg_usd and cg_usd > 0:
                        raw_oi, oi_kind = cg_usd, "usd"
                    elif cg_qty and cg_qty > 0:
                        raw_oi, oi_kind = cg_qty, "base"
                    if raw_oi > 0:
                        source_parts.append("CoinGlass-OI")
        except Exception as exc:
            LOGGER.warning("CoinGlass OI failed for %s: %s", symbol, exc)
        try:
            res = _http_session().get(
                "https://open-api-v4.coinglass.com/api/futures/funding-rate/exchange-list",
                params={"symbol": base}, headers=headers, timeout=10,
            ).json()
            if str(res.get("code")) in {"0", "200"}:
                rows = res.get("data") or []
                row = next((r for r in rows if str(r.get("symbol", "")).upper() == base), rows[0] if rows else None)
                if row:
                    vals = [safe_float(x.get("funding_rate"), np.nan) for x in (row.get("stablecoin_margin_list") or [])]
                    vals = [x for x in vals if np.isfinite(x)]
                    if vals:
                        funding = float(np.mean(vals)) * 100
                        source_parts.append("CoinGlass-Funding")
        except Exception as exc:
            LOGGER.warning("CoinGlass funding failed for %s: %s", symbol, exc)

    if funding is None:
        funding = _binance_futures_funding(symbol)
        if funding is not None:
            source_parts.append("Binance-Funding")
    if raw_oi <= 0:
        fallback_oi = _binance_futures_oi(symbol)
        if fallback_oi is not None:
            raw_oi, oi_kind = fallback_oi, "base"
            source_parts.append("Binance-OI")

    now = time.time()
    delta = cg_delta if cg_delta is not None else 0.0
    with OI_LOCK:
        previous = OI_HISTORY.get(symbol)
        if cg_delta is None and previous and previous[2] == oi_kind:
            prev_oi, prev_ts, _ = previous
            if prev_oi > 0 and raw_oi > 0 and now - prev_ts <= 900:
                delta = ((raw_oi - prev_oi) / prev_oi) * 100
        if raw_oi > 0:
            OI_HISTORY[symbol] = (raw_oi, now, oi_kind)

    if cg_usd and cg_usd > 0:
        oi_disp = f"${smart_format(cg_usd)}"
    elif cg_qty and cg_qty > 0:
        oi_disp = f"{smart_format(cg_qty)} {base}"
    elif raw_oi > 0:
        oi_disp = f"{smart_format(raw_oi)} {base}"
    else:
        oi_disp = "N/A"
    ls = fetch_binance_long_short_ratio(symbol)
    taker = fetch_binance_taker_buy_sell(symbol)
    if ls.get("source") and ls.get("source") != "N/A":
        source_parts.append(str(ls.get("source")))
    if taker.get("source") and taker.get("source") != "N/A":
        source_parts.append(str(taker.get("source")))
    out = {
        "oi": oi_disp,
        "raw_oi": raw_oi,
        "oi_delta": delta,
        "funding_value": funding,
        "funding": f"{funding:+.4f}%" if funding is not None else "N/A",
        "source": " + ".join(dict.fromkeys(source_parts)) if source_parts else "N/A",
        "long_short": ls,
        "taker": taker,
        "long_ratio": ls.get("long_ratio"),
        "short_ratio": ls.get("short_ratio"),
        "long_short_ratio": ls.get("long_short_ratio"),
        "top_long_ratio": ls.get("top_long_ratio"),
        "taker_buy_pct": taker.get("buy_pct", 50),
        "taker_sell_pct": taker.get("sell_pct", 50),
    }
    with KLINE_CACHE_LOCK:
        DERIV_CACHE[_normalize_symbol(symbol)] = (time.time(), out)
        if len(DERIV_CACHE) > 80:
            for k, _ in sorted(DERIV_CACHE.items(), key=lambda x: x[1][0])[:20]:
                DERIV_CACHE.pop(k, None)
    return out


def fetch_btc_trend() -> str:
    try:
        df = fetch_klines("BTC/USDT", "1h", 60)
        ema = df["close"].ewm(span=20, adjust=False).mean().iloc[-1]
        return "صعودی" if float(df["close"].iloc[-1]) >= float(ema) else "نزولی"
    except Exception as exc:
        LOGGER.warning("BTC trend failed: %s", exc)
        return "خنثی"


def fetch_macro() -> dict[str, Any]:
    fear_value = "N/A"
    fear_text = "داده نیست"
    dominance = "N/A"
    sources: list[str] = []
    try:
        payload = _http_session().get("https://api.alternative.me/fng/", params={"limit": 1}, timeout=8).json()
        data = payload.get("data") or []
        if data:
            fear_value = data[0].get("value", "N/A")
            fear_text = data[0].get("value_classification", "N/A")
            sources.append("Alternative.me")
    except Exception as exc:
        LOGGER.warning("Fear & Greed failed: %s", exc)
    try:
        payload = _http_session().get("https://api.coingecko.com/api/v3/global", timeout=8).json()
        btc_dom = safe_float((payload.get("data") or {}).get("market_cap_percentage", {}).get("btc"), np.nan)
        if np.isfinite(btc_dom):
            dominance = f"{btc_dom:.2f}%"
            sources.append("CoinGecko")
    except Exception as exc:
        LOGGER.warning("CoinGecko macro failed: %s", exc)
    return {"fear_greed_val": fear_value, "fear_greed_text": fear_text, "global_status": " / ".join(sources) or "N/A", "dominance_btc": dominance}

# ============================================================
# TECHNICALS / DECISION CORE
# ============================================================




# === TITAN V6.2 PROFESSIONAL MODULES ===
# 1) Platt + Isotonic calibration from paper trades
# 2) BTC correlation filter for alts in high-vol
# 3) Order-Block / Fair Value Gap (FVG)
# 4) Depth WebSocket for default liquid symbols only

DEPTH_WATCHLIST = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"]
DEPTH_STATE: dict[str, dict[str, Any]] = {}
DEPTH_LOCK = threading.RLock()
BTC_RETURNS_CACHE: dict[str, Any] = {"ts": 0.0, "rets": None}

# Short-TTL cache for per-symbol BTC correlation (avoids repeated kline fetches)
BTC_CORR_CACHE: dict[str, tuple[float, dict]] = {}
BTC_CORR_CACHE_TTL = 90.0




def _pava_isotonic(xs: list[float], ys: list[float], ws: Optional[list[float]] = None) -> list[float]:
    """Pool-Adjacent-Violators for non-decreasing calibration curve."""
    n = len(ys)
    if n == 0:
        return []
    w = ws if ws and len(ws) == n else [1.0] * n
    y = list(ys)
    weight = [float(x) for x in w]
    i = 0
    while i < n - 1:
        if y[i] <= y[i + 1] + 1e-12:
            i += 1
            continue
        # merge i and i+1
        total_w = weight[i] + weight[i + 1]
        avg = (y[i] * weight[i] + y[i + 1] * weight[i + 1]) / max(total_w, 1e-12)
        y[i] = avg
        weight[i] = total_w
        del y[i + 1]
        del weight[i + 1]
        n -= 1
        if i > 0:
            i -= 1
    # expand back — simple: rebuild from unique pools by re-running with block sizes
    # For sparse bins we already merged; return monotone ys of same length as input via projection
    # Rebuild properly:
    y0 = list(ys)
    w0 = [float(x) for x in (ws if ws and len(ws) == len(ys) else [1.0] * len(ys))]
    blocks = [[i] for i in range(len(y0))]
    vals = [y0[i] for i in range(len(y0))]
    weights = [w0[i] for i in range(len(y0))]
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(vals) - 1:
            if vals[i] > vals[i + 1] + 1e-12:
                new_w = weights[i] + weights[i + 1]
                new_v = (vals[i] * weights[i] + vals[i + 1] * weights[i + 1]) / max(new_w, 1e-12)
                vals[i] = new_v
                weights[i] = new_w
                blocks[i] = blocks[i] + blocks[i + 1]
                del vals[i + 1]
                del weights[i + 1]
                del blocks[i + 1]
                changed = True
                if i > 0:
                    i -= 1
            else:
                i += 1
    out = [0.0] * len(y0)
    for b, v in zip(blocks, vals):
        for idx in b:
            out[idx] = v
    return out


def _platt_scale(raw_probs: list[float], labels: list[float], x_query: float) -> Optional[float]:
    """Fit simple Platt logistic P = 1/(1+exp(A*f+B)) via Newton on 2 params; return calibrated for x_query in [0,1]."""
    try:
        import math as _m
        n = len(raw_probs)
        if n < 12:
            return None
        # features as logit of raw
        f = []
        for p in raw_probs:
            p = clamp(p, 1e-4, 1 - 1e-4)
            f.append(_m.log(p / (1 - p)))
        y = labels
        A, B = 0.0, 0.0
        for _ in range(40):
            gA = gB = 0.0
            hAA = hAB = hBB = 0.0
            for fi, yi in zip(f, y):
                z = A * fi + B
                # stable sigmoid
                if z >= 0:
                    ez = _m.exp(-z)
                    p = 1.0 / (1.0 + ez)
                else:
                    ez = _m.exp(z)
                    p = ez / (1.0 + ez)
                diff = p - yi
                gA += diff * fi
                gB += diff
                w = p * (1 - p)
                hAA += w * fi * fi
                hAB += w * fi
                hBB += w
            # damped Newton
            det = hAA * hBB - hAB * hAB
            if abs(det) < 1e-12:
                break
            dA = (hBB * gA - hAB * gB) / det
            dB = (hAA * gB - hAB * gA) / det
            A -= 0.7 * dA
            B -= 0.7 * dB
            if abs(dA) + abs(dB) < 1e-6:
                break
        xq = clamp(x_query, 1e-4, 1 - 1e-4)
        fq = _m.log(xq / (1 - xq))
        z = A * fq + B
        if z >= 0:
            ez = _m.exp(-z)
            return 1.0 / (1.0 + ez)
        ez = _m.exp(z)
        return ez / (1.0 + ez)
    except Exception:
        return None


def calibrate_success_probability(
    symbol: str = "",
    direction: str = "",
    raw_prob: float = 50.0,
) -> dict[str, Any]:
    """Platt + Isotonic calibration using forecasts AND closed paper trades.

    Returns calibrated probability in 0-100 scale with diagnostics.
    """
    raw = float(clamp(raw_prob, 1.0, 99.0))
    pairs: list[tuple[float, float]] = []
    sources_used: list[str] = []
    try:
        where = ["outcome IN ('WIN','LOSS')", "success_prob > 0"]
        args: list[Any] = []
        if symbol:
            where.append("symbol=?")
            args.append(symbol)
        if direction in {"صعودی", "نزولی", "LONG", "SHORT"}:
            # map
            dmap = {"LONG": "صعودی", "SHORT": "نزولی"}
            dval = dmap.get(direction, direction)
            where.append("direction=?")
            args.append(dval)
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                "SELECT success_prob, outcome FROM forecasts WHERE " + " AND ".join(where)
                + " ORDER BY evaluated_at DESC, id DESC LIMIT 800",
                args,
            ).fetchall()
            for r in rows:
                pp = safe_float(r[0], 50) / 100.0
                yy = 1.0 if str(r[1]).upper() == "WIN" else 0.0
                if math.isfinite(pp):
                    pairs.append((clamp(pp, 0, 1), yy))
            if pairs:
                sources_used.append("forecasts")
            # Paper trades with stored entry probability contribute honest samples.
            paper_where = ["status='CLOSED'", "success_prob > 0", "pnl_pct IS NOT NULL"]
            paper_args: list[Any] = []
            if symbol:
                paper_where.append("symbol=?")
                paper_args.append(symbol)
            if direction in {"صعودی", "نزولی", "LONG", "SHORT"}:
                dmap = {"LONG": "صعودی", "SHORT": "نزولی"}
                dval = dmap.get(direction, direction)
                paper_where.append("decision=?")
                paper_args.append(dval)
            prows = con.execute(
                "SELECT success_prob, pnl_pct FROM paper_trades WHERE "
                + " AND ".join(paper_where)
                + " ORDER BY closed_at DESC, id DESC LIMIT 400",
                paper_args,
            ).fetchall()
            paper_n = 0
            for r in prows:
                pp = safe_float(r[0], 0) / 100.0
                pnl = safe_float(r[1], 0)
                if not math.isfinite(pp) or pp <= 0:
                    continue
                yy = 1.0 if pnl > 0 else 0.0
                pairs.append((clamp(pp, 0, 1), yy))
                paper_n += 1
            if paper_n:
                sources_used.append("paper_trades")
    except Exception as exc:
        LOGGER.debug("calibration data load failed: %s", exc)

    if len(pairs) < 8:
        return {
            "raw": round(raw, 1),
            "calibrated": round(raw, 1),
            "samples": len(pairs),
            "method": "prior_only",
            "platt": None,
            "isotonic": None,
            "sources": sources_used,
        }

    probs = [p for p, _ in pairs]
    labels = [y for _, y in pairs]
    x = raw / 100.0

    # Platt
    platt_p = _platt_scale(probs, labels, x)

    # Isotonic on 10 bins
    bins = []
    for k in range(10):
        lo, hi = k / 10, (k + 1) / 10
        vals = [y for px, y in pairs if (lo <= px < hi) or (k == 9 and lo <= px <= hi)]
        if vals:
            rate = (sum(vals) + 2.0) / (len(vals) + 4.0)  # Beta(2,2)
            bins.append((lo + 0.05, rate, len(vals)))
    xs = [b[0] for b in bins]
    ys = [b[1] for b in bins]
    ws = [b[2] for b in bins]
    iso = _pava_isotonic(xs, ys, ws) if bins else []
    iso_p = None
    if bins and iso:
        if x <= xs[0]:
            iso_p = iso[0]
        elif x >= xs[-1]:
            iso_p = iso[-1]
        else:
            j = 0
            for i in range(len(xs) - 1):
                if xs[i] <= x <= xs[i + 1]:
                    j = i
                    break
            span = max(xs[j + 1] - xs[j], 1e-9)
            iso_p = iso[j] + (iso[j + 1] - iso[j]) * (x - xs[j]) / span

    # Blend: prefer isotonic when samples high; Platt for smooth mid-range
    n = len(pairs)
    if platt_p is not None and iso_p is not None:
        w_iso = min(0.65, n / 120.0)
        cal = (1 - w_iso) * platt_p + w_iso * iso_p
        method = "platt+isotonic"
    elif iso_p is not None:
        cal = iso_p
        method = "isotonic"
    elif platt_p is not None:
        cal = platt_p
        method = "platt"
    else:
        cal = x
        method = "raw"

    # Shrink toward raw when n small
    shrink = min(1.0, n / 80.0)
    cal = shrink * cal + (1 - shrink) * x
    # Conservative cap: never claim >88% from calibration alone
    cal = clamp(cal, 0.08, 0.88)

    # ECE / Brier rough
    brier = sum((p - y) ** 2 for p, y in pairs) / max(1, n)
    ece = 0.0
    if bins:
        for (_, rate, cnt), mid in zip(bins, xs):
            ece += (cnt / n) * abs(rate - mid)

    return {
        "raw": round(raw, 1),
        "calibrated": round(cal * 100.0, 1),
        "samples": n,
        "method": method,
        "platt": round(platt_p * 100, 1) if platt_p is not None else None,
        "isotonic": round(iso_p * 100, 1) if iso_p is not None else None,
        "ece": round(ece, 4),
        "brier": round(brier, 4),
        "sources": sources_used,
    }


def compute_btc_correlation(symbol: str, lookback: int = 48) -> dict[str, Any]:
    """Pearson correlation of recent 1h returns vs BTC — for high-vol alt filter."""
    try:
        if symbol in {"BTC/USDT", "BTCUSDT"}:
            return {"corr": 1.0, "samples": lookback, "regime": "self"}
        now = time.time()
        _ck = f"{_normalize_symbol(symbol)}|{lookback}"
        _hit = BTC_CORR_CACHE.get(_ck)
        if _hit and (now - _hit[0]) < BTC_CORR_CACHE_TTL:
            return _hit[1]
        global BTC_RETURNS_CACHE
        btc_rets = BTC_RETURNS_CACHE.get("rets")
        if btc_rets is None or now - float(BTC_RETURNS_CACHE.get("ts") or 0) > 180:
            btc_df = fetch_klines("BTC/USDT", "1h", lookback + 5)
            btc_rets = btc_df["close"].astype(float).pct_change().dropna().tail(lookback)
            BTC_RETURNS_CACHE = {"ts": now, "rets": btc_rets}
        alt_df = fetch_klines(symbol, "1h", lookback + 5)
        alt_rets = alt_df["close"].astype(float).pct_change().dropna().tail(lookback)
        n = min(len(btc_rets), len(alt_rets))
        if n < 12:
            return {"corr": 0.0, "samples": n, "regime": "insufficient"}
        a = alt_rets.tail(n).values
        b = btc_rets.tail(n).values
        if float(np.std(a)) < 1e-12 or float(np.std(b)) < 1e-12:
            return {"corr": 0.0, "samples": n, "regime": "flat"}
        corr = float(np.corrcoef(a, b)[0, 1])
        if not math.isfinite(corr):
            corr = 0.0
        _out = {"corr": round(corr, 3), "samples": n, "regime": "high_beta" if corr >= 0.75 else "decoupled" if corr < 0.35 else "normal"}
        BTC_CORR_CACHE[_ck] = (now, _out)
        if len(BTC_CORR_CACHE) > 60:
            for _k, _ in sorted(BTC_CORR_CACHE.items(), key=lambda x: x[1][0])[:15]:
                BTC_CORR_CACHE.pop(_k, None)
        return _out
    except Exception as exc:
        LOGGER.debug("btc corr failed %s: %s", symbol, exc)
        return {"corr": 0.0, "samples": 0, "regime": "error"}


def apply_btc_correlation_filter(
    symbol: str,
    decision_tag: str,
    bias: str,
    atr_pct: float,
    btc_trend: str,
    corr_info: Optional[dict] = None,
) -> tuple[str, str, dict[str, Any]]:
    """In high-vol regimes, block alt longs when BTC is bearish & correlation is high (and vice versa)."""
    info = corr_info or compute_btc_correlation(symbol)
    note = {
        "corr": info.get("corr"),
        "corr_regime": info.get("regime"),
        "filter_applied": False,
        "reason": "",
    }
    if symbol in {"BTC/USDT", "BTCUSDT"}:
        return decision_tag, bias, note
    corr = safe_float(info.get("corr"), 0)
    high_vol = atr_pct >= 3.5
    # Only act in high volatility or very high beta
    if not high_vol and corr < 0.8:
        return decision_tag, bias, note
    if corr < 0.55:
        note["reason"] = "همبستگی پایین با BTC — فیلتر غیرفعال"
        return decision_tag, bias, note

    if decision_tag == "LONG" and btc_trend == "نزولی" and corr >= 0.65:
        note["filter_applied"] = True
        note["reason"] = f"آلت لانگ در رژیم پرنوسان با همبستگی BTC={corr:.2f} و روند نزولی BTC مسدود شد"
        return "WAIT", "خنثی", note
    if decision_tag == "SHORT" and btc_trend == "صعودی" and corr >= 0.65:
        note["filter_applied"] = True
        note["reason"] = f"آلت شورت در رژیم پرنوسان با همبستگی BTC={corr:.2f} و روند صعودی BTC مسدود شد"
        return "WAIT", "خنثی", note
    note["reason"] = "فیلتر همبستگی BTC عبور کرد"
    return decision_tag, bias, note


def detect_order_blocks_fvg(df: pd.DataFrame, lookback: int = 40) -> dict[str, Any]:
    """Simple Order-Block and Fair Value Gap detection on closed candles.

    Bullish OB: last down candle before strong impulsive up move.
    Bearish OB: last up candle before strong impulsive down move.
    FVG: 3-candle gap where candle[i-2].high < candle[i].low (bull) or reverse (bear).
    """
    try:
        if df is None or len(df) < 15:
            return {"order_blocks": [], "fvgs": [], "nearest_ob": None, "nearest_fvg": None}
        d = df.tail(lookback).reset_index(drop=True)
        o = d["open"].astype(float)
        h = d["high"].astype(float)
        l = d["low"].astype(float)
        c = d["close"].astype(float)
        atr_s = (h - l).rolling(14).mean().bfill()
        obs: list[dict[str, Any]] = []
        fvgs: list[dict[str, Any]] = []
        price = float(c.iloc[-1])

        for i in range(3, len(d) - 1):
            body = abs(float(c.iloc[i]) - float(o.iloc[i]))
            atr_i = float(atr_s.iloc[i]) or price * 0.01
            move = float(c.iloc[i]) - float(c.iloc[i - 1])
            # Bullish FVG: gap up between candle i-2 high and candle i low
            if float(h.iloc[i - 2]) < float(l.iloc[i]):
                gap_lo, gap_hi = float(h.iloc[i - 2]), float(l.iloc[i])
                if gap_hi - gap_lo > 0.15 * atr_i:
                    fvgs.append({
                        "type": "bullish_fvg",
                        "low": round(gap_lo, 8),
                        "high": round(gap_hi, 8),
                        "mid": round((gap_lo + gap_hi) / 2, 8),
                        "index": i,
                        "guide": "گپ صعودی پرنشده — اغلب به‌عنوان حمایت پویا عمل می‌کند؛ پر شدن گپ می‌تواند ادامه یا برگشت باشد.",
                    })
            # Bearish FVG
            if float(l.iloc[i - 2]) > float(h.iloc[i]):
                gap_hi, gap_lo = float(l.iloc[i - 2]), float(h.iloc[i])
                if gap_hi - gap_lo > 0.15 * atr_i:
                    fvgs.append({
                        "type": "bearish_fvg",
                        "low": round(gap_lo, 8),
                        "high": round(gap_hi, 8),
                        "mid": round((gap_lo + gap_hi) / 2, 8),
                        "index": i,
                        "guide": "گپ نزولی پرنشده — اغلب به‌عنوان مقاومت پویا؛ پر شدن گپ نشانه فشار خرید یا ادامه نزول است.",
                    })

            # Order block: impulse after opposite candle
            if move > 1.2 * atr_i and float(c.iloc[i - 1]) < float(o.iloc[i - 1]):
                # bullish OB = prior bearish candle
                obs.append({
                    "type": "bullish_ob",
                    "low": round(float(l.iloc[i - 1]), 8),
                    "high": round(float(h.iloc[i - 1]), 8),
                    "mid": round((float(l.iloc[i - 1]) + float(h.iloc[i - 1])) / 2, 8),
                    "index": i - 1,
                    "guide": "بلاک سفارش صعودی: آخرین کندل نزولی قبل از حرکت قوی بالا. بازگشت قیمت به این ناحیه می‌تواند تقاضا را فعال کند.",
                })
            if move < -1.2 * atr_i and float(c.iloc[i - 1]) > float(o.iloc[i - 1]):
                obs.append({
                    "type": "bearish_ob",
                    "low": round(float(l.iloc[i - 1]), 8),
                    "high": round(float(h.iloc[i - 1]), 8),
                    "mid": round((float(l.iloc[i - 1]) + float(h.iloc[i - 1])) / 2, 8),
                    "index": i - 1,
                    "guide": "بلاک سفارش نزولی: آخرین کندل صعودی قبل از حرکت قوی پایین. بازگشت به این ناحیه می‌تواند عرضه را فعال کند.",
                })

        # Keep nearest to price
        def _dist(zone):
            return abs(price - safe_float(zone.get("mid"), price))

        obs = sorted(obs, key=_dist)[:4]
        fvgs = sorted(fvgs, key=_dist)[:4]
        nearest_ob = obs[0] if obs else None
        nearest_fvg = fvgs[0] if fvgs else None
        return {
            "order_blocks": obs,
            "fvgs": fvgs,
            "nearest_ob": nearest_ob,
            "nearest_fvg": nearest_fvg,
            "price": round(price, 8),
        }
    except Exception as exc:
        LOGGER.debug("OB/FVG failed: %s", exc)
        return {"order_blocks": [], "fvgs": [], "nearest_ob": None, "nearest_fvg": None}


def get_depth_snapshot(symbol: str) -> dict[str, Any]:
    """Read cached partial book depth for watchlist symbols."""
    pair = _binance_symbol(symbol)
    with DEPTH_LOCK:
        row = DEPTH_STATE.get(pair) or DEPTH_STATE.get(symbol) or {}
    if not row:
        return {"available": False, "symbol": pair}
    age = time.time() - safe_float(row.get("ts"), 0)
    return {
        "available": age < 30,
        "symbol": pair,
        "bid": row.get("bid"),
        "ask": row.get("ask"),
        "spread_bps": row.get("spread_bps"),
        "bid_vol": row.get("bid_vol"),
        "ask_vol": row.get("ask_vol"),
        "imbalance": row.get("imbalance"),
        "age_sec": round(age, 1),
        "source": row.get("source", "depth"),
    }


def _depth_websocket_worker() -> None:
    """Lightweight partial book depth for a few liquid symbols only (mobile-friendly)."""
    if _websocket_client is None:
        return
    streams = "/".join(f"{s.lower()}@depth5@1000ms" for s in DEPTH_WATCHLIST)
    url = f"wss://data-stream.binance.vision/stream?streams={streams}"
    while not LIVE_STOP.is_set():
        try:
            ws = _websocket_client.create_connection(url, timeout=15)
            ws.settimeout(25)
            LOGGER.info("Depth WebSocket connected for %s", DEPTH_WATCHLIST)
            while not LIVE_STOP.is_set():
                raw = ws.recv()
                if not raw:
                    break
                try:
                    msg = json.loads(raw)
                    data = msg.get("data") or msg
                    bids = data.get("bids") or data.get("b") or []
                    asks = data.get("asks") or data.get("a") or []
                    stream = str(msg.get("stream") or "")
                    sym = stream.split("@")[0].upper() if "@" in stream else ""
                    if not sym and data.get("s"):
                        sym = str(data["s"]).upper()
                    if not bids or not asks or not sym:
                        continue
                    best_bid = safe_float(bids[0][0])
                    best_ask = safe_float(asks[0][0])
                    bid_vol = sum(safe_float(x[1]) for x in bids[:5])
                    ask_vol = sum(safe_float(x[1]) for x in asks[:5])
                    mid = (best_bid + best_ask) / 2 if best_bid and best_ask else 0
                    spread_bps = ((best_ask - best_bid) / mid * 10000) if mid else 0
                    imb = (bid_vol - ask_vol) / max(bid_vol + ask_vol, 1e-12)
                    with DEPTH_LOCK:
                        DEPTH_STATE[sym] = {
                            "bid": best_bid,
                            "ask": best_ask,
                            "bid_vol": round(bid_vol, 4),
                            "ask_vol": round(ask_vol, 4),
                            "spread_bps": round(spread_bps, 2),
                            "imbalance": round(imb, 4),
                            "ts": time.time(),
                            "source": "DepthWS",
                        }
                except Exception:
                    continue
            try:
                ws.close()
            except Exception:
                pass
        except Exception as exc:
            LOGGER.info("Depth WS unavailable (REST only): %s", exc)
            LIVE_STOP.wait(8)



def wilder_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = gain / loss.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).replace([np.inf, -np.inf], np.nan).fillna(50.0)


def calc_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    previous_close = df["close"].shift(1)
    tr = pd.concat([(df["high"] - df["low"]), (df["high"] - previous_close).abs(), (df["low"] - previous_close).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean().bfill()


def calc_vwap(df: pd.DataFrame) -> float:
    if df.empty:
        return float("nan")
    timestamps = pd.to_datetime(df["t"], unit="ms", utc=True)
    latest_day = timestamps.iloc[-1].date()
    session_df = df[timestamps.dt.date == latest_day]
    if session_df.empty:
        session_df = df
    typical = (session_df["high"] + session_df["low"] + session_df["close"]) / 3.0
    volume_sum = float(session_df["vol"].sum())
    return float((typical * session_df["vol"]).sum() / volume_sum) if volume_sum > 0 else float(session_df["close"].iloc[-1])


def _tf_forecast(df: pd.DataFrame, fast: int = 20, slow: int = 50) -> tuple[str, float, dict[str, float]]:
    """Multi-factor TF score: EMA structure + momentum + RSI + ADX + volume + MACD + candle pressure.

    Symmetric for LONG/SHORT. Higher ADX amplifies directional conviction; low ADX shrinks
    extremes toward neutral so sideways markets do not fake strong signals.
    """
    if df is None or len(df) < slow + 5:
        return "خنثی", 50.0, {"rsi": 50.0, "momentum": 0.0, "ema_gap": 0.0, "adx": 0.0, "vol_z": 0.0}
    close = df["close"].astype(float)
    high = df["high"].astype(float)
    low = df["low"].astype(float)
    vol = df["vol"].astype(float) if "vol" in df.columns else pd.Series([1.0] * len(df))
    fast_ema = close.ewm(span=fast, adjust=False).mean()
    slow_ema = close.ewm(span=slow, adjust=False).mean()
    rsi_value = float(wilder_rsi(close).iloc[-1])
    lookback = min(8, len(close) - 1)
    momentum = (float(close.iloc[-1]) / float(close.iloc[-1 - lookback]) - 1) * 100
    ema_gap = (float(fast_ema.iloc[-1]) / float(slow_ema.iloc[-1]) - 1) * 100

    # ADX (trend strength) — soft gate
    adx_val = 20.0
    try:
        if "_adx_series" in globals():
            adx_s = _adx_series(df, 14)
            adx_val = float(adx_s.iloc[-1]) if adx_s is not None and len(adx_s) else 20.0
        else:
            # lightweight ATR-based trend proxy
            tr = pd.concat([(high - low), (high - close.shift(1)).abs(), (low - close.shift(1)).abs()], axis=1).max(axis=1)
            atr14 = tr.ewm(alpha=1/14, adjust=False).mean()
            up = high.diff().clip(lower=0)
            dn = (-low.diff()).clip(lower=0)
            plus_dm = up.where(up > dn, 0.0)
            minus_dm = dn.where(dn > up, 0.0)
            plus_di = 100 * plus_dm.ewm(alpha=1/14, adjust=False).mean() / atr14.replace(0, np.nan)
            minus_di = 100 * minus_dm.ewm(alpha=1/14, adjust=False).mean() / atr14.replace(0, np.nan)
            dx = (100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)).fillna(20)
            adx_val = float(dx.ewm(alpha=1/14, adjust=False).mean().iloc[-1])
    except Exception:
        adx_val = 20.0
    adx_val = float(clamp(adx_val if math.isfinite(adx_val) else 20.0, 0, 60))

    # Volume z-score (last vs 20-bar mean)
    vol_z = 0.0
    try:
        v_mean = float(vol.tail(21).iloc[:-1].mean()) or 1.0
        v_std = float(vol.tail(21).iloc[:-1].std()) or 1.0
        vol_z = (float(vol.iloc[-1]) - v_mean) / max(v_std, 1e-9)
        vol_z = float(np.clip(vol_z, -3.0, 3.0))
    except Exception:
        vol_z = 0.0

    # MACD hist tilt
    macd_tilt = 0.0
    try:
        m = calc_macd(close)
        hist = safe_float(m.get("hist"), 0)
        last_px = float(close.iloc[-1]) or 1.0
        macd_tilt = float(np.clip(hist / max(last_px * 0.002, 1e-12), -1.5, 1.5))
        if m.get("cross") == "bull":
            macd_tilt += 0.35
        elif m.get("cross") == "bear":
            macd_tilt -= 0.35
    except Exception:
        pass

    # Candle body pressure (last 3)
    pressure = 0.0
    try:
        for i in range(-3, 0):
            o, c = float(df["open"].iloc[i]), float(close.iloc[i])
            rng = max(float(high.iloc[i]) - float(low.iloc[i]), 1e-12)
            pressure += ((c - o) / rng) * (0.5 if i == -3 else 0.75 if i == -2 else 1.0)
        pressure = float(np.clip(pressure / 2.25, -1.0, 1.0))
    except Exception:
        pressure = 0.0

    score = 50.0
    # Structure (EMA) — primary directional spine
    score += 14.0 if float(close.iloc[-1]) > float(fast_ema.iloc[-1]) else -14.0
    score += 12.0 if float(fast_ema.iloc[-1]) > float(slow_ema.iloc[-1]) else -12.0
    # Momentum
    score += float(np.clip(momentum * 3.2, -12.0, 12.0))
    # RSI mean-reversion mild + trend confirmation
    if rsi_value < 28:
        score += 4.0
    elif rsi_value < 38:
        score += 1.5
    elif rsi_value > 72:
        score -= 4.0
    elif rsi_value > 62:
        score -= 1.5
    # EMA gap magnitude
    score += float(np.clip(ema_gap * 1.1, -5.5, 5.5))
    # MACD + candle pressure
    score += macd_tilt * 4.5
    score += pressure * 5.0
    # Volume confirms move direction
    if abs(momentum) > 0.15:
        score += float(np.clip(vol_z * (1.0 if momentum > 0 else -1.0) * 2.2, -5.0, 5.0))

    # ADX scaling: low ADX compresses toward 50; high ADX preserves extremes
    adx_scale = float(clamp(0.55 + (adx_val / 40.0) * 0.55, 0.55, 1.15))
    score = 50.0 + (score - 50.0) * adx_scale
    score = float(clamp(score, 0, 100))

    direction = "صعودی" if score >= 54 else "نزولی" if score <= 46 else "خنثی"
    return direction, score, {
        "rsi": round(rsi_value, 2),
        "momentum": round(momentum, 4),
        "ema_gap": round(ema_gap, 4),
        "adx": round(adx_val, 2),
        "vol_z": round(vol_z, 3),
        "macd_tilt": round(macd_tilt, 3),
        "pressure": round(pressure, 3),
        "adx_scale": round(adx_scale, 3),
    }


def _funding_bias(funding: Optional[float]) -> tuple[float, str]:
    if funding is None:
        return 0.0, "فاقد داده"
    if funding >= 0.08:
        return -7.0, "ازدحام لانگ / ریسک بازگشت"
    if funding >= 0.03:
        return -3.0, "فشار لانگ متوسط"
    if funding <= -0.08:
        return 7.0, "ازدحام شورت / ریسک پوشش شورت"
    if funding <= -0.03:
        return 3.0, "فشار شورت متوسط"
    return 0.0, "خنثی"


def _oi_bias(oi_delta: float, price_change: float) -> tuple[float, str]:
    if not math.isfinite(oi_delta):
        return 0.0, "فاقد داده"
    if price_change > 0 and oi_delta > 1.0:
        return 4.0, "افزایش قیمت + افزایش OI"
    if price_change < 0 and oi_delta > 1.0:
        return -4.0, "کاهش قیمت + افزایش OI"
    if price_change > 0 and oi_delta < -1.0:
        return 2.0, "افزایش قیمت + کاهش OI"
    if price_change < 0 and oi_delta < -1.0:
        return -2.0, "کاهش قیمت + کاهش OI"
    return 0.0, "OI بدون تأیید قوی"



def _adx_series(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Wilder-style ADX without external dependencies."""
    if df is None or df.empty or len(df) < period + 3:
        return pd.Series(dtype=float)
    high, low, close = df["high"].astype(float), df["low"].astype(float), df["close"].astype(float)
    up = high.diff(); down = -low.diff()
    plus_dm = up.where((up > down) & (up > 0), 0.0)
    minus_dm = down.where((down > up) & (down > 0), 0.0)
    tr = pd.concat([(high-low), (high-close.shift()).abs(), (low-close.shift()).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1/period, adjust=False, min_periods=period).mean()
    pdi = 100 * plus_dm.ewm(alpha=1/period, adjust=False, min_periods=period).mean() / atr.replace(0, np.nan)
    mdi = 100 * minus_dm.ewm(alpha=1/period, adjust=False, min_periods=period).mean() / atr.replace(0, np.nan)
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1/period, adjust=False, min_periods=period).mean().fillna(0.0)


def _rolling_trend_stability(close: pd.Series, lookback: int = 20) -> tuple[float, float]:
    """Return (signed stability, consistency) from closed-candle returns.

    Stability is the average sign agreement of returns, scaled by direction.
    Consistency is the fraction of returns agreeing with the dominant direction.
    """
    r = pd.to_numeric(close, errors="coerce").pct_change().dropna().tail(lookback)
    if len(r) < max(8, lookback // 2):
        return 0.0, 0.0
    pos = float((r > 0).mean()); neg = float((r < 0).mean())
    consistency = max(pos, neg)
    signed = (pos - neg) * consistency
    return float(clamp(signed, -1.0, 1.0)), float(clamp(consistency, 0.0, 1.0))


def _candle_pressure(df: pd.DataFrame, lookback: int = 12) -> dict[str, float]:
    """Measure body dominance and directional close location, not raw volume prediction."""
    if df is None or df.empty:
        return {"pressure": 0.0, "body_quality": 0.0, "close_location": 0.5}
    x = df.tail(lookback).copy()
    rng = (x["high"] - x["low"]).replace(0, np.nan)
    body = (x["close"] - x["open"]).abs() / rng
    loc = (x["close"] - x["low"]) / rng
    signed_body = np.sign(x["close"] - x["open"]) * body.fillna(0)
    weights = np.linspace(0.5, 1.0, len(x))
    pressure = float(np.average(signed_body.fillna(0), weights=weights)) if len(x) else 0.0
    return {
        "pressure": round(clamp(pressure, -1.0, 1.0), 4),
        "body_quality": round(clamp(float(body.fillna(0).mean()), 0.0, 1.0), 4),
        "close_location": round(clamp(float(loc.fillna(0.5).tail(3).mean()), 0.0, 1.0), 4),
    }


def _precision_engine_snapshot(
    df15: pd.DataFrame,
    df1h: pd.DataFrame,
    price: float,
    atr: float,
    rsi: float,
    vwap: float,
    ema20: float,
    ema50: float,
    direction: str,
    volume_spike: bool,
    structure: dict[str, Any],
    regime: dict[str, Any],
    derivatives: dict[str, Any],
) -> dict[str, Any]:
    """Precision gate: entry timing, trend stability, stretch and market-quality filters.

    This is deliberately a gate/diagnostic, not a promise of predictive accuracy.
    """
    try:
        adx_s = _adx_series(df1h)
        adx = float(adx_s.iloc[-1]) if not adx_s.empty else 0.0
        signed_stability, consistency = _rolling_trend_stability(df1h["close"], 20)
        cp = _candle_pressure(df15, 12)
        atr_safe = max(float(atr), price * 0.0001, 1e-12)
        stretch_vwap = abs(price - vwap) / atr_safe if vwap > 0 else 0.0
        stretch_ema = abs(price - ema20) / atr_safe if ema20 > 0 else 0.0
        trend_up = ema20 > ema50
        trend_dir = 1 if trend_up else -1
        wanted = 1 if direction in {"صعودی", "LONG", "LONG/BUY"} else -1 if direction in {"نزولی", "SHORT", "SHORT/SELL"} else 0
        trend_alignment = trend_dir * wanted if wanted else 0
        structure_score = safe_float((structure or {}).get("confirmation_score"), 50)
        regime_name = str((regime or {}).get("regime", "unknown")).lower()
        trend_regime = any(k in regime_name for k in ("trend", "bull", "bear"))
        oi_delta = safe_float((derivatives or {}).get("oi_delta"), 0)
        funding = safe_float((derivatives or {}).get("funding"), 0)

        # ADX: low trend strength is a common source of false breakout-style entries.
        adx_score = clamp((adx - 12.0) / 28.0 * 100.0, 0, 100)
        stability_score = clamp(consistency * 100.0, 0, 100)
        direction_consistency = clamp((0.5 + 0.5 * signed_stability * wanted) * 100.0, 0, 100) if wanted else 50
        stretch_penalty = 0.0
        if stretch_vwap > 2.8: stretch_penalty += min(25.0, (stretch_vwap - 2.8) * 9.0)
        if stretch_ema > 3.2: stretch_penalty += min(20.0, (stretch_ema - 3.2) * 7.0)
        rsi_penalty = 0.0
        if wanted > 0 and rsi > 74: rsi_penalty = min(18.0, (rsi - 74) * 1.8)
        if wanted < 0 and rsi < 26: rsi_penalty = min(18.0, (26 - rsi) * 1.8)
        body_score = cp["body_quality"] * 100.0
        candle_direction = cp["pressure"] * wanted
        candle_score = clamp(50.0 + candle_direction * 45.0 + (body_score - 50.0) * 0.25, 0, 100)
        derivative_alignment = 50.0
        if wanted:
            # OI confirmation is supportive only when it points with price direction; funding is a softer input.
            if wanted > 0 and oi_delta > 0: derivative_alignment += min(18.0, oi_delta * 2.0)
            if wanted < 0 and oi_delta < 0: derivative_alignment += min(18.0, abs(oi_delta) * 2.0)
            if wanted > 0 and funding < -0.0002: derivative_alignment += 5.0
            if wanted < 0 and funding > 0.0002: derivative_alignment += 5.0
        derivative_alignment = clamp(derivative_alignment, 0, 100)

        precision = (
            0.24 * adx_score
            + 0.22 * stability_score
            + 0.18 * direction_consistency
            + 0.14 * candle_score
            + 0.12 * clamp(structure_score, 0, 100)
            + 0.10 * derivative_alignment
        ) - stretch_penalty - rsi_penalty
        if trend_alignment < 0:
            precision -= 12.0
        if not trend_regime and adx < 16:
            precision -= 8.0
        precision = float(clamp(precision, 0, 100))

        hard_blocks = []
        if price <= 0 or atr <= 0: hard_blocks.append("invalid_price_or_atr")
        if adx < 11 and consistency < 0.58: hard_blocks.append("low_trend_strength")
        if stretch_vwap > 4.0 or stretch_ema > 4.5: hard_blocks.append("overextended_entry")
        if wanted and direction_consistency < 34: hard_blocks.append("directional_instability")
        return {
            "score": round(precision, 1), "adx": round(adx, 2),
            "trend_stability": round(signed_stability, 4), "consistency": round(consistency, 4),
            "direction_consistency": round(direction_consistency, 1),
            "stretch_vwap_atr": round(stretch_vwap, 2), "stretch_ema_atr": round(stretch_ema, 2),
            "candle_pressure": cp["pressure"], "body_quality": cp["body_quality"],
            "candle_score": round(candle_score, 1), "derivative_alignment": round(derivative_alignment, 1),
            "trend_alignment": trend_alignment, "hard_blocks": hard_blocks,
            "entry_timing": "GOOD" if precision >= 72 and not hard_blocks else "WAIT" if precision < 56 or hard_blocks else "CAUTIOUS",
        }
    except Exception as exc:
        LOGGER.debug("precision engine failed: %s", exc)
        return {"score": 50.0, "entry_timing": "CAUTIOUS", "hard_blocks": [], "error": str(exc)}


def _friction_adjusted_rr(entry: float, sl: float, tp: float) -> float:
    risk = abs(entry - sl)
    reward = abs(tp - entry)
    friction = max(entry * TOTAL_ENTRY_BUFFER, 1e-12)
    return float(reward / max(risk + friction, 1e-12))



# ============================================================
# TITAN V9 — NEURAL SYNAPSE (central nervous system)
# Connects: TF scores · structure · regime · confluence · precision ·
# patterns · forecast path · derivatives · AI ensemble · DQ · ladder ·
# calibration · portfolio. Produces one coherent decision + confidence.
# Analysis-only. Never invents edge — only fuses existing evidence.
# ============================================================

class TitanNeuralSynapseV9:
    """Advanced multi-layer fusion with explainable weighted synapses."""

    # Layer weights (sum ≈ 1.0) — tuned for reliability over aggressiveness
    W = {
        # V28 tuned: stronger TF spine + precision + calibration for reliable edges
        "tf_spine": 0.20,       # multi-TF weighted score
        "structure": 0.11,      # market structure HH/HL
        "regime": 0.08,         # trend/vol regime
        "confluence": 0.11,     # multi-factor confluence
        "precision": 0.12,      # entry timing / ADX / stretch
        "pattern": 0.06,        # chart patterns
        "forecast": 0.07,       # probabilistic path (self-weighted)
        "derivatives": 0.08,    # funding / OI / L-S / taker
        "ai": 0.09,             # AI ensemble
        "calibration": 0.08,    # historical success calibration
    }

    def _side_from_score(self, sc: float) -> str:
        # Tuned V28: 54/46 — fewer missed edges than 56/44, still avoids noise
        if sc >= 54:
            return "LONG"
        if sc <= 46:
            return "SHORT"
        return "WAIT"

    def _tf_vector(self, tf_scores: dict) -> tuple[float, str, float]:
        if not tf_scores:
            return 50.0, "WAIT", 0.0
        weights = {"15m": 0.18, "1h": 0.30, "4h": 0.28, "1d": 0.24}  # V28 balanced actionable
        keys = [k for k in weights if k in tf_scores]
        if not keys:
            vals = list(tf_scores.values())
            avg = float(sum(vals) / len(vals))
            return avg, self._side_from_score(avg), abs(avg - 50.0)
        wsum = sum(weights[k] for k in keys)
        avg = sum(safe_float(tf_scores[k], 50) * weights[k] for k in keys) / max(wsum, 1e-9)
        # agreement among TFs
        sides = [self._side_from_score(safe_float(tf_scores[k], 50)) for k in keys]
        maj = max(set(sides), key=sides.count)
        agree = sides.count(maj) / len(sides)
        return float(avg), maj, float(agree * abs(avg - 50.0))

    def _pattern_signal(self, patterns: dict) -> tuple[float, str]:
        primary = (patterns or {}).get("primary") or {}
        if not primary:
            return 50.0, "WAIT"
        bias = str((primary.get("guide") or {}).get("bias", "خنثی"))
        conf = safe_float(primary.get("confidence"), 50) / 100.0
        if bias == "صعودی":
            return 50.0 + 18.0 * conf, "LONG"
        if bias == "نزولی":
            return 50.0 - 18.0 * conf, "SHORT"
        return 50.0, "WAIT"

    def _forecast_signal(self, forecast: dict, path_stats: dict) -> tuple[float, str]:
        if not forecast or not forecast.get("ok"):
            return 50.0, "WAIT"
        overall = str(forecast.get("overall_bias", "خنثی"))
        move = safe_float(forecast.get("expected_move_pct"), 0)
        strength = safe_float(forecast.get("path_strength"), 0)
        scale = safe_float((path_stats or {}).get("weight_scale"), 0.35)
        # damp by historical path accuracy
        tilt = float(np.clip(move * 2.5 + strength * 0.15, -18, 18)) * scale
        sc = 50.0 + tilt
        side = "LONG" if overall == "صعودی" and sc >= 53 else "SHORT" if overall == "نزولی" and sc <= 47 else "WAIT"
        return float(clamp(sc, 5, 95)), side

    def _deriv_signal(self, derivatives: dict, wanted_hint: int = 0) -> tuple[float, str]:
        sc = 50.0
        funding = derivatives.get("funding_value")
        oi_d = safe_float(derivatives.get("oi_delta"), 0)
        ls_ratio = safe_float(derivatives.get("long_short_ratio"), 1.0)
        taker_buy = safe_float(derivatives.get("taker_buy_pct"), 50)
        if funding is not None:
            f = safe_float(funding, 0)
            # extreme funding is contrarian
            if f >= 0.06:
                sc -= 6
            elif f <= -0.06:
                sc += 6
            elif f >= 0.025:
                sc -= 2.5
            elif f <= -0.025:
                sc += 2.5
        if oi_d > 1.5:
            sc += 3.0 if wanted_hint >= 0 else -3.0
        elif oi_d < -1.5:
            sc -= 2.0 if wanted_hint >= 0 else 2.0
        # crowding
        if ls_ratio >= 1.6:
            sc -= 5  # long crowded → short bias
        elif ls_ratio <= 0.65:
            sc += 5
        # taker flow
        sc += float(np.clip((taker_buy - 50) * 0.12, -5, 5))
        sc = float(clamp(sc, 10, 90))
        return sc, self._side_from_score(sc)

    def _ai_signal(self, fusion: dict, ai_opinions: dict) -> tuple[float, str, float]:
        maj = str((fusion or {}).get("ai_majority") or "WAIT")
        agree = safe_float((fusion or {}).get("ai_agreement"), 0)
        if maj not in {"LONG", "SHORT", "WAIT"}:
            # parse from opinions if needed
            votes = []
            for key in ("gemini", "openai", "grok", "claude", "deepseek", "internal"):
                text = str((ai_opinions or {}).get(key) or "")
                if not text:
                    continue
                v = extract_structured_ai_vote(text)
                votes.append(v.get("side", "WAIT"))
            if votes:
                maj = max(set(votes), key=votes.count)
                agree = votes.count(maj) / len(votes) * 100.0
        if maj == "LONG":
            sc = 50.0 + min(28.0, agree * 0.28)
        elif maj == "SHORT":
            sc = 50.0 - min(28.0, agree * 0.28)
        else:
            sc = 50.0
        return float(clamp(sc, 15, 85)), maj if maj in {"LONG", "SHORT", "WAIT"} else "WAIT", float(agree)

    def fuse(self, *, tf_scores: dict, structure: dict, regime: dict, confluence: dict,
             precision: dict, patterns: dict, forecast: dict, path_stats: dict,
             derivatives: dict, fusion: dict, ai_opinions: dict,
             data_quality: dict, ladder: dict, calib: dict,
             quant_bias: str, quant_score: float) -> dict:
        """Full neural fuse → side, confidence, layer map, vetoes."""
        layers: dict[str, Any] = {}
        reasons: list[str] = []
        vetoes: list[str] = []

        tf_sc, tf_side, tf_agree_mag = self._tf_vector(tf_scores or {})
        layers["tf_spine"] = {"score": round(tf_sc, 1), "side": tf_side, "weight": self.W["tf_spine"]}

        struct_bias = str((structure or {}).get("bias", "خنثی"))
        struct_conf = safe_float((structure or {}).get("confirmation_score"), 50)
        if struct_bias == "صعودی":
            st_sc = 50 + min(22, struct_conf * 0.25)
            st_side = "LONG"
        elif struct_bias == "نزولی":
            st_sc = 50 - min(22, struct_conf * 0.25)
            st_side = "SHORT"
        else:
            st_sc, st_side = 50.0, "WAIT"
        layers["structure"] = {"score": round(st_sc, 1), "side": st_side, "weight": self.W["structure"]}

        reg_name = str((regime or {}).get("regime", "unknown")).lower()
        if "up" in reg_name or "bull" in reg_name:
            rg_sc, rg_side = 62.0, "LONG"
        elif "down" in reg_name or "bear" in reg_name:
            rg_sc, rg_side = 38.0, "SHORT"
        elif "high_vol" in reg_name:
            rg_sc, rg_side = 50.0, "WAIT"
            reasons.append("رژیم پرنوسان → کاهش اطمینان")
        else:
            rg_sc, rg_side = 50.0, "WAIT"
        layers["regime"] = {"score": rg_sc, "side": rg_side, "weight": self.W["regime"]}

        conf_sc = safe_float((confluence or {}).get("score"), 50)
        layers["confluence"] = {"score": conf_sc, "side": self._side_from_score(conf_sc), "weight": self.W["confluence"]}

        prec_sc = safe_float((precision or {}).get("score"), 50)
        layers["precision"] = {"score": prec_sc, "side": self._side_from_score(prec_sc), "weight": self.W["precision"]}
        for b in (precision or {}).get("hard_blocks") or []:
            vetoes.append(f"precision:{b}")

        p_sc, p_side = self._pattern_signal(patterns or {})
        layers["pattern"] = {"score": round(p_sc, 1), "side": p_side, "weight": self.W["pattern"]}

        f_sc, f_side = self._forecast_signal(forecast or {}, path_stats or {})
        layers["forecast"] = {"score": round(f_sc, 1), "side": f_side, "weight": self.W["forecast"]}

        wanted_hint = 1 if quant_bias == "صعودی" else -1 if quant_bias == "نزولی" else 0
        d_sc, d_side = self._deriv_signal(derivatives or {}, wanted_hint)
        layers["derivatives"] = {"score": round(d_sc, 1), "side": d_side, "weight": self.W["derivatives"]}

        a_sc, a_side, a_agree = self._ai_signal(fusion or {}, ai_opinions or {})
        layers["ai"] = {"score": round(a_sc, 1), "side": a_side, "weight": self.W["ai"], "agreement": a_agree}

        cal_sc = safe_float((calib or {}).get("calibrated"), safe_float((fusion or {}).get("success_probability"), 50))
        # map calibrated success (around 50-80) to directional lean via quant
        if quant_bias == "صعودی":
            c_sc = 40 + cal_sc * 0.35
        elif quant_bias == "نزولی":
            c_sc = 60 - cal_sc * 0.35
        else:
            c_sc = 50.0
        layers["calibration"] = {"score": round(c_sc, 1), "side": self._side_from_score(c_sc), "weight": self.W["calibration"]}

        # Weighted neural score
        neural_score = 0.0
        w_total = 0.0
        for name, layer in layers.items():
            w = float(layer.get("weight") or 0)
            neural_score += safe_float(layer.get("score"), 50) * w
            w_total += w
        neural_score = neural_score / max(w_total, 1e-9)

        # Blend with quant spine (prevents AI-only drift)
        quant_sc = safe_float(quant_score, 50)
        neural_score = 0.62 * neural_score + 0.38 * quant_sc
        neural_score = float(clamp(neural_score, 0, 100))

        # Side vote among layers (weighted)
        long_w = short_w = wait_w = 0.0
        for layer in layers.values():
            w = float(layer.get("weight") or 0)
            s = layer.get("side")
            if s == "LONG":
                long_w += w
            elif s == "SHORT":
                short_w += w
            else:
                wait_w += w
        if long_w > short_w and long_w >= wait_w * 0.45:
            side = "LONG"
        elif short_w > long_w and short_w >= wait_w * 0.45:
            side = "SHORT"
        elif long_w > short_w * 1.15 and neural_score >= 54:
            side = "LONG"
        elif short_w > long_w * 1.15 and neural_score <= 46:
            side = "SHORT"
        else:
            side = "WAIT"

        # Hard gates — only true hard_veto kills; soft DQ lowers confidence
        dq = data_quality or {}
        if dq.get("hard_veto"):
            side = "WAIT"
            vetoes.append("data_quality_veto")
            reasons.append("وتوی سخت کیفیت داده → انتظار")
        elif safe_float(dq.get("score"), 100) < MIN_DATA_QUALITY_SCORE:
            vetoes.append("data_quality_soft")
            reasons.append("کیفیت داده مرزی — جهت حفظ با کاهش اطمینان")

        ladder = ladder or {}
        if side in {"LONG", "SHORT"} and ladder and not ladder.get("passed", True):
            # Soft miss: keep direction if HTF not strongly against; only hard-WAIT on structural flip
            htf_s = safe_float(ladder.get("htf_score"), 50)
            structural = (
                (side == "LONG" and htf_s <= 38) or (side == "SHORT" and htf_s >= 62)
            )
            if structural:
                vetoes.append("entry_ladder")
                reasons.append("نردبان ورود HTF خلاف جهت قوی → انتظار")
                side = "WAIT"
            else:
                reasons.append("نردبان ورود ناقص — جهت حفظ شد با اطمینان کمتر")

        # Precision hard blocks
        if (precision or {}).get("hard_blocks") and side in {"LONG", "SHORT"}:
            if safe_float(prec_sc, 50) < 48:
                side = "WAIT"
                reasons.append("بلوک‌های سخت دقت ورود فعال")

        # AI hard conflict with weak quant
        if a_side in {"LONG", "SHORT"} and side in {"LONG", "SHORT"} and a_side != side and a_agree >= 88:
            if abs(neural_score - 50) < 12:
                side = "WAIT"
                reasons.append("تعارض قوی AI با سیگنال ضعیف → انتظار")
            else:
                reasons.append("تعارض AI لحاظ شد (جریمه اطمینان)")

        # Confidence from layer agreement + distance from 50 + calib
        side_agreement = max(long_w, short_w, wait_w) / max(long_w + short_w + wait_w, 1e-9)
        confidence = (
            0.35 * abs(neural_score - 50) * 2
            + 0.30 * side_agreement * 100
            + 0.20 * safe_float(dq.get("score"), 60)
            + 0.15 * cal_sc
        )
        if side == "WAIT":
            confidence = min(confidence, 55)
        if any("نردبان ورود ناقص" in str(r) for r in reasons):
            confidence = min(confidence, 78)
        confidence = float(clamp(confidence, 5, 92))

        bias = "صعودی" if side == "LONG" else "نزولی" if side == "SHORT" else "خنثی"

        # Human-readable synapse summary
        top_layers = sorted(layers.items(), key=lambda x: abs(safe_float(x[1].get("score"), 50) - 50), reverse=True)[:4]
        for name, layer in top_layers:
            reasons.append(f"{name}: {layer.get('side')} ({layer.get('score')})")

        return {
            "side": side,
            "bias": bias,
            "neural_score": round(neural_score, 1),
            "confidence": round(confidence, 1),
            "layers": layers,
            "long_weight": round(long_w, 3),
            "short_weight": round(short_w, 3),
            "wait_weight": round(wait_w, 3),
            "side_agreement": round(side_agreement, 3),
            "reasons": reasons[:8],
            "vetoes": vetoes,
            "param_version": TITAN_PARAM_VERSION,
        }



TITAN_NEURAL = TitanNeuralSynapseV9()


# ============================================================
# TITAN V10 — PROFESSIONAL SIGNAL GRADE + DOSSIER
# A+ … F classification with multi-gate checklist.
# Only A+/A appear as actionable high-trust signals.
# ============================================================

GRADE_RANK = {"A+": 6, "A": 5, "B": 4, "C": 3, "D": 2, "F": 1, "—": 0}

def classify_signal_grade(
    *,
    decision_tag: str,
    signal_quality: float,
    success_prob: float,
    alignment: float,
    neural: Optional[dict] = None,
    meta: Optional[dict] = None,
    ladder: Optional[dict] = None,
    data_quality: Optional[dict] = None,
    precision: Optional[dict] = None,
    effective_rr1: float = 0.0,
    ai_agreement: float = 0.0,
    pattern_conf: float = 0.0,
    forecast_aligned: bool = False,
) -> dict[str, Any]:
    """Professional institutional-style grade with checklist evidence.

    A+ : all hard gates pass, quality≥85, neural confirms, RR≥1.4, meta ACCEPT
    A  : hard gates pass, quality≥75, neural same side, meta not REJECT
    B  : directional but missing 1 soft edge (watchlist, not primary action)
    C  : weak directional lean — observation only
    D  : noise / conflict
    F  : hard veto or WAIT with poor data
    """
    neural = neural or {}
    meta = meta or {}
    ladder = ladder or {}
    data_quality = data_quality or {}
    precision = precision or {}

    checklist: list[dict[str, Any]] = []
    def _chk(name: str, ok: bool, detail: str = "") -> bool:
        checklist.append({"name": name, "ok": bool(ok), "detail": detail})
        return bool(ok)

    is_dir = decision_tag in {"LONG", "SHORT"}
    dq_sc = safe_float(data_quality.get("score"), 0)
    ladder_ok = bool(ladder.get("passed", False)) if is_dir else True
    meta_label = str(meta.get("label") or "")
    meta_ok = meta_label == "ACCEPT"
    meta_not_reject = meta_label != "REJECT"
    neural_side = str(neural.get("side") or "")
    neural_conf = safe_float(neural.get("confidence"), 0)
    neural_sc = safe_float(neural.get("neural_score"), 50)
    neural_same = (not neural) or (neural_side == decision_tag) or (not is_dir)
    prec_sc = safe_float(precision.get("score"), 50)
    hard_blocks = list(precision.get("hard_blocks") or [])
    dq_ok = dq_sc >= MIN_DATA_QUALITY_SCORE and not data_quality.get("hard_veto")
    rr_ok = effective_rr1 >= MIN_EFFECTIVE_RR if is_dir else True

    g_dq = _chk("کیفیت داده", dq_ok, f"DQ={dq_sc:.0f}")
    g_ladder = _chk("نردبان HTF→MTF→LTF", ladder_ok or not is_dir, f"HTF={ladder.get('htf_score','—')} MTF={ladder.get('mtf_score','—')}")
    g_meta = _chk("متا-برچسب", meta_not_reject, meta_label or "—")
    g_neural = _chk("سیناپس عصبی", neural_same if is_dir else True, f"{neural_side} conf={neural_conf:.0f}")
    g_rr = _chk("نسبت ریسک/پاداش", rr_ok, f"RR1={effective_rr1:.2f}")
    g_prec = _chk("دقت ورود", prec_sc >= 52 and not hard_blocks, f"P={prec_sc:.0f} blocks={len(hard_blocks)}")
    g_align = _chk("همسویی TF", safe_float(alignment, 0) >= 55, f"align={alignment:.0f}")
    g_prob = _chk("احتمال موفقیت", safe_float(success_prob, 0) >= 55, f"p={success_prob:.0f}%")
    g_ai = _chk("اجماع AI", safe_float(ai_agreement, 0) >= 40 or not is_dir, f"agree={ai_agreement:.0f}%")
    g_pattern = _chk("الگو/مسیر", pattern_conf >= 50 or forecast_aligned or not is_dir, f"pat={pattern_conf:.0f} fc={forecast_aligned}")

    hard_pass = g_dq and g_ladder and g_meta and g_neural and g_rr and g_prec and is_dir
    soft_count = sum(1 for x in (g_align, g_prob, g_ai, g_pattern) if x)
    passed = sum(1 for c in checklist if c["ok"])
    total = len(checklist)

    grade = "F"
    label_fa = "رد / غیرقابل‌اتکا"
    action = "اجتناب"
    tier_color = "#64748b"

    if not is_dir:
        if dq_sc >= 65 and safe_float(signal_quality, 0) >= 48:
            grade, label_fa, action, tier_color = "C", "خنثی / رصد", "منتظر تأیید", "#fbbf24"
        else:
            grade, label_fa, action, tier_color = "D", "بدون لبه", "عبور", "#94a3b8"
    # V28.3: realistic institutional bands — A+/A reachable without perfect AI stack
    elif hard_pass and safe_float(signal_quality, 0) >= 78 and safe_float(success_prob, 0) >= 60 and meta_not_reject and effective_rr1 >= 1.25 and soft_count >= 2:
        grade, label_fa, action, tier_color = "A+", "اطمینان بالا", "اولویت ورود", "#4ade80"
    elif (hard_pass or (g_dq and ladder_ok and rr_ok)) and safe_float(signal_quality, 0) >= 62 and safe_float(success_prob, 0) >= 52 and meta_not_reject and soft_count >= 1:
        grade, label_fa, action, tier_color = "A", "قابل‌اتکا", "ورود با مدیریت ریسک", "#22c55e"
    elif g_dq and is_dir and safe_float(signal_quality, 0) >= 52 and meta_not_reject:
        grade, label_fa, action, tier_color = "B", "متوسط / نیاز تأیید", "واچ‌لیست فعال", "#38bdf8"
    elif is_dir and safe_float(signal_quality, 0) >= 46:
        grade, label_fa, action, tier_color = "C", "ضعیف", "رصد — ورود محتاطانه", "#fbbf24"
    else:
        grade, label_fa, action, tier_color = "D", "نویز / تعارض", "اجتناب", "#f43f5e"

    # Force demote on any hard veto leftover
    if data_quality.get("hard_veto") or (is_dir and not g_dq and dq_sc < 40):
        grade, label_fa, action, tier_color = "F", "وتوی داده", "اجتناب کامل", "#7f1d1d"
    if is_dir and hard_blocks and prec_sc < 38:
        if GRADE_RANK.get(grade, 0) > GRADE_RANK["C"]:
            grade, label_fa, action, tier_color = "C", "بلاک دقت ورود", "رصد", "#fbbf24"

    trust = float(clamp(
        0.30 * safe_float(signal_quality, 0)
        + 0.25 * safe_float(success_prob, 0)
        + 0.15 * (100.0 * passed / max(total, 1))
        + 0.15 * neural_conf
        + 0.15 * dq_sc,
        0, 100,
    ))

    return {
        "grade": grade,
        "label_fa": label_fa,
        "action": action,
        "tier_color": tier_color,
        "rank": GRADE_RANK.get(grade, 0),
        "trust_index": round(trust, 1),
        "checklist": checklist,
        "passed_gates": passed,
        "total_gates": total,
        "hard_pass": hard_pass,
        "param_version": TITAN_PARAM_VERSION,
    }


def build_signal_dossier(item: dict[str, Any]) -> dict[str, Any]:
    """Compact professional dossier for ranked board + card header."""
    grade = item.get("signal_grade") or {}
    neural = item.get("neural_v9") or {}
    return {
        "symbol": item.get("symbol"),
        "base": item.get("base_symbol"),
        "icon": item.get("coin_icon"),
        "name": item.get("coin_name"),
        "decision": item.get("decision_tag") or "WAIT",
        "bias": item.get("bias"),
        "grade": grade.get("grade", "—"),
        "grade_label": grade.get("label_fa", "—"),
        "action": grade.get("action", "—"),
        "trust": grade.get("trust_index", 0),
        "quality": item.get("signal_quality"),
        "success_prob": item.get("success_probability"),
        "score": item.get("score"),
        "alignment": item.get("alignment"),
        "neural_score": neural.get("neural_score") or item.get("neural_score"),
        "neural_conf": neural.get("confidence") or item.get("neural_confidence"),
        "price": item.get("price"),
        "entry": item.get("entry_valid"),
        "sl": item.get("stop_loss"),
        "tp1": item.get("tp1"),
        "tp2": item.get("tp2"),
        "rr1": item.get("rr_tp1"),
        "rr2": item.get("rr_tp2"),
        "tag": item.get("signal_tag"),
        "tier_color": grade.get("tier_color", "#94a3b8"),
    }


def rank_market_signals(market_data: list[dict[str, Any]]) -> dict[str, Any]:
    """Classify market into actionable / watch / avoid boards (V28.3).

    - actionable: A+/A directional (primary board)
    - active: any LONG/SHORT (includes B) for HUD counts so the main page
      shows real directional activity, not only institutional A+
    - watchlist: B directional + high opportunity EARLY states
    """
    dossiers = [build_signal_dossier(x) for x in (market_data or []) if x]
    # Enrich dossier with opportunity fields from source items
    by_sym = {str(x.get("symbol")): x for x in (market_data or []) if x}
    for d in dossiers:
        src = by_sym.get(str(d.get("symbol"))) or {}
        d["opportunity_score"] = safe_float(src.get("opportunity_score"), 0)
        d["opportunity_state"] = str(src.get("opportunity_state") or "")
        d["entry_mode"] = str(src.get("entry_mode") or "")
    dossiers.sort(key=lambda d: (
        -GRADE_RANK.get(str(d.get("grade")), 0),
        -safe_float(d.get("opportunity_score"), 0),
        -safe_float(d.get("trust"), 0),
        -safe_float(d.get("quality"), 0),
        -safe_float(d.get("success_prob"), 0),
    ))
    actionable = [d for d in dossiers if d.get("grade") in {"A+", "A"} and d.get("decision") in {"LONG", "SHORT"}]
    active = [d for d in dossiers if d.get("decision") in {"LONG", "SHORT"}]
    watch = [
        d for d in dossiers
        if (d.get("grade") == "B" and d.get("decision") in {"LONG", "SHORT"})
        or str(d.get("opportunity_state") or "").startswith(("EARLY_", "WATCH_"))
    ]
    observe = [d for d in dossiers if d.get("grade") in {"C", "D"} or d.get("decision") == "WAIT"]
    avoid = [d for d in dossiers if d.get("grade") == "F"]
    long_n = sum(1 for d in active if d.get("decision") == "LONG")
    short_n = sum(1 for d in active if d.get("decision") == "SHORT")
    wait_n = sum(1 for d in dossiers if d.get("decision") == "WAIT")
    return {
        "all": dossiers,
        "actionable": actionable,
        "active": active,
        "watchlist": watch,
        "observe": observe[:12],
        "avoid": avoid,
        "counts": {
            "actionable": len(actionable),
            "active": len(active),
            "watch": len(watch),
            "observe": len(observe),
            "avoid": len(avoid),
            "long": long_n,
            "short": short_n,
            "wait": wait_n,
            "total": len(dossiers),
        },
        "top": (actionable[0] if actionable else (active[0] if active else (dossiers[0] if dossiers else None))),
        "top3": (actionable or active)[:3],
        "param_version": TITAN_PARAM_VERSION,
    }




class TitanDecisionCoreV2:
    def validate_data(self, payload: dict[str, Any]) -> bool:
        return all(k in payload and payload[k] is not None for k in ("price", "score"))

    def detect_regime(self, atr_pct: float = 0, trend_score: float = 50) -> str:
        if atr_pct > 5:
            return "high_volatility"
        if trend_score >= 60:
            return "bull_trend"
        if trend_score <= 40:
            return "bear_trend"
        return "sideways"

    def confidence(self, score: float, agreement: float = 100, risk: float = 0) -> float:
        result = float(score)
        result *= max(0.5, agreement / 100)
        result -= risk
        return max(0, min(100, round(result, 2)))

    def decide(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.validate_data(payload):
            return {"decision": "WAIT", "confidence": 0, "reason": "داده کافی نیست"}
        score = float(payload.get("score", 50))
        agreement = float(payload.get("agreement", 70))
        risk = float(payload.get("risk", 0))
        confidence = self.confidence(score, agreement, risk)
        decision = "WAIT"
        if confidence >= 65 and score >= 60:
            decision = "LONG"
        elif confidence >= 65 and score <= 40:
            decision = "SHORT"
        return {
            "decision": decision,
            "confidence": confidence,
            "regime": self.detect_regime(payload.get("atr_pct", 0), score),
            "explanation": ["داده اعتبارسنجی شد", "روند و ریسک بررسی شد", "تصمیم با فیلتر اطمینان صادر شد"],
        }

TITAN_DECISION_CORE = TitanDecisionCoreV2()


# ============================================================
# TITAN DECISION CORE V3 - SAFE INTEGRATION WRAPPER
# Restored from the user's original master build.
# ============================================================

def titan_final_decision(
    score=50,
    price=None,
    ai_votes=None,
    risk=0,
    atr_pct=0,
    metadata=None
):
    """Unified decision gateway for all existing engine outputs."""
    payload = {
        "score": score,
        "price": price,
        "risk": risk,
        "atr_pct": atr_pct,
        "metadata": metadata or {}
    }
    if ai_votes:
        numeric_votes = [float(v) for v in ai_votes.values() if isinstance(v, (int, float))] if isinstance(ai_votes, dict) else []
        payload["agreement"] = (sum(numeric_votes) / len(numeric_votes)) if numeric_votes else 50
        payload["ai_votes"] = ai_votes
    result = TITAN_DECISION_CORE.decide(payload)
    result["system_checks"] = {
        "data_validation": True,
        "confidence_filter": True,
        "risk_filter": True,
        "explainability": True
    }
    return result


def build_titan_analysis(*, symbol: str, price: float, rsi: float, vwap: float, ema20: float, ema50: float, atr: float,
                         volume_spike: bool, btc_trend: str, derivatives: dict[str, Any],
                         tf_results: dict[str, str], tf_scores: dict[str, float]) -> dict[str, Any]:
    vwap_dev = ((price - vwap) / vwap * 100.0) if vwap > 0 else 0.0
    funding = derivatives.get("funding_value")
    oi_delta = safe_float(derivatives.get("oi_delta"), 0.0)
    price_change_proxy = ((price / ema20) - 1.0) * 100.0 if ema20 > 0 else 0.0
    score = 50.0
    reasons_for: list[str] = []
    reasons_against: list[str] = []

    weights = [TF_CFG[t]["weight"] for t in tf_scores]
    weighted_tf = float(np.average(list(tf_scores.values()), weights=weights)) if tf_scores else 50.0
    score += weighted_tf - 50.0
    if ema20 > ema50:
        score += 5.0; reasons_for.append("EMA20 بالاتر از EMA50 است")
    elif ema20 < ema50:
        score -= 5.0; reasons_against.append("EMA20 پایین‌تر از EMA50 است")
    if price > vwap:
        score += 4.0; reasons_for.append("قیمت بالای VWAP است")
    elif price < vwap:
        score -= 4.0; reasons_against.append("قیمت پایین VWAP است")
    if volume_spike:
        if abs(price_change_proxy) > 0.15:
            score += 3.0
        reasons_for.append("حجم نسبت به میانگین بالاتر است")
    if btc_trend == "صعودی" and symbol != "BTC/USDT":
        score += 5.0; reasons_for.append("روند BTC پشتیبان صعود است")
    elif btc_trend == "نزولی" and symbol != "BTC/USDT":
        score -= 5.0; reasons_against.append("روند BTC فشار نزولی ایجاد می‌کند")
    f_adj, f_reason = _funding_bias(funding)
    score += f_adj
    if f_adj > 0: reasons_for.append(f_reason)
    elif f_adj < 0: reasons_against.append(f_reason)
    oi_adj, oi_reason = _oi_bias(oi_delta, price_change_proxy)
    score += oi_adj
    if oi_adj > 0: reasons_for.append(oi_reason)
    elif oi_adj < 0: reasons_against.append(oi_reason)

    score = clamp(score, 0, 100)
    bias = "صعودی" if score >= 58 else "نزولی" if score <= 42 else "خنثی"
    agreement_count = sum(
        1 for direction in tf_results.values()
        if (bias == "صعودی" and "صعودی" in direction)
        or (bias == "نزولی" and "نزولی" in direction)
        or (bias == "خنثی" and "خنثی" in direction)
    )
    alignment = clamp(50 + agreement_count * 10 + abs(score - 50) * 0.25, 50, 95)

    rsi_note = "متعادل"
    if rsi >= 70:
        rsi_note = "اشباع خرید / ریسک اصلاح"; reasons_against.append("RSI بالاتر از 70 است")
    elif rsi <= 30:
        rsi_note = "اشباع فروش / احتمال واکنش"; reasons_for.append("RSI پایین 30 است")
    if not reasons_for: reasons_for.append("تأیید جهت‌دار قوی از داده‌های فعلی دیده نشد")
    if not reasons_against: reasons_against.append("مخالفت جدی در داده‌های موجود دیده نشد")

    volatility_pct = atr / price * 100 if price > 0 else 0.0
    conviction = "بالا" if alignment >= 78 and abs(score - 50) >= 18 else "متوسط" if alignment >= 65 else "پایین"
    if bias == "صعودی":
        invalidation = "شکست معتبر EMA50/VWAP و افت امتیاز زیر 50."
    elif bias == "نزولی":
        invalidation = "بازپس‌گیری معتبر EMA50/VWAP و رشد امتیاز بالای 50."
    else:
        invalidation = "خروج از محدوده خنثی با تأیید حجم و همسویی چندتایم‌فریمی."
    summary = (f"TITAN: سوگیری {bias} با امتیاز {round(score)}/100 و همسویی {round(alignment)}/100. "
               f"RSI {rsi:.1f}، انحراف VWAP {vwap_dev:+.2f}% و ATR حدود {volatility_pct:.2f}%. "
               f"اعتماد سیستم {conviction} است؛ خروجی احتمالاتی است، نه تضمین سود.")
    return {
        "bias": bias, "score": int(round(score)), "alignment": int(round(alignment)), "conviction": conviction,
        "summary": summary, "reasons_for": reasons_for[:4], "reasons_against": reasons_against[:4],
        "invalidation": invalidation, "vwap_dev": vwap_dev, "rsi_note": rsi_note,
        "funding_note": f_reason, "oi_note": oi_reason,
    }


def calculate_levels(
    price: float,
    atr: float,
    swing_low: float,
    swing_high: float,
    bias: str,
    *,
    vwap: float = 0.0,
    ema20: float = 0.0,
    ema50: float = 0.0,
    structure: Optional[dict[str, Any]] = None,
    confluence: float = 50.0,
    order_blocks_fvg: Optional[dict[str, Any]] = None,
    fibonacci: Optional[dict[str, Any]] = None,
    forecast: Optional[dict[str, Any]] = None,
) -> tuple[float, float, float]:
    """Professional multi-anchor SL/TP: ATR + swing + structure + OB/FVG + fib + path.

    Higher confluence tightens risk and stretches reward slightly for high-conviction setups.
    Forecast path can stretch TP2 toward the expected mid of the 12-candle scenario.
    Always analysis-only — never executes orders.
    """
    rm = clamp(safe_float(USER_SETTINGS.get("risk_multiplier"), 1.2), 0.2, 5.0)
    atr = max(float(atr), price * 0.0005)
    friction = price * TOTAL_ENTRY_BUFFER
    structure = structure or {}
    conf = clamp(safe_float(confluence, 50.0), 0.0, 100.0)
    conf_factor = 0.85 + (conf / 100.0) * 0.30  # 0.85 .. 1.15
    rr1_mult = 1.5 * conf_factor
    rr2_mult = 2.6 * conf_factor

    struct_low = safe_float(structure.get("swing_low"), swing_low)
    struct_high = safe_float(structure.get("swing_high"), swing_high)
    if struct_low <= 0:
        struct_low = swing_low
    if struct_high <= 0:
        struct_high = swing_high

    anchors_below = [p for p in (swing_low, struct_low, ema50 if ema50 > 0 else None, vwap if 0 < vwap < price else None) if p and p > 0]
    anchors_above = [p for p in (swing_high, struct_high, ema50 if ema50 > 0 else None, vwap if vwap > price else None) if p and p > 0]

    # Order-block / FVG as structural SL magnets
    obf = order_blocks_fvg or {}
    nearest_ob = obf.get("nearest_ob") or {}
    nearest_fvg = obf.get("nearest_fvg") or {}
    if nearest_ob.get("type") == "bullish_ob" and safe_float(nearest_ob.get("low"), 0) > 0:
        anchors_below.append(safe_float(nearest_ob.get("low")))
    if nearest_ob.get("type") == "bearish_ob" and safe_float(nearest_ob.get("high"), 0) > 0:
        anchors_above.append(safe_float(nearest_ob.get("high")))
    if nearest_fvg.get("type") == "bullish_fvg" and safe_float(nearest_fvg.get("low"), 0) > 0:
        anchors_below.append(safe_float(nearest_fvg.get("low")))
    if nearest_fvg.get("type") == "bearish_fvg" and safe_float(nearest_fvg.get("high"), 0) > 0:
        anchors_above.append(safe_float(nearest_fvg.get("high")))

    # Fibonacci 0.618 / 0.786 as optional anchors near price
    fib = fibonacci or {}
    for fk in ("0.618", "0.786", "0.500"):
        fv = safe_float(fib.get(fk), 0)
        if fv <= 0:
            continue
        if fv < price:
            anchors_below.append(fv)
        elif fv > price:
            anchors_above.append(fv)

    # Forecast path target (step ~6 and step ~12 mid)
    fc = forecast or {}
    fc_candles = fc.get("candles") or []
    path_tp_boost = 1.0
    path_target = None
    if fc_candles and fc.get("ok"):
        mid_step = fc_candles[min(5, len(fc_candles) - 1)]
        far_step = fc_candles[min(len(fc_candles) - 1, 11)]
        path_target = safe_float(far_step.get("close"), 0)
        strength = safe_float(fc.get("path_strength"), 0)
        path_tp_boost = 1.0 + min(0.22, strength / 200.0)

    if bias == "صعودی":
        atr_sl = price - rm * atr
        swing_sl = max(anchors_below) - 0.25 * atr if anchors_below else atr_sl
        sl = min(atr_sl, swing_sl) - friction
        if sl >= price:
            sl = price - max(rm * atr, price * 0.004) - friction
        dist = max(price - sl, atr * 0.9)
        tp1 = price + rr1_mult * dist * path_tp_boost + friction
        tp2 = price + rr2_mult * dist * path_tp_boost + friction
        if path_target and path_target > price:
            # Soft pull TP2 toward forecast mid if further than RR path
            tp2 = max(tp2, min(path_target, price + 4.2 * dist))
        return float(sl), float(tp1), float(tp2)

    if bias == "نزولی":
        atr_sl = price + rm * atr
        swing_sl = min(anchors_above) + 0.25 * atr if anchors_above else atr_sl
        sl = max(atr_sl, swing_sl) + friction
        if sl <= price:
            sl = price + max(rm * atr, price * 0.004) + friction
        dist = max(sl - price, atr * 0.9)
        tp1 = price - rr1_mult * dist * path_tp_boost - friction
        tp2 = price - rr2_mult * dist * path_tp_boost - friction
        if path_target and path_target < price:
            tp2 = min(tp2, max(path_target, price - 4.2 * dist))
        return float(sl), float(tp1), float(tp2)

    return (
        float(price - 1.6 * atr - friction),
        float(price + 1.6 * atr + friction),
        float(price + 3.0 * atr + friction),
    )


def refine_bias_with_edge(
    bias: str,
    score: int,
    alignment: float,
    structure: dict[str, Any],
    regime: dict[str, Any],
    confluence: dict[str, Any],
    meta: dict[str, Any],
) -> tuple[str, str]:
    """Balanced multi-layer LONG/SHORT decision — no long-only bias.

    Requires structural + regime + confluence agreement. Symmetric thresholds
    for both directions so SHORT setups are not systematically suppressed.
    """
    struct_bias = str((structure or {}).get("bias", "خنثی"))
    regime_name = str((regime or {}).get("regime", "unknown"))
    conf_score = safe_float((confluence or {}).get("score"), 50)
    meta_label = str((meta or {}).get("label", "WATCH"))
    meta_prob = safe_float((meta or {}).get("probability"), 50)

    long_votes = 0.0
    short_votes = 0.0

    # Core quant bias (symmetric)
    if bias == "صعودی":
        long_votes += 2.0
    elif bias == "نزولی":
        short_votes += 2.0
    else:
        # neutral core still allows promotion from structure/regime
        if score >= 55:
            long_votes += 0.5
        elif score <= 45:
            short_votes += 0.5

    if struct_bias == "صعودی":
        long_votes += 1.5
    elif struct_bias == "نزولی":
        short_votes += 1.5

    if regime_name in {"trend_up", "breakout_watch"} or "up" in regime_name:
        long_votes += 1.2
    elif regime_name in {"trend_down"} or "down" in regime_name:
        short_votes += 1.2
    elif regime_name == "high_volatility":
        # volatility does not favor either side
        pass

    # Confluence strengthens whichever side score already leans
    if conf_score >= 68:
        if score >= 55:
            long_votes += 1.0
        elif score <= 45:
            short_votes += 1.0
    if conf_score >= 78:
        if score >= 52:
            long_votes += 0.5
        elif score <= 48:
            short_votes += 0.5

    if meta_label == "ACCEPT" and meta_prob >= 68:
        if score >= 54:
            long_votes += 1.0
        elif score <= 46:
            short_votes += 1.0

    # High-conviction directional (V28.5: reachable with real multi-layer lean)
    if long_votes >= 3.0 and short_votes <= 1.8 and alignment >= 48 and score >= 52:
        return "صعودی", "LONG"
    if short_votes >= 3.0 and long_votes <= 1.8 and alignment >= 48 and score <= 48:
        return "نزولی", "SHORT"

    # Moderate conviction
    if bias == "صعودی" and long_votes >= short_votes + 0.6 and score >= 54 and alignment >= 48:
        return "صعودی", "LONG"
    if bias == "نزولی" and short_votes >= long_votes + 0.6 and score <= 46 and alignment >= 48:
        return "نزولی", "SHORT"

    # Score-led when layers agree mildly
    if long_votes >= short_votes + 1.2 and score >= 56 and alignment >= 50:
        return "صعودی", "LONG"
    if short_votes >= long_votes + 1.2 and score <= 44 and alignment >= 50:
        return "نزولی", "SHORT"

    # Structure-led override when quant is neutral but structure is clear
    if bias == "خنثی":
        if long_votes >= 2.8 and short_votes <= 1.2 and score >= 52 and alignment >= 52:
            return "صعودی", "LONG"
        if short_votes >= 2.8 and long_votes <= 1.2 and score <= 48 and alignment >= 52:
            return "نزولی", "SHORT"

    return "خنثی", "WAIT"

# ============================================================
# AI LAYER
# ============================================================

DEFAULT_MODEL_SETTINGS = {
    "openai_models": ["gpt-4o-mini"],
    "gemini_models": ["gemini-2.5-flash", "gemini-2.0-flash"],
    "grok_models": ["grok-4-1-fast-reasoning"],
    "claude_models": ["claude-sonnet-4-6"],
    "deepseek_models": ["deepseek-chat"],
}


def _load_model_settings() -> dict[str, Any]:
    data = _load_json(MODEL_SETTINGS_PATH, DEFAULT_MODEL_SETTINGS)
    out = {k: list(v) for k, v in DEFAULT_MODEL_SETTINGS.items()}
    if isinstance(data, dict):
        for key in out:
            if isinstance(data.get(key), list):
                vals = [str(x).strip() for x in data[key] if str(x).strip()]
                if vals: out[key] = vals
    return out


def _build_ai_prompt(payload: dict[str, Any]) -> str:
    return (
        "دستور اجباری زبان: فقط فارسی. هیچ کلمه لاتین، انگلیسی یا مخفف انگلیسی ننویس. "
        "به‌جای Long بگو خرید/صعودی، به‌جای Short بگو فروش/نزولی، به‌جای Wait بگو انتظار. "
        "به‌جای RSI بگو شاخص قدرت نسبی، به‌جای VWAP بگو میانگین وزنی حجم، به‌جای Funding بگو نرخ تأمین مالی. "
        "تو تحلیل‌گر محافظه‌کار بازار رمزارز هستی. فقط از داده‌های زیر استفاده کن. تضمین سود نده. "
        "تناقض روند، مومنتوم، میانگین‌ها، حجم و مشتقات را بگو. حداکثر ۵ جمله کوتاه فارسی روان. "
        "جمله آخر دقیقاً با یکی از این سه قالب تمام شود: «نتیجه نهایی: صعودی» یا «نتیجه نهایی: نزولی» یا «نتیجه نهایی: انتظار».\n"
        + json.dumps(payload, ensure_ascii=False, default=str)
    )


def _cache_key(provider: str, model: str, payload: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps({"provider": provider, "model": model, "payload": payload}, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def _cached_ai(provider: str, model: str, payload: dict[str, Any], ttl: int = AI_CACHE_TTL) -> Optional[str]:
    cache = _load_json(AI_CACHE_PATH, {})
    item = cache.get(_cache_key(provider, model, payload)) if isinstance(cache, dict) else None
    if isinstance(item, dict) and time.time() - safe_float(item.get("ts"), 0) < ttl:
        return str(item.get("text")) if item.get("text") else None
    return None


def _store_ai(provider: str, model: str, payload: dict[str, Any], text: str) -> None:
    cache = _load_json(AI_CACHE_PATH, {})
    if not isinstance(cache, dict): cache = {}
    cache[_cache_key(provider, model, payload)] = {"ts": time.time(), "text": text}
    if len(cache) > 800:
        items = sorted(cache.items(), key=lambda x: safe_float(x[1].get("ts"), 0))
        for key, _ in items[:len(cache) - 800]: cache.pop(key, None)
    _save_json(AI_CACHE_PATH, cache)


def _persianize_ai_text(value: str) -> str:
    """Light glossary swap so dashboard stays Persian even if model leaks English terms."""
    if not value:
        return value
    pairs = [
        ("LONG", "خرید"), ("SHORT", "فروش"), ("WAIT", "انتظار"),
        ("Long", "خرید"), ("Short", "فروش"), ("Wait", "انتظار"),
        ("bullish", "صعودی"), ("bearish", "نزولی"), ("neutral", "خنثی"),
        ("Bullish", "صعودی"), ("Bearish", "نزولی"), ("Neutral", "خنثی"),
        ("support", "حمایت"), ("resistance", "مقاومت"),
        ("Support", "حمایت"), ("Resistance", "مقاومت"),
        ("Funding", "نرخ تأمین مالی"), ("funding", "نرخ تأمین مالی"),
        ("Open Interest", "بهره باز"), ("open interest", "بهره باز"),
        ("momentum", "مومنتوم"), ("Momentum", "مومنتوم"),
        ("breakout", "شکست سطح"), ("Breakout", "شکست سطح"),
        ("overbought", "اشباع خرید"), ("oversold", "اشباع فروش"),
        ("risk", "ریسک"), ("Risk", "ریسک"),
        ("entry", "ورود"), ("stop loss", "حد ضرر"), ("take profit", "حد سود"),
        ("Buy", "خرید"), ("Sell", "فروش"), ("buy", "خرید"), ("sell", "فروش"),
        ("HIGH CONVICTION", "اطمینان بالا"), ("CONFIRMED SETUP", "ستاپ تأییدشده"),
        ("WATCH", "تحت نظر"), ("LOW EDGE", "لبه ضعیف"),
    ]
    out = value
    for en, fa in pairs:
        out = out.replace(en, fa)
    return out


def _clean_ai_text(text: Any) -> str:
    """Normalize AI output and push toward Persian dashboard display."""
    if text is None:
        return ""
    if isinstance(text, (list, tuple)):
        text = " ".join(str(x) for x in text)
    value = " ".join(str(text).strip().split())
    if not value:
        return ""
    value = _persianize_ai_text(value)
    return value[:12000]


def _extract_gemini_text(response: dict[str, Any]) -> str:
    chunks: list[str] = []
    for candidate in response.get("candidates", []) or []:
        for part in (candidate.get("content") or {}).get("parts", []) or []:
            if part.get("text"): chunks.append(str(part["text"]))
    return _clean_ai_text(" ".join(chunks))


def _extract_chat_completion(response: dict[str, Any]) -> str:
    try:
        choices = response.get("choices") or []
        if not choices: return ""
        content = (choices[0].get("message") or {}).get("content", "")
        if isinstance(content, list):
            content = " ".join(str(x.get("text", "")) for x in content if isinstance(x, dict))
        return _clean_ai_text(content)
    except Exception:
        return ""


def _extract_openai_response(response: dict[str, Any]) -> str:
    """Extract text from the OpenAI Responses API across compatible response shapes."""
    try:
        # Preferred Responses API convenience field.
        output_text = response.get("output_text")
        if output_text:
            return _clean_ai_text(output_text)

        chunks: list[str] = []
        for item in response.get("output", []) or []:
            if not isinstance(item, dict):
                continue
            for content in item.get("content", []) or []:
                if not isinstance(content, dict):
                    continue
                if content.get("text"):
                    chunks.append(str(content["text"]))
        return _clean_ai_text(" ".join(chunks))
    except Exception:
        return ""


GEMINI_LAST_ERROR = ""
_GEMINI_MODEL_CACHE: dict[str, Any] = {"ts": 0.0, "models": []}
_GEMINI_MODEL_CACHE_TTL = 900.0
_GEMINI_MODEL_LOCK = threading.RLock()

def _gemini_available_models(force: bool = False) -> list[str]:
    """Return configured Gemini models first and cache API discovery.

    Model discovery is metadata, not market data; repeating it for every coin
    creates needless latency and can itself consume rate-limit budget.
    """
    configured = [str(x).strip() for x in _load_model_settings().get("gemini_models", []) if str(x).strip()]
    now = time.time()
    with _GEMINI_MODEL_LOCK:
        cached = list(_GEMINI_MODEL_CACHE.get("models") or [])
        if cached and not force and now - safe_float(_GEMINI_MODEL_CACHE.get("ts"), 0) < _GEMINI_MODEL_CACHE_TTL:
            return list(dict.fromkeys(configured + cached))

    discovered: list[str] = []
    if GEMINI_API_KEY:
        try:
            response = _request_json(
                "GET",
                "https://generativelanguage.googleapis.com/v1beta/models",
                headers={"x-goog-api-key": GEMINI_API_KEY},
                params={"pageSize": 100},
                timeout=12,
            )
            for item in (response or {}).get("models", []) or []:
                if not isinstance(item, dict):
                    continue
                name = str(item.get("name", "")).strip()
                methods = item.get("supportedGenerationMethods", []) or []
                if name.startswith("models/"):
                    name = name.split("/", 1)[1]
                if name and "generateContent" in methods:
                    discovered.append(name)
        except Exception as exc:
            LOGGER.warning("Gemini model discovery failed: %s", exc)

    with _GEMINI_MODEL_LOCK:
        _GEMINI_MODEL_CACHE.update(ts=now, models=discovered)
    return list(dict.fromkeys(configured + discovered))

def _call_gemini(payload: dict[str, Any], global_summary: bool = False) -> Optional[str]:
    global GEMINI_LAST_ERROR
    GEMINI_LAST_ERROR = ""
    if not GEMINI_API_KEY:
        GEMINI_LAST_ERROR = "Gemini API key not found"
        return None
    prompt = (
        "تو یک تحلیلگر حرفه‌ای بازار رمزارز زیر نظر موتور TITAN ENTERPRISE هستی. "
        "بر اساس داده‌های واقعی زیر، تحلیل دقیق و کوتاه فارسی ارائه کن. "
        "فقط فارسی بنویس. هیچ واژه انگلیسی یا لاتین مجاز نیست. از ادعاهای بدون داده خودداری کن. خروجی مخصوص داشبورد فارسی باشد.\n"
        + ("یک جمع‌بندی کلان بازار در حداکثر 6 جمله ارائه کن.\n" if global_summary else _build_ai_prompt(payload))
        + json.dumps(payload, ensure_ascii=False, default=str)
    ) if global_summary else (
        "تو تحلیلگر اختصاصی TITAN ENTERPRISE هستی. پاسخ را فقط به زبان فارسی و مبتنی بر داده‌های زیر بده. ممنوعیت مطلق انگلیسی: اگر پاسخ داخلی انگلیسی بود همان را کامل به فارسی روان بازنویسی کن و فقط فارسی برگردان. "
        "جمع‌بندی باید برای داشبورد قابل نمایش باشد و شامل وضعیت بازار، دلیل اصلی، روند، مومنتوم، حجم، حمایت و مقاومت احتمالی، سطوح فیبوناچی، ریسک مهم و وضعیت تایم‌فریم‌ها باشد. خروجی فقط فارسی باشد.\n"
        + _build_ai_prompt(payload)
    )
    models = _gemini_available_models()
    if not models:
        GEMINI_LAST_ERROR = "No Gemini model supporting generateContent was found"
        return None
    for model in models:
        cached = _cached_ai("gemini", model, payload, 600 if global_summary else AI_CACHE_TTL)
        if cached:
            return cached
        response = _request_json(
            "POST",
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
            headers={"x-goog-api-key": GEMINI_API_KEY, "Content-Type": "application/json"},
            json={
                "contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"maxOutputTokens": 420, "temperature": 0.2},
            },
            timeout=35,
        )
        if response:
            text = _extract_gemini_text(response)
            if text:
                _store_ai("gemini", model, payload, text)
                return text
            feedback = response.get("promptFeedback") or {}
            block = feedback.get("blockReason") or ""
            finish = ""
            try:
                finish = (response.get("candidates") or [{}])[0].get("finishReason", "")
            except Exception:
                pass
            GEMINI_LAST_ERROR = f"Gemini returned no text (blockReason={block or 'none'}, finishReason={finish or 'none'})"
        else:
            GEMINI_LAST_ERROR = f"Gemini request failed for model {model}"
    return None


def _call_openai(payload: dict[str, Any]) -> Optional[str]:
    if not OPENAI_API_KEY: return None
    prompt = _build_ai_prompt(payload)
    for model in _load_model_settings().get("openai_models", []):
        cached = _cached_ai("openai", model, payload)
        if cached: return cached

        headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json",
        }

        # Primary path: OpenAI Responses API.
        response = _request_json(
            "POST",
            "https://api.openai.com/v1/responses",
            headers=headers,
            json={
                "model": model,
                "input": prompt,
                "max_output_tokens": 420,
            },
            timeout=30,
        )
        if response:
            text = _extract_openai_response(response)
            if text:
                _store_ai("openai", model, payload, text)
                return text

        # Compatibility fallback: Chat Completions API.
        response = _request_json(
            "POST",
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json={
                "model": model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 420,
            },
            timeout=30,
        )
        if response:
            text = _extract_chat_completion(response)
            if text:
                _store_ai("openai", model, payload, text)
                return text
    return None


def _call_openai_compatible(provider: str, api_key: str, base_url: str, models: list[str], payload: dict[str, Any]) -> Optional[str]:
    if not api_key: return None
    prompt = _build_ai_prompt(payload)
    for model in models:
        cached = _cached_ai(provider, model, payload)
        if cached: return cached
        response = _request_json("POST", f"{base_url}/chat/completions",
                                 headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                                 json={"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": 420}, timeout=30)
        if response:
            text = _extract_chat_completion(response)
            if text:
                _store_ai(provider, model, payload, text); return text
    return None


def _call_claude(payload: dict[str, Any]) -> Optional[str]:
    if not CLAUDE_API_KEY: return None
    prompt = _build_ai_prompt(payload)
    for model in _load_model_settings().get("claude_models", []):
        cached = _cached_ai("claude", model, payload)
        if cached: return cached
        response = _request_json("POST", "https://api.anthropic.com/v1/messages",
                                 headers={"x-api-key": CLAUDE_API_KEY, "anthropic-version": "2023-06-01", "Content-Type": "application/json"},
                                 json={"model": model, "max_tokens": 420, "messages": [{"role": "user", "content": prompt}]}, timeout=30)
        if response:
            chunks = [str(x.get("text", "")) for x in response.get("content", []) or [] if isinstance(x, dict) and x.get("type") == "text"]
            text = _clean_ai_text(" ".join(chunks))
            if text:
                _store_ai("claude", model, payload, text); return text
    return None


def generate_ai_opinions(symbol: str, price: float, rsi: float, vwap: float, ema20: float, ema50: float, atr: float,
                         vol_spike: bool, btc_trend: str, derivatives: dict[str, Any], tf_results: dict[str, str],
                         titan: dict[str, Any], *, force: bool = False) -> dict[str, Any]:
    # Bulk dashboard refresh must not wait on 5 LLM providers (often 10–40s each).
    if DASHBOARD_FAST_SCAN and not force:
        # V29: never block the market scan on an LLM, but do reuse a fresh
        # Gemini opinion produced asynchronously by the previous scan. This
        # makes AI a real evidence channel without making the dashboard wait.
        cached_ai = {}
        try:
            raw = _load_json(AI_SYMBOL_CACHE_PATH, {})
            if isinstance(raw, dict):
                row = raw.get(_normalize_symbol(symbol)) or {}
                if isinstance(row, dict) and (time.time() - safe_float(row.get("ts"), 0)) <= AUTO_AI_REFRESH_SECONDS:
                    cached_ai = row
        except Exception:
            cached_ai = {}
        if cached_ai.get("text"):
            return {
                "providers": ["gemini"],
                "gemini": cached_ai.get("text", ""),
                "internal": (titan or {}).get("summary") or "",
                "titan": (titan or {}).get("summary") or "",
                "ai_status": {"gemini": "تحلیل Gemini تازه/کش‌شده", "openai": "غیرفعال در اسکن سریع",
                              "grok": "غیرفعال در اسکن سریع", "claude": "غیرفعال در اسکن سریع",
                              "deepseek": "غیرفعال در اسکن سریع"},
                "fast_scan": True,
                "cached_at": cached_ai.get("ts"),
            }
        return {
            "providers": [],
            "internal": (titan or {}).get("summary") or "",
            "titan": (titan or {}).get("summary") or "",
            "ai_status": {
                "gemini": "در صف تحلیل پس‌زمینه",
                "openai": "غیرفعال در اسکن سریع",
                "grok": "غیرفعال در اسکن سریع",
                "claude": "غیرفعال در اسکن سریع",
                "deepseek": "غیرفعال در اسکن سریع",
            },
            "fast_scan": True,
        }
    payload = {
        "symbol": symbol, "price": price, "rsi": round(rsi, 2), "vwap": round(vwap, 8), "ema20": round(ema20, 8),
        "ema50": round(ema50, 8), "atr": round(atr, 8), "volume_spike": vol_spike, "btc_trend": btc_trend,
        "oi": derivatives.get("oi"), "oi_delta": derivatives.get("oi_delta"), "funding": derivatives.get("funding"),
        "timeframes": tf_results, "titan_bias": titan["bias"], "titan_score": titan["score"], "titan_alignment": titan["alignment"],
    }
    result: dict[str, Any] = {"providers": [], "internal": titan["summary"], "titan": titan["summary"], "ai_status": {}}
    jobs = {
        "gemini": (bool(GEMINI_API_KEY), lambda: _call_gemini(payload)),
        "openai": (bool(OPENAI_API_KEY), lambda: _call_openai(payload)),
        "grok": (bool(GROK_API_KEY), lambda: _call_openai_compatible("grok", GROK_API_KEY, "https://api.x.ai/v1", _load_model_settings().get("grok_models", []), payload)),
        "claude": (bool(CLAUDE_API_KEY), lambda: _call_claude(payload)),
        "deepseek": (bool(DEEPSEEK_API_KEY), lambda: _call_openai_compatible("deepseek", DEEPSEEK_API_KEY, "https://api.deepseek.com", _load_model_settings().get("deepseek_models", []), payload)),
    }
    for name, (enabled, _) in jobs.items(): result["ai_status"][name] = "در انتظار" if enabled else "فعال نیست"
    active = [(name, fn) for name, (enabled, fn) in jobs.items() if enabled]
    if active:
        executor = _get_ai_pool(max(3, len(active)))
        futures = {executor.submit(fn): name for name, fn in active}
        for future in as_completed(futures):
            name = futures[future]
            try:
                text = future.result(timeout=18)
                if text:
                    result[name] = text; result["providers"].append(name); result["ai_status"][name] = "تحلیل آماده"
                else:
                    result["ai_status"][name] = "فعال نیست"
            except Exception as exc:
                result["ai_status"][name] = "فعال نیست"; LOGGER.warning("AI provider %s failed: %s", name, exc)
    return result

# ============================================================
# ASSET ANALYSIS / QUALITY
# ============================================================


def _record_data_quality(symbol: str, frames: dict[str, pd.DataFrame], derivatives: dict[str, Any], macro_ok: bool = True) -> None:
    try:
        candles_ok = int(all(isinstance(frames.get(tf), pd.DataFrame) and len(frames.get(tf)) >= 10 for tf in TF_CFG))
        volume_ok = int(all("vol" in frames[tf].columns and float(frames[tf]["vol"].tail(20).sum()) > 0 for tf in TF_CFG))
        funding_ok = int(derivatives.get("funding_value") is not None)
        oi_ok = int(safe_float(derivatives.get("raw_oi"), 0) > 0)
        overall = int(candles_ok and volume_ok and (funding_ok or oi_ok) and macro_ok)
        with DB_LOCK, db_conn() as con:
            con.execute("INSERT INTO data_quality(created_at,symbol,source,latency_ms,candles_ok,volume_ok,funding_ok,oi_ok,macro_ok,overall_ok,details) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                        (time.time(), symbol, "Binance/CoinGlass", 0.0, candles_ok, volume_ok, funding_ok, oi_ok, int(macro_ok), overall, json.dumps({"candles": candles_ok, "volume": volume_ok, "funding": funding_ok, "oi": oi_ok, "macro": int(macro_ok)}, ensure_ascii=False)))
    except Exception as exc:
        LOGGER.info("Data quality record skipped: %s", exc)


def _create_alert(severity: str, symbol: str, category: str, message: str) -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("INSERT INTO alerts(created_at,severity,symbol,category,message) VALUES(?,?,?,?,?)", (time.time(), severity, symbol, category, message))
    except Exception:
        pass


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    started = time.perf_counter()
    try:
        requested = {tf: (120 if tf in ("15m", "1h") else 90) for tf in TF_CFG}
        frames: dict[str, pd.DataFrame] = {}
        derivatives_box: dict[str, Any] = {"d": None}
        pool = _get_kline_pool(5)
        futs = {pool.submit(fetch_klines, symbol, tf, requested[tf]): ("kl", tf) for tf in TF_CFG}
        futs[pool.submit(fetch_derivatives, symbol)] = ("deriv", None)
        for future in as_completed(futs):
            kind, key = futs[future]
            try:
                val = future.result()
                if kind == "kl":
                    frames[key] = val
                else:
                    derivatives_box["d"] = val
            except Exception as exc:
                if kind == "kl":
                    raise
                LOGGER.debug("deriv parallel fail %s: %s", symbol, exc)
        df15, df1h = frames["15m"], frames["1h"]
        signal_close = float(df1h["close"].iloc[-1])
        # Indicators use only CLOSED candles; entry/levels use a fresh spot price when available.
        # This removes the old up-to-one-hour stale-entry problem without leaking an open candle
        # into EMA/RSI/ATR calculations.
        live_price = None
        with LIVE_LOCK:
            lp = LIVE_PRICES.get(_normalize_symbol(symbol)) or {}
            if time.time() - safe_float(lp.get("ts"), 0) <= 15:
                live_price = safe_float(lp.get("price"), 0) or None
        if not live_price:
            live_price = _fetch_live_prices([symbol]).get(_normalize_symbol(symbol))
        price = float(live_price or signal_close)
        live_age_sec = None
        with LIVE_LOCK:
            lp2 = LIVE_PRICES.get(_normalize_symbol(symbol)) or {}
            if lp2.get("ts"):
                live_age_sec = time.time() - safe_float(lp2.get("ts"), 0)
        # Perf: compute each series once; defer heavy forecast until structure/regime exist
        close_1h = df1h["close"]
        rsi_series_1h = wilder_rsi(close_1h)
        rsi = float(rsi_series_1h.iloc[-1])
        atr = float(calc_atr(df1h).iloc[-1])
        vwap = calc_vwap(df15)
        ema20_s = close_1h.ewm(span=20, adjust=False).mean()
        ema50_s = close_1h.ewm(span=50, adjust=False).mean()
        ema20 = float(ema20_s.iloc[-1])
        ema50 = float(ema50_s.iloc[-1])
        vol15 = df15["vol"]
        if len(vol15) > 1:
            vol_mean = float(vol15.iloc[:-1].ewm(span=20, adjust=False).mean().iloc[-1])
        else:
            vol_mean = float(vol15.mean()) if len(vol15) else 0.0
        cur_vol = float(vol15.iloc[-1]) if len(vol15) else 0.0
        volume_spike = cur_vol > vol_mean * 1.20 if vol_mean > 0 else False
        derivatives = derivatives_box.get("d") or fetch_derivatives(symbol)
        macd_info = calc_macd(close_1h)
        stoch_info = calc_stoch_rsi(close_1h)
        pivots = calc_pivot_points(df1h)
        vol_delta = calc_volume_delta(df15, 24)
        session_info = market_session_utc()
        pattern_pack = detect_chart_patterns(df1h, rsi_series_1h)
        # Placeholder; full forecast runs once after structure/regime (avoids 2x path cost)
        candle_forecast = {"ok": False, "candles": [], "horizon": 12}
        structure_zones = detect_order_blocks_fvg(df1h)
        depth_snap = get_depth_snapshot(symbol)
        # Soft score nudges from advanced layers (symmetric, no long bias)
        adv_nudge = 0.0
        if macd_info.get("cross") == "bull":
            adv_nudge += 3.0
        elif macd_info.get("cross") == "bear":
            adv_nudge -= 3.0
        if macd_info.get("hist", 0) > 0:
            adv_nudge += 1.5
        elif macd_info.get("hist", 0) < 0:
            adv_nudge -= 1.5
        if stoch_info.get("zone") == "oversold":
            adv_nudge += 2.5
        elif stoch_info.get("zone") == "overbought":
            adv_nudge -= 2.5
        if vol_delta.get("delta_pct", 0) > 12:
            adv_nudge += 2.0
        elif vol_delta.get("delta_pct", 0) < -12:
            adv_nudge -= 2.0
        ls_ratio = safe_float((derivatives.get("long_short") or {}).get("long_short_ratio"), 1.0)
        if ls_ratio >= 1.6:
            adv_nudge -= 2.5  # crowded long -> mild short pressure
        elif ls_ratio <= 0.65:
            adv_nudge += 2.5  # crowded short -> mild long pressure
        taker_buy = safe_float(derivatives.get("taker_buy_pct"), 50)
        if taker_buy >= 58:
            adv_nudge += 1.5
        elif taker_buy <= 42:
            adv_nudge -= 1.5
        adv_nudge += safe_float(pattern_pack.get("score_bias"), 0)
        # Align quant score with probabilistic candle path (12-step)
        fc_bias = str((candle_forecast or {}).get("overall_bias") or "")
        fc_str = safe_float((candle_forecast or {}).get("path_strength"), 0)
        if fc_bias == "صعودی":
            adv_nudge += min(4.0, 1.2 + fc_str * 0.06)
        elif fc_bias == "نزولی":
            adv_nudge -= min(4.0, 1.2 + fc_str * 0.06)
        adv_nudge *= float(session_info.get("liquidity_boost", 1.0))
        adv_nudge = float(clamp(adv_nudge, -10.0, 10.0))

        tf_results: dict[str, str] = {}
        tf_scores: dict[str, float] = {}
        for tf, df in frames.items():
            direction, score, _ = _tf_forecast(df)
            tf_results[tf] = "🟢 صعودی" if direction == "صعودی" else "🔴 نزولی" if direction == "نزولی" else "⚖️ خنثی"
            tf_scores[tf] = score
        base_score = float(np.average([tf_scores[t] for t in TF_CFG], weights=[TF_CFG[t]["weight"] for t in TF_CFG]))
        btc_adjust = 5.0 if symbol != "BTC/USDT" and btc_trend == "صعودی" else -5.0 if symbol != "BTC/USDT" and btc_trend == "نزولی" else 0.0
        provisional = clamp(base_score + btc_adjust, 0, 100)

        titan = build_titan_analysis(symbol=symbol, price=price, rsi=rsi, vwap=vwap, ema20=ema20, ema50=ema50,
                                     atr=atr, volume_spike=volume_spike, btc_trend=btc_trend, derivatives=derivatives,
                                     tf_results=tf_results, tf_scores=tf_scores)
        # Apply advanced technical / positioning nudge before structure refine
        score_n = int(round(clamp(safe_float(titan.get("score"), 50) + adv_nudge, 0, 100)))
        titan["score"] = score_n
        if score_n >= 58:
            titan["bias"] = "صعودی"
        elif score_n <= 42:
            titan["bias"] = "نزولی"
        else:
            titan["bias"] = "خنثی"
        bias, score_int, alignment = titan["bias"], titan["score"], titan["alignment"]
        titan["adv_layers"] = {
            "macd": macd_info, "stoch_rsi": stoch_info, "pivots": pivots,
            "volume_delta": vol_delta, "session": session_info, "nudge": round(adv_nudge, 2),
            "long_short_ratio": ls_ratio, "taker_buy_pct": taker_buy,
        }
        swing_low = float(df1h["low"].tail(12).min())
        swing_high = float(df1h["high"].tail(12).max())
        tech = technical_layers(df1h)
        fib = tech.get("fibonacci") or {}
        sr = tech.get("support_resistance") or {}
        bb = tech.get("bollinger") or {}

        # TITAN PROFESSIONAL EDGE SUITE: structure/regime first so levels & bias use them.
        structure = TITAN_EDGE_SUITE.market_structure(df1h)
        regime = TITAN_EDGE_SUITE.regime_detection(df1h, atr=atr, score=score_int)
        # Re-forecast with structure/regime context so path ↔ structure stay aligned
        try:
            candle_forecast = forecast_future_candles(
                df1h, horizon=12, patterns=pattern_pack,
                macd=macd_info, stoch=stoch_info,
                structure=structure, regime=regime,
            )
        except Exception:
            pass
        liquidity = TITAN_EDGE_SUITE.liquidity_map(df15, price)
        confluence = TITAN_EDGE_SUITE.signal_confluence(
            score=score_int, alignment=alignment, rsi=rsi, price=price, vwap=vwap,
            ema20=ema20, ema50=ema50, volume_spike=volume_spike, derivatives=derivatives,
            structure=structure, regime=regime.get("regime", "unknown"))
        precision_pre = _precision_engine_snapshot(
            df15, df1h, price, atr, rsi, vwap, ema20, ema50, bias, volume_spike,
            structure, regime, derivatives)
        hist_wr = TITAN_EDGE_SUITE.historical_win_rate_for_item({"bias": bias})
        preliminary_quality = int(round(clamp(
            0.35 * alignment
            + 0.30 * confluence["score"]
            + 0.20 * abs(score_int - 50) * 2
            + 0.10 * (80 if volume_spike else 40)
            + 0.05 * safe_float(structure.get("confirmation_score"), 50)
            + 0.10 * safe_float(precision_pre.get("score"), 50),
            0, 100)))
        meta = TITAN_EDGE_SUITE.meta_label(confluence["score"], preliminary_quality, hist_wr)

        # Multi-layer directional refine (LONG / SHORT / WAIT)
        bias, decision_tag = refine_bias_with_edge(
            bias, score_int, alignment, structure, regime, confluence, meta)
        titan["bias"] = bias

        # Early AI lean (status-only providers skipped later); soft confirmation only
        # Full AI text is generated after levels — ensemble still runs post-AI.

        sl, tp1, tp2 = calculate_levels(
            price, atr, swing_low, swing_high, bias,
            vwap=vwap, ema20=ema20, ema50=ema50,
            structure=structure, confluence=safe_float(confluence.get("score"), 50),
            order_blocks_fvg=structure_zones, fibonacci=fib, forecast=candle_forecast,
        )
        ai = generate_ai_opinions(symbol, price, rsi, vwap, ema20, ema50, atr, volume_spike, btc_trend, derivatives, tf_results, titan)
        _record_data_quality(symbol, frames, derivatives)

        # Adaptive fusion: quant + structure + regime + confluence + AI + history
        ai_pre = TITAN_EDGE_SUITE.ai_ensemble(ai, bias)
        fusion = TITAN_ADAPTIVE.fuse_decision(
            symbol=symbol,
            quant_bias=bias,
            score=float(score_int),
            alignment=float(alignment),
            structure=structure,
            regime=regime,
            confluence=confluence,
            meta=meta,
            ai_ensemble=ai_pre,
            forecast=candle_forecast,
            patterns=pattern_pack,
        )
        prev_bias, prev_tag = bias, decision_tag
        bias = fusion.get("bias", bias)
        decision_tag = fusion.get("decision", decision_tag)
        # Recompute precision for the final fused direction; never let AI alone bypass a poor entry.
        precision = _precision_engine_snapshot(
            df15, df1h, price, atr, rsi, vwap, ema20, ema50, bias, volume_spike,
            structure, regime, derivatives)
        pscore = safe_float(precision.get("score"), 50)
        if decision_tag in {"LONG", "SHORT"}:
            # Only invalid price/ATR hard-kills. Soft precision only tags risk.
            severe_blocks = [x for x in (precision.get("hard_blocks") or []) if x in {"invalid_price_or_atr"}]
            if severe_blocks:
                decision_tag, bias = "WAIT", "خنثی"
                fusion["precision_veto"] = True
                fusion["precision_reason"] = severe_blocks
            elif pscore < 40 or "overextended_entry" in (precision.get("hard_blocks") or []):
                fusion["precision_soft"] = True
                fusion["precision_reason"] = [f"precision_soft={pscore:.0f}"]

        # --- V8 Data Quality hard gate ---
        dq = assess_data_quality(
            symbol=symbol, price=price, live_age_sec=live_age_sec,
            df15=df15, df1h=df1h, derivatives=derivatives, frames=frames,
        )
        fusion["data_quality"] = dq
        if dq.get("hard_veto") and decision_tag in {"LONG", "SHORT"}:
            decision_tag, bias = "WAIT", "خنثی"
            fusion["dq_veto"] = True
            fusion.setdefault("explanation", []).append(
                f"وتوی کیفیت داده ({dq.get('score')}) · {', '.join((dq.get('reasons') or [])[:3])}"
            )

        # --- V8 Entry Ladder (4h/1d → 1h → 15m) ---
        # V28.4: ladder is advisory quality penalty, not a hard WAIT kill-switch.
        ladder = entry_ladder_gate(tf_scores, tf_results, decision_tag, bias)
        fusion["entry_ladder"] = ladder
        if decision_tag in {"LONG", "SHORT"} and not ladder.get("passed", True):
            fusion["ladder_soft"] = True
            fusion.setdefault("explanation", []).append(
                "نردبان ورود ناقص (نرم): " + ", ".join((ladder.get("reasons") or [])[:4])
            )

        # --- V8 Forecast path weight from tracked accuracy ---
        fc_stats = forecast_path_accuracy_stats(symbol)
        fusion["forecast_accuracy"] = fc_stats
        if decision_tag in {"LONG", "SHORT"} and candle_forecast.get("ok"):
            fc_side = candle_forecast.get("overall_bias")
            aligned = (decision_tag == "LONG" and fc_side == "صعودی") or (decision_tag == "SHORT" and fc_side == "نزولی")
            if not aligned and safe_float(fc_stats.get("weight_scale"), 0) >= 0.7 and safe_float(fc_stats.get("samples"), 0) >= 12:
                # Trusted path disagrees → soft demote to WAIT if other edges weak
                if safe_float(fusion.get("fused_score"), 0) < 0.28 and pscore < 60:
                    decision_tag, bias = "WAIT", "خنثی"
                    fusion["forecast_veto"] = True
                    fusion.setdefault("explanation", []).append("مسیر ۱۲ کندلی معتبر خلاف جهت ستاپ ضعیف")

        # --- V8 Portfolio crowding (soft: penalty only, do not erase real edges) ---
        port = portfolio_side_pressure(decision_tag, symbol)
        fusion["portfolio"] = port
        if decision_tag in {"LONG", "SHORT"} and not port.get("ok", True):
            fusion["portfolio_soft"] = True
            fusion.setdefault("explanation", []).append((port.get("reason") or "فشار سبد") + " · فقط هشدار")
            if isinstance(fusion.get("success_probability"), (int, float)):
                fusion["success_probability"] = float(clamp(
                    safe_float(fusion.get("success_probability"), 50) - 8, 5, 88
                ))
        elif port.get("penalty", 0) and isinstance(fusion.get("success_probability"), (int, float)):
            fusion["success_probability"] = float(clamp(
                safe_float(fusion.get("success_probability"), 50) - port["penalty"] * 0.35, 5, 88
            ))

        # BTC correlation filter for alts in high-vol
        atr_pct_now = (atr / price * 100) if price > 0 else 0.0
        try:
            corr_info = compute_btc_correlation(symbol)
            decision_tag, bias, corr_note = apply_btc_correlation_filter(
                symbol, decision_tag, bias, atr_pct_now, btc_trend, corr_info)
            fusion["btc_correlation"] = corr_note
        except Exception as _corr_exc:
            LOGGER.debug("corr filter skip: %s", _corr_exc)
            corr_note = {}
        # Order blocks / FVG + depth already computed once above (perf: no double work)
        if not structure_zones:
            try:
                structure_zones = detect_order_blocks_fvg(df1h)
            except Exception:
                structure_zones = {"order_blocks": [], "fvgs": [], "nearest_ob": None, "nearest_fvg": None}
        if not depth_snap:
            depth_snap = get_depth_snapshot(symbol)
        titan["bias"] = bias
        titan["fusion"] = {
            "fused_score": fusion.get("fused_score"),
            "success_probability": fusion.get("success_probability"),
            "explanation": fusion.get("explanation"),
            "ai_majority": fusion.get("ai_majority"),
            "weights": fusion.get("weights"),
            "reliability": fusion.get("reliability"),
            "thresholds": fusion.get("thresholds"),
            "prior_quant": prev_bias,
            "prior_tag": prev_tag,
        }
        # Recalculate levels if direction changed after fusion
        if bias != prev_bias or decision_tag != prev_tag:
            sl, tp1, tp2 = calculate_levels(
                price, atr, swing_low, swing_high, bias,
                vwap=vwap, ema20=ema20, ema50=ema50,
                structure=structure, confluence=safe_float(confluence.get("score"), 50),
                order_blocks_fvg=structure_zones, fibonacci=fib, forecast=candle_forecast,
            )
        # Soft score nudge toward fused conviction (display only, clamped)
        try:
            fused_nudge = int(round(safe_float(fusion.get("fused_score"), 0) * 8))
            score_int = int(clamp(score_int + fused_nudge, 0, 100))
            titan["score"] = score_int
        except Exception:
            pass

        volatility_pct = atr / price * 100 if price > 0 else 0.0
        risk_distance_pct = abs(price - sl) / price * 100 if price > 0 else 0.0
        rr_tp1 = abs(tp1 - price) / max(abs(price - sl), 1e-12)
        rr_tp2 = abs(tp2 - price) / max(abs(price - sl), 1e-12)

        ai_consensus = TITAN_EDGE_SUITE.ai_ensemble(ai, bias)
        drawdown_values = []
        try:
            with DB_LOCK, db_conn() as con:
                drawdown_values = [safe_float(r[0]) for r in con.execute("SELECT r_multiple FROM paper_trades WHERE status='CLOSED' AND r_multiple IS NOT NULL ORDER BY closed_at ASC LIMIT 300").fetchall()]
        except Exception:
            drawdown_values = []
        governor = TITAN_EDGE_SUITE.drawdown_governor(drawdown_values)
        adaptive = TITAN_EDGE_SUITE.adaptive_risk(
            base_risk=1.0, volatility_pct=volatility_pct,
            confidence=meta["probability"], regime=regime.get("regime", "unknown"),
            drawdown_pct=governor.get("drawdown_pct", 0))
        risk = {**adaptive, "governor_state": governor.get("state"), "governor_multiplier": governor.get("risk_multiplier")}
        # Professional composite quality: alignment + confluence + meta + AI agreement + structure
        ai_agree = safe_float(ai_consensus.get("agreement"), 0)
        signal_quality = int(round(clamp(
            preliminary_quality * 0.45
            + confluence["score"] * 0.20
            + meta["probability"] * 0.15
            + ai_agree * 0.10
            + safe_float(structure.get("confirmation_score"), 50) * 0.07
            + pscore * 0.15,
            0, 100)))
        if governor.get("state") == "DEFENSIVE":
            signal_quality = min(signal_quality, 62)
        if decision_tag == "WAIT":
            signal_quality = min(signal_quality, 70)
        # Blend adaptive success probability into quality
        success_prob = safe_float((titan.get("fusion") or {}).get("success_probability"), 50)
        # Precision is an entry-quality correction, not a claim of calibrated probability.
        success_prob = float(clamp(0.88 * success_prob + 0.12 * pscore, 5, 88))
        try:
            cal_dir = "صعودی" if decision_tag == "LONG" else "نزولی" if decision_tag == "SHORT" else ""
            cal_pack = calibrate_success_probability_v8(
                symbol, cal_dir, success_prob, regime=str((regime or {}).get("regime", "")),
            )
            success_prob = float(clamp(safe_float(cal_pack.get("calibrated"), success_prob), 5, 88))
            if isinstance(titan.get("fusion"), dict):
                titan["fusion"]["success_probability"] = success_prob
                titan["fusion"]["probability_calibration"] = cal_pack
                titan["fusion"]["param_version"] = TITAN_PARAM_VERSION
        except Exception as _cal_exc:
            LOGGER.debug("post cal failed: %s", _cal_exc)
            cal_pack = {}
        # V8 meta-label final accept/reject
        try:
            stretch = max(
                safe_float((precision or {}).get("stretch_vwap_atr"), 0),
                safe_float((precision or {}).get("stretch_ema_atr"), 0),
            )
            meta_v8 = meta_label_v8(
                confluence_score=safe_float(confluence.get("score"), 50),
                precision_score=pscore,
                alignment=float(alignment),
                success_prob=success_prob,
                ai_conflict=bool((titan.get("fusion") or {}).get("ai_conflict")),
                stretch_atr=stretch,
                ladder_passed=bool((fusion.get("entry_ladder") or {}).get("passed", True)),
                data_quality=safe_float((fusion.get("data_quality") or {}).get("score"), 50),
                hist_wr=safe_float(hist_wr, 50) if not isinstance(hist_wr, dict) else safe_float(hist_wr.get("win_rate"), 50),
            )
            fusion["meta_v8"] = meta_v8
            titan["fusion"]["meta_v8"] = meta_v8
            if decision_tag in {"LONG", "SHORT"} and meta_v8.get("label") == "REJECT":
                # V28.4: soft — keep direction, tag risk, lower quality
                fusion["meta_soft_reject"] = True
                fusion.setdefault("explanation", []).append("متا-برچسب V8 رد نرم → جهت حفظ با کاهش کیفیت")
            if decision_tag in {"LONG", "SHORT"}:
                register_portfolio_signal(symbol, decision_tag)
        except Exception as _mv:
            LOGGER.debug("meta_v8 failed: %s", _mv)

        # --- V9 Neural Synapse: full-system coherence gate ---
        try:
            path_stats = forecast_path_accuracy_stats(symbol)
            calib_v9 = calibrate_success_probability_v8(
                symbol=symbol,
                direction=decision_tag if decision_tag in {"LONG", "SHORT"} else ("LONG" if bias == "صعودی" else "SHORT" if bias == "نزولی" else ""),
                raw_prob=safe_float(fusion.get("success_probability"), 50),
                regime=str((regime or {}).get("regime", "")),
            )
            fusion["probability_calibration"] = calib_v9
            _prec_for_neural = precision_pre
            try:
                if "precision" in locals() and isinstance(precision, dict):
                    _prec_for_neural = precision
            except Exception:
                pass
            _ai_for_neural = ai if isinstance(ai, dict) else {}
            _dq_for_neural = fusion.get("data_quality") or {}
            neural = TITAN_NEURAL.fuse(
                tf_scores=tf_scores,
                structure=structure,
                regime=regime,
                confluence=confluence,
                precision=_prec_for_neural,
                patterns=pattern_pack,
                forecast=candle_forecast,
                path_stats=path_stats,
                derivatives=derivatives,
                fusion=fusion,
                ai_opinions=_ai_for_neural,
                data_quality=_dq_for_neural,
                ladder=fusion.get("entry_ladder") or {},
                calib=calib_v9,
                quant_bias=bias,
                quant_score=float(score_int),
            )
            fusion["neural_v9"] = neural
            titan["fusion"]["neural_v9"] = neural
            titan["neural_score"] = neural.get("neural_score")
            titan["neural_confidence"] = neural.get("confidence")
            # Neural can only demote or confirm — never invent a side from WAIT quant without ladder
            n_side = neural.get("side", "WAIT")
            n_conf = safe_float(neural.get("confidence"), 0)
            if decision_tag in {"LONG", "SHORT"}:
                # Opportunity-preserving rule: a neutral neural layer is not enough by itself
                # to erase a strong, data-valid directional setup. Only demote when the
                # neural layer is materially uncertain AND the directional edge is weak.
                _dq_now = safe_float((fusion.get("data_quality") or {}).get("score"), 0)
                _sq_now = safe_float(signal_quality, 0)
                _edge_now = abs(safe_float(neural.get("neural_score"), 50) - 50)
                if n_side == "WAIT" and n_conf >= 70:
                    # Neutral neural never kills a data-valid directional edge by itself.
                    fusion.setdefault("explanation", []).append(
                        "سیناپس عصبی خنثی — جهت کمی حفظ شد (V28.5)"
                    )
                    signal_quality = min(int(signal_quality), 70)
                elif n_side != decision_tag and n_side in {"LONG", "SHORT"} and n_conf >= 82:
                    # Only extreme opposite neural with weak edge demotes to WAIT.
                    if _sq_now < 55 and _edge_now < 8:
                        decision_tag, bias = "WAIT", "خنثی"
                        fusion.setdefault("explanation", []).append(
                            f"سیناپس عصبی خلاف جهت قوی ({n_side}) conf={n_conf:.0f} + لبه ضعیف → انتظار"
                        )
                    else:
                        fusion.setdefault("explanation", []).append(
                            f"تعارض Neural ثبت شد اما Edge حفظ شد · {decision_tag}"
                        )
                        signal_quality = min(int(signal_quality), 68)
                elif n_side == decision_tag and n_conf >= 62:
                    fusion.setdefault("explanation", []).append(
                        f"سیناپس عصبی V9 تأیید {n_side} · score={neural.get('neural_score')} · conf={n_conf:.0f}"
                    )
            elif decision_tag == "WAIT" and n_side in {"LONG", "SHORT"} and n_conf >= 52:
                # Balanced opportunity promotion: allow a strong consensus setup to surface
                # even when one timeframe is merely early/neutral. Hard data failures and
                # strong opposite HTF/MTF structure still block the promotion.
                trial_ladder = entry_ladder_gate(tf_scores, tf_results, n_side, neural.get("bias", "خنثی"))
                _dq_promote = safe_float((fusion.get("data_quality") or {}).get("score"), 0)
                _rr_promote = _friction_adjusted_rr(price, sl, tp1)
                _neural_dir_ok = (safe_float(neural.get("neural_score"), 50) >= 55) if n_side == "LONG" else (safe_float(neural.get("neural_score"), 50) <= 45)
                _opportunity_ok = _dq_promote >= MIN_DATA_QUALITY_SCORE and _neural_dir_ok
                _quality_ok = safe_float(signal_quality, 0) >= 58 and pscore >= 52 and success_prob >= 52 and _rr_promote >= 1.10
                _hard_opposite = (
                    (n_side == "LONG" and trial_ladder.get("htf_side") == "SHORT" and trial_ladder.get("htf_score",50) <= 43)
                    or (n_side == "SHORT" and trial_ladder.get("htf_side") == "LONG" and trial_ladder.get("htf_score",50) >= 57)
                )
                if _opportunity_ok and _quality_ok and not _hard_opposite:
                    decision_tag = n_side
                    bias = neural.get("bias", "صعودی" if n_side == "LONG" else "نزولی")
                    fusion["opportunity_mode"] = True
                    fusion.setdefault("explanation", []).append(
                        f"Opportunity Engine: {n_side} فعال شد · Neural={n_conf:.0f} · RR={_rr_promote:.2f} · تایم‌فریم‌ها در آستانه ورود"
                    )
            # Soft quality blend with neural confidence
            if isinstance(neural.get("neural_score"), (int, float)):
                signal_quality = int(round(clamp(
                    0.55 * signal_quality + 0.25 * safe_float(fusion.get("success_probability"), 50)
                    + 0.10 * pscore + 0.10 * n_conf,
                    0, 100,
                )))
        except Exception as _neu:
            LOGGER.debug("neural synapse V9 failed: %s", _neu)

        signal_quality = int(round(clamp(0.60 * signal_quality + 0.25 * success_prob + 0.15 * pscore, 0, 100)))
        if decision_tag == "WAIT":
            signal_quality = min(signal_quality, 68)
        effective_rr1 = _friction_adjusted_rr(price, sl, tp1)
        effective_rr2 = _friction_adjusted_rr(price, sl, tp2)
        if decision_tag in {"LONG", "SHORT"} and effective_rr1 < MIN_EFFECTIVE_RR:
            # V28.4: keep direction; only hard-kill if RR is tiny AND quality is weak.
            if effective_rr1 < 0.85 and (signal_quality < 50 or success_prob < 48):
                decision_tag, bias = "WAIT", "خنثی"
                signal_quality = min(signal_quality, 55)
                fusion["rr_veto"] = True
            else:
                fusion["rr_warning"] = True
                fusion["rr_warning_value"] = round(effective_rr1, 2)
                signal_quality = min(signal_quality, 72)
        # If AI majority conflicts hard, cap quality
        if (titan.get("fusion") or {}).get("ai_majority") in {"LONG", "SHORT"}:
            if decision_tag not in {"WAIT", (titan.get("fusion") or {}).get("ai_majority")} and ai_pre.get("providers", 0) >= 2:
                signal_quality = min(signal_quality, 60)

        meta_v8_label = str(((fusion.get("meta_v8") or {}).get("label") if isinstance(fusion, dict) else "") or meta.get("label") or "")
        neural_pack = (fusion.get("neural_v9") or {}) if isinstance(fusion, dict) else {}
        neural_side = str(neural_pack.get("side") or "")
        neural_conf = safe_float(neural_pack.get("confidence"), 0)
        neural_ok = (not neural_pack) or (neural_side in {decision_tag, "WAIT"} and neural_side != "WAIT") or (neural_side == decision_tag)
        if neural_pack and decision_tag in {"LONG", "SHORT"}:
            neural_ok = neural_side == decision_tag and neural_conf >= 55
        if (
            signal_quality >= 82
            and meta_v8_label == "ACCEPT"
            and decision_tag in {"LONG", "SHORT"}
            and success_prob >= 62
            and bool((fusion.get("entry_ladder") or {}).get("passed", False))
            and not fusion.get("dq_veto")
            and neural_ok
            and neural_conf >= 58
        ):
            signal_tag = "HIGH CONVICTION"
        elif signal_quality >= 70 and decision_tag in {"LONG", "SHORT"} and success_prob >= 56 and meta_v8_label != "REJECT" and (not neural_pack or neural_side in {decision_tag, "WAIT"}):
            signal_tag = "CONFIRMED SETUP"
        elif signal_quality >= 55:
            signal_tag = "WATCH"
        else:
            signal_tag = "LOW EDGE"

        signal_grade: dict[str, Any] = {"grade": "—", "label_fa": "—", "action": "—", "trust_index": 0, "checklist": [], "rank": 0}
        # --- V10 Professional Grade ---
        try:
            _pat_primary = (pattern_pack or {}).get("primary") or {}
            _pat_conf = safe_float(_pat_primary.get("confidence"), 0)
            _fc_bias = str((candle_forecast or {}).get("overall_bias") or "")
            _fc_aligned = (
                (decision_tag == "LONG" and _fc_bias == "صعودی")
                or (decision_tag == "SHORT" and _fc_bias == "نزولی")
            )
            signal_grade = classify_signal_grade(
                decision_tag=decision_tag,
                signal_quality=float(signal_quality),
                success_prob=float(success_prob),
                alignment=float(alignment),
                neural=neural_pack if isinstance(neural_pack, dict) else fusion.get("neural_v9"),
                meta=fusion.get("meta_v8") or meta,
                ladder=fusion.get("entry_ladder") or {},
                data_quality=fusion.get("data_quality") or {},
                precision=precision if isinstance(precision, dict) else precision_pre,
                effective_rr1=float(effective_rr1) if effective_rr1 is not None else 0.0,
                ai_agreement=safe_float((fusion.get("ai_agreement") if isinstance(fusion, dict) else None) or (ai_consensus or {}).get("agreement"), 0),
                pattern_conf=_pat_conf,
                forecast_aligned=_fc_aligned,
            )
            # V28.4: only hard F + data veto kills direction; D/C stay visible as risk-tagged signals
            if decision_tag in {"LONG", "SHORT"} and signal_grade.get("grade") == "F" and (fusion.get("data_quality") or {}).get("hard_veto"):
                decision_tag, bias = "WAIT", "خنثی"
                signal_tag = "LOW EDGE"
                titan["bias"] = bias
                fusion.setdefault("explanation", []).append(
                    f"درجه F + وتوی داده → سیگنال لغو شد ({signal_grade.get('label_fa')})"
                )
            elif decision_tag in {"LONG", "SHORT"} and signal_grade.get("grade") in {"C", "D"}:
                signal_tag = "WATCH" if signal_grade.get("grade") == "C" else "LOW EDGE"
                fusion.setdefault("explanation", []).append(
                    f"درجه {signal_grade.get('grade')} → جهت حفظ شد با برچسب ریسک ({signal_grade.get('label_fa')})"
                )
            fusion["signal_grade"] = signal_grade
            titan["fusion"]["signal_grade"] = signal_grade
            titan["bias"] = bias
        except Exception as _gr:
            LOGGER.debug("signal grade failed: %s", _gr)
            signal_grade = {"grade": "—", "label_fa": "نامشخص", "action": "—", "trust_index": 0, "checklist": [], "rank": 0}

        # V27.3 FINAL BALANCED OPPORTUNITY PASS
        # Purpose: prevent a valid directional setup from being flattened to WAIT by
        # a single soft/secondary gate, while keeping hard data/safety vetoes intact.
        try:
            _f = fusion if isinstance(fusion, dict) else {}
            _dqf = safe_float((_f.get("data_quality") or {}).get("score"), 0)
            _neuf = (_f.get("neural_v9") or {}) if isinstance(_f, dict) else {}
            _nside = str(_neuf.get("side") or "")
            _nscore = safe_float(_neuf.get("neural_score"), 50)
            _nconf = safe_float(_neuf.get("confidence"), 0)
            _a_major = str(_f.get("ai_majority") or "")
            _cand = _nside if _nside in {"LONG","SHORT"} else _a_major if _a_major in {"LONG","SHORT"} else (
                "LONG" if bias == "صعودی" else "SHORT" if bias == "نزولی" else (
                    "LONG" if score_int >= 55 else "SHORT" if score_int <= 45 else ""
                )
            )
            _tfvals = [safe_float(v,50) for v in (tf_scores or {}).values()]
            _tfavg = float(np.mean(_tfvals)) if _tfvals else 50.0
            _dir_edge = abs(float(score_int)-50.0)
            _rr_ok = safe_float(effective_rr1, 0) >= MIN_EFFECTIVE_RR
            _meta_final = str((_f.get("meta_v8") or {}).get("label") or "")
            _hard_block = bool(
                _f.get("dq_veto")
                or _f.get("portfolio_veto")
                or (_meta_final == "REJECT" and _dqf < 48)
                or (_f.get("ai_conflict") and _nconf >= 82)
            )
            _grade_now = str((signal_grade or {}).get("grade") or "")
            _strong_dir = (
                _cand in {"LONG","SHORT"}
                and _dqf >= 46
                and _dir_edge >= 3.5
                and safe_float(alignment,0) >= 44
                and safe_float(pscore,0) >= 40
                and safe_float(success_prob,0) >= 44
                and _rr_ok
                and not _hard_block
                and _grade_now not in {"F"}
            )
            _support_votes = 0
            _support_reasons = []
            _struct_final = _f.get("structure") or {}
            if _cand == "LONG":
                if _nside == "LONG" and _nconf >= 52:
                    _support_votes += 1; _support_reasons.append("neural")
                if _a_major == "LONG":
                    _support_votes += 1; _support_reasons.append("ai")
                if score_int >= 54:
                    _support_votes += 1; _support_reasons.append("score")
                if _tfavg >= 53:
                    _support_votes += 1; _support_reasons.append("tf")
                if str(_struct_final.get("bias") or "") == "صعودی":
                    _support_votes += 1; _support_reasons.append("structure")
            elif _cand == "SHORT":
                if _nside == "SHORT" and _nconf >= 52:
                    _support_votes += 1; _support_reasons.append("neural")
                if _a_major == "SHORT":
                    _support_votes += 1; _support_reasons.append("ai")
                if score_int <= 46:
                    _support_votes += 1; _support_reasons.append("score")
                if _tfavg <= 47:
                    _support_votes += 1; _support_reasons.append("tf")
                if str(_struct_final.get("bias") or "") == "نزولی":
                    _support_votes += 1; _support_reasons.append("structure")
            _candidate_support = _support_votes >= 2
            if decision_tag == "WAIT" and _strong_dir and _candidate_support:
                _hard_htf_opposite = (
                    (_cand == "LONG" and safe_float((_f.get("entry_ladder") or {}).get("htf_score"),50) <= 34)
                    or (_cand == "SHORT" and safe_float((_f.get("entry_ladder") or {}).get("htf_score"),50) >= 66)
                )
                if not _hard_htf_opposite:
                    decision_tag = _cand
                    bias = "صعودی" if _cand == "LONG" else "نزولی"
                    _f["opportunity_mode"] = True
                    _f.setdefault("explanation", []).append(
                        f"Opportunity-Preserve V28.2: {_cand} فعال شد؛ لبه جهت‌دار واقعی، RR کافی، بدون وتوی سخت و {_support_votes} شاهد مستقل ({', '.join(_support_reasons[:4])})."
                    )
                    signal_quality = max(signal_quality, min(82, int(round(52 + _dir_edge * 1.6))))
            # WAIT only when no independent directional evidence exists.
        except Exception as _opp_final_exc:
            LOGGER.debug("final opportunity pass failed: %s", _opp_final_exc)

        edge = {
            "confluence": confluence, "regime": regime, "liquidity": liquidity, "structure": structure,
            "ai": ai_consensus, "meta": meta, "risk": risk, "governor": governor,
            "strategy_lab": TITAN_EDGE_SUITE.strategy_lab(df1h),
            "decision_tag": decision_tag,
            "fusion": titan.get("fusion") or {},
            "precision": precision,
        }

        base_symbol = symbol.split("/")[0].upper()
        coin_name, coin_icon = COIN_META.get(base_symbol, (base_symbol, "●"))
        color = "#4ade80" if score_int >= 60 else "#f43f5e" if score_int <= 40 else "#fbbf24"
        return {
            "symbol": symbol, "base_symbol": base_symbol, "coin_name": coin_name, "coin_icon": coin_icon,
            "tv_symbol": _binance_symbol(symbol), "price": smart_format(price), "rsi": f"{rsi:.1f}",
            "entry_valid": smart_format(price), "tp1": smart_format(tp1), "tp2": smart_format(tp2), "stop_loss": smart_format(sl),
            "coinglass_oi": derivatives["oi"], "coinglass_funding": derivatives["funding"], "derivatives_source": derivatives["source"],
            "btc_trend": btc_trend, "tfs": tf_results, "titan_analysis": titan, "ai_opinions": ai,
            "alignment": alignment, "bias": bias, "score": score_int, "score_bar": score_int, "score_color": color,
            "score_icon": "🟢" if score_int >= 60 else "🔴" if score_int <= 40 else "🟡", "volume_spike": volume_spike,
            "provisional_tf_score": round(provisional, 1), "volatility_pct": round(volatility_pct, 3),
            "risk_distance_pct": round(risk_distance_pct, 3), "rr_tp1": round(rr_tp1, 2), "rr_tp2": round(rr_tp2, 2),
            "effective_rr_tp1": round(effective_rr1, 2), "effective_rr_tp2": round(effective_rr2, 2),
            "precision": precision, "entry_timing": precision.get("entry_timing", "CAUTIOUS"),
            "signal_quality": signal_quality, "signal_tag": signal_tag,
            "fusion": titan.get("fusion") or {}, "edge": edge, "decision_tag": decision_tag,
            "success_probability": safe_float((titan.get("fusion") or {}).get("success_probability"), 50),
            "ai_majority": (titan.get("fusion") or {}).get("ai_majority"),
            "ai_conflict": bool((titan.get("fusion") or {}).get("ai_conflict")),
            "decision_terminal": TITAN_EDGE_SUITE.decision_terminal({
                "symbol": symbol, "price": smart_format(price), "bias": bias,
                "rr_tp1": round(rr_tp1, 2), "rr_tp2": round(rr_tp2, 2), "effective_rr_tp1": round(effective_rr1, 2),
                "precision": precision, "signal_quality": signal_quality,
                "signal_tag": signal_tag, "edge": edge, "decision_tag": decision_tag}),
            "latency_ms": round((time.perf_counter() - started) * 1000, 1),
            "macd": macd_info,
            "stoch_rsi": stoch_info,
            "pivots": {k: smart_format(v) for k, v in (pivots or {}).items()},
            "volume_delta": vol_delta,
            "session": session_info,
            "long_short_ratio": derivatives.get("long_short_ratio"),
            "long_ratio": derivatives.get("long_ratio"),
            "short_ratio": derivatives.get("short_ratio"),
            "top_long_ratio": derivatives.get("top_long_ratio"),
            "taker_buy_pct": derivatives.get("taker_buy_pct"),
            "taker_sell_pct": derivatives.get("taker_sell_pct"),
            "adv_nudge": round(adv_nudge, 2),
            "patterns": pattern_pack,
            "candle_forecast": candle_forecast,
            "rsi_value": round(rsi, 2),
            "macd_hist": macd_info.get("hist"),
            "macd_cross": macd_info.get("cross"),
            "btc_correlation": (fusion.get("btc_correlation") if isinstance(fusion, dict) else None) or {},
            "order_blocks_fvg": structure_zones,
            "depth": depth_snap,
            "technical": {
                "fibonacci": {k: smart_format(v) for k, v in fib.items()},
                "support": smart_format(sr.get("support")) if sr.get("support") is not None else "N/A",
                "resistance": smart_format(sr.get("resistance")) if sr.get("resistance") is not None else "N/A",
                "bollinger": {
                    "upper": smart_format(bb.get("upper")) if bb.get("upper") is not None else "N/A",
                    "middle": smart_format(bb.get("middle")) if bb.get("middle") is not None else "N/A",
                    "lower": smart_format(bb.get("lower")) if bb.get("lower") is not None else "N/A",
                },
            },
            "tf_scores": {k: round(float(v), 1) for k, v in tf_scores.items()},
            "buy_sell": (lambda _bp: {
                "pressure": edge.get("liquidity", {}).get("pressure", 0),
                "bias": edge.get("liquidity", {}).get("liquidity_bias", "unknown"),
                "state": edge.get("liquidity", {}).get("state", "unknown"),
                "buy_pct": int(_bp),
                "sell_pct": int(100 - _bp),
                "taker_buy_pct": safe_float(derivatives.get("taker_buy_pct"), 50),
                "taker_sell_pct": safe_float(derivatives.get("taker_sell_pct"), 50),
                "volume_delta_pct": safe_float(vol_delta.get("delta_pct"), 0),
            })(clamp(
                0.45 * (50 + safe_float(edge.get("liquidity", {}).get("pressure"), 0) * 80)
                + 0.35 * safe_float(derivatives.get("taker_buy_pct"), 50)
                + 0.20 * (50 + safe_float(vol_delta.get("delta_pct"), 0) * 0.8),
                5, 95)),
            "whale": {
                "oi": derivatives.get("oi", "N/A"),
                "oi_delta": round(safe_float(derivatives.get("oi_delta"), 0), 3),
                "funding": derivatives.get("funding", "N/A"),
                "note": titan.get("oi_note", "") or titan.get("funding_note", ""),
                "label": (
                    "ورود نهنگ / افزایش موقعیت" if safe_float(derivatives.get("oi_delta"), 0) > 1.5
                    else "خروج نقدینگی" if safe_float(derivatives.get("oi_delta"), 0) < -1.5
                    else "رفتار خنثی نهنگ"
                ),
            },
            "sentiment": {
                "rsi": round(rsi, 1),
                "rsi_note": titan.get("rsi_note", ""),
                "funding_note": titan.get("funding_note", ""),
                "score": score_int,
                "label": "مثبت" if score_int >= 60 else "منفی" if score_int <= 40 else "خنثی",
            },
            "data_quality": fusion.get("data_quality") if isinstance(fusion, dict) else {},
            "entry_ladder": fusion.get("entry_ladder") if isinstance(fusion, dict) else {},
            "meta_v8": fusion.get("meta_v8") if isinstance(fusion, dict) else {},
            "neural_v9": fusion.get("neural_v9") if isinstance(fusion, dict) else {},
            "neural_score": (fusion.get("neural_v9") or {}).get("neural_score") if isinstance(fusion, dict) else None,
            "neural_confidence": (fusion.get("neural_v9") or {}).get("confidence") if isinstance(fusion, dict) else None,
            "signal_grade": signal_grade if isinstance(signal_grade, dict) else (fusion.get("signal_grade") if isinstance(fusion, dict) else {}),
            "grade": (signal_grade.get("grade") if isinstance(signal_grade, dict) else None) or "—",
            "grade_label": (signal_grade.get("label_fa") if isinstance(signal_grade, dict) else None) or "—",
            "grade_action": (signal_grade.get("action") if isinstance(signal_grade, dict) else None) or "—",
            "trust_index": (signal_grade.get("trust_index") if isinstance(signal_grade, dict) else None) or 0,
            "grade_checklist": (signal_grade.get("checklist") if isinstance(signal_grade, dict) else None) or [],
            "forecast_accuracy": fusion.get("forecast_accuracy") if isinstance(fusion, dict) else {},
            "param_version": TITAN_PARAM_VERSION,
            "confidence_gates": {
                "dq_veto": bool(isinstance(fusion, dict) and fusion.get("dq_veto")),
                "ladder_veto": bool(isinstance(fusion, dict) and fusion.get("ladder_veto")),
                "forecast_veto": bool(isinstance(fusion, dict) and fusion.get("forecast_veto")),
                "portfolio_veto": bool(isinstance(fusion, dict) and fusion.get("portfolio_veto")),
                "precision_veto": bool(isinstance(fusion, dict) and fusion.get("precision_veto")),
                "neural_veto": bool(isinstance(fusion, dict) and (fusion.get("neural_v9") or {}).get("side") == "WAIT" and decision_tag in {"LONG", "SHORT"}),
            },
        }
    except Exception as exc:
        LOGGER.exception("analyze_asset failed for %s: %s", symbol, exc)
        return None


# ============================================================
# TITAN PROFESSIONAL EDGE SUITE - 12 ADDITIVE MODULES
# No external dependency. Every module is fail-safe and analysis-only.
# ============================================================

class TitanProfessionalEdgeSuite:
    """Twelve professional research layers wired into the existing TITAN pipeline.

    1) Signal Confluence Engine
    2) Regime Detection Engine
    3) Liquidity / Order-Flow Proxy
    4) Market Structure Engine
    5) Walk-Forward / OOS validator
    6) Strategy Laboratory
    7) Meta-Labeling
    8) Adaptive Risk Engine
    9) Drawdown Governor
    10) AI Ensemble Consensus
    11) Counterfactual Engine
    12) Decision Terminal payload builder

    The engine is deliberately dependency-free and conservative: missing market/API data
    lowers confidence instead of inventing values. It never executes real orders.
    """

    def __init__(self):
        self.name = "TITAN PROFESSIONAL EDGE SUITE"
        self.memory_path = MEMORY_DIR / "professional_edge_memory.json"
        self.memory = self._load_memory()

    def _load_memory(self):
        try:
            data = _load_json(self.memory_path, {})
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _save_memory(self):
        try:
            _save_json(self.memory_path, self.memory)
        except Exception as exc:
            LOGGER.debug("Professional edge memory save skipped: %s", exc)

    # 1) Signal Confluence Engine
    def signal_confluence(self, *, score=50, alignment=50, rsi=50, price=0, vwap=0,
                          ema20=0, ema50=0, volume_spike=False, derivatives=None,
                          structure=None, regime="unknown"):
        derivatives = derivatives or {}
        structure = structure or {}
        checks = []
        points = []
        if score >= 60:
            checks.append(("momentum", 1)); points.append("مومنتوم صعودی")
        elif score <= 40:
            checks.append(("momentum", 1)); points.append("مومنتوم نزولی")
        else:
            checks.append(("momentum", 0))
        checks.append(("mtf", clamp(alignment / 100.0, 0, 1)))
        if price and vwap:
            checks.append(("vwap", 1 if (score >= 60 and price >= vwap) or (score <= 40 and price <= vwap) else 0.35))
        if ema20 and ema50:
            ema_ok = 1 if (score >= 60 and ema20 >= ema50) or (score <= 40 and ema20 <= ema50) else 0.25
            checks.append(("trend", ema_ok))
        checks.append(("volume", 1.0 if volume_spike else 0.4))
        oi = safe_float(derivatives.get("oi_delta"), 0)
        funding = safe_float(derivatives.get("funding_value"), 0)
        oi_score = 0.55
        if score >= 60 and oi > 0: oi_score = 0.9
        elif score <= 40 and oi > 0: oi_score = 0.8
        elif oi < 0: oi_score = 0.4
        checks.append(("open_interest", oi_score))
        structure_score = safe_float(structure.get("confirmation_score"), 50) / 100.0
        checks.append(("structure", clamp(structure_score, 0, 1)))
        regime_bonus = 1.0 if regime not in {"range", "unknown"} else 0.65
        checks.append(("regime", regime_bonus))
        raw = sum(v for _, v in checks) / max(1, len(checks))
        confluence = int(round(clamp(35 + raw * 65, 0, 100)))
        disagreement = [name for name, val in checks if val < 0.5]
        return {"score": confluence, "components": {k: round(float(v), 3) for k, v in checks},
                "disagreements": disagreement, "label": "STRONG CONFLUENCE" if confluence >= 80 else "CONFIRMED" if confluence >= 68 else "WATCH"}

    # 2) Regime Detection Engine
    def regime_detection(self, df, atr=None, score=50):
        try:
            close = df["close"].astype(float)
            if len(close) < 60: return {"regime": "unknown", "confidence": 0, "features": {}}
            ret20 = float(close.iloc[-1] / close.iloc[-21] - 1) if len(close) > 21 else 0.0
            ret5 = float(close.iloc[-1] / close.iloc[-6] - 1) if len(close) > 6 else 0.0
            atr_pct = float(atr / close.iloc[-1] * 100) if atr is not None and close.iloc[-1] else 0.0
            ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
            ema50 = float(close.ewm(span=50, adjust=False).mean().iloc[-1])
            slope = abs(ret20) * 100
            if atr_pct >= 4.5:
                regime = "high_volatility"
            elif ret20 > 0.05 and ema20 > ema50 and slope > 1.5:
                regime = "trend_up"
            elif ret20 < -0.05 and ema20 < ema50 and slope > 1.5:
                regime = "trend_down"
            elif abs(ret5) > 0.02 and abs(ret20) < 0.04:
                regime = "breakout_watch"
            elif atr_pct < 1.2 and abs(ret20) < 0.025:
                regime = "range"
            else:
                regime = "transition"
            score_fit = 100 - min(80, abs((score - 50) - (20 if "up" in regime else -20 if "down" in regime else 0)) * 1.8)
            return {"regime": regime, "confidence": int(round(clamp(score_fit, 20, 95))),
                    "features": {"ret5_pct": round(ret5*100,3), "ret20_pct": round(ret20*100,3), "atr_pct": round(atr_pct,3), "ema_spread_pct": round((ema20/ema50-1)*100,3) if ema50 else 0}}
        except Exception as exc:
            LOGGER.debug("Regime detection failed: %s", exc)
            return {"regime": "unknown", "confidence": 0, "features": {}}

    # 3) Liquidity / Order-Flow Proxy
    def liquidity_map(self, df, current_price):
        try:
            data = df.tail(60).copy()
            price = float(current_price)
            if data.empty or price <= 0: raise ValueError("invalid liquidity input")
            vol = pd.to_numeric(data["vol"], errors="coerce").fillna(0)
            high_vol = data.loc[vol.nlargest(min(8, len(vol))).index]
            upper = float(high_vol["high"].median()) if not high_vol.empty else price
            lower = float(high_vol["low"].median()) if not high_vol.empty else price
            ranges = {"upper_pool": round(upper, 8), "lower_pool": round(lower, 8),
                      "upper_distance_pct": round((upper/price-1)*100,3),
                      "lower_distance_pct": round((lower/price-1)*100,3)}
            if upper > price * 1.003 and lower < price * 0.997:
                state = "balanced_liquidity"
            elif upper > price * 1.01:
                state = "overhead_liquidity"
            elif lower < price * 0.99:
                state = "downside_liquidity"
            else:
                state = "compressed"
            # buy/sell pressure proxy from candle location + volume
            clv = ((data["close"] - data["low"]) - (data["high"] - data["close"])) / (data["high"] - data["low"]).replace(0, np.nan)
            pressure = float((clv.fillna(0) * vol).sum() / max(float(vol.sum()), 1.0))
            return {"state": state, "pressure": round(pressure, 3), "map": ranges,
                    "liquidity_bias": "buying" if pressure > 0.12 else "selling" if pressure < -0.12 else "balanced"}
        except Exception as exc:
            LOGGER.debug("Liquidity map failed: %s", exc)
            return {"state": "unavailable", "pressure": 0, "map": {}, "liquidity_bias": "unknown"}

    # 4) Market Structure Engine
    def market_structure(self, df):
        try:
            d = df.tail(80).copy()
            highs = d["high"].rolling(5, center=True).max()
            lows = d["low"].rolling(5, center=True).min()
            swing_highs = d.loc[(d["high"] == highs).fillna(False), "high"].tail(6).tolist()
            swing_lows = d.loc[(d["low"] == lows).fillna(False), "low"].tail(6).tolist()
            last = float(d["close"].iloc[-1])
            recent_high = max(swing_highs[-3:]) if swing_highs else float(d["high"].tail(20).max())
            recent_low = min(swing_lows[-3:]) if swing_lows else float(d["low"].tail(20).min())
            prev_high = swing_highs[-4] if len(swing_highs) >= 4 else recent_high
            prev_low = swing_lows[-4] if len(swing_lows) >= 4 else recent_low
            higher_high = recent_high > prev_high
            higher_low = recent_low > prev_low
            lower_high = recent_high < prev_high
            lower_low = recent_low < prev_low
            if last > recent_high * 1.001:
                event = "BOS_UP"
            elif last < recent_low * 0.999:
                event = "BOS_DOWN"
            elif higher_high and higher_low:
                event = "BULL_STRUCTURE"
            elif lower_high and lower_low:
                event = "BEAR_STRUCTURE"
            else:
                event = "RANGE_STRUCTURE"
            confirmation = 80 if event in {"BOS_UP", "BOS_DOWN"} else 72 if event in {"BULL_STRUCTURE", "BEAR_STRUCTURE"} else 48
            return {"event": event, "last": round(last, 8), "swing_high": round(recent_high, 8), "swing_low": round(recent_low, 8), "confirmation_score": confirmation,
                    "bias": "صعودی" if event in {"BOS_UP", "BULL_STRUCTURE"} else "نزولی" if event in {"BOS_DOWN", "BEAR_STRUCTURE"} else "خنثی"}
        except Exception as exc:
            LOGGER.debug("Market structure failed: %s", exc)
            return {"event": "UNKNOWN", "confirmation_score": 0, "bias": "خنثی"}

    # 5) Walk-forward / OOS validation helper
    def out_of_sample_check(self, returns, min_samples=30, return_unit="pct"):
        arr = np.asarray(returns, dtype=float)
        arr = arr[np.isfinite(arr)]
        if arr.size < min_samples:
            return {"samples": int(arr.size), "oos_expectancy": 0.0, "oos_win_rate": 0.0,
                    "train_expectancy": 0.0, "status": "insufficient", "min_samples": int(min_samples),
                    "return_unit": return_unit}
        split = min(max(int(arr.size * 0.7), 10), arr.size - 10)
        train, test = arr[:split], arr[split:]
        decisive = test[test != 0]
        wins = int((decisive > 0).sum()); losses = int((decisive < 0).sum())
        return {"samples": int(test.size), "oos_expectancy": round(float(test.mean()), 4),
                "oos_win_rate": round(wins / (wins + losses) * 100, 2) if wins + losses else 0.0,
                "train_expectancy": round(float(train.mean()), 4), "status": "ok",
                "min_samples": int(min_samples), "return_unit": return_unit}

    # 6) Strategy Laboratory
    def strategy_lab(self, df, horizon=3, min_signals=30):
        strategies = {}
        try:
            close = pd.to_numeric(df["close"], errors="coerce")
            ema20 = close.ewm(span=20, adjust=False).mean(); ema50 = close.ewm(span=50, adjust=False).mean()
            rsi = wilder_rsi(close)
            signal_map = {
                "trend": np.where(ema20 > ema50, 1, np.where(ema20 < ema50, -1, 0)),
                "momentum": np.where(rsi > 55, 1, np.where(rsi < 45, -1, 0)),
                "breakout": np.where(close > close.rolling(20).max().shift(1), 1, np.where(close < close.rolling(20).min().shift(1), -1, 0)),
                "mean_reversion": np.where(rsi < 30, 1, np.where(rsi > 70, -1, 0)),
            }
            for name, signal in signal_map.items():
                sig = pd.Series(signal, index=df.index).fillna(0).astype(float)
                future = close.shift(-horizon) / close - 1.0
                raw = (future * sig * 100.0) - (TOTAL_ENTRY_BUFFER * 2.0 * 100.0)
                valid = raw[(sig != 0) & future.notna()].replace([np.inf, -np.inf], np.nan).dropna()
                metrics = _safe_return_series(valid.tolist(), return_unit="pct")
                strategies[name] = {
                    "signals": int((sig != 0).sum()), "complete_signals": int(valid.size),
                    "win_rate": metrics["win_rate"], "loss_rate": metrics["loss_rate"],
                    "expectancy_pct": metrics["expectancy"], "profit_factor": metrics["profit_factor"],
                    "max_drawdown_pct": metrics["max_drawdown"], "max_losing_streak": metrics["max_losing_streak"],
                }
            eligible = [(n,v) for n,v in strategies.items() if v["complete_signals"] >= min_signals]
            leader = max(eligible, key=lambda kv: kv[1]["expectancy_pct"], default=(None, {}))
            return {"strategies": strategies, "leader": leader[0], "leader_expectancy_pct": leader[1].get("expectancy_pct",0),
                    "horizon_bars": int(horizon), "min_signals": int(min_signals), "cost_model": "round_trip_fee+spread+slippage"}
        except Exception as exc:
            LOGGER.debug("Strategy lab failed: %s", exc)
            return {"strategies": {}, "leader": None, "leader_expectancy_pct": 0, "horizon_bars": int(horizon), "min_signals": int(min_signals)}

    # 7) Meta-Labeling
    def meta_label(self, confluence, quality, historical_win_rate=0):
        base = 0.45 * confluence + 0.35 * quality + 0.20 * clamp(historical_win_rate, 0, 100)
        probability = clamp(base, 0, 100)
        label = "ACCEPT" if probability >= 72 else "WATCH" if probability >= 58 else "REJECT"
        return {"probability": round(probability,2), "label": label}

    # 8) Adaptive Risk Engine
    def adaptive_risk(self, base_risk=1.0, volatility_pct=1.0, confidence=50, regime="unknown", drawdown_pct=0):
        factor = 1.0
        if volatility_pct > 4: factor *= 0.55
        elif volatility_pct > 2.5: factor *= 0.75
        elif volatility_pct < 0.8: factor *= 1.05
        if confidence < 60: factor *= 0.75
        elif confidence > 80: factor *= 1.05
        if regime in {"high_volatility", "transition"}: factor *= 0.75
        if drawdown_pct > 10: factor *= 0.45
        elif drawdown_pct > 5: factor *= 0.65
        return {"base_risk_pct": round(base_risk,3), "risk_pct": round(clamp(base_risk*factor,0.1,2.5),3), "factor": round(factor,3)}

    # 9) Drawdown Governor
    def drawdown_governor(self, values, unit="r"):
        arr = np.asarray(values, dtype=float); arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return {"state": "NORMAL", "drawdown_pct": 0.0, "risk_multiplier": 1.0, "unit": unit, "observations": 0}
        account_returns = arr / 100.0 if unit == "pct" else arr * 0.01
        account_returns = np.clip(account_returns, -0.999, 10.0)
        equity = np.cumprod(1.0 + account_returns)
        peak = np.maximum.accumulate(equity)
        dd_pct = float(np.max((peak - equity) / np.maximum(peak, 1e-12)) * 100.0)
        if dd_pct >= 15: state, mult = "DEFENSIVE", 0.35
        elif dd_pct >= 10: state, mult = "REDUCED", 0.55
        elif dd_pct >= 5: state, mult = "CAUTIOUS", 0.75
        else: state, mult = "NORMAL", 1.0
        return {"state": state, "drawdown_pct": round(dd_pct,3), "risk_multiplier": mult, "unit": unit, "observations": int(arr.size)}

    # 10) AI Ensemble Consensus
    def ai_ensemble(self, ai_opinions, titan_bias):
        mapping = {"صعودی": "LONG", "نزولی": "SHORT", "خنثی": "WAIT"}
        target = mapping.get(titan_bias, "WAIT")
        votes = []; providers = []; details = {}
        import re
        final_re = re.compile(r"نتیجه\s*نهایی\s*[:：-]?\s*(صعودی|نزولی|انتظار|خنثی)", re.I)
        for provider, raw_text in (ai_opinions or {}).items():
            if provider in {"ai_status", "providers", "internal", "titan"} or not isinstance(raw_text, str):
                continue
            text = raw_text.strip(); t = text.lower()
            if not text:
                continue
            # Prefer the explicitly requested final label. Keyword fallback only uses the
            # tail of the answer, reducing false votes when both bull/bear risks are discussed.
            matches = final_re.findall(text)
            if matches:
                lab = matches[-1]
                vote = "LONG" if lab == "صعودی" else "SHORT" if lab == "نزولی" else "WAIT"
            else:
                tail = t[-320:]
                long_hits = sum(tail.count(k) for k in ("صعودی", "bull", "long", "خرید"))
                short_hits = sum(tail.count(k) for k in ("نزولی", "bear", "short", "فروش"))
                vote = "LONG" if long_hits > short_hits else "SHORT" if short_hits > long_hits else "WAIT"
            votes.append(vote); providers.append(provider)
            details[provider] = {"vote": vote, "snippet": (text[:180] + "…") if len(text) > 180 else text}
        total = len(votes)
        agree = sum(v == target for v in votes)
        long_n = votes.count("LONG"); short_n = votes.count("SHORT"); wait_n = votes.count("WAIT")
        majority = "LONG" if long_n > short_n and long_n > wait_n else "SHORT" if short_n > long_n and short_n > wait_n else "WAIT"
        majority_n = max(long_n, short_n, wait_n) if total else 0
        return {
            "target": target, "votes": dict(zip(providers, votes)), "details": details,
            "agreement": round(agree / total * 100, 1) if total else 0.0,
            "majority_agreement": round(majority_n / total * 100, 1) if total else 0.0,
            "providers": total, "tally": {"LONG": long_n, "SHORT": short_n, "WAIT": wait_n},
            "majority": majority,
            "status": "CONSENSUS" if total and majority_n / total >= 0.66 else "MIXED" if total else "NO_AI_DATA",
        }

    # 11) Counterfactual Engine
    def counterfactual(self, price, sl, tp1, tp2, direction, future_prices):
        result = {"path": "NONE", "bars_to_tp1": None, "bars_to_tp2": None, "bars_to_sl": None, "mae_pct": 0.0, "mfe_pct": 0.0}
        try:
            future = [float(x) for x in future_prices if float(x) > 0]
            if not future or price <= 0: return result
            signed = [((x-price)/price*100) * (1 if direction != "نزولی" else -1) for x in future]
            result["mfe_pct"] = round(max(signed), 3); result["mae_pct"] = round(min(signed), 3)
            tp1_hit = (tp1 > price and any(x >= tp1 for x in future)) if direction != "نزولی" else any(x <= tp1 for x in future)
            tp2_hit = (tp2 > price and any(x >= tp2 for x in future)) if direction != "نزولی" else any(x <= tp2 for x in future)
            sl_hit = any(x <= sl for x in future) if direction != "نزولی" else any(x >= sl for x in future)
            if tp2_hit: result["path"] = "TP2"
            elif tp1_hit: result["path"] = "TP1"
            elif sl_hit: result["path"] = "SL"
            if tp1_hit:
                result["bars_to_tp1"] = next(i+1 for i,x in enumerate(future) if (x >= tp1 if direction != "نزولی" else x <= tp1))
            if tp2_hit:
                result["bars_to_tp2"] = next(i+1 for i,x in enumerate(future) if (x >= tp2 if direction != "نزولی" else x <= tp2))
            if sl_hit:
                result["bars_to_sl"] = next(i+1 for i,x in enumerate(future) if (x <= sl if direction != "نزولی" else x >= sl))
            return result
        except Exception:
            return result

    # 12) Decision Terminal
    def decision_terminal(self, item):
        edge = item.get("edge") or {}
        return {
            "symbol": item.get("symbol"), "price": item.get("price"), "bias": item.get("bias"),
            "decision_tag": item.get("decision_tag") or edge.get("decision_tag") or "WAIT",
            "regime": (edge.get("regime") or {}).get("regime", "unknown"),
            "market_risk": (edge.get("risk") or {}).get("risk_pct", 0),
            "liquidity": (edge.get("liquidity") or {}).get("state", "unknown"),
            "structure": (edge.get("structure") or {}).get("event", "unknown"),
            "structure_bias": (edge.get("structure") or {}).get("bias", "خنثی"),
            "confluence": (edge.get("confluence") or {}).get("score", 0),
            "confluence_label": (edge.get("confluence") or {}).get("label", ""),
            "meta_probability": (edge.get("meta") or {}).get("probability", 0),
            "meta_label": (edge.get("meta") or {}).get("label", "WATCH"),
            "ai_consensus": (edge.get("ai") or {}).get("agreement", 0),
            "ai_status": (edge.get("ai") or {}).get("status", "NO_AI_DATA"),
            "risk_reward_1": item.get("rr_tp1"), "risk_reward_2": item.get("rr_tp2"),
            "setup_quality": item.get("signal_quality"), "signal_tag": item.get("signal_tag"),
            "governor": (edge.get("governor") or {}).get("state", "NORMAL"),
            "final_state": (edge.get("meta") or {}).get("label", "WATCH"),
        }

    def register_observation(self, item):
        try:
            key = str(item.get("symbol"))
            bucket = self.memory.setdefault("symbols", {}).setdefault(key, {"observations":0,"quality_sum":0.0,"wins":0,"losses":0})
            bucket["observations"] += 1
            bucket["quality_sum"] += safe_float(item.get("signal_quality"), 0)
            self._save_memory()
        except Exception:
            pass

    def historical_win_rate_for_item(self, item):
        try:
            with DB_LOCK, db_conn() as con:
                row = con.execute("SELECT trades,wins FROM setup_stats WHERE setup_key LIKE ? ORDER BY trades DESC LIMIT 1", (f"%{item.get('bias')}%",)).fetchone()
            if row and row[0]: return float(row[1]/row[0]*100)
        except Exception:
            pass
        return 0.0



# ============================================================
# TITAN ADAPTIVE INTELLIGENCE — self-correcting weights & fusion
# Learns from forecast outcomes + AI disagreement patterns.
# ============================================================

class TitanAdaptiveIntelligence:
    """Professional calibration layer.

    Goals:
    - Reduce LONG/SHORT mismatch between quant core and AI ensemble
    - Raise success rate by demanding multi-layer agreement
    - Learn from past WIN/LOSS and shift weights so repeated mistakes fade
    - Never invent edge: disagreement → WAIT unless history strongly favors one side
    """

    def __init__(self):
        self.path = MEMORY_DIR / "adaptive_calibration.json"
        self.state = self._load()

    def _default(self) -> dict[str, Any]:
        return {
            "version": 4,
            "updated_at": 0.0,
            "global": {
                "long_wins": 0, "long_losses": 0,
                "short_wins": 0, "short_losses": 0,
                "ai_agree_wins": 0, "ai_agree_losses": 0,
                "ai_disagree_wins": 0, "ai_disagree_losses": 0,
            },
            "weights": {
                "quant": 0.24,
                "structure": 0.16,
                "regime": 0.12,
                "confluence": 0.14,
                "ai": 0.28,
                "history": 0.06,
            },
            "thresholds": {
                "long_score": 54.0,
                "short_score": 46.0,
                "min_alignment": 50.0,
                "min_confluence": 54.0,
                "ai_consensus_pct": 55.0,
                "promote_score_buffer": 6.0,
            },
            "symbols": {},
            "error_patterns": {
                "false_long": 0,
                "false_short": 0,
                "ignored_ai_long": 0,
                "ignored_ai_short": 0,
            },
        }

    def _load(self) -> dict[str, Any]:
        data = _load_json(self.path, {})
        base = self._default()
        if not isinstance(data, dict):
            return base
        for k, v in base.items():
            if k not in data:
                data[k] = v
            elif isinstance(v, dict) and isinstance(data.get(k), dict):
                for kk, vv in v.items():
                    data[k].setdefault(kk, vv)
        return data

    def _save(self) -> None:
        try:
            self.state["updated_at"] = time.time()
            _save_json(self.path, self.state)
        except Exception as exc:
            LOGGER.debug("adaptive save skipped: %s", exc)

    def _wr(self, wins: float, losses: float) -> float:
        # Beta(2,2) shrinkage prevents 1-3 lucky outcomes from becoming 0%/100% reliability.
        wins = max(0.0, float(wins)); losses = max(0.0, float(losses))
        return ((wins + 2.0) / (wins + losses + 4.0)) * 100.0

    def refresh_from_db(self) -> None:
        """Rebuild calibration memory from DB exactly once per stored outcome.

        The previous implementation reset global counters but kept per-symbol buckets,
        causing the same history to be counted again on every restart/refresh.
        """
        try:
            with DB_LOCK, db_conn() as con:
                rows = con.execute(
                    "SELECT symbol,direction,outcome,ai_majority FROM forecasts "
                    "WHERE outcome IN ('WIN','LOSS') ORDER BY id DESC LIMIT 400"
                ).fetchall()
            self.state["global"] = dict(self._default()["global"])
            self.state["symbols"] = {}
            self.state["error_patterns"] = dict(self._default()["error_patterns"])
            g = self.state["global"]
            for row in rows:
                direction = str(row["direction"]); outcome = str(row["outcome"]); symbol = str(row["symbol"])
                ai_maj = str(row["ai_majority"] or "")
                is_long = direction in {"صعودی", "LONG", "long"}
                is_short = direction in {"نزولی", "SHORT", "short"}
                win = outcome == "WIN"
                if is_long:
                    g["long_wins" if win else "long_losses"] += 1
                elif is_short:
                    g["short_wins" if win else "short_losses"] += 1
                bucket = self.state["symbols"].setdefault(
                    symbol, {"long_wins": 0, "long_losses": 0, "short_wins": 0, "short_losses": 0}
                )
                if is_long:
                    bucket["long_wins" if win else "long_losses"] += 1
                elif is_short:
                    bucket["short_wins" if win else "short_losses"] += 1
                ai_long = ai_maj in {"LONG", "صعودی"}; ai_short = ai_maj in {"SHORT", "نزولی"}
                has_ai = ai_long or ai_short
                ai_agreed = has_ai and ((is_long and ai_long) or (is_short and ai_short))
                if has_ai:
                    g["ai_agree_wins" if (ai_agreed and win) else
                      "ai_agree_losses" if ai_agreed else
                      "ai_disagree_wins" if win else "ai_disagree_losses"] += 1
                    if not win and not ai_agreed:
                        if is_long: self.state["error_patterns"]["false_long"] += 1
                        if is_short: self.state["error_patterns"]["false_short"] += 1
            self._rebalance_weights()
            self._save()
        except Exception as exc:
            LOGGER.debug("adaptive refresh failed: %s", exc)

    def record_outcome(
        self,
        *,
        symbol: str,
        direction: str,
        outcome: str,
        ai_agreed: bool = True,
        quant_was_long: bool = False,
        quant_was_short: bool = False,
    ) -> None:
        g = self.state["global"]
        is_long = direction in {"صعودی", "LONG", "long"}
        is_short = direction in {"نزولی", "SHORT", "short"}
        win = outcome == "WIN"
        loss = outcome == "LOSS"
        if not (win or loss):
            return
        if is_long:
            g["long_wins" if win else "long_losses"] += 1
        elif is_short:
            g["short_wins" if win else "short_losses"] += 1
        if ai_agreed:
            g["ai_agree_wins" if win else "ai_agree_losses"] += 1
        else:
            g["ai_disagree_wins" if win else "ai_disagree_losses"] += 1
            if loss and is_long:
                self.state["error_patterns"]["false_long"] = int(self.state["error_patterns"].get("false_long", 0)) + 1
            if loss and is_short:
                self.state["error_patterns"]["false_short"] = int(self.state["error_patterns"].get("false_short", 0)) + 1
            # Track when quant ignored AI and lost
            if loss and quant_was_long and not is_long:
                pass
            if loss and not ai_agreed:
                if is_long:
                    self.state["error_patterns"]["ignored_ai_short"] = int(self.state["error_patterns"].get("ignored_ai_short", 0)) + 1
                if is_short:
                    self.state["error_patterns"]["ignored_ai_long"] = int(self.state["error_patterns"].get("ignored_ai_long", 0)) + 1
        bucket = self.state["symbols"].setdefault(
            symbol, {"long_wins": 0, "long_losses": 0, "short_wins": 0, "short_losses": 0}
        )
        if is_long:
            bucket["long_wins" if win else "long_losses"] += 1
        elif is_short:
            bucket["short_wins" if win else "short_losses"] += 1
        self._rebalance_weights()
        self._save()

    def _rebalance_weights(self) -> None:
        """Self-tune layer weights and thresholds from observed WIN/LOSS patterns."""
        g = self.state["global"]
        long_wr = self._wr(g["long_wins"], g["long_losses"])
        short_wr = self._wr(g["short_wins"], g["short_losses"])
        agree_n = g["ai_agree_wins"] + g["ai_agree_losses"]
        disagree_n = g["ai_disagree_wins"] + g["ai_disagree_losses"]
        agree_wr = self._wr(g["ai_agree_wins"], g["ai_agree_losses"])
        disagree_wr = self._wr(g["ai_disagree_wins"], g["ai_disagree_losses"])
        # Recompute from stable defaults; do not ratchet thresholds/weights merely because
        # this method is called repeatedly with the same observations.
        defaults = self._default()
        w = dict(defaults["weights"])
        th = dict(defaults["thresholds"])
        ep = self.state["error_patterns"]

        # When trades that agreed with AI win more → increase AI weight
        if agree_n >= 5 and agree_wr >= disagree_wr + 6:
            w["ai"] = min(0.38, float(w.get("ai", 0.26)) + 0.025)
            w["quant"] = max(0.16, float(w.get("quant", 0.26)) - 0.015)
            w["confluence"] = min(0.18, float(w.get("confluence", 0.14)) + 0.005)
        elif disagree_n >= 5 and disagree_wr > agree_wr + 8:
            # Rare: quant alone better — small quant bump but keep AI gate
            w["quant"] = min(0.32, float(w.get("quant", 0.26)) + 0.015)
            w["ai"] = max(0.18, float(w.get("ai", 0.26)) - 0.01)

        # False long epidemic → harder long threshold, more structure weight
        if ep.get("false_long", 0) >= 4 and long_wr < 48:
            th["long_score"] = min(70.0, float(th.get("long_score", 58)) + 1.2)
            th["min_confluence"] = min(78.0, float(th.get("min_confluence", 62)) + 1.0)
            w["structure"] = min(0.24, float(w.get("structure", 0.16)) + 0.01)
            w["quant"] = max(0.15, float(w.get("quant", 0.26)) - 0.01)
        if ep.get("false_short", 0) >= 4 and short_wr < 48:
            th["short_score"] = max(30.0, float(th.get("short_score", 42)) - 1.2)
            th["min_confluence"] = min(78.0, float(th.get("min_confluence", 62)) + 1.0)
            w["structure"] = min(0.24, float(w.get("structure", 0.16)) + 0.01)

        # Good side performance → slightly easier barriers
        if (g["long_wins"] + g["long_losses"]) >= 10 and long_wr >= 58:
            th["long_score"] = max(54.0, float(th.get("long_score", 58)) - 0.6)
        if (g["short_wins"] + g["short_losses"]) >= 10 and short_wr >= 58:
            th["short_score"] = min(46.0, float(th.get("short_score", 42)) + 0.6)

        # Normalize weights
        total = sum(float(v) for v in w.values()) or 1.0
        self.state["weights"] = {k: round(float(v) / total, 4) for k, v in w.items()}
        self.state["thresholds"] = th

    def side_reliability(self, symbol: str = "") -> dict[str, float]:
        g = self.state["global"]
        long_wr = self._wr(g["long_wins"], g["long_losses"])
        short_wr = self._wr(g["short_wins"], g["short_losses"])
        sym = self.state["symbols"].get(symbol) or {}
        if (sym.get("long_wins", 0) + sym.get("long_losses", 0)) >= 4:
            long_wr = 0.55 * long_wr + 0.45 * self._wr(sym["long_wins"], sym["long_losses"])
        if (sym.get("short_wins", 0) + sym.get("short_losses", 0)) >= 4:
            short_wr = 0.55 * short_wr + 0.45 * self._wr(sym["short_wins"], sym["short_losses"])
        return {
            "long_wr": round(long_wr, 2),
            "short_wr": round(short_wr, 2),
            "long_samples": int(g["long_wins"] + g["long_losses"]),
            "short_samples": int(g["short_wins"] + g["short_losses"]),
        }

    def fuse_decision(
        self,
        *,
        symbol: str,
        quant_bias: str,
        score: float,
        alignment: float,
        structure: dict[str, Any],
        regime: dict[str, Any],
        confluence: dict[str, Any],
        meta: dict[str, Any],
        ai_ensemble: dict[str, Any],
        forecast: Optional[dict[str, Any]] = None,
        patterns: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Professional multi-layer fusion — TITAN ↔ AI ↔ forecast ↔ patterns.

        Rules (priority):
        1) Strong AI↔quant disagreement → WAIT (do not force a side)
        2) AI consensus can promote borderline quant only with structure/confluence support
        3) Historical false-long / false-short raises the bar for that side
        4) Success probability must clear a floor before LONG/SHORT leaves WAIT
        5) Weights self-tune from past WIN/LOSS via _rebalance_weights
        6) 12-candle forecast path and chart patterns vote as soft directional layers
        """
        w = dict(self.state.get("weights") or {})
        th = dict(self.state.get("thresholds") or {})
        # Ensure weight keys exist and normalize
        for k, default in (("quant", 0.26), ("structure", 0.16), ("regime", 0.12),
                           ("confluence", 0.14), ("ai", 0.26), ("history", 0.06)):
            w[k] = float(w.get(k, default))
        ssum = sum(w.values()) or 1.0
        w = {k: v / ssum for k, v in w.items()}

        rel = self.side_reliability(symbol)
        struct_bias = str((structure or {}).get("bias", "خنثی"))
        regime_name = str((regime or {}).get("regime", "unknown"))
        conf = safe_float((confluence or {}).get("score"), 50)
        meta_prob = safe_float((meta or {}).get("probability"), 50)
        meta_label = str((meta or {}).get("label", "WATCH"))
        ai_majority = str((ai_ensemble or {}).get("majority", "WAIT"))
        ai_target_agree = safe_float((ai_ensemble or {}).get("agreement"), 0)
        ai_agree = safe_float((ai_ensemble or {}).get("majority_agreement"), ai_target_agree)
        ai_status = str((ai_ensemble or {}).get("status", "NO_AI_DATA"))
        ai_providers = int((ai_ensemble or {}).get("providers", 0) or 0)
        tally = (ai_ensemble or {}).get("tally") or {}
        errors = self.state.get("error_patterns") or {}

        def dir_score(label: str) -> float:
            lab = str(label or "")
            if lab in {"صعودی", "LONG", "trend_up", "BOS_UP", "BULL_STRUCTURE"} or "up" in lab.lower():
                return 1.0
            if lab in {"نزولی", "SHORT", "trend_down", "BOS_DOWN", "BEAR_STRUCTURE"} or "down" in lab.lower():
                return -1.0
            return 0.0

        quant_cont = clamp((float(score) - 50.0) / 50.0, -1.0, 1.0)
        quant_d = dir_score(quant_bias) if quant_bias != "خنثی" else quant_cont * 0.5
        struct_d = dir_score(struct_bias)
        regime_d = dir_score(regime_name)
        conf_d = quant_cont if conf >= 58 else quant_cont * 0.35
        ai_d = dir_score(ai_majority)

        hist_d = 0.0
        if rel["long_wr"] >= rel["short_wr"] + 8 and rel["long_samples"] >= 5:
            hist_d = 0.4
        elif rel["short_wr"] >= rel["long_wr"] + 8 and rel["short_samples"] >= 5:
            hist_d = -0.4
        elif rel["long_wr"] < 42 and rel["long_samples"] >= 8:
            hist_d = -0.25  # punish historically bad longs
        elif rel["short_wr"] < 42 and rel["short_samples"] >= 8:
            hist_d = 0.25

        # Forecast + pattern soft votes (do not dominate quant/AI)
        fc = forecast or {}
        fc_d = dir_score(str(fc.get("overall_bias") or ""))
        _fc_acc = forecast_path_accuracy_stats(symbol)
        _fc_scale = safe_float(_fc_acc.get("weight_scale"), 0.35)
        fc_w = (min(0.12, 0.04 + safe_float(fc.get("path_strength"), 0) / 400.0) * _fc_scale) if fc.get("ok") else 0.0
        pat = patterns or {}
        primary = pat.get("primary") or {}
        pat_d = dir_score(str((primary.get("guide") or {}).get("bias") or ""))
        pat_conf = safe_float(primary.get("confidence"), 0) / 100.0
        pat_w = min(0.10, 0.03 + pat_conf * 0.07) if primary else 0.0

        # Renormalize so total weight stays 1.0 after adding soft layers
        base_keys = ("quant", "structure", "regime", "confluence", "ai", "history")
        base_sum = sum(w[k] for k in base_keys) or 1.0
        soft = fc_w + pat_w
        scale = max(0.78, 1.0 - soft)
        for k in base_keys:
            w[k] = w[k] / base_sum * scale
        w["forecast"] = fc_w
        w["pattern"] = pat_w

        fused = (
            w["quant"] * quant_d
            + w["structure"] * struct_d
            + w["regime"] * regime_d
            + w["confluence"] * conf_d
            + w["ai"] * ai_d
            + w["history"] * hist_d
            + w["forecast"] * fc_d
            + w["pattern"] * pat_d
        )
        fused = float(clamp(fused, -1.0, 1.0))
        if fc_d != 0 and fc.get("ok"):
            # mild agreement note later via explanation
            pass

        # Adaptive barriers from learned thresholds + error patterns
        long_barrier = float(th.get("long_score", 58))
        short_barrier = float(th.get("short_score", 42))
        min_align = float(th.get("min_alignment", 58))
        min_conf = float(th.get("min_confluence", 62))
        ai_need = float(th.get("ai_consensus_pct", 55))
        promote_buf = float(th.get("promote_score_buffer", 4))

        # Raise bar if system keeps making false longs/shorts
        fl = int(errors.get("false_long", 0) or 0)
        fs = int(errors.get("false_short", 0) or 0)
        if fl >= 5:
            long_barrier = min(70.0, long_barrier + min(6.0, fl * 0.35))
        if fs >= 5:
            short_barrier = max(30.0, short_barrier - min(6.0, fs * 0.35))

        # Symbol-specific reliability adjusts barriers
        if rel["long_samples"] >= 6 and rel["long_wr"] < 45:
            long_barrier = min(72.0, long_barrier + 3)
        if rel["short_samples"] >= 6 and rel["short_wr"] < 45:
            short_barrier = max(28.0, short_barrier - 3)
        if rel["long_samples"] >= 6 and rel["long_wr"] > 60:
            long_barrier = max(54.0, long_barrier - 2)
        if rel["short_samples"] >= 6 and rel["short_wr"] > 60:
            short_barrier = min(46.0, short_barrier + 2)

        explanation: list[str] = []
        explanation.append(f"هم‌جوشی={fused:+.2f} · وزن AI={w['ai']:.0%} · وزن کمی={w['quant']:.0%}")

        # --- AI alignment gates ---
        quant_side = "LONG" if quant_bias == "صعودی" or score >= 54 else "SHORT" if quant_bias == "نزولی" or score <= 46 else "WAIT"
        ai_conflict = False
        if ai_providers >= 1 and ai_majority in {"LONG", "SHORT"} and quant_side in {"LONG", "SHORT"}:
            if ai_majority != quant_side:
                ai_conflict = True
                explanation.append(f"اختلاف TITAN({quant_side}) با اکثریت هوش‌مصنوعی({ai_majority})")

        # Base technical OK flags (balanced: real edge can pass without extreme fusion)
        long_ok = (
            fused >= 0.10
            and score >= long_barrier
            and alignment >= min_align - 4
            and conf >= min_conf - 12
            and quant_d >= -0.22
        )
        short_ok = (
            fused <= -0.10
            and score <= short_barrier
            and alignment >= min_align - 4
            and conf >= min_conf - 12
            and quant_d <= 0.22
        )

        # Graded AI interaction: AI is a decision partner, not an automatic veto.
        # A single disagreement must not erase a technically strong opportunity.
        # Only a strong AI consensus against a weak quant setup is allowed to veto.
        if ai_conflict and ai_providers >= 1:
            strong_quant_long = quant_side == "LONG" and fused >= 0.30 and conf >= 68 and struct_d >= 0
            strong_quant_short = quant_side == "SHORT" and fused <= -0.30 and conf >= 68 and struct_d <= 0
            hard_ai_veto = ai_agree >= 78 and fused < 0.22 if quant_side == "LONG" else ai_agree >= 78 and fused > -0.22 if quant_side == "SHORT" else False
            if hard_ai_veto and not (strong_quant_long or strong_quant_short):
                if quant_side == "LONG": long_ok = False
                if quant_side == "SHORT": short_ok = False
                explanation.append("اجماع قوی AI خلاف setup ضعیف → عدم ورود")
            else:
                # Keep the quant opportunity alive, but reduce conviction slightly.
                explanation.append("اختلاف AI/TITAN → رأی AI به‌عنوان جریمه وزن‌دار لحاظ شد، نه وتوی کامل")

        # AI majority veto of weak quant
        if ai_providers >= 1 and ai_majority == "SHORT" and ai_agree >= ai_need:
            if long_ok and fused < 0.40:
                long_ok = False
                explanation.append("وتوی فروش هوش مصنوعی روی خرید ضعیف")
        if ai_providers >= 1 and ai_majority == "LONG" and ai_agree >= ai_need:
            if short_ok and fused > -0.40:
                short_ok = False
                explanation.append("وتوی خرید هوش مصنوعی روی فروش ضعیف")

        # AI promotion of borderline setups (only same direction)
        if ai_providers >= 1 and ai_agree >= ai_need:
            if ai_majority == "LONG" and not long_ok:
                if (
                    score >= long_barrier - max(5.0, promote_buf)
                    and alignment >= min_align - 7
                    and fused >= 0.08
                    and struct_d >= -0.10
                    and conf >= 53
                ):
                    long_ok = True
                    explanation.append("ارتقای مرزی خرید با اجماع هوش مصنوعی")
            if ai_majority == "SHORT" and not short_ok:
                if (
                    score <= short_barrier + max(5.0, promote_buf)
                    and alignment >= min_align - 7
                    and fused <= -0.08
                    and struct_d <= 0.10
                    and conf >= 53
                ):
                    short_ok = True
                    explanation.append("ارتقای مرزی فروش با اجماع هوش مصنوعی")

        # Meta-label gate
        if meta_label == "REJECT":
            long_ok = False
            short_ok = False
            explanation.append("متا-برچسب رد → انتظار")

        # Success probability model (0-100)
        base_succ = 50.0
        base_succ += abs(fused) * 22.0
        base_succ += (alignment - 50) * 0.25
        base_succ += (conf - 50) * 0.20
        base_succ += (meta_prob - 50) * 0.15
        if ai_providers >= 1:
            if not ai_conflict:
                base_succ += min(12.0, ai_agree * 0.12)
            else:
                base_succ -= min(15.0, 8 + (100 - ai_agree) * 0.05)
        # Historical calibration is sample-size weighted and Bayesian-shrunk.
        # `success_probability` remains an estimate, not a guaranteed/calibrated market probability.
        side_wr = 50.0; side_n = 0
        if long_ok:
            side_wr, side_n = rel["long_wr"], rel["long_samples"]
        elif short_ok:
            side_wr, side_n = rel["short_wr"], rel["short_samples"]
        hist_weight = min(0.35, max(0.0, side_n) / 60.0 * 0.35)
        base_succ = (1.0 - hist_weight) * base_succ + hist_weight * side_wr
        certainty_cap = 72.0 if side_n < 8 else 80.0 if side_n < 20 else 88.0
        if ai_providers == 0:
            certainty_cap = min(certainty_cap, 76.0)
        success_probability = float(clamp(base_succ, 5, certainty_cap))
        cal_dir = "LONG" if long_ok else "SHORT" if short_ok else ""
        calibration = _probability_calibration(symbol, cal_dir, success_probability)
        calibrated_probability = float(calibration.get("calibrated", success_probability))
        # Blend only partially so sparse historical data cannot dominate the live model.
        if calibration.get("samples", 0) >= 12:
            success_probability = float(clamp(0.55 * success_probability + 0.45 * calibrated_probability, 5, certainty_cap))

        # Hard floor: no directional call without enough estimated success score
        # Opportunity-aware floor: strong multi-factor technical setups can fire even
        # when AI confidence is imperfect. This avoids an always-WAIT system while
        # keeping a minimum quality floor.
        technical_edge = abs(fused) >= 0.28 and alignment >= (min_align - 4) and conf >= (min_conf - 5)
        min_succ = 54.0 if technical_edge else (56.0 if ai_providers >= 1 else 53.0)
        if success_probability < min_succ and not (technical_edge and success_probability >= 52.0):
            if long_ok or short_ok:
                explanation.append(f"احتمال موفقیت {success_probability:.0f}% زیر کف {min_succ:.0f} → انتظار")
            long_ok = False
            short_ok = False

        if long_ok and short_ok:
            decision, final_bias = "WAIT", "خنثی"
            explanation.append("تعارض دوطرفه → انتظار")
        elif long_ok:
            decision, final_bias = "LONG", "صعودی"
            explanation.append(f"تأیید خرید · احتمال≈{success_probability:.0f}%")
        elif short_ok:
            decision, final_bias = "SHORT", "نزولی"
            explanation.append(f"تأیید فروش · احتمال≈{success_probability:.0f}%")
        else:
            decision, final_bias = "WAIT", "خنثی"
            explanation.append("شرایط برای سیگنال جهتی کافی نیست")

        if fc.get("ok") and fc_d != 0:
            agree = (decision == "LONG" and fc_d > 0) or (decision == "SHORT" and fc_d < 0)
            explanation.append(
                f"مسیر {fc.get('horizon', 12)} کندلی: {fc.get('overall_bias')} · "
                f"{'هم‌راستا' if agree else 'ناهم‌راستا'} با تصمیم · قدرت مسیر {safe_float(fc.get('path_strength'), 0):.0f}"
            )
        if primary:
            explanation.append(
                f"الگوی «{primary.get('id')}» (اطمینان {safe_float(primary.get('confidence'), 0):.0f}%) · سوگیری {(primary.get('guide') or {}).get('bias', '—')}"
            )

        return {
            "decision": decision,
            "bias": final_bias,
            "fused_score": round(fused, 4),
            "success_probability": round(success_probability, 1),
            "probability_calibration": calibration,
            "weights": {k: round(v, 4) for k, v in w.items()},
            "thresholds": {
                "long_score": long_barrier,
                "short_score": short_barrier,
                "min_alignment": min_align,
                "min_confluence": min_conf,
                "min_success": min_succ,
            },
            "reliability": rel,
            "ai_majority": ai_majority,
            "ai_agreement": ai_agree,
            "ai_target_agreement": ai_target_agree,
            "ai_conflict": ai_conflict,
            "explanation": explanation,
            "tally": tally,
            "quant_side": quant_side,
        }



TITAN_ADAPTIVE = TitanAdaptiveIntelligence()
try:
    TITAN_ADAPTIVE.refresh_from_db()
except Exception:
    pass



TITAN_EDGE_SUITE = TitanProfessionalEdgeSuite()

def _first_touch_ohlc(window: pd.DataFrame, direction: str, sl: float, tp1: float, tp2: float | None = None) -> tuple[str, str, float | None]:
    """Chronological barrier evaluator using OHLC.

    If SL and TP are both inside the same candle, ordering is unknowable at that
    granularity, so the result is AMBIGUOUS rather than silently choosing a winner.
    """
    if window is None or window.empty or not np.isfinite(sl) or not np.isfinite(tp1):
        return "MISS", "NONE", None
    is_long = direction in {"صعودی", "LONG", "long"}
    is_short = direction in {"نزولی", "SHORT", "short"}
    if not (is_long or is_short):
        return "NEUTRAL", "NONE", None
    for _, bar in window.sort_values("t").iterrows():
        high = safe_float(bar.get("high"), np.nan); low = safe_float(bar.get("low"), np.nan)
        if not (np.isfinite(high) and np.isfinite(low)):
            continue
        sl_hit = low <= sl if is_long else high >= sl
        tp1_hit = high >= tp1 if is_long else low <= tp1
        tp2_hit = False
        if tp2 is not None and np.isfinite(tp2):
            tp2_hit = high >= tp2 if is_long else low <= tp2
        if sl_hit and (tp1_hit or tp2_hit):
            return "AMBIGUOUS", "BOTH_SAME_BAR", None
        if sl_hit:
            return "LOSS", "SL", float(sl)
        if tp2_hit:
            return "WIN", "TP2", float(tp2)
        if tp1_hit:
            return "WIN", "TP1", float(tp1)
    return "MISS", "NONE", None


# ============================================================
# PAPER / FORECAST / METRICS
# ============================================================


def _record_setup_outcome(item: dict[str, Any], pnl_r: float) -> None:
    key = "|".join([str(item.get("bias")), str(item.get("signal_tag")), str(item.get("tfs", {}).get("1h", "")), str(item.get("tfs", {}).get("4h", ""))])
    with DB_LOCK, db_conn() as con:
        row = con.execute("SELECT trades,wins,losses,pnl_r FROM setup_stats WHERE setup_key=?", (key,)).fetchone()
        trades, wins, losses, pnl = tuple(row) if row else (0, 0, 0, 0.0)
        trades += 1
        wins += int(pnl_r > 0); losses += int(pnl_r < 0); pnl += pnl_r
        con.execute("INSERT OR REPLACE INTO setup_stats(setup_key,trades,wins,losses,pnl_r,updated_at) VALUES(?,?,?,?,?,?)", (key, trades, wins, losses, pnl, time.time()))


def calculate_position_size(account_size: float, risk_pct: float, entry: float, stop: float) -> dict[str, float]:
    account = max(0.0, float(account_size)); risk = clamp(float(risk_pct), 0.01, 20.0); distance = abs(entry - stop)
    risk_cash = account * risk / 100.0; quantity = risk_cash / distance if distance > 0 else 0.0
    return {"risk_cash": round(risk_cash, 4), "quantity": round(quantity, 8), "notional": round(quantity * max(entry, 0), 4)}


def paper_open_signal(item: dict[str, Any], account_size: float = 10000.0, risk_pct: float = 1.0) -> bool:
    try:
        entry = safe_float(str(item.get("price", "0")).replace(",", ""))
        sl = safe_float(str(item.get("stop_loss", "0")).replace(",", ""))
        if entry <= 0 or sl <= 0 or item.get("bias") not in {"صعودی", "نزولی"}:
            return False
        size = calculate_position_size(account_size, risk_pct, entry, sl)
        # Persist model probability at entry for honest calibration samples.
        pred_prob = safe_float(
            item.get("success_probability",
                     item.get("success_prob",
                              item.get("decision_confidence", 50.0))),
            50.0,
        )
        pred_prob = float(clamp(pred_prob, 1.0, 99.0))
        with DB_LOCK, db_conn() as con:
            exists = con.execute("SELECT 1 FROM paper_trades WHERE symbol=? AND status='OPEN' LIMIT 1", (item["symbol"],)).fetchone()
            if exists: return False
            con.execute(
                "INSERT INTO paper_trades(symbol,timeframe,created_at,decision,entry,sl,tp1,tp2,quantity,risk_pct,status,success_prob) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    item["symbol"], "1h", time.time(), item["bias"], entry, sl,
                    safe_float(item.get("tp1")), safe_float(item.get("tp2")),
                    size["quantity"], risk_pct, "OPEN", pred_prob,
                ),
            )
        return True
    except Exception as exc:
        LOGGER.warning("Paper signal failed: %s", exc); return False


def evaluate_paper_trades() -> None:
    """Evaluate paper trades with chronological candle touches, not sparse polling prices."""
    now = time.time()
    with DB_LOCK, db_conn() as con:
        rows = con.execute("SELECT * FROM paper_trades WHERE status='OPEN' ORDER BY created_at LIMIT 200").fetchall()
    for row in rows:
        try:
            start_ms = int(float(row["created_at"]) * 1000)
            # Up to ~10 days of 15m bars; enough for normal monitored setups.
            df = fetch_klines(row["symbol"], "15m", 1000, start_ms=start_ms)
            window = df[df["t"] >= start_ms]
            outcome, hit, exit_price = _first_touch_ohlc(
                window, str(row["decision"]), safe_float(row["sl"], np.nan),
                safe_float(row["tp1"], np.nan), safe_float(row["tp2"], np.nan)
            )
            if outcome not in {"WIN", "LOSS"}:
                # Do not leave paper positions open forever. The live signal
                # horizon is 4h; after that, a no-touch setup becomes a
                # time-expiry observation rather than an eternally pending trade.
                created = safe_float(row["created_at"], now)
                if now >= created + 240 * 60 and not window.empty:
                    outcome = "TIME_EXIT"
                    hit = "TIME_EXIT"
                    exit_price = safe_float(window["close"].iloc[-1], row["entry"])
                else:
                    continue
            entry = safe_float(row["entry"], 0); decision = str(row["decision"]); exit_price = safe_float(exit_price, entry)
            pnl_pct = ((exit_price - entry) / entry) * 100 if entry else 0.0
            if decision in {"نزولی", "SHORT"}: pnl_pct *= -1
            # Apply round-trip execution friction to realized paper PnL.
            pnl_pct -= TOTAL_ENTRY_BUFFER * 2.0 * 100.0
            risk_per_unit = abs(entry - safe_float(row["sl"], entry))
            r_multiple = ((exit_price - entry) / risk_per_unit) if decision in {"صعودی", "LONG"} and risk_per_unit else ((entry - exit_price) / risk_per_unit if risk_per_unit else 0.0)
            r_multiple -= (TOTAL_ENTRY_BUFFER * 2.0 * entry / risk_per_unit) if risk_per_unit else 0.0
            with DB_LOCK, db_conn() as con:
                con.execute("UPDATE paper_trades SET status='CLOSED',exit_price=?,pnl_pct=?,r_multiple=?,closed_at=?,reason=? WHERE id=?",
                            (exit_price, pnl_pct, r_multiple, now, hit, row["id"]))
        except Exception as exc:
            LOGGER.warning("Paper evaluation failed #%s: %s", row["id"], exc)

def store_forecasts(market_data: list[dict[str, Any]]) -> None:
    """Store one independent directional forecast per symbol/cooldown window.

    This avoids inflating sample size by inserting essentially the same signal every
    dashboard refresh. WAIT/neutral rows are not used as pseudo-trades.
    """
    now = time.time()
    with DB_LOCK, db_conn() as con:
        for item in market_data:
            decision = str(item.get("decision_tag") or (item.get("edge") or {}).get("decision_tag") or "WAIT")
            direction = "صعودی" if decision == "LONG" else "نزولی" if decision == "SHORT" else "خنثی"
            if decision not in {"LONG", "SHORT"} or safe_float(item.get("signal_quality"), 0) < MIN_DIRECTIONAL_QUALITY:
                continue
            _g = str(item.get("grade") or (item.get("signal_grade") or {}).get("grade") or "")
            if _g in {"D", "F"}:
                continue
            recent = con.execute(
                "SELECT 1 FROM forecasts WHERE symbol=? AND timeframe='1h' AND direction=? AND created_at>=? LIMIT 1",
                (item["symbol"], direction, now - SIGNAL_COOLDOWN_SECONDS),
            ).fetchone()
            if recent:
                continue
            fusion = (item.get("titan_analysis") or {}).get("fusion") or item.get("fusion") or {}
            edge_ai = (item.get("edge") or {}).get("ai") or {}
            ai_maj = str(fusion.get("ai_majority") or edge_ai.get("majority") or "")
            ai_ag = safe_float(fusion.get("ai_agreement") or edge_ai.get("majority_agreement") or edge_ai.get("agreement"), 0)
            fused = safe_float(fusion.get("fused_score"), 0); succ = safe_float(fusion.get("success_probability"), 0)
            forecast_obj = item.get("candle_forecast") or {}
            predicted_move = safe_float(forecast_obj.get("expected_move_pct"), 0.0)
            con.execute(
                "INSERT INTO forecasts(symbol,timeframe,created_at,direction,score,alignment,price,sl,tp1,tp2,horizon_minutes,source,ai_majority,ai_agreement,fused_score,success_prob,predicted_move_pct) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (item["symbol"], "1h", now, direction, item["score"], item["alignment"],
                 safe_float(str(item.get("price", "0")).replace(",", "")),
                 safe_float(str(item.get("stop_loss", "0")).replace(",", "")),
                 safe_float(str(item.get("tp1", "0")).replace(",", "")),
                 safe_float(str(item.get("tp2", "0")).replace(",", "")),
                 240, "quant+ai-fusion-v5-audited", ai_maj, ai_ag, fused, succ, predicted_move),
            )

def evaluate_pending_forecasts() -> None:
    now = time.time()
    with DB_LOCK, db_conn() as con:
        rows = con.execute("SELECT * FROM forecasts WHERE outcome='PENDING' AND created_at <= ? LIMIT 100", (now,)).fetchall()
    learned_any = False
    for row in rows:
        horizon_end = float(row["created_at"]) + int(row["horizon_minutes"]) * 60
        if now < horizon_end:
            continue
        try:
            start_ms = int(float(row["created_at"]) * 1000)
            end_ms = int(horizon_end * 1000)
            bars_needed = max(20, min(1000, int(math.ceil(int(row["horizon_minutes"]) / 15)) + 4))
            df = fetch_klines(row["symbol"], "15m", bars_needed, start_ms=start_ms, end_ms=end_ms)
            window = df[(df["t"] >= start_ms) & (df["t"] <= end_ms)]
            if window.empty:
                continue
            direction = str(row["direction"])
            outcome, hit_type, _ = _first_touch_ohlc(
                window, direction, safe_float(row["sl"], np.nan), safe_float(row["tp1"], np.nan), safe_float(row["tp2"], np.nan)
            )
            with DB_LOCK, db_conn() as con:
                con.execute("UPDATE forecasts SET outcome=?, evaluated_at=?, hit_type=? WHERE id=?", (outcome, now, hit_type, row["id"]))
            learned_any = learned_any or outcome in {"WIN", "LOSS"}
            # Track realized path vs predicted direction for forecast self-weighting
            try:
                entry_px = safe_float(row["price"], 0)
                last_px = float(window["close"].iloc[-1]) if len(window) else 0.0
                if entry_px > 0 and last_px > 0:
                    actual_move = (last_px / entry_px - 1.0) * 100.0
                    pred_bias = str(row["direction"])
                    if pred_bias in {"LONG", "صعودی"}:
                        pred_bias = "صعودی"
                    elif pred_bias in {"SHORT", "نزولی"}:
                        pred_bias = "نزولی"
                    record_forecast_path_outcome(
                        str(row["symbol"]), pred_bias,
                        predicted_move_pct=safe_float(row["predicted_move_pct"], 0.0),
                        actual_move_pct=actual_move,
                    )
            except Exception:
                pass
        except Exception as exc:
            LOGGER.warning("Forecast evaluation failed #%s: %s", row["id"], exc)
    # Rebuild adaptive state from authoritative DB once, preventing duplicate learning.
    if learned_any:
        try:
            TITAN_ADAPTIVE.refresh_from_db()
        except Exception as learn_exc:
            LOGGER.debug("adaptive refresh skip: %s", learn_exc)

def _safe_return_series(values: list[float], return_unit: str = "pct") -> dict[str, Any]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return {"trades": 0, "decisive_trades": 0, "neutral_trades": 0, "win_rate": 0.0, "loss_rate": 0.0,
                "profit_factor": None, "expectancy": 0.0, "max_drawdown": 0.0, "sharpe": 0.0, "sortino": 0.0,
                "avg_win": 0.0, "avg_loss": 0.0, "max_losing_streak": 0, "return_unit": return_unit}
    wins, losses = arr[arr > 0], arr[arr < 0]
    neutral = int((arr == 0).sum()); decisive = int(wins.size + losses.size)
    gross_loss = abs(float(losses.sum())); mean = float(arr.mean())
    account_returns = arr / 100.0 if return_unit == "pct" else arr * 0.01
    account_returns = np.clip(account_returns, -0.999, 10.0)
    equity = np.cumprod(1.0 + account_returns)
    peak = np.maximum.accumulate(equity)
    drawdowns = (peak - equity) / np.maximum(peak, 1e-12) * 100.0
    std = float(arr.std(ddof=1)) if arr.size > 1 else 0.0
    downside = np.minimum(arr, 0.0)
    downside_dev = float(np.sqrt(np.mean(np.square(downside)))) if arr.size else 0.0
    streak = max_streak = 0
    for x in arr:
        if x < 0: streak += 1; max_streak = max(max_streak, streak)
        elif x > 0: streak = 0
    return {
        "trades": int(arr.size), "wins": int(wins.size), "losses": int(losses.size), "decisive_trades": decisive, "neutral_trades": neutral,
        "win_rate": round(wins.size / decisive * 100, 2) if decisive else 0.0,
        "loss_rate": round(losses.size / decisive * 100, 2) if decisive else 0.0,
        "profit_factor": round(float(wins.sum() / gross_loss), 3) if gross_loss > 0 else None,
        "expectancy": round(mean, 4), "max_drawdown": round(float(drawdowns.max()), 4),
        "sharpe": round(mean / std, 3) if std else 0.0,
        "sortino": round(mean / downside_dev, 3) if downside_dev else 0.0,
        "avg_win": round(float(wins.mean()), 4) if wins.size else 0.0,
        "avg_loss": round(float(losses.mean()), 4) if losses.size else 0.0,
        "max_losing_streak": int(max_streak), "return_unit": return_unit,
    }


def get_audit_stats() -> dict[str, Any]:
    """Multi-tier historical accuracy: overall + LONG vs SHORT split + grade."""
    with DB_LOCK, db_conn() as con:
        evaluated = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome IN ('WIN','LOSS','MISS','NEUTRAL','AMBIGUOUS')").fetchone()[0]
        wins = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='WIN'").fetchone()[0]
        losses = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='LOSS'").fetchone()[0]
        neutral = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome IN ('MISS','NEUTRAL')").fetchone()[0]
        ambiguous = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='AMBIGUOUS'").fetchone()[0]
        tp_hits = con.execute("SELECT COUNT(*) FROM forecasts WHERE hit_type IN ('TP1','TP2')").fetchone()[0]
        sl_hits = con.execute("SELECT COUNT(*) FROM forecasts WHERE hit_type='SL'").fetchone()[0]
        long_w = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='WIN' AND direction IN ('صعودی','LONG')").fetchone()[0]
        long_l = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='LOSS' AND direction IN ('صعودی','LONG')").fetchone()[0]
        short_w = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='WIN' AND direction IN ('نزولی','SHORT')").fetchone()[0]
        short_l = con.execute("SELECT COUNT(*) FROM forecasts WHERE outcome='LOSS' AND direction IN ('نزولی','SHORT')").fetchone()[0]
    decisive = wins + losses
    wr = round(wins / decisive * 100, 1) if decisive else 0.0
    long_dec = long_w + long_l
    short_dec = short_w + short_l
    long_wr = round(long_w / long_dec * 100, 1) if long_dec else 0.0
    short_wr = round(short_w / short_dec * 100, 1) if short_dec else 0.0
    # Accuracy tier without relying on prior predictions: pure outcome grade
    if decisive < 8:
        tier, tier_label = "C", "نمونه ناکافی"
    elif wr >= 62 and tp_hits >= sl_hits:
        tier, tier_label = "A", "دقت بالا"
    elif wr >= 52:
        tier, tier_label = "B", "دقت قابل قبول"
    elif wr >= 42:
        tier, tier_label = "C", "دقت متوسط"
    else:
        tier, tier_label = "D", "نیاز به بازتنظیم"
    # Wilson lower bound communicates uncertainty better than raw win-rate alone.
    if decisive:
        z = 1.96; phat = wins / decisive
        denom = 1 + z*z/decisive
        centre = phat + z*z/(2*decisive)
        margin = z * math.sqrt((phat*(1-phat) + z*z/(4*decisive))/decisive)
        wr_lower95 = max(0.0, (centre - margin) / denom * 100.0)
    else:
        wr_lower95 = 0.0
    resolution_rate = (decisive / evaluated * 100.0) if evaluated else 0.0
    return {
        "evaluated": int(evaluated), "wins": int(wins), "losses": int(losses),
        "neutral": int(neutral), "ambiguous": int(ambiguous),
        "win_rate": wr, "tp_hits": int(tp_hits), "sl_hits": int(sl_hits),
        "long_win_rate": long_wr, "short_win_rate": short_wr,
        "long_trades": int(long_dec), "short_trades": int(short_dec),
        "win_rate_lower_95": round(wr_lower95, 1), "resolution_rate": round(resolution_rate, 1),
        "tier": tier, "tier_label": tier_label,
        "label": "Historical first-touch audit · deduplicated directional signals · uncertainty-aware",
        "probability_calibration": _probability_calibration(),
    }

# ============================================================
# BACKTEST / WALK FORWARD - FIXED HORIZON LOGIC
# ============================================================


def backtest_signal_logic(symbol: str, tf: str = "1h", limit: int = 1000) -> dict[str, Any]:
    """Technical-proxy backtest with separate Long/Short metrics.

    Important: this validates the deterministic single-timeframe technical core only;
    it does NOT pretend to reproduce live AI/derivatives/adaptive fusion historically.

    LONG: score >= 58 + EMA structure lean
    SHORT: score <= 40 + stricter filter (RSI not deeply oversold bounce zone) + stronger score edge
    Costs include round-trip fee+spread+slippage.
    """
    limit = min(max(int(limit), 100), MAX_BACKTEST_CANDLES)
    try:
        df = fetch_klines(symbol, tf, limit)
    except Exception as exc:
        return {"ok": False, "error": str(exc), "symbol": symbol, "timeframe": tf}
    if len(df) < 80:
        return {"ok": False, "error": "داده تاریخی کافی نیست", "symbol": symbol, "timeframe": tf}
    unit = str(tf)[-1]; n = int(str(tf)[:-1] or "1"); minutes = n * {"m": 1, "h": 60, "d": 1440}.get(unit, 60)
    hold_bars = 1 if minutes >= 60 else max(1, math.ceil(60 / minutes))
    returns: list[float] = []; decisions: list[str] = []
    long_returns: list[float] = []; short_returns: list[float] = []
    cf_records = []
    friction = TOTAL_ENTRY_BUFFER * 2.0
    for i in range(60, len(df) - hold_bars):
        sample = df.iloc[:i + 1].copy()
        direction, score, meta = _tf_forecast(sample)
        entry = float(sample["close"].iloc[-1])
        future = float(df["close"].iloc[i + hold_bars])
        rsi_v = safe_float((meta or {}).get("rsi"), 50)
        ema_gap = safe_float((meta or {}).get("ema_gap"), 0)
        mom = safe_float((meta or {}).get("momentum"), 0)

        take_long = direction == "صعودی" and score >= 58 and ema_gap >= -0.15
        # Short is stricter: need deeper bear lean, avoid catching falling knives in extreme oversold without momentum
        take_short = (
            direction == "نزولی"
            and score <= 40
            and ema_gap <= 0.10
            and mom <= 0.15
            and not (rsi_v < 22 and mom > -0.5)  # skip pure panic bounce traps
        )

        if take_long:
            pnl = ((future - entry) / entry) * 100 - friction * 100
            returns.append(pnl); long_returns.append(pnl); decisions.append("LONG")
            side = "صعودی"
        elif take_short:
            pnl = ((entry - future) / entry) * 100 - friction * 100
            returns.append(pnl); short_returns.append(pnl); decisions.append("SHORT")
            side = "نزولی"
        else:
            continue

        future_prices = df["close"].iloc[i + 1:min(len(df), i + 13)].tolist()
        cf_records.append(TITAN_EDGE_SUITE.counterfactual(
            entry,
            entry * (1 - 0.01) if side == "صعودی" else entry * (1 + 0.01),
            entry * (1 + 0.015) if side == "صعودی" else entry * (1 - 0.015),
            entry * (1 + 0.025) if side == "صعودی" else entry * (1 - 0.025),
            side, future_prices,
        ))

    metrics = _safe_return_series(returns, return_unit="pct")
    long_m = _safe_return_series(long_returns, return_unit="pct")
    short_m = _safe_return_series(short_returns, return_unit="pct")
    oos = TITAN_EDGE_SUITE.out_of_sample_check(returns, return_unit="pct")
    governor = TITAN_EDGE_SUITE.drawdown_governor(returns, unit="pct")
    paths = {p: sum(1 for x in cf_records if x.get("path") == p) for p in ("TP1", "TP2", "SL", "NONE")}
    strategies = TITAN_EDGE_SUITE.strategy_lab(df)
    return {
        "ok": True, "symbol": symbol, "timeframe": tf, "candles": len(df), "metrics": metrics,
        "validation_scope": "technical_proxy_only_no_historical_ai_or_derivatives",
        "long_metrics": long_m, "short_metrics": short_m,
        "long_signals": len(long_returns), "short_signals": len(short_returns),
        "directional_signals": len(decisions), "from": float(df["t"].iloc[0]), "to": float(df["t"].iloc[-1]),
        "return_series_pct": [round(float(x), 6) for x in returns[-1500:]],
        "filters": {
            "long": "score>=58 + ema_gap>=-0.15",
            "short": "score<=40 + ema_gap<=0.10 + momentum<=0.15 + not panic-oversold trap",
            "note": "SHORT filters are stricter to reduce false breakdown signals",
        },
        "professional": {
            "oos": oos, "drawdown_governor": governor,
            "counterfactual": {"paths": paths, "sample": len(cf_records)},
            "strategy_lab": strategies,
            "meta_labeling_reference": "OOS + confluence + historical setup stats + side-split",
        },
    }



def _probability_calibration(symbol: str = "", direction: str = "", raw_prob: float = 50.0) -> dict[str, Any]:
    """Delegate to Platt+Isotonic calibrator (forecasts + paper trades)."""
    return calibrate_success_probability(symbol=symbol, direction=direction, raw_prob=raw_prob)


def _proxy_trade_candidates(df: pd.DataFrame, long_threshold: float, short_threshold: float,
                            min_gap_long: float, min_gap_short: float, max_momentum_short: float,
                            start: int, end: int, friction: float) -> list[float]:
    out=[]
    for i in range(max(60,start), min(end, len(df)-1)):
        sample=df.iloc[:i+1]
        direction, score, meta=_tf_forecast(sample)
        entry=float(df['close'].iloc[i]); future=float(df['close'].iloc[i+1])
        rsi=safe_float(meta.get('rsi'),50); gap=safe_float(meta.get('ema_gap'),0); mom=safe_float(meta.get('momentum'),0)
        if direction=='صعودی' and score>=long_threshold and gap>=min_gap_long:
            out.append(((future-entry)/entry)*100-friction)
        elif direction=='نزولی' and score<=short_threshold and gap<=min_gap_short and mom<=max_momentum_short and not(rsi<22 and mom>-0.5):
            out.append(((entry-future)/entry)*100-friction)
    return out

def walk_forward_backtest(symbol: str, tf: str = "1h", limit: int = 1200, train: int = 300, test: int = 100) -> dict[str, Any]:
    """Purged walk-forward proxy validation with train-only parameter selection.

    This is still a technical proxy (historical AI/derivatives are not reconstructed),
    but unlike the older implementation it actually tunes thresholds on the training
    segment, inserts a purge gap, and reports parameter stability and test-only results.
    """
    limit=min(max(int(limit),train+test+40),MAX_BACKTEST_CANDLES)
    try: df=fetch_klines(symbol,tf,limit)
    except Exception as exc: return {"ok":False,"error":str(exc)}
    friction=TOTAL_ENTRY_BUFFER*2.0*100
    windows=[]; all_test=[]; all_long=[]; all_short=[]; chosen=[]; i=60; purge=1
    grid=[(58,42,-0.15,0.10,0.15),(60,40,-0.10,0.08,0.10),(62,38,-0.05,0.05,0.05),
          (64,36,0.00,0.03,0.00),(60,39,-0.20,0.12,0.20)]
    while i+train+purge+test<=len(df):
        tr=df.iloc[i:i+train]; te=df.iloc[i+train+purge:i+train+purge+test]
        scored=[]
        for params in grid:
            rs=_proxy_trade_candidates(df,*params,i,i+train,friction)
            if len(rs)<8: continue
            m=_safe_return_series(rs,return_unit='pct')
            # Penalize unstable/small samples and large drawdown; choose only on TRAIN.
            obj=safe_float(m.get('expectancy'),-999)-0.10*safe_float(m.get('max_drawdown'),0)+0.002*min(len(rs),100)
            scored.append((obj,params,m))
        if not scored: best=(grid[0],{})
        else:
            best=max(scored,key=lambda z:z[0]); best=(best[1],best[2])
        params=best[0]; chosen.append(params)
        long_t,short_t,gap_l,gap_s,mom_s=params
        rs=[]; lr=[]; sr=[]
        for j in range(len(te)-1):
            sample=df.iloc[:i+train+purge+j+1]
            direction,score,meta=_tf_forecast(sample)
            entry=float(te['close'].iloc[j]); future=float(te['close'].iloc[j+1])
            rsi=safe_float(meta.get('rsi'),50); gap=safe_float(meta.get('ema_gap'),0); mom=safe_float(meta.get('momentum'),0)
            if direction=='صعودی' and score>=long_t and gap>=gap_l:
                x=((future-entry)/entry)*100-friction; rs.append(x);lr.append(x)
            elif direction=='نزولی' and score<=short_t and gap<=gap_s and mom<=mom_s and not(rsi<22 and mom>-0.5):
                x=((entry-future)/entry)*100-friction; rs.append(x);sr.append(x)
        wm=_safe_return_series(rs,return_unit='pct'); wm['long']=_safe_return_series(lr,return_unit='pct'); wm['short']=_safe_return_series(sr,return_unit='pct')
        wm['selected_params']={'long_score':long_t,'short_score':short_t,'long_gap':gap_l,'short_gap':gap_s,'short_momentum':mom_s,'train_trade_count':int(safe_float(best[1].get('trades'),0)) if isinstance(best[1],dict) else 0}
        windows.append(wm); all_test.extend(rs);all_long.extend(lr);all_short.extend(sr);i+=test
    agg=_safe_return_series(all_test,return_unit='pct')
    stability={}
    if chosen:
        for idx,name in enumerate(('long_score','short_score','long_gap','short_gap','short_momentum')):
            vals=[p[idx] for p in chosen]; stability[name]={'min':min(vals),'max':max(vals),'mean':round(float(np.mean(vals)),4),'unique':len(set(vals))}
    return {'ok':True,'symbol':symbol,'timeframe':tf,'windows':len(windows),'aggregate':agg,
            'long_aggregate':_safe_return_series(all_long,return_unit='pct'),'short_aggregate':_safe_return_series(all_short,return_unit='pct'),
            'window_metrics':windows,'purge_candles':purge,
            'validation_scope':'technical_proxy_with_train_only_threshold_selection_and_purge',
            'parameter_stability':stability,'selected_parameters_history':chosen,
            'professional':{'out_of_sample':TITAN_EDGE_SUITE.out_of_sample_check(all_test,return_unit='pct'),
                            'drawdown_governor':TITAN_EDGE_SUITE.drawdown_governor(all_test,unit='pct'),
                            'strategy_lab':TITAN_EDGE_SUITE.strategy_lab(df)}}

# ============================================================
# LIVE ENGINE
# ============================================================


def _register_live_price(symbol: str, price: float, source: str = "REST") -> None:
    if price <= 0: return
    symbol = _normalize_symbol(symbol)
    with LIVE_LOCK:
        previous = LIVE_PRICES.get(symbol, {})
        LIVE_PRICES[symbol] = {"price": float(price), "source": source, "ts": time.time(), "age_ms": 0, "change_pct": ((price / previous["price"] - 1) * 100) if previous.get("price") else 0.0}


def _live_status() -> dict[str, Any]:
    now = time.time()
    with LIVE_LOCK:
        rows = dict(LIVE_PRICES)
    if not rows:
        return {"status": "NO_DATA", "count": 0, "median_age_ms": None, "sources": [], "websocket": bool(_websocket_client)}
    ages = []; sources = set()
    for item in rows.values():
        age = max(0, now - float(item.get("ts", now))) * 1000; item["age_ms"] = round(age, 1); ages.append(age); sources.add(item.get("source", "REST"))
    median_age = statistics.median(ages) if ages else None
    return {"status": "LIVE" if median_age is not None and median_age < 10000 else "DELAYED", "count": len(rows), "median_age_ms": round(median_age, 1) if median_age is not None else None, "sources": sorted(sources), "websocket": bool(_websocket_client)}


def _rest_live_price_worker() -> None:
    while not LIVE_STOP.is_set():
        try:
            for symbol, price in _fetch_live_prices(USER_SETTINGS.get("active_coins") or DEFAULT_COINS).items(): _register_live_price(symbol, price, "REST")
        except Exception as exc: LOGGER.warning("Live REST worker failed: %s", exc)
        LIVE_STOP.wait(LIVE_PRICE_POLL_SECONDS)


def _websocket_worker() -> None:
    if _websocket_client is None: return
    while not LIVE_STOP.is_set():
        try:
            symbols = [_normalize_symbol_for_binance(s).lower() for s in (USER_SETTINGS.get("active_coins") or DEFAULT_COINS)]
            streams = "/".join(f"{s}@miniTicker" for s in symbols)
            ws = _websocket_client.create_connection(f"wss://data-stream.binance.vision/stream?streams={streams}", timeout=10)
            ws.settimeout(10)
            while not LIVE_STOP.is_set():
                raw = ws.recv()
                if not raw: break
                data = json.loads(raw).get("data", {})
                symbol = str(data.get("s", "")); price = safe_float(data.get("c"), 0)
                if symbol and price > 0: _register_live_price(symbol, price, "WebSocket")
            try: ws.close()
            except Exception: pass
        except Exception as exc:
            LOGGER.info("WebSocket unavailable; REST fallback active: %s", exc); LIVE_STOP.wait(5)


def start_live_engine() -> None:
    if any(t.is_alive() for t in LIVE_THREADS): return
    LIVE_STOP.clear()
    rest = threading.Thread(target=_rest_live_price_worker, name="titan-live-rest", daemon=True)
    rest.start(); LIVE_THREADS.append(rest)
    if _websocket_client is not None:
        ws = threading.Thread(target=_websocket_worker, name="titan-live-ws", daemon=True)
        ws.start(); LIVE_THREADS.append(ws)
        # Depth only for a few liquid symbols — lower battery/CPU on mobile
        depth_t = threading.Thread(target=_depth_websocket_worker, name="titan-depth-ws", daemon=True)
        depth_t.start(); LIVE_THREADS.append(depth_t)

# ============================================================
# MARKET CACHE / COMMAND CENTER
# ============================================================


def _load_market_cache() -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    data = _load_json(MARKET_CACHE_PATH, {})
    if not isinstance(data, dict): return [], "", {}
    return data.get("data", []) if isinstance(data.get("data"), list) else [], str(data.get("gemini_summary", "") or ""), data.get("macro", {}) if isinstance(data.get("macro"), dict) else {}


def _global_ai_summary(market_data: list[dict[str, Any]], macro: dict[str, Any]) -> str:
    payload = {"macro": macro, "coins": [{"symbol": x.get("symbol"), "bias": x.get("bias"), "score": x.get("score"), "alignment": x.get("alignment")} for x in market_data[:8]]}
    return _call_gemini(payload, global_summary=True) or ""


def _market_pulse_snapshot(market_data: list[dict[str, Any]], macro: dict[str, Any]) -> dict[str, Any]:
    items = market_data or []
    scores = [safe_float(x.get("score"), 50) for x in items]
    alignments = [safe_float(x.get("alignment"), 50) for x in items]
    bullish = sum(1 for x in items if x.get("bias") == "صعودی")
    bearish = sum(1 for x in items if x.get("bias") == "نزولی")
    neutral = max(0, len(items) - bullish - bearish)
    avg_score = float(np.mean(scores)) if scores else 50.0
    avg_alignment = float(np.mean(alignments)) if alignments else 0.0
    leader = max(items, key=lambda x: safe_float(x.get("signal_quality"), 0), default=None)
    if avg_score >= 62: regime = "متمایل به صعود"
    elif avg_score <= 38: regime = "متمایل به نزول"
    else: regime = "خنثی / دوطرفه"
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"), "regime": regime,
        "avg_score": round(avg_score, 1), "avg_alignment": round(avg_alignment, 1),
        "breadth": {"bullish": bullish, "bearish": bearish, "neutral": neutral, "total": len(items)},
        "leader": {"symbol": leader.get("symbol"), "score": leader.get("score"), "quality": leader.get("signal_quality"), "tag": leader.get("signal_tag")} if leader else None,
        "btc_trend": macro.get("btc_trend", "N/A"), "fear_greed": macro.get("fear_greed_val", "N/A"),
        "confluence_avg": round(float(np.mean([safe_float(x.get("edge",{}).get("confluence",{}).get("score"),50) for x in items])) if items else 0,1),
        "meta_accept": sum(1 for x in items if x.get("edge",{}).get("meta",{}).get("label") == "ACCEPT"),
        "defensive_count": sum(1 for x in items if x.get("edge",{}).get("governor",{}).get("state") in {"DEFENSIVE","REDUCED"}),
    }


_BACKGROUND_REFRESH_LOCK = threading.Lock()
_BACKGROUND_REFRESH_RUNNING = False
_SCAN_PROGRESS_LOCK = threading.Lock()
_SCAN_PROGRESS = {
    "status":"idle", "phase":"آماده", "started_at":0.0, "finished_at":0.0,
    "completed":0, "total":0, "percent":0, "message":"هنوز اسکن جدیدی اجرا نشده است",
    "last_success_at":0.0, "elapsed_sec":0.0, "fresh":False
}

def _scan_progress_update(**kwargs):
    with _SCAN_PROGRESS_LOCK:
        _SCAN_PROGRESS.update(kwargs)
        if _SCAN_PROGRESS.get("started_at"):
            _SCAN_PROGRESS["elapsed_sec"] = round(max(0.0, time.time()-float(_SCAN_PROGRESS["started_at"])),1)
        return dict(_SCAN_PROGRESS)

def _scan_progress_snapshot():
    with _SCAN_PROGRESS_LOCK:
        out=dict(_SCAN_PROGRESS)
        if out.get("started_at"):
            out["elapsed_sec"]=round(max(0.0,time.time()-float(out["started_at"])),1)
        return out

def _scan_supervisor_tick() -> None:
    """Android watchdog: recover a stalled scanner without starting duplicate scans."""
    try:
        p = _scan_progress_snapshot()
        if p.get("status") == "running":
            started = float(p.get("started_at") or 0.0)
            # A phone/network stall should not leave the UI permanently stuck.
            if started and time.time() - started > max(180.0, AUTO_SCAN_INTERVAL_SECONDS * 4):
                LOGGER.warning("Android scan watchdog: stale scan detected; releasing refresh gate")
                _scan_progress_update(status="stalled", phase="watchdog", message="اسکن قبلی متوقف شده بود؛ تلاش مجدد…", fresh=False)
                global _BACKGROUND_REFRESH_RUNNING
                with _BACKGROUND_REFRESH_LOCK:
                    _BACKGROUND_REFRESH_RUNNING = False
    except Exception as exc:
        LOGGER.debug("scan watchdog failed: %s", exc)


def _background_market_refresh(force: bool = False) -> bool:
    """Refresh market data outside the request thread so the dashboard can render immediately."""
    global _BACKGROUND_REFRESH_RUNNING
    with _BACKGROUND_REFRESH_LOCK:
        if _BACKGROUND_REFRESH_RUNNING:
            return False
        _BACKGROUND_REFRESH_RUNNING = True
    def _runner():
        global _BACKGROUND_REFRESH_RUNNING
        try:
            update_cache(force)
        except Exception as exc:
            LOGGER.exception("Background market refresh failed: %s", exc)
        finally:
            with _BACKGROUND_REFRESH_LOCK:
                _BACKGROUND_REFRESH_RUNNING = False
    threading.Thread(target=_runner, name="titan-market-refresh", daemon=True).start()
    return True

def _fast_market_snapshot() -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    """Return memory cache first, then disk cache, without network calls."""
    with CACHE_LOCK:
        cached_data = list(CACHE.get("data") or [])
        cached_summary = CACHE.get("gemini_summary") or ""
        cached_macro = CACHE.get("macro") or {}
    if cached_data:
        # Single-source price rule: even RAM-cache hits must pass through the
        # same LIVE_PRICES rebase before any API/dashboard consumer receives them.
        try:
            live_data = _v29_sync_snapshot_to_live(cached_data)
            with CACHE_LOCK:
                CACHE["data"] = live_data
            return live_data, cached_summary, cached_macro
        except Exception as exc:
            LOGGER.debug("Live RAM snapshot sync failed: %s", exc)
            return cached_data, cached_summary, cached_macro
    data, summary, macro = _load_market_cache()
    if data:
        # Preserve the timestamp written by the scan instead of replacing it
        # with application restart time. This is critical for truthful freshness.
        raw=_load_json(MARKET_CACHE_PATH,{})
        stored_ts=safe_float(raw.get("timestamp"),0.0) if isinstance(raw,dict) else 0.0
        with CACHE_LOCK:
            CACHE.update(timestamp=stored_ts or time.time(), data=data, gemini_summary=summary, macro=macro)
    # Critical consistency rule: cached analytical state may be 40s old, but the
    # displayed market price must always come from the freshest live ticker.
    if data:
        try:
            data = _v29_sync_snapshot_to_live(list(data))
            with CACHE_LOCK:
                CACHE["data"] = data
        except Exception as exc:
            LOGGER.debug("Live snapshot sync failed: %s", exc)
    return data or [], summary or "", macro or {}


def _v29_num_price(value: Any) -> float:
    """Parse TITAN display prices safely."""
    try:
        s = str(value or "").replace(",", "").replace("$", "").replace("USDT", "").strip()
        return float(s)
    except Exception:
        return 0.0


def _v29_shift_price_field(value: Any, ratio: float) -> Any:
    p = _v29_num_price(value)
    if p <= 0 or not math.isfinite(ratio):
        return value
    return smart_format(p * ratio)


def _v29_sync_snapshot_to_live(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Rebase only price-dependent dashboard outputs to the newest Binance spot
    price. Closed-candle indicators remain untouched; entry/SL/TP and the
    scenario path move with the live reference price.
    """
    if not data:
        return data
    now = time.time()
    with LIVE_LOCK:
        live_map = {
            k: dict(v) for k, v in LIVE_PRICES.items()
            if safe_float(v.get("price"), 0) > 0
        }
    for item in data:
        sym = _normalize_symbol(item.get("symbol", ""))
        lp = live_map.get(sym)
        if not lp:
            continue
        live = safe_float(lp.get("price"), 0)
        if live <= 0:
            continue
        old = _v29_num_price(item.get("price"))
        if old <= 0:
            item["price"] = smart_format(live)
            item["entry_valid"] = smart_format(live)
            continue

        ratio = live / old
        # Keep the canonical signal timestamp/price for audit, but expose a
        # second, authoritative live price for the current UI.
        item.setdefault("signal_snapshot", {})
        item["signal_snapshot"].setdefault("price", old)
        item["signal_snapshot"].setdefault("timestamp", item.get("scan_timestamp", now))
        item["price"] = smart_format(live)
        item["price_raw"] = float(live)
        item["live_price"] = float(live)
        item["entry_valid"] = smart_format(live)
        item["entry_raw"] = float(live)
        for key in ("stop_loss", "tp1", "tp2"):
            if key in item:
                item[key] = _v29_shift_price_field(item.get(key), ratio)

        # Recompute price-relative risk metrics from the live price.
        sl = _v29_num_price(item.get("stop_loss"))
        tp1 = _v29_num_price(item.get("tp1"))
        tp2 = _v29_num_price(item.get("tp2"))
        if sl > 0:
            item["stop_loss_raw"] = float(sl)
            if tp1 > 0: item["tp1_raw"] = float(tp1)
            if tp2 > 0: item["tp2_raw"] = float(tp2)
            item["risk_distance_pct"] = round(abs(live - sl) / live * 100.0, 3)
            item["rr_tp1"] = round(abs(tp1 - live) / max(abs(live - sl), 1e-12), 2) if tp1 > 0 else item.get("rr_tp1", 0)
            item["rr_tp2"] = round(abs(tp2 - live) / max(abs(live - sl), 1e-12), 2) if tp2 > 0 else item.get("rr_tp2", 0)
            item["effective_rr_tp1"] = item["rr_tp1"]
            item["effective_rr_tp2"] = item["rr_tp2"]

        scan_ts = safe_float(item.get("scan_timestamp"), now)
        item["live_price"] = live
        item["live_price_source"] = lp.get("source", "Binance")
        item["live_price_ts"] = safe_float(lp.get("ts"), now)
        item["live_price_age_sec"] = round(max(0.0, now - safe_float(lp.get("ts"), now)), 2)
        item["live_sync"] = True
        item["price_delta_from_scan_pct"] = round((live / old - 1.0) * 100.0, 4)
        item["signal_age_sec"] = round(max(0.0, now - scan_ts), 1)

        # Re-anchor future candle scenario to the same live price while keeping
        # its modeled percentage geometry unchanged.
        fc = item.get("candle_forecast")
        if isinstance(fc, dict):
            fc["last_price"] = round(live, 8)
            for candle in fc.get("candles", []) or []:
                if isinstance(candle, dict):
                    for k in ("open", "high", "low", "close", "mid", "band_low", "band_high"):
                        if k in candle:
                            try:
                                candle[k] = round(float(candle[k]) * ratio, 8)
                            except Exception:
                                pass
    return data


def _v29_async_gemini_enrichment(snapshot: list[dict[str, Any]], macro: dict[str, Any]) -> None:
    """Low-latency asynchronous Gemini evidence pass; never blocks market scan."""
    if not GEMINI_API_KEY or not snapshot:
        return
    try:
        ordered = sorted(
            snapshot,
            key=lambda x: (
                -safe_float(x.get("signal_quality"), 0),
                -safe_float(x.get("success_probability"), 0),
            ),
        )[:AUTO_AI_TOP_N]
        raw = _load_json(AI_SYMBOL_CACHE_PATH, {})
        cache = raw if isinstance(raw, dict) else {}
        jobs = []
        for item in ordered:
            sym = _normalize_symbol(item.get("symbol", ""))
            payload = {
                "task": "TITAN evidence review only; do not invent prices; use supplied live price.",
                "symbol": sym,
                "live_price": _v29_num_price(item.get("price")),
                "decision": item.get("decision_tag", "WAIT"),
                "score": item.get("score", 50),
                "signal_quality": item.get("signal_quality", 0),
                "success_probability": item.get("success_probability", 50),
                "timeframes": item.get("tf_scores", {}),
                "bias": item.get("bias"),
                "entry": item.get("entry_valid"),
                "stop_loss": item.get("stop_loss"),
                "tp1": item.get("tp1"),
                "tp2": item.get("tp2"),
                "rsi": item.get("rsi"),
                "macd": item.get("macd"),
                "derivatives": {
                    "oi": item.get("coinglass_oi"),
                    "funding": item.get("coinglass_funding"),
                    "taker_buy_pct": item.get("taker_buy_pct"),
                    "long_short_ratio": item.get("long_short_ratio"),
                },
                "macro": {
                    "btc_trend": macro.get("btc_trend"),
                    "fear_greed": macro.get("fear_greed_val"),
                },
            }
            jobs.append((sym, payload))

        def one(sym_payload):
            sym, payload = sym_payload
            try:
                result = _call_gemini(payload)
                if result:
                    return sym, {"ts": time.time(), "text": result, "source": "Gemini", "price": payload["live_price"]}
            except Exception as exc:
                LOGGER.debug("V29 async Gemini %s failed: %s", sym, exc)
            return sym, None

        pool = _get_ai_pool(min(4, max(1, len(jobs))))
        futures = [pool.submit(one, j) for j in jobs]
        for fut in as_completed(futures):
            sym, row = fut.result()
            if row:
                cache[sym] = row

        _save_json(AI_SYMBOL_CACHE_PATH, cache)

        # Feed fresh Gemini evidence into the in-memory dashboard without
        # forcing a page reload. The next automatic scan also consumes it.
        with CACHE_LOCK:
            current = CACHE.get("data") or []
            by = {_normalize_symbol(x.get("symbol", "")): x for x in current}
            for sym, row in cache.items():
                if sym in by and isinstance(by[sym], dict) and row.get("text"):
                    ai = by[sym].get("ai_opinions") if isinstance(by[sym].get("ai_opinions"), dict) else {}
                    ai = dict(ai)
                    ai["gemini"] = row["text"]
                    ai["providers"] = list(dict.fromkeys((ai.get("providers") or []) + ["gemini"]))
                    ai["ai_status"] = dict(ai.get("ai_status") or {})
                    ai["ai_status"]["gemini"] = "تحلیل Gemini زنده"
                    ai["cached_at"] = row.get("ts")
                    by[sym]["ai_opinions"] = ai
            CACHE["data"] = _v29_sync_snapshot_to_live(list(by.values()))
            CACHE["timestamp"] = time.time()
            snap = CACHE["data"]
            summary = CACHE.get("gemini_summary") or ""
            macro_now = CACHE.get("macro") or macro
        _save_json(MARKET_CACHE_PATH, {
            "timestamp": time.time(), "data": snap,
            "gemini_summary": summary, "macro": macro_now
        })
    except Exception as exc:
        LOGGER.warning("V29 Gemini enrichment failed: %s", exc)


def _v29_auto_loop() -> None:
    """Permanent autonomous maintenance loop independent of browser requests.

    Three independent maintenance lanes are kept alive:
      1) live multi-asset market scans;
      2) forecast/outcome resolution and learning calibration;
      3) throttled historical-performance/backtest snapshots.

    The performance lane is dispatched in its own daemon thread so an Android
    backtest cannot block the live dashboard or the 45-second market scanner.
    """
    last_scan = 0.0
    while True:
        try:
            now = time.time()
            if now - last_scan >= AUTO_SCAN_INTERVAL_SECONDS:
                started = time.perf_counter()
                queued = _background_market_refresh(False)
                last_scan = now
                LOGGER.info(
                    "V29 autonomous scan %s in %.1fms",
                    "queued" if queued else "already-running",
                    (time.perf_counter() - started) * 1000,
                )

            # Resolve matured forecasts and rebuild the conservative learning
            # profile from actual outcomes. This never invents a result.
            _scan_supervisor_tick()
            _safe_background_forecast_maintenance()

            # Historical performance is throttled internally (currently every
            # 5 minutes) and rotates through symbols. Dispatching it separately
            # prevents a slow backtest/API call from freezing live updates.
            try:
                if now - _PERFORMANCE_LAST_RUN >= PERFORMANCE_AUTO_INTERVAL_SECONDS:
                    threading.Thread(
                        target=autonomous_performance_maintenance,
                        kwargs={"force": False},
                        name="titan-performance-maintenance",
                        daemon=True,
                    ).start()
            except Exception as perf_exc:
                LOGGER.debug("Performance maintenance dispatch failed: %s", perf_exc)
        except Exception as exc:
            LOGGER.warning("V29 autonomous loop error: %s", exc)
        LIVE_STOP.wait(AUTO_MAINTENANCE_INTERVAL_SECONDS)


def update_cache(force: bool = False) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    global CACHE
    reload_keys()
    now = time.time()
    with CACHE_LOCK:
        if CACHE["data"] and not force and now - CACHE["timestamp"] < MARKET_CACHE_TTL:
            return CACHE["data"], CACHE["gemini_summary"], CACHE["macro"]
    with UPDATE_LOCK:
        with CACHE_LOCK:
            if CACHE["data"] and not force and time.time() - CACHE["timestamp"] < MARKET_CACHE_TTL:
                return CACHE["data"], CACHE["gemini_summary"], CACHE["macro"]
        coins = USER_SETTINGS.get("active_coins") or DEFAULT_COINS
        scan_started=time.time()
        _scan_progress_update(status="running",phase="دریافت داده‌های زنده و کلان",started_at=scan_started,finished_at=0.0,completed=0,total=len(coins),percent=4,message="در حال دریافت قیمت، BTC و داده‌های کلان…",fresh=False)
        # Bootstrap: macro + BTC + batch live prices in parallel (one REST round-trip for all coins)
        def _batch_live():
            try:
                prices = _fetch_live_prices(list(coins))
                for sym, px in prices.items():
                    _register_live_price(sym, px, "REST-batch")
                return len(prices)
            except Exception as exc:
                LOGGER.debug("batch live prices: %s", exc)
                return 0
        with ThreadPoolExecutor(max_workers=3) as meta_ex:
            btc_future = meta_ex.submit(fetch_btc_trend)
            macro_future = meta_ex.submit(fetch_macro)
            live_future = meta_ex.submit(_batch_live)
            btc_trend = btc_future.result()
            macro = macro_future.result()
            try:
                live_future.result(timeout=8)
            except Exception:
                pass
        macro["btc_trend"] = btc_trend
        _scan_progress_update(phase="تحلیل تک‌تک ارزها با موتور یکپارچه",percent=12,message="داده‌های اولیه آماده شد؛ تحلیل ارزها در حال انجام است…")
        results: list[dict[str, Any]] = []
        scan_t0 = time.perf_counter()
        pool = _get_analysis_pool(min(14, max(6, len(coins))))
        futures = {pool.submit(analyze_asset, symbol, btc_trend): symbol for symbol in coins}
        for future in as_completed(futures):
            symbol = futures[future]
            try:
                result = future.result()
                if result:
                    results.append(result)
            except Exception as exc:
                LOGGER.exception("Asset analysis failed for %s: %s", symbol, exc)
            finally:
                done=len(results)
                pct=12 + int(72 * min(1.0, done/max(1,len(coins))))
                _scan_progress_update(completed=done,percent=pct,message=f"تحلیل {done}/{len(coins)} ارز تکمیل شد…")
        if not results:
            stale_data, stale_summary, stale_macro = _load_market_cache()
            with CACHE_LOCK: CACHE.update(timestamp=time.time(), data=stale_data, gemini_summary=stale_summary, macro=stale_macro)
            return stale_data, stale_summary, stale_macro
        order = {coin: i for i, coin in enumerate(coins)}
        # V28.4: directional first (LONG/SHORT), then grade, quality, original order
        def _result_rank(x: dict) -> tuple:
            dec = str(x.get("decision_tag") or "WAIT").upper()
            dir_pri = 0 if dec in {"LONG", "SHORT"} else 1
            side_pri = 0 if dec == "LONG" else 1 if dec == "SHORT" else 2
            g = str(x.get("grade") or ((x.get("signal_grade") or {}).get("grade")) or "—")
            return (
                dir_pri,
                side_pri,
                -GRADE_RANK.get(g, 0),
                -safe_float(x.get("opportunity_score"), 0),
                -safe_float(x.get("trust_index"), 0),
                -safe_float(x.get("signal_quality"), 0),
                order.get(x.get("symbol"), 999),
            )
        results.sort(key=_result_rank)
        scan_timestamp=time.time()
        for _item in results:
            _item["scan_timestamp"]=scan_timestamp
            _item["scan_time_utc"]=datetime.fromtimestamp(scan_timestamp,timezone.utc).isoformat(timespec="seconds")
        try:
            signal_board = rank_market_signals(results)
            macro["signal_board"] = signal_board
            macro["actionable_count"] = signal_board.get("counts", {}).get("actionable", 0)
            macro["grade_summary"] = {
                g: sum(1 for r in results if (r.get("grade") or (r.get("signal_grade") or {}).get("grade")) == g)
                for g in ("A+", "A", "B", "C", "D", "F")
            }
        except Exception as _sb:
            LOGGER.debug("signal board failed: %s", _sb)
            macro["signal_board"] = {"actionable": [], "watchlist": [], "counts": {}}
        try:
            # V32 records one timeframe-specific decision per symbol at scan time.
            # It is deduplicated and later evaluated only against historical OHLC.
            v32_record_scan_predictions(results)
            v32_evaluate_pending()
            store_forecasts(results)
            for item in results:
                _g = str(item.get("grade") or (item.get("signal_grade") or {}).get("grade") or "")
                if (item.get("decision_tag") in {"LONG", "SHORT"}
                    and item.get("alignment", 0) >= 65
                    and item.get("signal_quality", 0) >= MIN_DIRECTIONAL_QUALITY
                    and item.get("bias") in {"صعودی", "نزولی"}
                    and _g in {"A+", "A", "B"}):
                    paper_open_signal(item)
            evaluate_paper_trades(); evaluate_pending_forecasts()
        except Exception as exc: LOGGER.warning("Forecast/paper batch failed: %s", exc)
        # Do NOT block first dashboard paint on Gemini. The market result is complete and
        # usable at this point; keep the previous summary until the fresh AI summary arrives.
        with CACHE_LOCK:
            previous_summary = CACHE.get("gemini_summary") or ""
        if not previous_summary:
            _, previous_summary, _ = _load_market_cache()
        payload = {"timestamp": time.time(), "data": results, "gemini_summary": previous_summary, "macro": macro}
        finished=time.time()
        _scan_progress_update(status="complete",phase="اسکن کامل شد",completed=len(results),total=len(coins),percent=100,finished_at=finished,last_success_at=finished,elapsed_sec=round(finished-scan_started,1),message=f"اسکن جدید کامل شد · {len(results)}/{len(coins)} ارز · داده تازه",fresh=True)
        LOGGER.info("update_cache analyze done in %.1fs coins=%s", time.perf_counter()-scan_t0, len(results))
        results = _v29_sync_snapshot_to_live(results)
        payload["data"] = results
        _save_json(MARKET_CACHE_PATH, payload)
        with CACHE_LOCK:
            CACHE.update(timestamp=time.time(), data=results, gemini_summary=previous_summary, macro=macro)
        # Gemini is deliberately asynchronous: it enriches the live snapshot and
        # is consumed by the next scan, while the current dashboard stays fast.
        threading.Thread(
            target=_v29_async_gemini_enrichment,
            args=(list(results), dict(macro)),
            name="titan-gemini-enrichment",
            daemon=True,
        ).start()
        # Gemini global summary is also non-blocking.
        def _ai_summary_refresh(snapshot, macro_snapshot):
            try:
                fresh = _global_ai_summary(snapshot, macro_snapshot)
                if fresh:
                    with CACHE_LOCK:
                        CACHE["gemini_summary"] = fresh
                    current = _load_market_cache()
                    _save_json(MARKET_CACHE_PATH, {"timestamp": time.time(), "data": current[0] or snapshot, "gemini_summary": fresh, "macro": macro_snapshot})
            except Exception as exc:
                LOGGER.warning("Async Gemini dashboard summary failed: %s", exc)
        threading.Thread(target=_ai_summary_refresh, args=(results, macro), name="titan-gemini-summary", daemon=True).start()
        return results, previous_summary, macro

# ============================================================
# ADVANCED METRICS
# ============================================================


def get_advanced_metrics() -> dict[str, Any]:
    live = _live_status(); audit = get_audit_stats()
    with DB_LOCK, db_conn() as con:
        paper_total = con.execute("SELECT COUNT(*) FROM paper_trades").fetchone()[0]
        paper_closed = con.execute("SELECT COUNT(*) FROM paper_trades WHERE status='CLOSED'").fetchone()[0]
        paper_open = con.execute("SELECT COUNT(*) FROM paper_trades WHERE status='OPEN'").fetchone()[0]
        paper_values = [safe_float(r[0]) for r in con.execute("SELECT r_multiple FROM paper_trades WHERE status='CLOSED' AND r_multiple IS NOT NULL").fetchall()]
        alerts = [dict(r) for r in con.execute("SELECT id,created_at,severity,symbol,category,message FROM alerts ORDER BY id DESC LIMIT 10").fetchall()]
        quality = con.execute("SELECT COUNT(*), COALESCE(SUM(overall_ok),0) FROM data_quality").fetchone()
    governor = TITAN_EDGE_SUITE.drawdown_governor(paper_values)
    return {"generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "live": live, "historical": audit,
            "paper": {"total": int(paper_total), "closed": int(paper_closed), "open": int(paper_open), **_safe_return_series(paper_values)},
            "data_quality": {"samples": int(quality[0]), "healthy": int(quality[1]), "cache_ttl_seconds": MARKET_CACHE_TTL},
            "drawdown_governor": governor, "edge_suite": {"modules": 12, "status": "ACTIVE", "name": TITAN_EDGE_SUITE.name}, "alerts": alerts}

# ============================================================
# AUTONOMOUS PERFORMANCE SNAPSHOT ENGINE
# ============================================================

PERFORMANCE_AUTO_INTERVAL_SECONDS = 300
PERFORMANCE_SYMBOLS_PER_RUN = 3
_PERFORMANCE_LOCK = threading.Lock()
_PERFORMANCE_LAST_RUN = 0.0
_PERFORMANCE_CURSOR = 0
_PERFORMANCE_LAST_RESULT: dict[str, Any] = {"ok": True, "status": "never_run", "completed": 0, "failed": 0}


def _store_performance_snapshot(symbol: str, tf: str, result: dict[str, Any]) -> None:
    if not isinstance(result, dict) or not result.get("ok"):
        return
    m = result.get("metrics") or {}
    oos = (((result.get("professional") or {}).get("oos") or {}).get("status")
           or ((result.get("professional") or {}).get("out_of_sample") or {}).get("status") or "")
    payload = json.dumps(result, ensure_ascii=False, default=str)
    with DB_LOCK, db_conn() as con:
        con.execute(
            """INSERT INTO performance_snapshots(
                symbol,timeframe,created_at,trades,wins,losses,win_rate,expectancy,
                profit_factor,max_drawdown,sharpe,sortino,oos_status,metrics_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                _normalize_symbol(symbol), str(tf), time.time(),
                int(safe_float(m.get("trades"), 0)),
                int(safe_float(m.get("wins"), 0)),
                int(safe_float(m.get("losses"), 0)),
                safe_float(m.get("win_rate"), 0),
                safe_float(m.get("expectancy"), 0),
                safe_float(m.get("profit_factor"), 0) if m.get("profit_factor") is not None else None,
                safe_float(m.get("max_drawdown"), 0),
                safe_float(m.get("sharpe"), 0),
                safe_float(m.get("sortino"), 0),
                str(oos),
                payload[-120000:],
            ),
        )


def autonomous_performance_maintenance(force: bool = False) -> dict[str, Any]:
    """Continuously build auditable backtest history without browser interaction.

    This is deliberately throttled for Android: a small rotating subset of coins
    is evaluated each cycle, while all timeframes are covered for those coins.
    """
    global _PERFORMANCE_LAST_RUN, _PERFORMANCE_CURSOR, _PERFORMANCE_LAST_RESULT
    now = time.time()
    if not force and now - _PERFORMANCE_LAST_RUN < PERFORMANCE_AUTO_INTERVAL_SECONDS:
        return {"ok": True, "skipped": True, "reason": "interval"}
    if not _PERFORMANCE_LOCK.acquire(blocking=False):
        return {"ok": True, "skipped": True, "reason": "already_running"}
    try:
        _PERFORMANCE_LAST_RUN = now
        coins = list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
        if not coins:
            return {"ok": False, "error": "no active coins"}
        start = _PERFORMANCE_CURSOR % len(coins)
        selected = [coins[(start + i) % len(coins)] for i in range(min(PERFORMANCE_SYMBOLS_PER_RUN, len(coins)))]
        _PERFORMANCE_CURSOR = (start + len(selected)) % len(coins)
        summary = {"ok": True, "symbols": selected, "timeframes": list(TF_CFG), "completed": 0, "failed": 0, "started_at": now}
        for sym in selected:
            for tf in TF_CFG:
                try:
                    result = backtest_signal_logic(_normalize_symbol(sym), tf, 800)
                    if result.get("ok"):
                        _store_performance_snapshot(sym, tf, result)
                        summary["completed"] += 1
                    else:
                        summary["failed"] += 1
                except Exception as exc:
                    summary["failed"] += 1
                    LOGGER.debug("Autonomous performance %s %s failed: %s", sym, tf, exc)
        # Retain bounded history; raw metrics are also available in the latest rows.
        with DB_LOCK, db_conn() as con:
            con.execute(
                "DELETE FROM performance_snapshots WHERE id NOT IN "
                "(SELECT id FROM performance_snapshots ORDER BY created_at DESC LIMIT 5000)"
            )
        summary["finished_at"] = time.time()
        summary["elapsed_sec"] = round(summary["finished_at"] - now, 2)
        summary["status"] = "complete" if summary["failed"] == 0 else "partial"
        _PERFORMANCE_LAST_RESULT = dict(summary)
        return summary
    finally:
        _PERFORMANCE_LOCK.release()


def get_performance_history(symbol: str = "", tf: str = "", limit: int = 120) -> dict[str, Any]:
    symbol = _normalize_symbol(symbol) if symbol else ""
    limit = max(1, min(int(limit), 500))
    where, args = [], []
    if symbol:
        where.append("symbol=?"); args.append(symbol)
    if tf in TF_CFG:
        where.append("timeframe=?"); args.append(tf)
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    with DB_LOCK, db_conn() as con:
        rows = con.execute(
            f"SELECT symbol,timeframe,created_at,trades,wins,losses,win_rate,expectancy,"
            f"profit_factor,max_drawdown,sharpe,sortino,oos_status "
            f"FROM performance_snapshots{clause} ORDER BY created_at DESC LIMIT ?",
            (*args, limit),
        ).fetchall()
    return {
        "ok": True,
        "items": [dict(r) for r in rows],
        "count": len(rows),
        "source": "AUTONOMOUS_BACKTEST_HISTORY",
        "autonomous_status": dict(_PERFORMANCE_LAST_RESULT),
    }


# ============================================================
# TITAN ENTERPRISE V4 - ADVANCED CONTROL MODULES
# Restored from the user's original master build. Additive only.
# ============================================================

class TitanEnterpriseEnhancementV4:
    """
    Enterprise enhancement layer:
    1. Pipeline validation
    2. Learning memory hooks
    3. Backtest framework
    4. Adaptive weighting
    5. Market manipulation protection
    6. Runtime safety checks
    """
    def __init__(self):
        self.history = []
        self.weights = {
            "technical": 0.35,
            "ai": 0.30,
            "derivatives": 0.20,
            "risk": 0.15
        }

    def validate_pipeline(self, data):
        return bool(data and isinstance(data, dict))

    def save_feedback(self, signal, result):
        _append_capped(self.history, {"signal": signal, "result": result}, 256)

    def adaptive_weights(self, market_state="normal"):
        if market_state == "sideways":
            self.weights = {
                "technical": 0.25,
                "ai": 0.25,
                "derivatives": 0.30,
                "risk": 0.20
            }
        elif market_state == "trend":
            self.weights = {
                "technical": 0.45,
                "ai": 0.30,
                "derivatives": 0.15,
                "risk": 0.10
            }
        return self.weights

    def backtest_record(self, decision, price_before, price_after):
        change = 0
        if price_before:
            change = ((price_after - price_before) / price_before) * 100
        return {"decision": decision, "performance": round(change, 4)}

    def anomaly_check(self, volume_change=0, volatility=0):
        if volume_change > 300 or volatility > 10:
            return {"blocked": True, "reason": "market anomaly detected"}
        return {"blocked": False}

    def self_check(self, payload):
        checks = {
            "data": self.validate_pipeline(payload),
            "risk": payload.get("risk", 0) < 50 if isinstance(payload, dict) else False,
            "engine": True
        }
        return {"passed": all(checks.values()), "checks": checks}


TITAN_ENTERPRISE_V4 = TitanEnterpriseEnhancementV4()


# ============================================================
# TITAN FULL AUDIT & TEST FRAMEWORK
# ============================================================

class TitanFullAuditFramework:
    """Internal validation, stress and decision-quality audit layer."""
    def __init__(self):
        self.results = []
        self.paper_trades = []

    def static_check(self):
        return {
            "python_syntax": True,
            "core_loaded": True,
            "error_guard": True,
            "decision_layer": "TITAN_DECISION_CORE" in globals()
        }

    def pipeline_check(self, payload=None):
        return {
            "data": isinstance(payload, dict) if payload is not None else False,
            "risk": True,
            "decision_ready": True
        }

    def stress_test(self, scenario):
        blocked = scenario in ["api_down", "invalid_data", "extreme_volatility"]
        return {"scenario": scenario, "safe_mode": blocked, "action": "WAIT" if blocked else "CONTINUE"}

    def record_paper_trade(self, signal):
        _append_capped(self.paper_trades, signal, 512)
        return {"saved": True, "count": len(self.paper_trades)}

    def decision_report(self, decision):
        report = {
            "decision": decision,
            "has_confidence": "confidence" in decision if isinstance(decision, dict) else False,
            "explainable": "explanation" in decision if isinstance(decision, dict) else False
        }
        _append_capped(self.results, report, 512)
        return report


TITAN_AUDIT_ENGINE = TitanFullAuditFramework()


# ============================================================
# TITAN ULTIMATE - BACKTEST & CALIBRATION ENGINE
# ============================================================

class TitanBacktestCalibrationEngine:
    """Offline evaluation and confidence calibration framework."""
    def __init__(self):
        self.trades = []
        self.stats = {"total": 0, "wins": 0, "losses": 0}

    def record(self, decision, entry, exit_price, confidence=0):
        if not entry:
            return None
        pnl = ((exit_price - entry) / entry) * 100
        if decision == "SHORT":
            pnl *= -1
        result = {
            "decision": decision, "entry": entry, "exit": exit_price,
            "confidence": confidence, "pnl": round(pnl, 4), "success": pnl > 0
        }
        _append_capped(self.trades, result, 2000)
        self.stats["total"] += 1
        if result["success"]:
            self.stats["wins"] += 1
        else:
            self.stats["losses"] += 1
        return result

    def report(self):
        total = self.stats["total"]
        if total == 0:
            return {"status": "no_data", "message": "No backtest records available"}
        return {
            "total_trades": total,
            "win_rate": round((self.stats["wins"] / total) * 100, 2),
            "loss_rate": round((self.stats["losses"] / total) * 100, 2),
            "avg_confidence": round(sum(t["confidence"] for t in self.trades) / total, 2)
        }

    def calibrate(self):
        report = self.report()
        if report.get("win_rate", 0) < 50:
            return {"action": "reduce_risk", "reason": "low historical accuracy"}
        return {"action": "normal", "reason": "acceptable historical performance"}


TITAN_BACKTEST_ENGINE = TitanBacktestCalibrationEngine()


# ============================================================
# TITAN ULTIMATE - WALK FORWARD VALIDATION ENGINE
# ============================================================

class TitanWalkForwardValidationEngine:
    """Walk-forward evaluation and confidence calibration layer."""
    def __init__(self):
        self.windows = []
        self.results = []

    def create_window(self, train_data, test_data):
        window = {
            "train_size": len(train_data) if train_data else 0,
            "test_size": len(test_data) if test_data else 0
        }
        _append_capped(self.windows, window, 512)
        return window

    def evaluate(self, predictions, outcomes):
        if not predictions or not outcomes:
            return {"status": "no_data", "accuracy": 0}
        total = min(len(predictions), len(outcomes))
        correct = sum(1 for p, o in zip(predictions[:total], outcomes[:total]) if p == o)
        result = {"samples": total, "accuracy": round((correct / total) * 100, 2)}
        _append_capped(self.results, result, 512)
        return result

    def calibrate_confidence(self, confidence, accuracy):
        if accuracy < 50:
            return max(0, confidence - 15)
        if accuracy > 70:
            return min(100, confidence + 5)
        return confidence

    def report(self):
        return {"windows": len(self.windows), "evaluations": len(self.results), "results": self.results}


TITAN_WALK_FORWARD_ENGINE = TitanWalkForwardValidationEngine()


# ============================================================
# TITAN QUANT VALIDATION ENGINE
# ============================================================

class TitanQuantValidationEngine:
    def __init__(self):
        self.records = []

    def add_trade(self, pnl_percent):
        _append_capped(self.records, float(pnl_percent), 5000)

    def metrics(self):
        if not self.records:
            return {"trades": 0}
        wins = [x for x in self.records if x > 0]
        losses = [x for x in self.records if x <= 0]
        gross_profit = sum(wins)
        gross_loss = abs(sum(losses))
        equity = 0
        peak = 0
        drawdown = 0
        losing = 0
        max_losing = 0
        for p in self.records:
            equity += p
            peak = max(peak, equity)
            drawdown = max(drawdown, peak - equity)
            losing = losing + 1 if p <= 0 else 0
            max_losing = max(max_losing, losing)
        return {
            "trades": len(self.records),
            "win_rate": round(len(wins) / len(self.records) * 100, 2),
            "profit_factor": round(gross_profit / gross_loss, 3) if gross_loss else None,
            "max_drawdown": round(drawdown, 3),
            "max_losing_streak": max_losing
        }

    def walk_forward(self, values, train=50, test=20):
        results = []
        i = 0
        while i + train + test <= len(values):
            train_set = values[i:i + train]
            test_set = values[i + train:i + train + test]
            results.append({
                "train": len(train_set),
                "test": len(test_set),
                "test_return": round(sum(test_set), 4)
            })
            i += test
        return results

    def stress_test(self, data):
        checks = {
            "empty_data": not bool(data),
            "extreme_volatility": abs(float(data.get("volatility", 0))) > 15 if isinstance(data, dict) else True,
            "invalid_price": float(data.get("price", 1)) <= 0 if isinstance(data, dict) else True
        }
        return {"safe": not any(checks.values()), "checks": checks}


TITAN_QUANT_VALIDATOR = TitanQuantValidationEngine()




# ============================================================
# TITAN ULTIMATE INTEGRATION ORCHESTRATOR
# ============================================================

class TitanUltimateOrchestrator:
    """Connects data, AI, risk, learning and decision layers."""
    def __init__(self):
        self.decision = globals().get("TITAN_DECISION_CORE")
        self.enhancer = globals().get("TITAN_ENTERPRISE_V4")
        self.memory = []

    def run(self, market_data):
        if not isinstance(market_data, dict):
            return {"decision": "WAIT", "confidence": 0, "reason": "invalid_data"}
        health = self.enhancer.self_check(market_data) if self.enhancer else {"passed": True}
        if not health.get("passed", True):
            return {"decision": "WAIT", "confidence": 0, "reason": "self_check_failed"}
        anomaly = self.enhancer.anomaly_check(
            market_data.get("volume_change", 0),
            market_data.get("volatility", 0)
        ) if self.enhancer else {"blocked": False}
        if anomaly.get("blocked"):
            return {"decision": "WAIT", "confidence": 0, "reason": anomaly.get("reason")}
        result = self.decision.decide(market_data) if self.decision else {"decision": "WAIT"}
        _append_capped(self.memory, {"input": market_data, "result": result}, 128)
        return result


TITAN_ULTIMATE = TitanUltimateOrchestrator()

# ============================================================
# FLASK
# ============================================================


app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["TEMPLATES_AUTO_RELOAD"] = False
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 3600
# Android-safe default: local-only dashboard.
HOST = "127.0.0.1"
_default_port = os.environ.get("TITAN_PORT_DEFAULT") or "8080"
try:
    PORT = int(os.environ.get("TITAN_PORT", _default_port) or _default_port)
except (TypeError, ValueError):
    PORT = int(_default_port)

@app.get("/favicon.ico")
def titan_favicon():
    return "", 204

@app.errorhandler(404)
def titan_not_found(exc):
    if request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": "not_found"}), 404
    return ("<h1>TITAN: 404</h1>", 404, {"Content-Type": "text/html; charset=utf-8"})

@app.errorhandler(Exception)
def titan_global_error_handler(exc):
    # Keep API responses JSON, but never leave the human-facing dashboard blank.
    LOGGER.exception("Unhandled application error: %s", exc)
    if request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": "internal_error", "detail": str(exc)[:500]}), 500
    detail = str(exc).replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
    return (
        "<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'>"
        "<title>TITAN Enterprise Error</title>"
        "<body style='background:#050812;color:#eef2ff;font-family:Tahoma;padding:30px'>"
        "<h2 style='color:#38bdf8'>⚡ TITAN ENTERPRISE</h2>"
        "<p>داشبورد با یک خطای داخلی مواجه شد، اما سرور فعال است.</p>"
        f"<pre style='white-space:pre-wrap;background:#0b1220;padding:16px;border-radius:12px'>{detail}</pre>"
        "<p>بعد از رفع خطا صفحه را Refresh کنید.</p></body></html>", 500, {"Content-Type": "text/html; charset=utf-8"}
    )

def _gemini_dashboard_status(summary: str) -> dict[str, Any]:
    return {
        "available": bool(GEMINI_API_KEY),
        "ready": bool(summary.strip()),
        "label": "تحلیل آماده" if summary.strip() else ("کلید Gemini موجود نیست" if not GEMINI_API_KEY else "در انتظار تحلیل"),
        "updated_at": _now_iso(),
    }

HTML = r'''
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
<meta name="titan-fast-paint" content="1">
<style id="titanBoot">body{background:#020711;color:#eaf5ff}#titanBootSplash{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:#020711;font-family:Tahoma,sans-serif;font-size:14px;color:#7dd3fc}#titanBootSplash.hide{opacity:0;pointer-events:none;transition:opacity .25s}</style>
<meta name="theme-color" content="#020711">
<meta name="mobile-web-app-capable" content="yes">

<style>
.scanTelemetry{margin:7px 0 10px;padding:8px 10px;border:1px solid rgba(56,189,248,.18);border-radius:12px;background:linear-gradient(90deg,rgba(8,18,35,.92),rgba(12,27,45,.72));box-shadow:0 0 18px rgba(0,0,0,.12)}.scanTelemetryTop{display:flex;justify-content:space-between;gap:8px;align-items:center;font-size:9px;color:#9fb3c8}.scanTelemetryBar{height:7px;border-radius:99px;background:#091321;overflow:hidden;margin-top:6px;border:1px solid rgba(255,255,255,.05)}.scanTelemetryBar i{display:block;height:100%;width:0%;transition:width .35s ease;background:linear-gradient(90deg,#38bdf8,#22c55e,#facc15)}.scanTelemetryMeta{display:flex;justify-content:space-between;gap:8px;margin-top:4px;font-size:8px;color:#71869c}.perfLearningGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.perfLearnCard{padding:8px;border-radius:10px;background:rgba(255,255,255,.025);border:1px solid rgba(56,189,248,.09)}.perfLearnCard b{display:block;font-size:12px}.perfLearnCard small{display:block;color:#71869c;font-size:7px;margin-top:3px}.perfLearnTable{width:100%;border-collapse:collapse;font-size:8px;margin-top:8px}.perfLearnTable th,.perfLearnTable td{padding:5px;border-bottom:1px solid rgba(255,255,255,.05);text-align:center}.perfLearnTable th{color:#7f9ab3}.perfLearnTable td{color:#d8e7f5}

:root{
 --bg:#030711;--bg2:#06101e;--panel:rgba(7,17,32,.86);--panel2:rgba(10,24,44,.72);
 --line:rgba(92,211,255,.20);--line2:rgba(255,255,255,.08);--text:#eaf5ff;--muted:#7890a8;
 --cyan:#31d7ff;--cyan2:#0ea5e9;--green:#23e6a8;--green2:#10b981;--red:#ff4d73;--gold:#ffd34e;--violet:#a78bfa;--blue:#4f8cff;
 --shadow:0 18px 55px rgba(0,0,0,.42), inset 0 1px 0 rgba(255,255,255,.045);
 --radius:18px;
}
*{box-sizing:border-box}
html,body{margin:0;min-height:100%;background:#02060d;color:var(--text);font-family:'Vazirmatn',Tahoma,sans-serif}
body{padding:0 10px 24px;overflow-x:hidden;background:
 radial-gradient(circle at 78% 2%,rgba(38,122,255,.12),transparent 28%),
 radial-gradient(circle at 12% 24%,rgba(0,230,255,.08),transparent 26%),
 linear-gradient(180deg,#020711 0%,#030913 48%,#02060c 100%)}
button,input{font-family:inherit}button{cursor:pointer}
a{text-decoration:none;color:inherit}
.legacyDashboard{display:none!important}
.titanApp{max-width:1600px;margin:0 auto;padding-top:10px}
.topHeader{position:sticky;top:0;z-index:100;display:grid;grid-template-columns:330px 1fr auto;gap:12px;align-items:center;padding:11px 14px;margin-bottom:10px;border:1px solid rgba(49,215,255,.25);border-radius:20px;background:linear-gradient(110deg,rgba(4,15,29,.96),rgba(8,18,38,.91));box-shadow:var(--shadow);backdrop-filter:blur(22px)}
.brand{display:flex;align-items:center;gap:10px;min-width:0}.brandMark{width:48px;height:48px;display:grid;place-items:center;border-radius:15px;background:linear-gradient(145deg,#082d49,#06111e);border:1px solid rgba(49,215,255,.5);box-shadow:0 0 28px rgba(49,215,255,.12);font-size:28px}.brand h1{margin:0;font-size:19px;line-height:1.1;letter-spacing:.4px;color:#f4fbff}.brand h1 span{color:var(--cyan)}.brand small{display:block;margin-top:3px;color:#7692aa;font-size:9px;letter-spacing:.7px}
.statusStrip{display:flex;gap:8px;overflow:auto;scrollbar-width:none}.statusStrip::-webkit-scrollbar{display:none}.statusPill{display:flex;align-items:center;gap:7px;white-space:nowrap;padding:9px 11px;border:1px solid var(--line2);border-radius:13px;background:rgba(255,255,255,.035);font-size:11px;color:#b7cadb}.statusPill b{color:#eaf5ff}.dot{width:8px;height:8px;border-radius:50%;display:inline-block;background:var(--green);box-shadow:0 0 12px currentColor}.dot.warn{background:var(--gold)}.dot.red{background:var(--red)}
.headerActions{display:flex;gap:7px}.glassBtn{border:1px solid rgba(49,215,255,.28);border-radius:12px;min-height:40px;padding:8px 12px;color:#e8f8ff;background:linear-gradient(145deg,rgba(14,165,233,.18),rgba(79,70,229,.14));box-shadow:inset 0 1px 0 rgba(255,255,255,.05);font-weight:800}.glassBtn:hover{border-color:rgba(49,215,255,.65);transform:translateY(-1px)}.glassBtn.gold{border-color:rgba(255,211,78,.35);background:linear-gradient(145deg,rgba(255,211,78,.15),rgba(245,158,11,.08))}
.appGrid{display:grid;grid-template-columns:205px minmax(0,1fr);gap:10px;align-items:start}.sidebar{position:sticky;top:82px;padding:10px;border:1px solid var(--line);border-radius:20px;background:linear-gradient(180deg,rgba(6,18,33,.95),rgba(4,11,21,.9));box-shadow:var(--shadow);backdrop-filter:blur(18px)}.sideBrand{padding:9px 10px 12px;border-bottom:1px solid var(--line2);margin-bottom:9px}.sideBrand b{font-size:13px}.sideBrand small{display:block;color:var(--muted);font-size:9px;margin-top:3px}.sideBtn{width:100%;display:flex;align-items:center;gap:9px;padding:10px 11px;margin:4px 0;border:1px solid transparent;border-radius:12px;background:transparent;color:#9fb3c7;text-align:right;font-weight:800;font-size:11px}.sideBtn:hover{background:rgba(49,215,255,.07);color:#eaffff}.sideBtn.active{color:#fff;border-color:rgba(49,215,255,.35);background:linear-gradient(90deg,rgba(14,165,233,.25),rgba(79,70,229,.12));box-shadow:0 7px 22px rgba(14,165,233,.10)}.sideIcon{width:25px;height:25px;display:grid;place-items:center;border-radius:8px;background:rgba(255,255,255,.05);font-size:14px}.sideFilter{margin-top:10px;padding-top:10px;border-top:1px solid var(--line2)}.sideFilter label{display:block;color:#6f879f;font-size:9px;margin-bottom:5px}.searchBox{width:100%;padding:9px 10px;border-radius:10px;border:1px solid rgba(49,215,255,.18);background:#06101c;color:#eaf5ff;outline:none;font-size:11px}.filterRow{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;margin-top:6px}.filterBtn{padding:7px 3px;border-radius:8px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.025);color:#91a8bd;font-size:9px;font-weight:900}.filterBtn.active{border-color:rgba(49,215,255,.45);color:#fff;background:rgba(49,215,255,.12)}
.mainArea{min-width:0}.mainTabs{display:flex;gap:6px;overflow:auto;scrollbar-width:none;padding:5px;border:1px solid var(--line);border-radius:16px;background:rgba(5,15,28,.78);margin-bottom:9px}.mainTabs::-webkit-scrollbar{display:none}.mainTab{flex:0 0 auto;border:1px solid transparent;border-radius:11px;padding:9px 12px;color:#8199af;background:transparent;font-size:10px;font-weight:900;white-space:nowrap}.mainTab.active{color:#fff;border-color:rgba(49,215,255,.35);background:linear-gradient(135deg,rgba(14,165,233,.23),rgba(124,58,237,.16));box-shadow:0 8px 22px rgba(14,165,233,.08)}
.tabPanel{display:none}.tabPanel.active{display:block}
.tickerRail{display:grid;grid-template-columns:repeat(7,minmax(150px,1fr));gap:6px;margin-bottom:9px}.ticker{min-width:0;padding:8px 9px;border:1px solid rgba(255,255,255,.07);border-radius:13px;background:linear-gradient(145deg,rgba(9,24,42,.88),rgba(5,13,24,.9));box-shadow:0 9px 28px rgba(0,0,0,.22)}.tickerTop{display:flex;align-items:center;justify-content:space-between;gap:5px}.tickerCoin{display:flex;align-items:center;gap:6px;min-width:0}.tickerIcon{width:27px;height:27px;display:grid;place-items:center;border-radius:9px;background:rgba(255,255,255,.06);font-size:15px}.ticker b{font-size:11px}.ticker small{display:block;color:#657d95;font-size:8px}.tickerPrice{font-size:10px;font-weight:900}.tickerMove{font-size:8px;font-weight:900}.up{color:var(--green)!important}.down{color:var(--red)!important}.neutral{color:var(--gold)!important}
.kpiGrid{display:grid;grid-template-columns:repeat(6,1fr);gap:7px;margin-bottom:9px}.kpi{min-width:0;padding:11px 10px;border:1px solid rgba(255,255,255,.07);border-radius:15px;background:linear-gradient(145deg,rgba(7,23,40,.9),rgba(5,13,24,.92));box-shadow:0 10px 30px rgba(0,0,0,.22)}.kpiHead{display:flex;justify-content:space-between;color:#718aa1;font-size:9px}.kpiValue{margin-top:5px;font-size:19px;font-weight:950}.kpiHint{margin-top:2px;color:#5e7891;font-size:8px}.kpiIcon{font-size:17px;opacity:.85}
.commandGrid{display:grid;grid-template-columns:minmax(0,1fr) 265px;gap:9px}.panel{padding:11px;border:1px solid var(--line);border-radius:18px;background:linear-gradient(145deg,rgba(7,19,35,.93),rgba(4,10,19,.92));box-shadow:var(--shadow);min-width:0}.panelHead{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:9px}.panelTitle{font-size:13px;font-weight:950}.panelSub{font-size:8px;color:#617a92;margin-top:2px}.panelAction{font-size:9px;color:var(--cyan);border:1px solid rgba(49,215,255,.2);padding:6px 8px;border-radius:9px;background:rgba(49,215,255,.05)}
.signalSummary{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:8px}.signalBox{position:relative;overflow:hidden;padding:12px;border-radius:15px;border:1px solid rgba(255,255,255,.07);background:rgba(0,0,0,.16)}.signalBox:after{content:"";position:absolute;width:70px;height:70px;border-radius:50%;right:-20px;top:-25px;background:currentColor;opacity:.07}.signalBox b{font-size:10px}.signalNum{font-size:24px;font-weight:950;margin-top:2px}.signalMeta{font-size:8px;color:#7089a0}.signalBox.long{color:var(--green);border-color:rgba(35,230,168,.28)}.signalBox.wait{color:var(--gold);border-color:rgba(255,211,78,.24)}.signalBox.short{color:var(--red);border-color:rgba(255,77,115,.27)}
.assetHeader{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:8px 0}.assetTools{display:flex;gap:5px;align-items:center}.assetTools button{font-size:9px;padding:6px 8px;border-radius:9px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);color:#91a7bb}.assetTools button.active{color:#fff;border-color:rgba(49,215,255,.4);background:rgba(49,215,255,.10)}
.assetGrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px}.assetCard{position:relative;min-width:0;padding:10px;border:1px solid rgba(255,255,255,.07);border-radius:15px;background:linear-gradient(145deg,rgba(8,24,41,.92),rgba(5,13,23,.92));box-shadow:0 9px 26px rgba(0,0,0,.25);cursor:pointer;overflow:hidden;transition:.16s}.assetCard:hover{transform:translateY(-2px);border-color:rgba(49,215,255,.42);box-shadow:0 15px 32px rgba(0,0,0,.36)}.assetCard.long{border-top:2px solid var(--green)}.assetCard.short{border-top:2px solid var(--red)}.assetCard.wait{border-top:2px solid var(--gold)}.assetTop{display:flex;justify-content:space-between;align-items:center;gap:6px}.assetIdentity{display:flex;align-items:center;gap:7px;min-width:0}.assetIcon{width:32px;height:32px;display:grid;place-items:center;border-radius:10px;background:rgba(255,255,255,.055);font-size:18px;flex:0 0 auto}.assetName{min-width:0}.assetName b{display:block;font-size:11px}.assetName small{display:block;color:#5e7790;font-size:7px;margin-top:1px}.decisionPill{font-size:8px;font-weight:950;padding:5px 7px;border-radius:99px;white-space:nowrap}.decisionPill.long{color:var(--green);background:rgba(35,230,168,.09);border:1px solid rgba(35,230,168,.3)}.decisionPill.short{color:var(--red);background:rgba(255,77,115,.09);border:1px solid rgba(255,77,115,.3)}.decisionPill.wait{color:var(--gold);background:rgba(255,211,78,.09);border:1px solid rgba(255,211,78,.3)}.assetPrice{display:flex;justify-content:space-between;align-items:end;margin:7px 0 5px}.assetPrice b{font-size:13px}.assetPrice span{font-size:8px}.scoreLine{display:flex;align-items:center;gap:6px}.scoreRing{width:35px;height:35px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(var(--ring,#31d7ff) calc(var(--score,0)*1%),#15273a 0);position:relative;flex:0 0 auto}.scoreRing:after{content:"";position:absolute;width:27px;height:27px;border-radius:50%;background:#06111e}.scoreRing span{position:relative;z-index:2;font-size:9px;font-weight:950}.scoreBar{height:5px;flex:1;border-radius:99px;background:#122236;overflow:hidden}.scoreBar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#0ea5e9,#31d7ff)}.assetTF{display:grid;grid-template-columns:repeat(4,1fr);gap:3px;margin-top:7px}.tfMini{padding:4px 2px;text-align:center;border-radius:7px;background:rgba(255,255,255,.025);font-size:7px;color:#607990}.tfMini b{display:block;color:#a8bdd0;font-size:8px;margin-top:2px}.assetBottom{display:flex;justify-content:space-between;gap:4px;margin-top:6px;color:#678099;font-size:7px}.assetOpen{color:var(--cyan);font-weight:900}
.sidePanels{display:grid;gap:9px}.healthList{display:grid;gap:6px}.healthRow{display:flex;justify-content:space-between;align-items:center;padding:7px 8px;border-radius:9px;background:rgba(255,255,255,.025);font-size:8px}.okDot{color:var(--green)}.warnDot{color:var(--gold)}.geminiCard{border-color:rgba(79,140,255,.35);background:linear-gradient(145deg,rgba(15,28,55,.94),rgba(6,13,27,.94))}.aiBadge{display:flex;justify-content:space-between;align-items:center;gap:6px}.aiBadge strong{color:#7db7ff;font-size:12px}.aiText{margin-top:8px;max-height:145px;overflow:auto;color:#b8cae0;font-size:9px;line-height:1.9}.miniGauge{height:7px;background:#13253a;border-radius:99px;overflow:hidden;margin-top:7px}.miniGauge i{display:block;height:100%;background:linear-gradient(90deg,#31d7ff,#8b5cf6);border-radius:99px}
.marketMini{display:grid;grid-template-columns:1fr 1fr;gap:5px}.macroBox{padding:8px;border-radius:10px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.05)}.macroBox small{display:block;color:#617991;font-size:7px}.macroBox b{font-size:12px}.eventList{display:grid;gap:5px}.eventItem{padding:7px;border-radius:9px;background:rgba(255,255,255,.025);border-right:2px solid var(--cyan);font-size:8px}.eventItem b{display:block;font-size:9px}.eventItem small{color:#678098}
.bottomGrid{display:grid;grid-template-columns:1.2fr .8fr;gap:9px;margin-top:9px}.performanceStrip{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.perfStat{padding:8px;border-radius:11px;background:rgba(255,255,255,.025);text-align:center}.perfStat small{display:block;color:#617990;font-size:7px}.perfStat b{display:block;font-size:15px;margin-top:3px}.gaugeDeck{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.tfGauge{padding:8px;text-align:center;border-radius:11px;background:rgba(255,255,255,.025)}.tfGauge .needle{width:50px;height:25px;margin:4px auto 2px;border-radius:50px 50px 0 0;border:5px solid #163047;border-bottom:0;position:relative}.tfGauge .needle:after{content:"";position:absolute;bottom:-3px;left:50%;width:3px;height:22px;background:var(--cyan);transform-origin:bottom center;transform:rotate(var(--rot,0deg));border-radius:4px}.tfGauge b{font-size:9px}.tfGauge small{display:block;color:#617991;font-size:7px}
.globalSection{margin-top:9px}.dataTable{width:100%;border-collapse:collapse;font-size:9px}.dataTable th,.dataTable td{padding:7px 5px;border-bottom:1px solid rgba(255,255,255,.06);text-align:center}.dataTable th{color:#6f8aa2;background:rgba(255,255,255,.025)}.tableWrap{overflow:auto}.miniChip{display:inline-flex;align-items:center;gap:5px;padding:5px 7px;border-radius:8px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.06);font-size:8px;color:#a8bacb}.signalBadge{display:inline-flex;align-items:center;padding:5px 8px;border-radius:99px;font-size:8px;font-weight:950}.signalBadge.long{color:var(--green);background:rgba(35,230,168,.1)}.signalBadge.short{color:var(--red);background:rgba(255,77,115,.1)}.signalBadge.wait{color:var(--gold);background:rgba(255,211,78,.1)}
/* Detail modal redesigned as a full coin workspace */
.modal{display:none;position:fixed;inset:0;z-index:1300;background:rgba(1,4,10,.78);backdrop-filter:blur(10px);align-items:center;justify-content:center;padding:12px}.detailModal .modalC{width:min(1180px,98vw);height:min(92vh,900px);max-height:92vh;overflow:hidden;padding:0;border:1px solid rgba(49,215,255,.28);border-radius:22px;background:#04101d;box-shadow:0 30px 90px rgba(0,0,0,.7)}.cdShell{height:100%;display:flex;flex-direction:column}.cdBanner{padding:14px 16px;border-bottom:1px solid rgba(255,255,255,.07);background:linear-gradient(110deg,rgba(7,28,47,.98),rgba(12,14,39,.98))}.cdBanner.long{background:linear-gradient(110deg,rgba(4,45,35,.98),rgba(5,18,34,.98))}.cdBanner.bear{background:linear-gradient(110deg,rgba(52,10,25,.98),rgba(12,14,39,.98))}.cdBanner.flat{background:linear-gradient(110deg,rgba(43,35,6,.98),rgba(8,18,32,.98))}.cdBannerInner{display:flex;justify-content:space-between;align-items:center;gap:12px}.cdTitleBlock{display:flex;align-items:center;gap:11px}.cdIconXL{width:52px;height:52px;display:grid;place-items:center;border-radius:16px;background:rgba(255,255,255,.06);font-size:27px;border:1px solid rgba(255,255,255,.1)}.modalKicker{color:#66839b;font-size:8px}.cdName{margin:2px 0;font-size:22px}.cdPair{font-size:9px;color:#718aa0}.cdPriceBig{font-size:22px;font-weight:950;text-align:left}.cdPriceBig small{font-size:9px;color:#70889e}.cdBodyPad{padding:10px 12px;overflow:auto}.coinDetailTabs{display:flex;gap:5px;overflow:auto;scrollbar-width:none;padding:5px;border:1px solid rgba(255,255,255,.07);border-radius:13px;background:rgba(0,0,0,.18);margin-bottom:9px}.coinDetailTabs::-webkit-scrollbar{display:none}.coinDetailTab{flex:0 0 auto;padding:8px 10px;border:1px solid transparent;border-radius:9px;background:transparent;color:#8299ae;font-size:9px;font-weight:900}.coinDetailTab.active{color:#fff;border-color:rgba(49,215,255,.35);background:rgba(49,215,255,.10)}.coinDetailPanel{display:none}.coinDetailPanel.active{display:block}.cdMetrics{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.cdMetric{padding:11px;text-align:center;border-radius:13px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06)}.cdMetric .ico{font-size:17px}.cdMetric .val{font-size:20px;font-weight:950;margin:3px 0}.cdMetric small{font-size:8px;color:#607990}.cdInfoBox{margin-top:8px;padding:10px;border-radius:12px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06);font-size:10px;line-height:1.9;color:#b6c8da}.cdSectionLabel{margin:10px 0 6px;font-size:10px;color:var(--cyan);font-weight:900}.cdTfStrip{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.cdTfCell{padding:9px;text-align:center;border-radius:11px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06)}.cdTfCell small{display:block;color:#607990;font-size:7px}.cdTfCell b{display:block;margin-top:4px;font-size:9px}.cdLevels{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.cdLevelCard{padding:11px;border-radius:13px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06)}.cdLevelCard .lbl{font-size:8px;color:#7891a6}.cdLevelCard .num{font-size:15px;font-weight:950;margin-top:4px}.detailActionGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.aiDetailGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.aiDetailCard{padding:11px;border-radius:13px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06);font-size:9px;line-height:1.9}.aiDetailCard>b{display:block;color:#a9c3d8;margin-bottom:5px}.cdChartBox{padding:8px;border-radius:14px;background:#06111d;border:1px solid rgba(49,215,255,.14)}.cdChartBox canvas{width:100%;height:320px;display:block}.cdFullDetails{font-size:9px}.cdFullDetails .card{display:block!important;background:rgba(255,255,255,.02)!important;box-shadow:none!important;border:1px solid rgba(255,255,255,.06)!important}.cdActions{display:flex;justify-content:flex-end;gap:7px;margin-top:9px}.iconBtn{min-width:40px;padding:8px}
/* global tabs */
.sectionGrid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.bigPanel{min-height:120px}.metricCards{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.metricBox{padding:10px;text-align:center;border-radius:12px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06)}.metricBox b{font-size:18px}.preBox{white-space:pre-wrap;background:#020711;padding:10px;border-radius:11px;color:#b8cadb;max-height:360px;overflow:auto;font-size:9px;line-height:1.7}.perfVisual{padding:0;border:0;background:none;box-shadow:none}.perfGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.perfCard{padding:11px;border-radius:13px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06);text-align:center}.perfCard small{font-size:8px;color:#647e95}.perfBig{font-size:22px;font-weight:950;margin:5px}.ring{width:78px;height:78px;border-radius:50%;display:grid;place-items:center;margin:7px auto;background:conic-gradient(var(--green) calc(var(--v)*1%),#14283b 0);position:relative}.ring:after{content:"";width:57px;height:57px;border-radius:50%;background:#06111e;position:absolute}.ring span{position:relative;z-index:2;font-size:13px;font-weight:950}.tfVisual{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.tfBox{padding:9px;border-radius:11px;background:rgba(255,255,255,.025);text-align:center}.tfBar{height:7px;background:#14273a;border-radius:99px;overflow:hidden;margin-top:6px}.tfBar i{display:block;height:100%;background:linear-gradient(90deg,var(--cyan),var(--violet));border-radius:99px}.perfCharts{display:grid;grid-template-columns:1.3fr .7fr;gap:7px;margin-top:7px}.chartPanel{padding:10px;border-radius:12px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06)}.chartPanel h3{font-size:9px;margin:0 0 6px;color:#8aa3b8}.perfCanvas{width:100%;height:210px}.perfNote{font-size:8px;color:#647e95;margin-top:6px}.gaugeGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.tfGaugeCard{padding:12px;border-radius:13px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.06);text-align:center}.tfGaugeCard .arc{width:92px;height:46px;margin:5px auto 0;border:9px solid #153047;border-bottom:0;border-radius:90px 90px 0 0;position:relative}.tfGaugeCard .arc:after{content:"";position:absolute;bottom:-6px;left:50%;width:4px;height:42px;background:var(--cyan);transform-origin:bottom center;transform:rotate(var(--rot,0deg));border-radius:5px}.tfGaugeCard b{font-size:11px}.tfGaugeCard small{display:block;color:#688098;font-size:8px}
@media(max-width:1200px){.tickerRail{grid-template-columns:repeat(4,minmax(150px,1fr))}.assetGrid{grid-template-columns:repeat(3,1fr)}.kpiGrid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:900px){body{padding:0 6px 18px}.topHeader{position:relative;grid-template-columns:1fr;gap:7px}.headerActions{width:100%}.headerActions>*{flex:1}.appGrid{grid-template-columns:1fr}.sidebar{position:relative;top:auto;display:flex;gap:5px;overflow:auto;padding:6px}.sideBrand,.sideFilter{display:none}.sideBtn{width:auto;flex:0 0 auto;margin:0;padding:8px 10px}.sideBtn span:not(.sideIcon){display:none}.sideIcon{width:28px;height:28px}.tickerRail{grid-template-columns:repeat(3,minmax(145px,1fr));overflow:auto}.commandGrid{grid-template-columns:1fr}.sidePanels{grid-template-columns:repeat(2,1fr)}.assetGrid{grid-template-columns:repeat(2,1fr)}.kpiGrid{grid-template-columns:repeat(3,1fr)}.bottomGrid,.sectionGrid{grid-template-columns:1fr}.perfGrid{grid-template-columns:1fr 1fr}.cdLevels{grid-template-columns:1fr 1fr}.cdMetrics{grid-template-columns:1fr 1fr}.gaugeGrid{grid-template-columns:1fr 1fr}.detailActionGrid,.aiDetailGrid{grid-template-columns:1fr}.perfCharts{grid-template-columns:1fr}}
@media(max-width:600px){.brand h1{font-size:17px}.statusStrip{width:100%}.kpiGrid{grid-template-columns:1fr 1fr}.assetGrid{grid-template-columns:1fr 1fr}.assetCard{padding:8px}.assetPrice b{font-size:11px}.tickerRail{grid-template-columns:repeat(2,minmax(145px,1fr))}.sidePanels{grid-template-columns:1fr}.signalSummary{grid-template-columns:1fr 1fr 1fr}.signalBox{padding:9px}.signalNum{font-size:19px}.cdName{font-size:18px}.cdPriceBig{font-size:18px}.cdBannerInner{align-items:flex-start}.cdChartBox canvas{height:230px}.perfGrid{grid-template-columns:1fr 1fr}.gaugeDeck{grid-template-columns:1fr 1fr}.tfVisual{grid-template-columns:1fr 1fr}}

/* ============================================================
   TITAN MOBILE ULTRA — presentation layer only
   No engine/data/API/decision logic is changed.
   Designed for Android phones: larger typography, touch targets,
   clearer hierarchy, stronger contrast and fewer tiny controls.
   ============================================================ */
@media(max-width:600px){
  :root{--mobilePad:8px}
  html{font-size:16px;-webkit-text-size-adjust:100%;text-size-adjust:100%}
  body{padding:0 var(--mobilePad) calc(28px + env(safe-area-inset-bottom));font-size:16px;line-height:1.55}
  .titanApp{width:100%;max-width:none;padding-top:8px}

  /* Header / branding */
  .topHeader{padding:13px 12px;margin-bottom:10px;border-radius:20px;gap:10px}
  .brand{gap:12px;min-height:62px}
  .brandMark{width:62px!important;height:62px!important;border-radius:18px;font-size:35px!important;flex:0 0 62px}
  .brand h1{font-size:22px!important;line-height:1.2;letter-spacing:.2px}
  .brand small{font-size:11px!important;line-height:1.5;margin-top:4px;letter-spacing:.2px}
  .statusStrip{gap:7px;padding-bottom:2px}
  .statusPill{min-height:42px;padding:9px 12px;font-size:13px!important;border-radius:13px}
  .statusPill b{font-size:13px!important}
  .dot{width:10px;height:10px;flex:0 0 10px}
  .headerActions{gap:8px}
  .headerActions .glassBtn{min-height:48px;padding:10px 12px;font-size:14px!important;border-radius:13px}

  /* Phone navigation */
  .appGrid{display:block}
  .sidebar{position:relative;top:auto;margin-bottom:10px;padding:7px;border-radius:17px;overflow-x:auto;overflow-y:hidden;display:flex;gap:7px;scroll-snap-type:x proximity}
  .sideBrand,.sideFilter{display:none!important}
  .sideBtn{width:auto;min-width:104px;min-height:52px;flex:0 0 auto;margin:0;padding:8px 11px;display:flex;justify-content:center;gap:7px;border-radius:13px;font-size:13px!important;scroll-snap-align:start}
  .sideBtn span:not(.sideIcon){display:inline!important;white-space:nowrap}
  .sideIcon{width:32px;height:32px;min-width:32px;border-radius:10px;font-size:18px!important}

  .mainArea{width:100%}
  .mainTabs{gap:6px;padding:6px;margin-bottom:10px;border-radius:15px}
  .mainTab{min-height:44px;padding:9px 13px;font-size:13px!important;border-radius:11px}

  /* Quick market rail */
  .tickerRail{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;overflow:visible}
  .ticker{padding:11px 10px;border-radius:15px;min-height:88px}
  .tickerIcon{width:36px;height:36px;border-radius:11px;font-size:20px!important}
  .tickerCoin{gap:8px}
  .ticker b{font-size:14px!important}
  .ticker small{font-size:10px!important;margin-top:1px}
  .tickerPrice{font-size:13px!important}
  .tickerMove{font-size:11px!important}

  /* KPI / signal cards */
  .kpiGrid{grid-template-columns:1fr 1fr;gap:8px}
  .kpi{padding:13px 12px;min-height:92px;border-radius:16px}
  .kpiHead{font-size:11px!important}
  .kpiValue{font-size:25px!important;line-height:1.15}
  .kpiHint{font-size:10px!important;line-height:1.5}
  .kpiIcon{font-size:22px!important}
  .signalSummary{grid-template-columns:1fr 1fr 1fr;gap:6px}
  .signalBox{padding:11px 8px;min-height:92px;border-radius:15px}
  .signalBox b{font-size:12px!important}
  .signalNum{font-size:24px!important}
  .signalMeta{font-size:10px!important}

  /* Main panels */
  .commandGrid,.sectionGrid,.bottomGrid,.sidePanels{grid-template-columns:1fr!important}
  .panel{padding:13px;border-radius:18px}
  .panelHead{margin-bottom:10px}
  .panelTitle{font-size:17px!important;line-height:1.4}
  .panelSub{font-size:11px!important;line-height:1.5}
  .panelAction{font-size:11px!important;padding:8px 10px}
  .glassBtn{min-height:46px;padding:9px 12px;font-size:13px!important;border-radius:12px}

  /* Asset cards: two readable columns */
  .assetHeader{margin:10px 0 8px;align-items:flex-start}
  .assetHeader .panelTitle{font-size:16px!important}
  .assetTools{gap:5px;flex-wrap:wrap;justify-content:flex-end}
  .assetTools button{min-height:40px;padding:8px 10px;font-size:11px!important;border-radius:10px}
  .assetGrid{grid-template-columns:1fr 1fr!important;gap:8px}
  .assetCard{padding:11px!important;min-height:154px;border-radius:16px}
  .assetIdentity{gap:8px}
  .assetIcon{width:40px;height:40px;font-size:23px!important;border-radius:12px}
  .assetName b{font-size:14px!important}
  .assetName small{font-size:9px!important}
  .decisionPill{font-size:10px!important;padding:6px 7px}
  .assetPrice{margin:9px 0 7px}
  .assetPrice b{font-size:14px!important}
  .assetPrice span{font-size:10px!important}
  .scoreRing{width:45px;height:45px}
  .scoreRing:after{width:34px;height:34px}
  .scoreRing span{font-size:11px!important}
  .scoreBar{height:7px}
  .assetCard .tfMini,.assetCard .tfRow,.assetCard .timeframes{font-size:10px!important}

  /* AI / performance typography */
  .aiText{font-size:13px!important;line-height:2!important}
  .metricCards{grid-template-columns:1fr 1fr;gap:8px}
  .metricBox{padding:12px;min-height:75px}
  .metricBox small{font-size:10px!important}
  .metricBox b{font-size:20px!important}
  .preBox{font-size:11px!important;line-height:1.8}
  .perfGrid{grid-template-columns:1fr 1fr!important;gap:8px}
  .perfCard{padding:13px;min-height:118px}
  .perfCard small{font-size:10px!important}
  .perfBig{font-size:25px!important}
  .ring{width:88px;height:88px}
  .ring:after{width:64px;height:64px}
  .ring span{font-size:15px!important}
  .chartPanel{padding:12px;border-radius:14px}
  .chartPanel h3{font-size:12px!important}
  .perfCanvas{height:230px}
  .tfVisual{grid-template-columns:1fr 1fr!important;gap:7px}
  .tfBox{padding:12px;font-size:11px!important}
  .tfBox b{font-size:15px!important}
  .perfNote{font-size:10px!important;line-height:1.7}
  .gaugeGrid{grid-template-columns:1fr 1fr!important}
  .tfGaugeCard{padding:13px}
  .tfGaugeCard b{font-size:14px!important}
  .tfGaugeCard small{font-size:10px!important}

  /* Command-center HUD */
  .hudgrid{grid-template-columns:1fr 1fr!important;gap:7px!important}
  .hudbox{padding:12px!important;border-radius:13px!important}
  .hudbox>div:first-child{font-size:11px!important}
  .hudbox .v{font-size:21px!important}

  /* Coin detail modal becomes a phone-first full-screen workspace */
  .modal{padding:0!important}
  .detailModal .modalBox,.modal .modalBox{width:100%!important;max-width:none!important;max-height:96vh!important;height:96vh!important;margin:2vh 0 0!important;border-radius:22px 22px 0 0!important}
  .cdBanner{padding:12px!important}
  .cdIcon{width:52px!important;height:52px!important;font-size:29px!important;border-radius:15px!important}
  .cdName{font-size:23px!important;line-height:1.25}
  .cdPair{font-size:11px!important}
  .cdPriceBig{font-size:23px!important}
  .cdPriceBig small{font-size:10px!important}
  .cdBodyPad{padding:10px!important}
  .coinDetailTabs{gap:5px;padding:5px;margin-bottom:10px}
  .coinDetailTab{min-height:44px;padding:9px 11px;font-size:12px!important;border-radius:10px}
  .cdMetrics{grid-template-columns:1fr 1fr!important;gap:7px}
  .cdMetric{padding:12px;min-height:95px}
  .cdMetric .ico{font-size:22px!important}
  .cdMetric .val{font-size:23px!important}
  .cdMetric small{font-size:10px!important}
  .cdInfoBox{font-size:12px!important;line-height:1.95}
  .cdSectionLabel{font-size:13px!important}
  .cdTfStrip{grid-template-columns:1fr 1fr!important;gap:7px}
  .cdTfCell{padding:11px;min-height:70px}
  .cdTfCell small{font-size:9px!important}
  .cdTfCell b{font-size:12px!important}
  .cdLevels{grid-template-columns:1fr 1fr!important}
  .cdLevelCard{padding:12px}
  .cdLevelCard .lbl{font-size:10px!important}
  .cdLevelCard .num{font-size:17px!important}
  .detailActionGrid,.aiDetailGrid{grid-template-columns:1fr!important}
  .aiDetailCard{padding:13px;font-size:12px!important;line-height:1.9}
  .cdChartBox canvas{height:280px!important}
  .cdFullDetails{font-size:11px!important}

  /* Quick navigation rail/cards */
  .titanNavShell{padding:10px!important;border-radius:18px!important}
  .titanNavHead{gap:8px!important}
  .titanNavTitle{font-size:17px!important}
  .titanNavSub{font-size:10px!important;line-height:1.5}
  .titanNavFilters{gap:5px!important}
  .titanNavFilters button{min-height:42px!important;padding:8px 10px!important;font-size:11px!important}
  .titanCoinRail{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;overflow:visible!important}
  .coinMiniCard{min-height:132px!important;padding:11px!important;border-radius:16px!important}
  .coinMiniIcon{width:39px!important;height:39px!important;font-size:22px!important;border-radius:12px!important}
  .coinMiniIdentity b{font-size:14px!important}
  .coinMiniIdentity small{font-size:9px!important}
  .coinMiniDecision{font-size:10px!important}
  .coinMiniPriceLine{font-size:10px!important}
  .coinMiniPriceLine strong{font-size:17px!important}
  .coinMiniPriceLine i{height:7px!important}
  .coinMiniTF{font-size:10px!important;gap:4px!important}
  .coinMiniOpen{font-size:11px!important}

  /* Avoid accidental tiny inline text throughout the redesigned dashboard. */
  .titanApp .miniChip{font-size:10px!important;min-height:30px;padding:6px 8px}
  .titanApp .signalBadge{font-size:10px!important;padding:7px 9px}
  .titanApp table{font-size:11px!important}
  .titanApp th,.titanApp td{padding:9px 7px!important}
}

@media(max-width:380px){
  body{padding-left:6px;padding-right:6px}
  .brand h1{font-size:20px!important}
  .brandMark{width:58px!important;height:58px!important;flex-basis:58px;font-size:32px!important}
  .brand small{font-size:10px!important}
  .ticker{min-height:82px;padding:9px}
  .tickerIcon{width:33px;height:33px;font-size:18px!important}
  .ticker b{font-size:13px!important}
  .tickerPrice{font-size:12px!important}
  .assetCard{padding:9px!important;min-height:145px}
  .assetIcon{width:36px;height:36px;font-size:21px!important}
  .assetName b{font-size:13px!important}
  .decisionPill{font-size:9px!important;padding:5px 6px}
  .scoreRing{width:41px;height:41px}
  .scoreRing:after{width:31px;height:31px}
  .scoreRing span{font-size:10px!important}
  .coinMiniCard{min-height:126px!important;padding:9px!important}
  .coinMiniIdentity b{font-size:13px!important}
  .coinMiniPriceLine strong{font-size:15px!important}
  .cdName{font-size:21px!important}
  .cdPriceBig{font-size:21px!important}
}

/* Larger phones / landscape: use the extra width instead of enlarging everything too much. */
@media(min-width:601px) and (max-width:900px){
  html{font-size:15px}
  .brand h1{font-size:21px}
  .panelTitle{font-size:15px}
  .assetName b{font-size:13px}
}



.cdVisualSummary{margin-bottom:10px;padding:12px;border-radius:17px;background:linear-gradient(145deg,rgba(9,29,48,.98),rgba(12,17,38,.98));border:1px solid rgba(49,215,255,.20);box-shadow:0 12px 35px rgba(0,0,0,.25)}
.cdVisualHero{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.07)}
.cdVisualKicker{display:block;color:#6f8da5;font-size:9px;margin-bottom:3px}.cdVisualHero strong{display:block;font-size:18px;color:#fff;font-weight:1000}.cdVisualHero small{display:block;color:#9eb4c7;font-size:10px;margin-top:3px}.cdVisualDecision{padding:9px 12px;border-radius:12px;font-size:13px;font-weight:1000;border:1px solid currentColor}.cdVisualDecision.long{color:#4ade80;background:rgba(74,222,128,.10)}.cdVisualDecision.short{color:#fb7185;background:rgba(251,113,133,.10)}.cdVisualDecision.wait{color:#facc15;background:rgba(250,204,21,.10)}
.cdVisualGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:7px}.cdVisualStat{padding:9px;border-radius:12px;background:rgba(255,255,255,.028);border:1px solid rgba(255,255,255,.06);text-align:center}.cdVisualStat span{display:block;color:#7893a9;font-size:8px}.cdVisualStat b{display:block;color:#fff;font-size:15px;margin-top:3px}.cdVisualStat small{font-size:8px;color:#7992a7;margin-right:2px}.cdVisualLevels{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:7px}.cdVisualLevels>div{padding:9px;border-radius:12px;text-align:center;background:linear-gradient(145deg,rgba(35,230,168,.08),rgba(255,255,255,.025));border:1px solid rgba(35,230,168,.12)}.cdVisualLevels span{display:block;color:#7893a9;font-size:8px}.cdVisualLevels b{display:block;color:#fff;font-size:12px;margin-top:3px}.cdVisualFlow{display:flex;align-items:center;gap:5px;margin-top:8px;overflow:hidden}.cdVisualFlow span{white-space:nowrap;padding:6px 8px;border-radius:9px;background:rgba(49,215,255,.06);border:1px solid rgba(49,215,255,.12);color:#bfefff;font-size:8px;font-weight:900}.cdVisualFlow i{height:1px;min-width:12px;flex:1;background:linear-gradient(90deg,rgba(49,215,255,.45),rgba(167,139,250,.35))}
@media(max-width:600px){.cdVisualGrid{grid-template-columns:repeat(2,1fr)}.cdVisualLevels{grid-template-columns:repeat(2,1fr)}.cdVisualHero strong{font-size:16px}.cdVisualDecision{font-size:11px}.cdVisualFlow span{font-size:7px;padding:6px 5px}.cdVisualFlow i{min-width:5px}}

/* ============================================================
   V27.1 MOBILE CLARITY + VISUAL DETAILS PATCH
   UI-only styling plus opportunity-preserving decision refinement below.
   ============================================================ */
@media(max-width:600px){
  .titanCoinRail{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important}
  .coinMiniCard{
    min-height:158px!important;padding:13px!important;border-radius:19px!important;
    border-width:1.5px!important;box-shadow:0 12px 30px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.08)!important;
  }
  .coinMiniCard.long{border-color:rgba(35,230,168,.50)!important;background:linear-gradient(145deg,rgba(8,53,45,.94),rgba(4,18,31,.98))!important}
  .coinMiniCard.wait{border-color:rgba(255,211,78,.50)!important;background:linear-gradient(145deg,rgba(54,44,9,.92),rgba(18,18,23,.98))!important}
  .coinMiniCard.short{border-color:rgba(255,77,115,.50)!important;background:linear-gradient(145deg,rgba(58,12,30,.94),rgba(18,14,25,.98))!important}
  .coinMiniTop{align-items:center!important;gap:8px!important}
  .coinMiniIdentity{gap:9px!important;min-width:0!important}
  .coinMiniIcon{
    width:52px!important;height:52px!important;min-width:52px!important;border-radius:15px!important;
    font-size:30px!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.18),rgba(255,255,255,.035) 58%)!important;
    border:1px solid rgba(255,255,255,.14)!important;box-shadow:0 0 18px rgba(49,215,255,.12)!important;
    display:grid!important;place-items:center!important;font-weight:950!important
  }
  .coinMiniIdentity b{display:block!important;font-size:17px!important;line-height:1.1!important;color:#fff!important;font-weight:1000!important;text-shadow:0 1px 10px rgba(255,255,255,.12)}
  .coinMiniIdentity small{display:block!important;font-size:11px!important;color:#b9cad9!important;margin-top:4px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;max-width:92px}
  .coinMiniDecision{font-size:11px!important;font-weight:1000!important;padding:7px 8px!important;border-radius:10px!important;border:1px solid currentColor!important;background:rgba(0,0,0,.18)!important;white-space:nowrap!important}
  .coinMiniPriceLine{margin-top:11px!important;font-size:10px!important;color:#9bb0c2!important}
  .coinMiniPriceLine strong{font-size:19px!important;color:#fff!important;font-weight:1000!important;letter-spacing:.1px!important;text-shadow:0 2px 12px rgba(49,215,255,.15)!important}
  .coinMiniPriceLine i{height:8px!important;margin-top:6px!important;background:#0d2234!important;border:1px solid rgba(255,255,255,.05)!important}
  .coinMiniTF{margin-top:9px!important;grid-template-columns:repeat(4,1fr)!important;gap:4px!important}
  .coinMiniTF span{padding:5px 2px!important;border-radius:8px!important;background:rgba(255,255,255,.045)!important;border:1px solid rgba(255,255,255,.06)!important;font-size:9px!important;color:#9fb2c3!important}
  .coinMiniTF b{display:block!important;font-size:11px!important;color:#fff!important;margin-top:2px!important;font-weight:950!important}
  .coinMiniOpen{margin-top:9px!important;padding:7px 8px!important;border-radius:9px!important;background:rgba(49,215,255,.07)!important;border:1px solid rgba(49,215,255,.20)!important;color:#bff3ff!important;font-size:11px!important;font-weight:950!important;text-align:center!important}

  /* Full-detail tab: turn the legacy detailed card into visual modules. */
  .cdFullDetails{font-size:12px!important;line-height:1.8!important}
  .cdFullDetails>.card{padding:13px!important;border-radius:18px!important;background:linear-gradient(145deg,rgba(7,22,39,.96),rgba(4,11,21,.98))!important}
  .cdFullDetails .ch{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:10px!important;padding:12px!important;border-radius:15px!important;background:linear-gradient(135deg,rgba(49,215,255,.10),rgba(124,58,237,.09))!important;border:1px solid rgba(49,215,255,.20)!important}
  .cdFullDetails .coin{display:flex!important;align-items:center!important;gap:10px!important}
  .cdFullDetails .coin .icon{width:56px!important;height:56px!important;display:grid!important;place-items:center!important;border-radius:16px!important;font-size:31px!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.20),rgba(255,255,255,.04) 60%)!important;border:1px solid rgba(255,255,255,.14)!important;box-shadow:0 0 24px rgba(49,215,255,.12)!important}
  .cdFullDetails .coin .name{font-size:18px!important;font-weight:1000!important;color:#fff!important}
  .cdFullDetails .coin .ticker{font-size:10px!important;color:#9eb4c7!important;margin-top:3px!important}
  .cdFullDetails .price{font-size:20px!important;font-weight:1000!important;color:#fff!important;white-space:nowrap!important}
  .cdFullDetails .price small{font-size:10px!important;color:#89a1b5!important}
  .cdFullDetails .scoreRow{margin-top:10px!important;padding:11px!important;border-radius:14px!important;background:rgba(255,255,255,.035)!important;border:1px solid rgba(255,255,255,.07)!important}
  .cdFullDetails .ringGauge{width:64px!important;height:64px!important}
  .cdFullDetails .ringGauge span{font-size:15px!important;font-weight:1000!important}
  .cdFullDetails .bar{height:9px!important;margin-top:9px!important;border-radius:99px!important;background:#0d2234!important;overflow:hidden!important}
  .cdFullDetails .scoreOrbit{display:grid!important;grid-template-columns:repeat(2,1fr)!important;gap:7px!important}
  .cdFullDetails .orbitItem{padding:10px!important;border-radius:12px!important;background:linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.018))!important;border:1px solid rgba(255,255,255,.07)!important;text-align:center!important}
  .cdFullDetails .orbitItem small{display:block!important;color:#7893a9!important;font-size:9px!important}
  .cdFullDetails .orbitItem b{display:block!important;font-size:16px!important;color:#fff!important;margin-top:3px!important}
  .cdFullDetails .tf{display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:6px!important;margin-top:9px!important}
  .cdFullDetails .tf span{padding:9px 3px!important;border-radius:11px!important;background:rgba(49,215,255,.06)!important;border:1px solid rgba(49,215,255,.12)!important;text-align:center!important;color:#8fa7bb!important;font-size:9px!important}
  .cdFullDetails .tf b{display:block!important;color:#fff!important;font-size:12px!important;margin-top:3px!important}
  .cdFullDetails .levels{display:grid!important;grid-template-columns:repeat(2,1fr)!important;gap:7px!important;margin-top:9px!important}
  .cdFullDetails .level{padding:11px!important;border-radius:13px!important;background:rgba(255,255,255,.035)!important;border:1px solid rgba(255,255,255,.07)!important;font-size:10px!important;color:#9db2c4!important}
  .cdFullDetails .level b{display:block!important;font-size:15px!important;color:#fff!important;margin-top:3px!important}
  .cdFullDetails .dualLevels{display:grid!important;grid-template-columns:1fr!important;gap:8px!important;margin-top:9px!important}
  .cdFullDetails .dualBox{padding:13px!important;border-radius:15px!important;font-size:11px!important;line-height:2!important;background:rgba(255,255,255,.03)!important;border:1px solid rgba(255,255,255,.08)!important}
  .cdFullDetails .panelTech{margin-top:9px!important;padding:13px!important;border-radius:15px!important;background:linear-gradient(145deg,rgba(7,26,43,.88),rgba(7,14,27,.96))!important;border:1px solid rgba(49,215,255,.16)!important}
  .cdFullDetails .panelTech .title{display:flex!important;align-items:center!important;gap:6px!important;font-size:13px!important;color:#dff9ff!important;margin-bottom:8px!important}
  .cdFullDetails .gaugeRow{display:grid!important;grid-template-columns:1fr 1fr!important;gap:8px!important}
  .cdFullDetails .gaugeRow>*{min-width:0!important}
  .cdFullDetails table{font-size:10px!important}
  .cdFullDetails table th,.cdFullDetails table td{padding:8px 5px!important}
  .cdFullDetails .miniChip,.cdFullDetails .signalBadge{font-size:10px!important;padding:7px 9px!important}
  .cdFullDetails .gradeBadge{font-size:12px!important;padding:6px 9px!important}
}
@media(max-width:380px){
  .titanCoinRail{grid-template-columns:1fr 1fr!important}
  .coinMiniCard{min-height:150px!important;padding:10px!important}
  .coinMiniIcon{width:46px!important;height:46px!important;min-width:46px!important;font-size:27px!important}
  .coinMiniIdentity b{font-size:15px!important}
  .coinMiniIdentity small{font-size:10px!important;max-width:82px}
  .coinMiniPriceLine strong{font-size:17px!important}
  .cdFullDetails .coin .icon{width:50px!important;height:50px!important;font-size:28px!important}
  .cdFullDetails .coin .name{font-size:16px!important}
}


/* V27.2 MOBILE CLARITY + GRAPHICAL DETAILS */
@media(max-width:600px){
  .titanCoinRail{grid-template-columns:1fr 1fr!important;gap:11px!important}
  .coinMiniCard{color:#f7fbff!important;min-height:176px!important;padding:13px!important;background:linear-gradient(145deg,#102a43 0%,#081a2e 52%,#050e1c 100%)!important;border:2px solid rgba(72,203,255,.42)!important;border-radius:20px!important;box-shadow:0 14px 34px rgba(0,0,0,.38),inset 0 1px 0 rgba(255,255,255,.12)!important}
  .coinMiniCard.long{background:linear-gradient(145deg,#073e35 0%,#082a2c 52%,#061421 100%)!important;border-color:rgba(42,245,177,.78)!important}
  .coinMiniCard.wait{background:linear-gradient(145deg,#493b09 0%,#29250e 52%,#101622 100%)!important;border-color:rgba(255,214,74,.82)!important}
  .coinMiniCard.short{background:linear-gradient(145deg,#4a102c 0%,#2c1229 52%,#101421 100%)!important;border-color:rgba(255,91,125,.82)!important}
  .coinMiniTop{display:flex!important;justify-content:space-between!important;align-items:flex-start!important;gap:7px!important}
  .coinMiniIdentity{display:flex!important;align-items:center!important;gap:10px!important;min-width:0!important}
  .coinMiniIcon{width:56px!important;height:56px!important;min-width:56px!important;display:grid!important;place-items:center!important;border-radius:17px!important;font-size:31px!important;color:#fff!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.30),rgba(49,215,255,.10) 45%,rgba(0,0,0,.18) 100%)!important;border:2px solid rgba(255,255,255,.18)!important;box-shadow:0 0 24px rgba(49,215,255,.22)!important}
  .coinMiniIdentity b{display:block!important;color:#fff!important;font-size:19px!important;font-weight:1000!important;line-height:1.05!important;text-shadow:0 2px 12px rgba(0,0,0,.55)!important}
  .coinMiniIdentity small{display:block!important;color:#d4e7f6!important;font-size:11px!important;font-weight:800!important;margin-top:5px!important;max-width:105px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}
  .coinMiniDecision{flex:0 0 auto!important;font-size:11px!important;font-weight:1000!important;padding:8px 9px!important;border-radius:11px!important;background:rgba(0,0,0,.32)!important;border:1.5px solid currentColor!important}
  .coinMiniPriceLine{display:grid!important;grid-template-columns:1fr auto!important;align-items:center!important;gap:3px 8px!important;margin-top:12px!important;padding:9px 10px!important;border-radius:14px!important;background:rgba(0,0,0,.28)!important;border:1px solid rgba(255,255,255,.12)!important}
  .coinMiniPriceLabel{color:#b9d3e6!important;font-size:10px!important;font-weight:900!important;grid-column:1!important}
  .coinMiniPriceValue{grid-column:1!important;color:#fff!important;font-size:21px!important;font-weight:1000!important;line-height:1.05!important;white-space:nowrap!important;text-shadow:0 2px 14px rgba(49,215,255,.30)!important}
  .coinMiniPriceValue small{font-size:9px!important;color:#9fc1d8!important}
  .coinMiniScoreBadge{grid-column:2!important;grid-row:1 / span 2!important;align-self:center!important;padding:7px 8px!important;border-radius:11px!important;background:rgba(49,215,255,.13)!important;border:1px solid rgba(49,215,255,.28)!important;color:#e5fbff!important;font-size:10px!important;font-weight:1000!important}
  .coinMiniPriceLine>i{grid-column:1 / -1!important;width:100%!important;height:9px!important;margin:3px 0 0!important;background:#071522!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:99px!important;overflow:hidden!important}
  .coinMiniPriceLine>i em{display:block!important;height:100%!important;border-radius:99px!important;background:linear-gradient(90deg,#22d3ee,#8b5cf6,#34d399)!important}
  .coinMiniTF{margin-top:9px!important;display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:4px!important}
  .coinMiniTF span{padding:5px 2px!important;text-align:center!important;border-radius:9px!important;background:rgba(255,255,255,.075)!important;border:1px solid rgba(255,255,255,.11)!important;color:#c3d8e7!important;font-size:9px!important;font-weight:800!important}
  .coinMiniTF b{display:block!important;color:#fff!important;font-size:11px!important;font-weight:1000!important;margin-top:2px!important}
  .coinMiniOpen{display:block!important;margin-top:9px!important;padding:8px!important;text-align:center!important;border-radius:10px!important;background:linear-gradient(90deg,rgba(49,215,255,.15),rgba(139,92,246,.13))!important;border:1px solid rgba(49,215,255,.30)!important;color:#e2fbff!important;font-size:11px!important;font-weight:1000!important}
  .cdFullDetails{font-size:12px!important;color:#d9e8f4!important;line-height:1.85!important}
  .cdFullDetails>.card{padding:12px!important;border-radius:20px!important;background:linear-gradient(145deg,#0b2035,#06111f)!important;border:1px solid rgba(49,215,255,.28)!important;box-shadow:0 12px 35px rgba(0,0,0,.30)!important}
  .cdFullDetails .ch{padding:13px!important;border-radius:16px!important;background:linear-gradient(135deg,rgba(49,215,255,.15),rgba(139,92,246,.12),rgba(35,230,168,.08))!important;border:1px solid rgba(49,215,255,.28)!important}
  .cdFullDetails .coin .icon{width:62px!important;height:62px!important;font-size:34px!important;border-radius:18px!important;color:#fff!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.28),rgba(49,215,255,.08) 50%,rgba(0,0,0,.20))!important;border:2px solid rgba(255,255,255,.16)!important;box-shadow:0 0 28px rgba(49,215,255,.20)!important}
  .cdFullDetails .coin .name{font-size:20px!important;color:#fff!important;font-weight:1000!important}.cdFullDetails .coin .ticker{font-size:11px!important;color:#b7d0e2!important;font-weight:800!important}.cdFullDetails .price{font-size:22px!important;color:#fff!important;font-weight:1000!important}.cdFullDetails .price small{font-size:10px!important;color:#a6c4d8!important}
  .cdFullDetails .scoreRow{padding:13px!important;border-radius:16px!important;background:linear-gradient(145deg,rgba(49,215,255,.09),rgba(139,92,246,.07))!important;border:1px solid rgba(255,255,255,.12)!important}
  .cdFullDetails .orbitItem,.cdFullDetails .level,.cdFullDetails .miniCard,.cdFullDetails .gaugeBox{background:linear-gradient(145deg,rgba(255,255,255,.075),rgba(255,255,255,.025))!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:14px!important;box-shadow:0 7px 18px rgba(0,0,0,.18)!important}
  .cdFullDetails .orbitItem b,.cdFullDetails .level b,.cdFullDetails .miniCard b{color:#fff!important;font-weight:1000!important}.cdFullDetails .orbitItem small,.cdFullDetails .level,.cdFullDetails .miniCard{color:#b9cfe0!important}
  .cdFullDetails .bar{height:10px!important;background:#081a2a!important;border:1px solid rgba(255,255,255,.08)!important}.cdFullDetails .tf span{padding:10px 4px!important;border-radius:12px!important;background:linear-gradient(145deg,rgba(49,215,255,.11),rgba(139,92,246,.07))!important;border:1px solid rgba(49,215,255,.18)!important;color:#c9dfec!important;font-weight:900!important}.cdFullDetails .tf b{color:#fff!important;font-size:13px!important}
  .cdFullDetails .dualLevels{display:grid!important;grid-template-columns:1fr!important;gap:10px!important}.cdFullDetails .dualBox{padding:14px!important;border-radius:16px!important;font-size:12px!important;background:linear-gradient(145deg,rgba(255,255,255,.06),rgba(255,255,255,.02))!important;border:1px solid rgba(255,255,255,.10)!important}.cdFullDetails .longBox{border-color:rgba(74,222,128,.35)!important;background:linear-gradient(145deg,rgba(74,222,128,.10),rgba(255,255,255,.02))!important}.cdFullDetails .shortBox{border-color:rgba(248,113,113,.35)!important;background:linear-gradient(145deg,rgba(248,113,113,.10),rgba(255,255,255,.02))!important}
  .cdFullDetails .panelTech{margin-top:11px!important;padding:14px!important;border-radius:17px!important;background:linear-gradient(145deg,rgba(7,31,50,.96),rgba(5,14,26,.98))!important;border:1px solid rgba(49,215,255,.20)!important;box-shadow:0 9px 22px rgba(0,0,0,.20)!important}.cdFullDetails .panelTech .title{font-size:14px!important;color:#e9fbff!important;font-weight:1000!important}.cdFullDetails .miniGrid{display:grid!important;grid-template-columns:1fr 1fr!important;gap:8px!important}.cdFullDetails .miniGrid>.miniCard{padding:11px!important;min-width:0!important}.cdFullDetails table{font-size:11px!important;color:#d6e7f3!important}.cdFullDetails table th{color:#8eddf3!important;background:rgba(49,215,255,.07)!important}.cdFullDetails table td{color:#d6e7f3!important;border-color:rgba(255,255,255,.08)!important}
}
@media(max-width:380px){.coinMiniCard{min-height:166px!important;padding:10px!important}.coinMiniIcon{width:48px!important;height:48px!important;min-width:48px!important;font-size:27px!important}.coinMiniIdentity b{font-size:16px!important}.coinMiniPriceValue{font-size:18px!important}.coinMiniScoreBadge{font-size:9px!important;padding:6px!important}.cdFullDetails .miniGrid{grid-template-columns:1fr!important}}


@media(max-width:600px){.detailVisualLegacy{display:grid!important;gap:10px!important;margin-top:10px!important}.detailVisualGroup{padding:11px!important;border-radius:18px!important;background:linear-gradient(145deg,rgba(9,29,48,.96),rgba(5,14,26,.98))!important;border:1px solid rgba(49,215,255,.18)!important;box-shadow:0 10px 24px rgba(0,0,0,.20)!important}.detailVisualGroupTitle{display:flex!important;align-items:center!important;gap:7px!important;margin-bottom:9px!important;padding:9px 10px!important;border-radius:12px!important;background:linear-gradient(90deg,rgba(49,215,255,.13),rgba(139,92,246,.08))!important;border:1px solid rgba(49,215,255,.15)!important;color:#e8fbff!important;font-size:13px!important;font-weight:1000!important}.detailVisualGroup .panelTech{margin-top:7px!important}}




/* V27.4 card header boost */

.card .ch .name,.card .coin .name{font-size:17px!important;font-weight:1000!important;color:#fff!important;-webkit-text-fill-color:#fff!important;text-shadow:0 1px 8px rgba(0,0,0,.4)!important}
.card .ch .price,.card .price{font-size:20px!important;font-weight:1000!important;color:#fff!important;-webkit-text-fill-color:#fff!important}
.card .icon,.card .coin .icon{width:52px!important;height:52px!important;font-size:28px!important;display:grid!important;place-items:center!important;border-radius:16px!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.28),rgba(49,215,255,.12) 45%,rgba(0,0,0,.2))!important;border:2px solid rgba(255,255,255,.2)!important}
.assetName b{font-size:16px!important;font-weight:1000!important;color:#fff!important}
.assetPrice b{font-size:16px!important;font-weight:1000!important;color:#fff!important}
.assetIcon{font-size:26px!important}


/* ===== ADVANCED WEB DASHBOARD SHELL V28 ===== */

/* V28.4 Active Signals Hero — impossible to miss */
.activeHero{
  margin:10px 0 14px;padding:14px 16px;border-radius:18px;
  border:2px solid rgba(45,245,180,.45);
  background:linear-gradient(120deg,rgba(16,185,129,.18),rgba(8,28,48,.96) 40%,rgba(239,68,68,.12));
  box-shadow:0 0 40px rgba(35,230,168,.15),0 14px 36px rgba(0,0,0,.35);
}
.activeHero.empty{border-color:rgba(255,211,78,.35);background:linear-gradient(120deg,rgba(255,211,78,.1),rgba(8,28,48,.96))}
.activeHeroHead{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap}
.activeHeroHead h3{margin:0;font-size:15px;font-weight:1000;color:#eafff6;letter-spacing:.3px}
.activeHeroHead .ahCount{font-size:12px;font-weight:950;padding:6px 12px;border-radius:99px;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.12);color:#7dd3fc}
.activeHeroGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px}
.ahCard{display:flex;flex-direction:column;gap:4px;padding:12px;border-radius:14px;border:1px solid rgba(255,255,255,.1);background:rgba(0,0,0,.28);cursor:pointer;transition:.15s;text-align:right;color:inherit;width:100%}
.ahCard:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(0,0,0,.35)}
.ahCard.long{border-color:rgba(35,230,168,.5);background:linear-gradient(160deg,rgba(35,230,168,.2),rgba(0,0,0,.25));box-shadow:inset 0 0 0 1px rgba(35,230,168,.15)}
.ahCard.short{border-color:rgba(255,77,115,.5);background:linear-gradient(160deg,rgba(255,77,115,.2),rgba(0,0,0,.25));box-shadow:inset 0 0 0 1px rgba(255,77,115,.15)}
.ahCard .ahTop{display:flex;justify-content:space-between;align-items:center}
.ahCard .ahTop b{font-size:14px;color:#fff;font-weight:1000}
.ahCard .ahSide{font-size:11px;font-weight:1000;padding:4px 8px;border-radius:99px}
.ahCard.long .ahSide{color:#23e6a8;background:rgba(35,230,168,.15)}
.ahCard.short .ahSide{color:#ff4d73;background:rgba(255,77,115,.15)}
.ahCard .ahMeta{font-size:10px;color:#9fb6c9;font-weight:800}
.ahCard .ahPrice{font-size:13px;color:#fff;font-weight:950;margin-top:2px}
.ahEmpty{font-size:12px;color:#fde68a;font-weight:800;line-height:1.7;padding:6px 2px}

/* V28.3 Top Picks + stronger signal hierarchy */
.topPicksBar{margin:10px 0 12px;padding:12px;border-radius:16px;border:1px solid rgba(49,215,255,.22);background:linear-gradient(135deg,rgba(8,28,48,.95),rgba(6,16,30,.92));box-shadow:0 10px 28px rgba(0,0,0,.25)}
.topPicksLabel{font-size:11px;font-weight:1000;color:#7dd3fc;letter-spacing:.6px;margin-bottom:8px}
.topPicksRow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.topPickCard{display:flex;align-items:center;gap:10px;padding:11px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.22);cursor:pointer;transition:.15s;text-align:right;width:100%;color:inherit}
.topPickCard:hover{transform:translateY(-2px);border-color:rgba(49,215,255,.4);box-shadow:0 8px 20px rgba(0,0,0,.3)}
.topPickCard.long{border-color:rgba(35,230,168,.35);background:linear-gradient(145deg,rgba(35,230,168,.12),rgba(0,0,0,.18))}
.topPickCard.short{border-color:rgba(255,77,115,.35);background:linear-gradient(145deg,rgba(255,77,115,.12),rgba(0,0,0,.18))}
.topPickCard .tpIcon{font-size:22px;width:36px;height:36px;display:grid;place-items:center;border-radius:11px;background:rgba(255,255,255,.06)}
.topPickCard .tpBody{min-width:0;flex:1}
.topPickCard .tpBody b{display:block;font-size:13px;font-weight:1000;color:#fff}
.topPickCard .tpBody small{display:block;font-size:10px;color:#8fa7bb;margin-top:2px;font-weight:800}
.assetCard.long{box-shadow:0 0 0 1px rgba(35,230,168,.2),0 12px 28px rgba(0,0,0,.28)!important}
.assetCard.short{box-shadow:0 0 0 1px rgba(255,77,115,.2),0 12px 28px rgba(0,0,0,.28)!important}
.decisionPill.long{box-shadow:0 0 12px rgba(35,230,168,.25)}
.decisionPill.short{box-shadow:0 0 12px rgba(255,77,115,.25)}
@media(max-width:700px){.topPicksRow{grid-template-columns:1fr!important}}

.titanV28Banner{
  background:linear-gradient(90deg,rgba(16,185,129,.28),rgba(49,215,255,.22),rgba(167,139,250,.18))!important;
  border:2px solid rgba(45,245,180,.55)!important;
  font-size:13px!important;font-weight:1000!important;color:#eafff6!important;
  padding:12px 14px!important;border-radius:16px!important;margin-bottom:8px!important;
  box-shadow:0 0 28px rgba(35,230,168,.18)!important;
}
.titanV28Notice{
  margin:0 0 14px!important;padding:10px 12px!important;border-radius:12px!important;
  background:rgba(251,191,36,.12)!important;border:1px dashed rgba(255,211,78,.45)!important;
  color:#ffe9a8!important;font-size:12px!important;font-weight:800!important;line-height:1.7!important;
}
.coinMiniCard{
  outline: none!important;
  transform: none!important;
}
.coinMiniPriceValue{
  font-size:24px!important;
  color:#7ef9ff!important;
  -webkit-text-fill-color:#7ef9ff!important;
}
.coinMiniSymbol{
  color:#ffffff!important;
  font-size:22px!important;
}

.titanApp{max-width:1480px!important;margin:0 auto!important;padding:8px 10px 28px!important}
.topHeader{
  position:sticky!important;top:0!important;z-index:120!important;
  display:grid!important;grid-template-columns:minmax(0,1.1fr) minmax(0,1.4fr) auto!important;
  gap:10px!important;align-items:center!important;
  padding:12px 14px!important;margin-bottom:12px!important;
  border:1px solid rgba(72,203,255,.32)!important;border-radius:22px!important;
  background:linear-gradient(120deg,rgba(5,18,36,.97),rgba(8,22,44,.94) 45%,rgba(12,16,38,.96))!important;
  box-shadow:0 18px 50px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.06)!important;
  backdrop-filter:blur(18px)!important;
}
.brand h1{font-size:18px!important;font-weight:1000!important;letter-spacing:.3px!important}
.brand small{font-size:10px!important;color:#8eb0c8!important;font-weight:700!important}
.statusStrip{gap:7px!important}
.statusPill{
  padding:8px 11px!important;border-radius:12px!important;
  background:rgba(255,255,255,.04)!important;border:1px solid rgba(255,255,255,.08)!important;
  font-size:11px!important;font-weight:800!important;
}
.kpiGrid{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(140px,1fr))!important;gap:10px!important;margin:12px 0!important}
.kpi{
  min-height:96px!important;padding:14px!important;border-radius:18px!important;
  background:linear-gradient(155deg,rgba(12,32,54,.95),rgba(6,14,26,.98))!important;
  border:1px solid rgba(72,203,255,.22)!important;
  box-shadow:0 12px 28px rgba(0,0,0,.28)!important;
}
.kpiValue{font-size:24px!important;font-weight:1000!important;color:#fff!important}
.kpiHead{font-size:11px!important;color:#9bb6cb!important;font-weight:900!important;letter-spacing:.4px!important}
.mainTabs{display:flex!important;gap:6px!important;overflow:auto!important;padding:6px!important;border-radius:16px!important;background:rgba(0,0,0,.22)!important;border:1px solid rgba(255,255,255,.07)!important;margin-bottom:12px!important}
.mainTab{flex:0 0 auto!important;padding:10px 14px!important;border-radius:12px!important;font-weight:900!important;font-size:12px!important;color:#8fa7bb!important;border:1px solid transparent!important;background:transparent!important}
.mainTab.active{color:#fff!important;background:rgba(49,215,255,.14)!important;border-color:rgba(49,215,255,.35)!important}
.panel,.section,.hud{
  border-radius:20px!important;
  background:linear-gradient(160deg,rgba(8,22,40,.92),rgba(4,12,24,.96))!important;
  border:1px solid rgba(72,203,255,.16)!important;
  box-shadow:0 14px 36px rgba(0,0,0,.28)!important;
}
.section>h2,.panelTitle{font-size:15px!important;font-weight:1000!important;color:#eaf7ff!important}
@media(max-width:900px){
  .topHeader{grid-template-columns:1fr!important;position:relative!important}
  .statusStrip{order:3!important}
  .headerActions{width:100%!important}
  .kpiGrid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
.advLiveBar{
  display:flex!important;flex-wrap:wrap!important;gap:8px!important;align-items:center!important;
  margin:0 0 12px!important;padding:10px 12px!important;border-radius:16px!important;
  background:linear-gradient(90deg,rgba(16,185,129,.12),rgba(49,215,255,.08),rgba(167,139,250,.08))!important;
  border:1px solid rgba(49,215,255,.2)!important;font-size:12px!important;font-weight:800!important;color:#d5ecf8!important;
}
.advLiveBar b{color:#fff!important}
.advLiveDot{width:9px;height:9px;border-radius:50%;background:#23e6a8;box-shadow:0 0 12px #23e6a8;display:inline-block;margin-left:4px}

/* ===== V27.4 UX: crystal-clear coins + mobile box fit + graphical details ===== */
.titanCoinRail{display:grid!important;grid-template-columns:repeat(auto-fill,minmax(158px,1fr))!important;gap:12px!important;width:100%!important;max-width:100%!important;overflow-x:hidden!important;padding:4px 2px 10px!important}
.coinMiniCard{position:relative!important;display:flex!important;flex-direction:column!important;width:100%!important;max-width:100%!important;min-width:0!important;min-height:188px!important;padding:14px 12px 12px!important;overflow:hidden!important;color:#f8fbff!important;-webkit-text-fill-color:#f8fbff!important;background:linear-gradient(155deg,#143352 0%,#0a1f35 48%,#061018 100%)!important;border:2px solid rgba(80,210,255,.55)!important;border-radius:20px!important;box-shadow:0 16px 36px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.14)!important}
.coinMiniCard.long{background:linear-gradient(155deg,#0a4a3c 0%,#0a2f2c 50%,#061820 100%)!important;border-color:rgba(45,245,180,.85)!important}
.coinMiniCard.short{background:linear-gradient(155deg,#551230 0%,#2e1228 50%,#10141f 100%)!important;border-color:rgba(255,95,130,.85)!important}
.coinMiniCard.wait{background:linear-gradient(155deg,#4d3f0c 0%,#2a2510 50%,#12161f 100%)!important;border-color:rgba(255,215,70,.85)!important}
.coinMiniTop{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:8px!important;min-width:0!important}
.coinMiniIdentity{display:flex!important;align-items:center!important;gap:10px!important;min-width:0!important;flex:1!important}
.coinMiniIcon{width:58px!important;height:58px!important;min-width:58px!important;display:grid!important;place-items:center!important;border-radius:18px!important;font-size:32px!important;line-height:1!important;color:#fff!important;-webkit-text-fill-color:#fff!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.35),rgba(49,215,255,.14) 42%,rgba(0,0,0,.25) 100%)!important;border:2px solid rgba(255,255,255,.28)!important;box-shadow:0 0 28px rgba(49,215,255,.28)!important}
.coinMiniNameBlock{display:flex!important;flex-direction:column!important;min-width:0!important;flex:1!important}
.coinMiniSymbol,.coinMiniIdentity b{display:block!important;color:#ffffff!important;-webkit-text-fill-color:#fff!important;font-size:20px!important;font-weight:1000!important;line-height:1.1!important;letter-spacing:.3px!important;text-shadow:0 2px 12px rgba(0,0,0,.55)!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}
.coinMiniFullName,.coinMiniIdentity small{display:block!important;color:#d8ebf8!important;-webkit-text-fill-color:#d8ebf8!important;font-size:12px!important;font-weight:800!important;margin-top:3px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;max-width:100%!important;opacity:1!important}
.coinMiniPair{display:block!important;font-style:normal!important;color:#8ec6e0!important;font-size:10px!important;font-weight:800!important;margin-top:2px!important}
.coinMiniDecision{flex:0 0 auto!important;padding:7px 9px!important;border-radius:999px!important;font-size:11px!important;font-weight:1000!important;letter-spacing:.2px!important;white-space:nowrap!important;color:#fff!important;background:rgba(0,0,0,.35)!important;border:1px solid rgba(255,255,255,.18)!important}
.coinMiniCard.long .coinMiniDecision{background:rgba(16,185,129,.28)!important;border-color:rgba(45,245,180,.55)!important;color:#9ff5d2!important}
.coinMiniCard.short .coinMiniDecision{background:rgba(244,63,94,.28)!important;border-color:rgba(255,95,130,.55)!important;color:#ffb3c4!important}
.coinMiniCard.wait .coinMiniDecision{background:rgba(251,191,36,.22)!important;border-color:rgba(255,215,70,.55)!important;color:#ffe9a3!important}
.coinMiniPriceLine{display:grid!important;grid-template-columns:1fr auto!important;align-items:center!important;gap:2px 8px!important;margin-top:12px!important;padding:10px 11px!important;border-radius:14px!important;background:rgba(0,0,0,.32)!important;border:1px solid rgba(255,255,255,.14)!important;min-width:0!important}
.coinMiniPriceLabel{grid-column:1/-1!important;color:#b9d3e6!important;font-size:11px!important;font-weight:900!important}
.coinMiniPriceValue{grid-column:1!important;color:#ffffff!important;-webkit-text-fill-color:#fff!important;font-size:22px!important;font-weight:1000!important;line-height:1.15!important;letter-spacing:.2px!important;text-shadow:0 2px 16px rgba(49,215,255,.35)!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;max-width:100%!important}
.coinMiniPriceUnit{grid-column:2!important;color:#9fc1d8!important;font-size:11px!important;font-weight:900!important}
.coinMiniScoreBadge{grid-column:2!important;justify-self:end!important;padding:6px 8px!important;border-radius:10px!important;background:rgba(49,215,255,.15)!important;border:1px solid rgba(49,215,255,.28)!important;color:#e8f9ff!important;font-size:11px!important;font-weight:1000!important;white-space:nowrap!important}
.coinMiniPriceLine i{grid-column:1/-1!important;display:block!important;height:8px!important;margin-top:6px!important;border-radius:99px!important;background:#0d2234!important;overflow:hidden!important}
.coinMiniPriceLine i em{display:block!important;height:100%!important;background:linear-gradient(90deg,#31d7ff,#23e6a8)!important;border-radius:99px!important}
.coinMiniTF{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:5px!important;margin-top:10px!important}
.coinMiniTF span{min-width:0!important;padding:6px 2px!important;text-align:center!important;border-radius:10px!important;background:rgba(255,255,255,.05)!important;border:1px solid rgba(255,255,255,.08)!important;font-size:9px!important;color:#9db4c8!important;overflow:hidden!important}
.coinMiniTF b{display:block!important;color:#fff!important;font-size:12px!important;margin-top:2px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}
.coinMiniOpen{display:block!important;margin-top:10px!important;text-align:center!important;padding:8px!important;border-radius:12px!important;background:rgba(49,215,255,.10)!important;border:1px solid rgba(49,215,255,.22)!important;color:#c8f0ff!important;font-size:12px!important;font-weight:900!important}

/* Modal / detail: no overflow off-screen */
.modal{padding:8px!important;align-items:flex-start!important}
.detailModal .modalC{width:min(1180px,100%)!important;max-width:100%!important;height:min(94vh,960px)!important;max-height:94vh!important;overflow:hidden!important}
.cdBodyPad{overflow:auto!important;overflow-x:hidden!important;-webkit-overflow-scrolling:touch!important;max-width:100%!important}
.cdFullDetails,.cdFullDetails *{max-width:100%!important;word-wrap:break-word!important;overflow-wrap:anywhere!important}
.cdMetrics{grid-template-columns:repeat(2,minmax(0,1fr))!important}
@media(min-width:720px){.cdMetrics{grid-template-columns:repeat(4,minmax(0,1fr))!important}}
.cdMetric .val{font-size:18px!important}
.cdName{font-size:20px!important;font-weight:1000!important;color:#fff!important}
.cdPriceBig{font-size:24px!important;font-weight:1000!important;color:#fff!important;text-shadow:0 2px 14px rgba(49,215,255,.25)!important}
.cdIconXL{width:56px!important;height:56px!important;font-size:30px!important}

/* Graphical detail blocks */
.cdVisualSummary{margin:8px 0 12px!important;padding:12px!important;border-radius:18px!important;background:linear-gradient(145deg,rgba(10,32,52,.98),rgba(6,14,28,.98))!important;border:1px solid rgba(49,215,255,.28)!important;box-shadow:0 12px 28px rgba(0,0,0,.28)!important}
.cdVisualHero{display:flex!important;justify-content:space-between!important;align-items:center!important;gap:10px!important;flex-wrap:wrap!important}
.cdVisualHero strong{display:block!important;font-size:18px!important;color:#fff!important}
.cdVisualHero small{display:block!important;color:#9bb8ce!important;margin-top:4px!important}
.cdVisualDecision{padding:10px 14px!important;border-radius:999px!important;font-weight:1000!important;font-size:14px!important}
.cdVisualDecision.long{background:rgba(16,185,129,.22)!important;color:#7dffc8!important;border:1px solid rgba(45,245,180,.45)!important}
.cdVisualDecision.short{background:rgba(244,63,94,.22)!important;color:#ffb0c2!important;border:1px solid rgba(255,95,130,.45)!important}
.cdVisualDecision.wait{background:rgba(251,191,36,.18)!important;color:#ffe39a!important;border:1px solid rgba(255,215,70,.4)!important}
.cdVisualGrid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin-top:12px!important}
@media(min-width:640px){.cdVisualGrid{grid-template-columns:repeat(4,minmax(0,1fr))!important}}
.cdVisualStat{padding:11px!important;border-radius:14px!important;background:rgba(255,255,255,.04)!important;border:1px solid rgba(255,255,255,.08)!important;min-width:0!important}
.cdVisualStat span{display:block!important;font-size:11px!important;color:#93acc0!important;font-weight:800!important}
.cdVisualStat b{display:block!important;margin-top:4px!important;font-size:18px!important;color:#fff!important;font-weight:1000!important}
.cdVisualLevels{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin-top:10px!important}
.cdVisualLevels>div{padding:11px!important;border-radius:14px!important;background:rgba(0,0,0,.22)!important;border:1px solid rgba(255,255,255,.08)!important;min-width:0!important}
.cdVisualLevels span{display:block!important;font-size:11px!important;color:#9db4c8!important}
.cdVisualLevels b{display:block!important;margin-top:3px!important;font-size:15px!important;color:#eaf7ff!important;word-break:break-all!important}
.cdVisualFlow{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:4px!important;flex-wrap:wrap!important;margin-top:12px!important;padding:10px!important;border-radius:14px!important;background:rgba(49,215,255,.07)!important;border:1px solid rgba(49,215,255,.16)!important;font-size:11px!important;font-weight:900!important;color:#cfeeff!important}
.cdVisualFlow i{flex:1!important;min-width:12px!important;height:2px!important;background:linear-gradient(90deg,rgba(49,215,255,.1),rgba(49,215,255,.55),rgba(49,215,255,.1))!important}
.detailVisualLegacy{display:grid!important;gap:12px!important;margin-top:10px!important}
.detailVisualGroup{padding:12px!important;border-radius:18px!important;background:linear-gradient(145deg,rgba(9,29,48,.96),rgba(5,14,26,.98))!important;border:1px solid rgba(49,215,255,.2)!important;box-shadow:0 10px 24px rgba(0,0,0,.22)!important;overflow:hidden!important}
.detailVisualGroupTitle{display:flex!important;align-items:center!important;gap:8px!important;margin-bottom:10px!important;padding:10px 12px!important;border-radius:12px!important;background:linear-gradient(90deg,rgba(49,215,255,.16),rgba(139,92,246,.1))!important;border:1px solid rgba(49,215,255,.18)!important;color:#e8fbff!important;font-size:14px!important;font-weight:1000!important}
.cdSchemaGrid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important;margin:8px 0 12px!important}
.cdSchemaCard{padding:12px!important;border-radius:14px!important;background:rgba(255,255,255,.035)!important;border:1px solid rgba(255,255,255,.09)!important;min-width:0!important}
.cdSchemaCard .h{display:flex!important;align-items:center!important;gap:7px!important;font-size:12px!important;font-weight:1000!important;color:#cfeeff!important;margin-bottom:6px!important}
.cdSchemaCard .b{font-size:15px!important;font-weight:1000!important;color:#fff!important;line-height:1.45!important;word-break:break-word!important}
.cdSchemaCard .t{font-size:11px!important;color:#8fa7bb!important;margin-top:4px!important;line-height:1.6!important}
.panelTech,.dualBox,.level,.miniCard{max-width:100%!important;overflow:hidden!important}
.tableWrap{overflow-x:auto!important;-webkit-overflow-scrolling:touch!important;max-width:100%!important}
.section,.panel,.hud,.card{max-width:100%!important;overflow-x:hidden!important}
body,html{overflow-x:hidden!important;max-width:100vw!important}
.titanApp{max-width:100%!important;padding-left:8px!important;padding-right:8px!important}
@media(max-width:420px){
  .titanCoinRail{grid-template-columns:1fr 1fr!important;gap:8px!important}
  .coinMiniIcon{width:48px!important;height:48px!important;min-width:48px!important;font-size:28px!important}
  .coinMiniSymbol,.coinMiniIdentity b{font-size:16px!important}
  .coinMiniPriceValue{font-size:17px!important}
  .cdSchemaGrid{grid-template-columns:1fr!important}
  .cdVisualLevels{grid-template-columns:1fr 1fr!important}
}


/* V27.3 MOBILE-FIRST HARD VISIBILITY OVERRIDES
   These are intentionally global because Android/Pydroid browsers can report a
   desktop CSS viewport even when the physical screen is a phone. */
.coinMiniCard{
  color:#f8fbff!important;
  -webkit-text-fill-color:#f8fbff!important;
  background:linear-gradient(145deg,#102a43 0%,#081a2e 52%,#050e1c 100%)!important;
  border:2px solid rgba(72,203,255,.48)!important;
  border-radius:20px!important;
  min-height:176px!important;
  padding:13px!important;
  box-shadow:0 14px 34px rgba(0,0,0,.42),inset 0 1px 0 rgba(255,255,255,.12),0 0 22px rgba(49,215,255,.07)!important;
  overflow:hidden!important;
  position:relative!important;
}
.coinMiniCard.long{background:linear-gradient(145deg,#073e35 0%,#082a2c 52%,#061421 100%)!important;border-color:rgba(42,245,177,.85)!important;box-shadow:0 14px 34px rgba(0,0,0,.42),0 0 24px rgba(42,245,177,.10)!important}
.coinMiniCard.wait{background:linear-gradient(145deg,#493b09 0%,#29250e 52%,#101622 100%)!important;border-color:rgba(255,214,74,.88)!important;box-shadow:0 14px 34px rgba(0,0,0,.42),0 0 24px rgba(255,214,74,.09)!important}
.coinMiniCard.short{background:linear-gradient(145deg,#4a102c 0%,#2c1229 52%,#101421 100%)!important;border-color:rgba(255,91,125,.88)!important;box-shadow:0 14px 34px rgba(0,0,0,.42),0 0 24px rgba(255,91,125,.10)!important}
.coinMiniCard *{box-sizing:border-box!important;color:inherit!important;-webkit-text-fill-color:inherit!important}
.coinMiniTop{display:flex!important;justify-content:space-between!important;align-items:flex-start!important;gap:8px!important}
.coinMiniIdentity{display:flex!important;align-items:center!important;gap:10px!important;min-width:0!important}
.coinMiniIcon{width:58px!important;height:58px!important;min-width:58px!important;display:grid!important;place-items:center!important;border-radius:17px!important;font-size:32px!important;color:#fff!important;-webkit-text-fill-color:#fff!important;background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.32),rgba(49,215,255,.12) 45%,rgba(0,0,0,.22) 100%)!important;border:2px solid rgba(255,255,255,.24)!important;box-shadow:0 0 25px rgba(49,215,255,.25)!important}
.coinMiniIdentity b{display:block!important;color:#fff!important;-webkit-text-fill-color:#fff!important;font-size:20px!important;font-weight:1000!important;line-height:1.05!important;text-shadow:0 2px 14px rgba(0,0,0,.7)!important}
.coinMiniIdentity small{display:block!important;color:#d9edfb!important;-webkit-text-fill-color:#d9edfb!important;font-size:11px!important;font-weight:850!important;margin-top:5px!important;max-width:110px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}
.coinMiniDecision{flex:0 0 auto!important;color:#fff!important;-webkit-text-fill-color:#fff!important;font-size:12px!important;font-weight:1000!important;padding:8px 10px!important;border-radius:12px!important;background:rgba(0,0,0,.38)!important;border:2px solid currentColor!important;white-space:nowrap!important;text-shadow:0 1px 7px rgba(0,0,0,.6)!important}
.coinMiniCard.long .coinMiniDecision{color:#4dffb2!important;-webkit-text-fill-color:#4dffb2!important}
.coinMiniCard.wait .coinMiniDecision{color:#ffe05b!important;-webkit-text-fill-color:#ffe05b!important}
.coinMiniCard.short .coinMiniDecision{color:#ff6b8b!important;-webkit-text-fill-color:#ff6b8b!important}
.coinMiniPriceLine{display:grid!important;grid-template-columns:1fr auto!important;align-items:center!important;gap:3px 8px!important;margin-top:12px!important;padding:10px!important;border-radius:14px!important;background:rgba(0,0,0,.38)!important;border:1px solid rgba(255,255,255,.14)!important}
.coinMiniPriceLabel{color:#c5dcec!important;-webkit-text-fill-color:#c5dcec!important;font-size:10px!important;font-weight:900!important}
.coinMiniPriceValue{grid-column:1!important;color:#fff!important;-webkit-text-fill-color:#fff!important;font-size:22px!important;font-weight:1000!important;line-height:1.05!important;white-space:nowrap!important;text-shadow:0 2px 16px rgba(49,215,255,.35)!important}
.coinMiniPriceValue small{font-size:10px!important;color:#a9cce0!important;-webkit-text-fill-color:#a9cce0!important}
.coinMiniScoreBadge{grid-column:2!important;grid-row:1/span 2!important;align-self:center!important;padding:8px 9px!important;border-radius:12px!important;background:linear-gradient(145deg,rgba(49,215,255,.18),rgba(139,92,246,.16))!important;border:1px solid rgba(49,215,255,.36)!important;color:#f0fdff!important;-webkit-text-fill-color:#f0fdff!important;font-size:11px!important;font-weight:1000!important}
.coinMiniPriceLine>i{grid-column:1/-1!important;width:100%!important;height:9px!important;margin:4px 0 0!important;background:#061522!important;border:1px solid rgba(255,255,255,.12)!important;border-radius:99px!important;overflow:hidden!important}
.coinMiniPriceLine>i em{display:block!important;height:100%!important;border-radius:99px!important;background:linear-gradient(90deg,#22d3ee,#8b5cf6,#34d399)!important}
.coinMiniTF{margin-top:9px!important;display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:4px!important}
.coinMiniTF span{padding:6px 2px!important;text-align:center!important;border-radius:9px!important;background:rgba(255,255,255,.09)!important;border:1px solid rgba(255,255,255,.13)!important;color:#cce2ef!important;-webkit-text-fill-color:#cce2ef!important;font-size:9px!important;font-weight:850!important}
.coinMiniTF b{display:block!important;color:#fff!important;-webkit-text-fill-color:#fff!important;font-size:11px!important;font-weight:1000!important;margin-top:2px!important}
.coinMiniOpen{display:block!important;margin-top:9px!important;padding:8px!important;text-align:center!important;border-radius:10px!important;background:linear-gradient(90deg,rgba(49,215,255,.17),rgba(139,92,246,.16))!important;border:1px solid rgba(49,215,255,.34)!important;color:#eaffff!important;-webkit-text-fill-color:#eaffff!important;font-size:11px!important;font-weight:1000!important}
/* Make the complete-detail tab unmistakably card-based even if legacy selectors win. */
.cdFullDetails{font-size:12px!important;color:#e4f1f8!important;-webkit-text-fill-color:#e4f1f8!important;line-height:1.9!important}
.cdFullDetails .panelTech,.cdFullDetails .ai,.cdFullDetails .deriv,.cdFullDetails .scoreRow,.cdFullDetails .dualBox,.cdFullDetails .miniCard,.cdFullDetails .gaugeBox,.cdFullDetails .level,.cdFullDetails .orbitItem{background:linear-gradient(145deg,rgba(13,38,61,.96),rgba(5,15,27,.98))!important;border:1px solid rgba(72,203,255,.24)!important;border-radius:16px!important;box-shadow:0 8px 24px rgba(0,0,0,.22),inset 0 1px 0 rgba(255,255,255,.05)!important;color:#dcecf5!important;-webkit-text-fill-color:#dcecf5!important;padding:12px!important}
.cdFullDetails .panelTech:nth-of-type(3n){border-color:rgba(192,132,252,.28)!important;background:linear-gradient(145deg,rgba(35,24,61,.94),rgba(7,14,27,.98))!important}
.cdFullDetails .panelTech .title{display:flex!important;align-items:center!important;gap:8px!important;font-size:14px!important;font-weight:1000!important;color:#f1fbff!important;-webkit-text-fill-color:#f1fbff!important;padding-bottom:8px!important;border-bottom:1px solid rgba(255,255,255,.08)!important;margin-bottom:9px!important}
.cdFullDetails .levels{display:grid!important;grid-template-columns:repeat(2,1fr)!important;gap:8px!important;margin-top:10px!important}
.cdFullDetails .level{min-height:68px!important;display:flex!important;flex-direction:column!important;justify-content:center!important;font-size:10px!important}
.cdFullDetails .level b{font-size:16px!important;color:#fff!important;-webkit-text-fill-color:#fff!important;margin-top:4px!important}
.cdFullDetails .dualLevels{display:grid!important;grid-template-columns:1fr 1fr!important;gap:9px!important;margin-top:10px!important}
.cdFullDetails .dualBox{min-height:118px!important;font-size:11px!important}
.cdFullDetails .longBox{border-color:rgba(74,222,128,.48)!important;background:linear-gradient(145deg,rgba(16,75,53,.82),rgba(5,20,28,.98))!important}
.cdFullDetails .shortBox{border-color:rgba(248,113,113,.48)!important;background:linear-gradient(145deg,rgba(85,25,45,.78),rgba(12,17,29,.98))!important}
.cdFullDetails .miniGrid{display:grid!important;grid-template-columns:repeat(2,1fr)!important;gap:8px!important}
.cdFullDetails .miniCard{min-height:82px!important}
.cdFullDetails .tf{display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:7px!important;margin-top:10px!important}
.cdFullDetails .tf span{padding:10px 4px!important;border-radius:12px!important;background:linear-gradient(145deg,rgba(49,215,255,.12),rgba(139,92,246,.09))!important;border:1px solid rgba(49,215,255,.22)!important;color:#cce6f2!important;-webkit-text-fill-color:#cce6f2!important;text-align:center!important;font-weight:900!important}
.cdFullDetails .tf b{display:block!important;color:#fff!important;-webkit-text-fill-color:#fff!important;font-size:13px!important;margin-top:3px!important}
.cdFullDetails .aiTitle{font-size:15px!important;font-weight:1000!important;color:#f2fbff!important;-webkit-text-fill-color:#f2fbff!important;padding:10px 0!important}
.cdFullDetails .aiRow{padding:12px!important;border-radius:14px!important;background:linear-gradient(135deg,rgba(49,215,255,.10),rgba(139,92,246,.09))!important;border:1px solid rgba(49,215,255,.22)!important}
.cdFullDetails .metrics{display:grid!important;grid-template-columns:repeat(4,1fr)!important;gap:6px!important;margin-top:8px!important}
.cdFullDetails .metrics .mini{padding:9px!important;border-radius:11px!important;background:rgba(255,255,255,.055)!important;border:1px solid rgba(255,255,255,.08)!important;text-align:center!important}
.cdFullDetails table{width:100%!important;border-collapse:separate!important;border-spacing:0 4px!important;font-size:11px!important;color:#e0eef5!important;-webkit-text-fill-color:#e0eef5!important}
.cdFullDetails table th{background:rgba(49,215,255,.10)!important;color:#8ee9ff!important;-webkit-text-fill-color:#8ee9ff!important;padding:8px!important}
.cdFullDetails table td{background:rgba(255,255,255,.035)!important;color:#e0eef5!important;-webkit-text-fill-color:#e0eef5!important;padding:8px!important;border:0!important}
@media(max-width:600px){
  .coinMiniCard{min-height:184px!important}
  .cdFullDetails .dualLevels{grid-template-columns:1fr!important}
  .cdFullDetails .metrics{grid-template-columns:repeat(2,1fr)!important}
  .cdFullDetails .miniGrid{grid-template-columns:1fr 1fr!important}
}
@media(max-width:380px){
  .coinMiniCard{min-height:176px!important;padding:10px!important}
  .coinMiniIcon{width:50px!important;height:50px!important;min-width:50px!important;font-size:28px!important}
  .coinMiniIdentity b{font-size:17px!important}
  .coinMiniPriceValue{font-size:19px!important}
  .cdFullDetails .miniGrid{grid-template-columns:1fr!important}
}



/* ===== HOVER ANIMATIONS V28 ===== */
@media (hover:hover) and (pointer:fine) {
  .ticker, button.ticker,
  .assetCard, button.assetCard,
  .coinMiniCard, button.coinMiniCard,
  .glassBtn, .headerActions .glassBtn, a.glassBtn,
  .sideBtn, .mainTab, .assetTools button,
  .kpi, .signalBox, .statusPill,
  .hudbox, .panel, .cdMetric, .cdSchemaCard, .cdVisualStat {
    transition:
      transform .22s cubic-bezier(.22,.9,.3,1),
      box-shadow .22s ease,
      border-color .22s ease,
      background .22s ease,
      filter .22s ease !important;
    will-change: transform;
  }

  .ticker:hover, button.ticker:hover {
    transform: translateY(-4px) scale(1.02) !important;
    border-color: rgba(72,203,255,.75) !important;
    box-shadow:
      0 16px 36px rgba(0,0,0,.45),
      0 0 24px rgba(49,215,255,.18),
      inset 0 1px 0 rgba(255,255,255,.12) !important;
    filter: brightness(1.08);
  }
  .ticker.up:hover, button.ticker.up:hover {
    border-color: rgba(45,245,180,.9) !important;
    box-shadow: 0 16px 36px rgba(0,0,0,.45), 0 0 26px rgba(35,230,168,.22) !important;
  }
  .ticker.down:hover, button.ticker.down:hover {
    border-color: rgba(255,95,130,.9) !important;
    box-shadow: 0 16px 36px rgba(0,0,0,.45), 0 0 26px rgba(255,77,115,.22) !important;
  }
  .ticker.neutral:hover, button.ticker.neutral:hover {
    border-color: rgba(255,211,78,.85) !important;
    box-shadow: 0 16px 36px rgba(0,0,0,.45), 0 0 22px rgba(255,211,78,.18) !important;
  }

  .assetCard:hover, button.assetCard:hover {
    transform: translateY(-5px) scale(1.025) !important;
    border-color: rgba(72,203,255,.8) !important;
    box-shadow:
      0 18px 40px rgba(0,0,0,.5),
      0 0 28px rgba(49,215,255,.2),
      inset 0 1px 0 rgba(255,255,255,.12) !important;
    filter: brightness(1.1);
  }
  .assetCard.long:hover, button.assetCard.long:hover {
    border-color: rgba(45,245,180,.95) !important;
    box-shadow: 0 18px 40px rgba(0,0,0,.5), 0 0 30px rgba(35,230,168,.28) !important;
  }
  .assetCard.short:hover, button.assetCard.short:hover {
    border-color: rgba(255,95,130,.95) !important;
    box-shadow: 0 18px 40px rgba(0,0,0,.5), 0 0 30px rgba(255,77,115,.28) !important;
  }
  .assetCard.wait:hover, button.assetCard.wait:hover {
    border-color: rgba(255,211,78,.95) !important;
    box-shadow: 0 18px 40px rgba(0,0,0,.5), 0 0 28px rgba(255,211,78,.22) !important;
  }

  .coinMiniCard:hover, button.coinMiniCard:hover {
    transform: translateY(-5px) scale(1.02) !important;
    border-color: rgba(80,210,255,.85) !important;
    box-shadow:
      0 20px 44px rgba(0,0,0,.5),
      0 0 32px rgba(49,215,255,.22),
      inset 0 1px 0 rgba(255,255,255,.14) !important;
    filter: brightness(1.08);
  }
  .coinMiniCard.long:hover { border-color: rgba(45,245,180,.95) !important; box-shadow: 0 20px 44px rgba(0,0,0,.5), 0 0 32px rgba(35,230,168,.25) !important; }
  .coinMiniCard.short:hover { border-color: rgba(255,95,130,.95) !important; box-shadow: 0 20px 44px rgba(0,0,0,.5), 0 0 32px rgba(255,77,115,.25) !important; }
  .coinMiniCard.wait:hover { border-color: rgba(255,211,78,.95) !important; box-shadow: 0 20px 44px rgba(0,0,0,.5), 0 0 28px rgba(255,211,78,.22) !important; }

  .glassBtn:hover, .headerActions .glassBtn:hover, a.glassBtn:hover,
  .assetTools button:hover, .sideBtn:hover, .mainTab:hover {
    transform: translateY(-2px) scale(1.03) !important;
    border-color: rgba(72,203,255,.7) !important;
    box-shadow: 0 10px 22px rgba(0,0,0,.4), 0 0 18px rgba(49,215,255,.2) !important;
    filter: brightness(1.12);
  }
  .glassBtn.gold:hover {
    border-color: rgba(255,211,78,.75) !important;
    box-shadow: 0 10px 22px rgba(0,0,0,.4), 0 0 18px rgba(255,211,78,.22) !important;
  }

  .kpi:hover, .signalBox:hover, .hudbox:hover {
    transform: translateY(-3px) !important;
    border-color: rgba(72,203,255,.45) !important;
    box-shadow: 0 14px 30px rgba(0,0,0,.35), 0 0 16px rgba(49,215,255,.12) !important;
  }

  .statusPill:hover {
    transform: translateY(-1px) scale(1.02) !important;
    border-color: rgba(72,203,255,.4) !important;
    background: rgba(49,215,255,.08) !important;
  }

  .cdMetric:hover, .cdSchemaCard:hover, .cdVisualStat:hover {
    transform: translateY(-2px) !important;
    border-color: rgba(72,203,255,.45) !important;
    box-shadow: 0 10px 22px rgba(0,0,0,.3) !important;
  }

  .tickerIcon, .assetIcon, .coinMiniIcon {
    transition: transform .22s ease, box-shadow .22s ease !important;
  }
  .ticker:hover .tickerIcon,
  .assetCard:hover .assetIcon,
  .coinMiniCard:hover .coinMiniIcon {
    transform: scale(1.12) rotate(-4deg) !important;
    box-shadow: 0 0 18px rgba(49,215,255,.35) !important;
  }
}

/* Active / press feedback (touch + mouse) */
.ticker:active, button.ticker:active,
.assetCard:active, button.assetCard:active,
.coinMiniCard:active, button.coinMiniCard:active,
.glassBtn:active, .sideBtn:active, .mainTab:active, .assetTools button:active {
  transform: translateY(0) scale(0.97) !important;
  filter: brightness(0.95) !important;
  transition-duration: .08s !important;
}

/* Soft glow pulse on decision pills when hovering parent card */
@media (hover:hover) and (pointer:fine) {
  .assetCard:hover .decisionPill,
  .coinMiniCard:hover .coinMiniDecision,
  .ticker:hover .tickerMove {
    animation: titanPillGlow 1.1s ease-in-out infinite alternate;
  }
}
@keyframes titanPillGlow {
  from { filter: brightness(1); }
  to { filter: brightness(1.25); text-shadow: 0 0 10px currentColor; }
}


/* User request: hide V28 verification banners */
.advLiveBar,.titanV28Banner,.titanV28Notice,#titanBootSplash{display:none!important;height:0!important;margin:0!important;padding:0!important;border:0!important;overflow:hidden!important}

/* Dark vivid small coin cards (ticker + assetCard) — high contrast on mobile */
.ticker,
button.ticker{
  background:linear-gradient(160deg,#0f2740 0%,#0a1a2e 55%,#06101c 100%)!important;
  border:1.5px solid rgba(72,203,255,.42)!important;
  border-radius:16px!important;
  box-shadow:0 10px 26px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.08)!important;
  color:#f2f8ff!important;
  -webkit-text-fill-color:#f2f8ff!important;
  min-height:92px!important;
  padding:11px 10px!important;
}
.ticker.up,button.ticker.up{border-color:rgba(45,245,180,.65)!important;background:linear-gradient(160deg,#0b3d34 0%,#0a2a28 55%,#07141f 100%)!important}
.ticker.down,button.ticker.down{border-color:rgba(255,95,130,.65)!important;background:linear-gradient(160deg,#4a1530 0%,#2a1224 55%,#10141f 100%)!important}
.ticker.neutral,button.ticker.neutral{border-color:rgba(255,211,78,.55)!important;background:linear-gradient(160deg,#3d3510 0%,#252110 55%,#10141c 100%)!important}
.ticker b,.tickerPrice{color:#ffffff!important;-webkit-text-fill-color:#fff!important;font-weight:1000!important}
.ticker small{color:#b7cfe0!important;-webkit-text-fill-color:#b7cfe0!important;font-weight:800!important}
.tickerIcon{
  background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.28),rgba(49,215,255,.12) 50%,rgba(0,0,0,.25))!important;
  border:1px solid rgba(255,255,255,.2)!important;
  box-shadow:0 0 14px rgba(49,215,255,.2)!important;
}
.tickerPrice{font-size:13px!important}
.tickerMove{font-size:10px!important;font-weight:1000!important}

.assetCard,button.assetCard{
  background:linear-gradient(160deg,#12304c 0%,#0c1f36 50%,#08131f 100%)!important;
  border:1.5px solid rgba(72,203,255,.40)!important;
  border-radius:16px!important;
  box-shadow:0 12px 28px rgba(0,0,0,.42), inset 0 1px 0 rgba(255,255,255,.1)!important;
  color:#f4f9ff!important;
  -webkit-text-fill-color:#f4f9ff!important;
  min-height:118px!important;
  padding:12px!important;
}
.assetCard.long,button.assetCard.long{
  background:linear-gradient(160deg,#0c4538 0%,#0a2f2c 50%,#081820 100%)!important;
  border-color:rgba(45,245,180,.7)!important;
  border-top:2px solid #23e6a8!important;
}
.assetCard.short,button.assetCard.short{
  background:linear-gradient(160deg,#4e1632 0%,#2c1428 50%,#10141f 100%)!important;
  border-color:rgba(255,95,130,.7)!important;
  border-top:2px solid #ff4d73!important;
}
.assetCard.wait,button.assetCard.wait{
  background:linear-gradient(160deg,#4a3c0e 0%,#2a2410 50%,#11151e 100%)!important;
  border-color:rgba(255,211,78,.7)!important;
  border-top:2px solid #ffd34e!important;
}
.assetName b,.assetPrice b{
  color:#ffffff!important;-webkit-text-fill-color:#fff!important;font-weight:1000!important;font-size:14px!important;
}
.assetName small{color:#c2d8e8!important;-webkit-text-fill-color:#c2d8e8!important;font-size:10px!important;font-weight:800!important}
.assetIcon{
  width:38px!important;height:38px!important;font-size:22px!important;
  background:radial-gradient(circle at 30% 25%,rgba(255,255,255,.3),rgba(49,215,255,.14) 45%,rgba(0,0,0,.28))!important;
  border:1.5px solid rgba(255,255,255,.22)!important;
  border-radius:12px!important;
}
.decisionPill{
  font-size:10px!important;padding:6px 8px!important;font-weight:1000!important;
  background:rgba(0,0,0,.35)!important;border:1px solid rgba(255,255,255,.15)!important;
}

/* Buttons that looked light/white → solid dark */
.glassBtn,
.glassBtn.gold,
header .glassBtn,
.headerActions .glassBtn,
.headerActions a.glassBtn,
.assetTools button,
.mainTab,
.sideBtn,
button.glassBtn{
  background:linear-gradient(145deg,#0d2438,#0a1828)!important;
  border:1px solid rgba(72,203,255,.35)!important;
  color:#e8f6ff!important;
  -webkit-text-fill-color:#e8f6ff!important;
  box-shadow:0 6px 16px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.06)!important;
}
.glassBtn.gold,
.headerActions .glassBtn.gold{
  background:linear-gradient(145deg,#2a2410,#16140c)!important;
  border-color:rgba(255,211,78,.4)!important;
  color:#ffe9a8!important;
  -webkit-text-fill-color:#ffe9a8!important;
}
.mainTab.active,.sideBtn.active{
  background:linear-gradient(145deg,#123a52,#0c2438)!important;
  border-color:rgba(49,215,255,.5)!important;
  color:#fff!important;
  -webkit-text-fill-color:#fff!important;
}
.assetTools button.active{
  background:linear-gradient(145deg,#0f3d34,#0a2824)!important;
  border-color:rgba(45,245,180,.45)!important;
  color:#9ff5d2!important;
}




/* Hide duplicate main tab row (sidebar already has nav) */
.mainTabs,#mainTabsNew{display:none!important;height:0!important;margin:0!important;padding:0!important;border:0!important;overflow:hidden!important}

/* Per-coin colorful borders (12 hues) */
.coinHue0{--coinAccent:#31d7ff;--coinGlow:rgba(49,215,255,.35)}
.coinHue1{--coinAccent:#a78bfa;--coinGlow:rgba(167,139,250,.35)}
.coinHue2{--coinAccent:#f472b6;--coinGlow:rgba(244,114,182,.35)}
.coinHue3{--coinAccent:#fbbf24;--coinGlow:rgba(251,191,36,.35)}
.coinHue4{--coinAccent:#34d399;--coinGlow:rgba(52,211,153,.35)}
.coinHue5{--coinAccent:#60a5fa;--coinGlow:rgba(96,165,250,.35)}
.coinHue6{--coinAccent:#fb7185;--coinGlow:rgba(251,113,133,.35)}
.coinHue7{--coinAccent:#2dd4bf;--coinGlow:rgba(45,212,191,.35)}
.coinHue8{--coinAccent:#c084fc;--coinGlow:rgba(192,132,252,.35)}
.coinHue9{--coinAccent:#f59e0b;--coinGlow:rgba(245,158,11,.35)}
.coinHue10{--coinAccent:#22d3ee;--coinGlow:rgba(34,211,238,.35)}
.coinHue11{--coinAccent:#e879f9;--coinGlow:rgba(232,121,249,.35)}

.ticker.coinHue0,.ticker.coinHue1,.ticker.coinHue2,.ticker.coinHue3,
.ticker.coinHue4,.ticker.coinHue5,.ticker.coinHue6,.ticker.coinHue7,
.ticker.coinHue8,.ticker.coinHue9,.ticker.coinHue10,.ticker.coinHue11,
.assetCard.coinHue0,.assetCard.coinHue1,.assetCard.coinHue2,.assetCard.coinHue3,
.assetCard.coinHue4,.assetCard.coinHue5,.assetCard.coinHue6,.assetCard.coinHue7,
.assetCard.coinHue8,.assetCard.coinHue9,.assetCard.coinHue10,.assetCard.coinHue11,
.coinMiniCard.coinHue0,.coinMiniCard.coinHue1,.coinMiniCard.coinHue2,.coinMiniCard.coinHue3,
.coinMiniCard.coinHue4,.coinMiniCard.coinHue5,.coinMiniCard.coinHue6,.coinMiniCard.coinHue7,
.coinMiniCard.coinHue8,.coinMiniCard.coinHue9,.coinMiniCard.coinHue10,.coinMiniCard.coinHue11{
  border:2px solid var(--coinAccent)!important;
  box-shadow:
    0 12px 28px rgba(0,0,0,.4),
    0 0 18px var(--coinGlow),
    inset 0 1px 0 rgba(255,255,255,.1)!important;
  background:
    radial-gradient(circle at 100% 0%, var(--coinGlow), transparent 42%),
    linear-gradient(160deg,#12304c 0%,#0c1f36 50%,#08131f 100%)!important;
}

/* LONG / SHORT override with strong green/red rings */
.ticker.up,.assetCard.long,.coinMiniCard.long{
  border-color:#23e6a8!important;
  box-shadow:0 12px 28px rgba(0,0,0,.42),0 0 22px rgba(35,230,168,.35),inset 0 0 20px rgba(35,230,168,.06)!important;
}
.ticker.down,.assetCard.short,.coinMiniCard.short{
  border-color:#ff4d73!important;
  box-shadow:0 12px 28px rgba(0,0,0,.42),0 0 22px rgba(255,77,115,.35),inset 0 0 20px rgba(255,77,115,.06)!important;
}

/* Signal ring around icon */
.tickerIcon.ringIcon,.assetIcon,.coinMiniIcon{
  position:relative!important;
  overflow:visible!important;
}
.tickerIcon.ringIcon .sigRing,
.assetCard .sigRing,
.coinMiniIcon .sigRing{
  position:absolute;inset:-4px;border-radius:50%;
  border:2px solid transparent;
  pointer-events:none;
}
.tickerIcon.up .sigRing,.ringIcon.up{
  box-shadow:0 0 0 2px rgba(35,230,168,.85),0 0 14px rgba(35,230,168,.45)!important;
  animation:ringPulseGreen 1.8s ease-in-out infinite;
}
.tickerIcon.down .sigRing,.ringIcon.down{
  box-shadow:0 0 0 2px rgba(255,77,115,.85),0 0 14px rgba(255,77,115,.45)!important;
  animation:ringPulseRed 1.8s ease-in-out infinite;
}
.tickerIcon.neutral{
  box-shadow:0 0 0 2px rgba(255,211,78,.55),0 0 10px rgba(255,211,78,.25)!important;
}
@keyframes ringPulseGreen{
  0%,100%{box-shadow:0 0 0 2px rgba(35,230,168,.7),0 0 10px rgba(35,230,168,.3)}
  50%{box-shadow:0 0 0 3px rgba(35,230,168,1),0 0 18px rgba(35,230,168,.55)}
}
@keyframes ringPulseRed{
  0%,100%{box-shadow:0 0 0 2px rgba(255,77,115,.7),0 0 10px rgba(255,77,115,.3)}
  50%{box-shadow:0 0 0 3px rgba(255,77,115,1),0 0 18px rgba(255,77,115,.55)}
}

.sigBadge.up{color:#7dffc8!important;background:rgba(16,185,129,.2)!important;border:1px solid rgba(45,245,180,.5)!important;padding:4px 7px!important;border-radius:99px!important}
.sigBadge.down{color:#ffb0c2!important;background:rgba(244,63,94,.2)!important;border:1px solid rgba(255,95,130,.5)!important;padding:4px 7px!important;border-radius:99px!important}
.sigBadge.neutral{color:#ffe9a3!important;background:rgba(251,191,36,.15)!important;border:1px solid rgba(255,211,78,.4)!important;padding:4px 7px!important;border-radius:99px!important}

.scoreChip{
  display:inline-flex!important;align-items:center!important;gap:5px!important;
  font-size:11px!important;font-weight:1000!important;color:#eaf7ff!important;
}
.scoreRingMini{
  width:16px;height:16px;border-radius:50%;
  background:conic-gradient(var(--coinAccent,#31d7ff) calc(var(--sc,0)*1%), rgba(255,255,255,.12) 0);
  box-shadow:0 0 8px var(--coinGlow,rgba(49,215,255,.3));
  display:inline-block;
}
.scoreChip.up .scoreRingMini{background:conic-gradient(#23e6a8 calc(var(--sc,0)*1%), rgba(255,255,255,.1) 0)}
.scoreChip.down .scoreRingMini{background:conic-gradient(#ff4d73 calc(var(--sc,0)*1%), rgba(255,255,255,.1) 0)}
.scoreChip.neutral .scoreRingMini{background:conic-gradient(#ffd34e calc(var(--sc,0)*1%), rgba(255,255,255,.1) 0)}

/* Ambient light orbs on panels */
.kpi,.signalBox,.hudbox,.panel{
  position:relative;overflow:hidden;
}
.kpi::before,.signalBox.long::after,.signalBox.short::after{
  content:"";position:absolute;width:80px;height:80px;border-radius:50%;
  filter:blur(28px);opacity:.35;pointer-events:none;z-index:0;
}
.kpi::before{top:-20px;right:-10px;background:rgba(49,215,255,.5)}
.signalBox.long::after{bottom:-15px;left:-10px;background:rgba(35,230,168,.55)}
.signalBox.short::after{bottom:-15px;left:-10px;background:rgba(255,77,115,.55)}
.signalBox.long{border:1.5px solid rgba(35,230,168,.45)!important;box-shadow:0 0 20px rgba(35,230,168,.15)!important}
.signalBox.short{border:1.5px solid rgba(255,77,115,.45)!important;box-shadow:0 0 20px rgba(255,77,115,.15)!important}
.signalBox.wait{border:1.5px solid rgba(255,211,78,.4)!important;box-shadow:0 0 16px rgba(255,211,78,.12)!important}

.topHeader{
  box-shadow:0 18px 50px rgba(0,0,0,.45),0 0 40px rgba(49,215,255,.08),inset 0 1px 0 rgba(255,255,255,.06)!important;
}
.brandMark{
  box-shadow:0 0 24px rgba(49,215,255,.35),inset 0 0 12px rgba(49,215,255,.15)!important;
  animation:brandGlow 3s ease-in-out infinite alternate;
}
@keyframes brandGlow{
  from{box-shadow:0 0 16px rgba(49,215,255,.25)}
  to{box-shadow:0 0 28px rgba(49,215,255,.5),0 0 40px rgba(167,139,250,.2)}
}
.dot{animation:dotBlink 2s ease-in-out infinite}
@keyframes dotBlink{0%,100%{opacity:1}50%{opacity:.55}}

.decisionPill.long{
  color:#9ff5d2!important;background:rgba(16,185,129,.25)!important;border:1px solid rgba(45,245,180,.55)!important;
  box-shadow:0 0 12px rgba(35,230,168,.25)!important;
}
.decisionPill.short{
  color:#ffb3c4!important;background:rgba(244,63,94,.25)!important;border:1px solid rgba(255,95,130,.55)!important;
  box-shadow:0 0 12px rgba(255,77,115,.25)!important;
}
.decisionPill.wait{
  color:#ffe9a3!important;background:rgba(251,191,36,.2)!important;border:1px solid rgba(255,211,78,.5)!important;
}


/* ===== HARD COLORED CARD BORDERS (final priority) ===== */
.ticker.coinHue0, .assetCard.coinHue0, .coinMiniCard.coinHue0,
button.ticker.coinHue0, button.assetCard.coinHue0, button.coinMiniCard.coinHue0{
  border: 0.32px solid #31d7ff !important;
  box-shadow: 0 0 0 1px rgba(49,215,255,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(49,215,255,.3) !important;
}
.ticker.coinHue1, .assetCard.coinHue1, .coinMiniCard.coinHue1,
button.ticker.coinHue1, button.assetCard.coinHue1, button.coinMiniCard.coinHue1{
  border: 0.32px solid #a78bfa !important;
  box-shadow: 0 0 0 1px rgba(167,139,250,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(167,139,250,.3) !important;
}
.ticker.coinHue2, .assetCard.coinHue2, .coinMiniCard.coinHue2,
button.ticker.coinHue2, button.assetCard.coinHue2, button.coinMiniCard.coinHue2{
  border: 0.32px solid #f472b6 !important;
  box-shadow: 0 0 0 1px rgba(244,114,182,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(244,114,182,.3) !important;
}
.ticker.coinHue3, .assetCard.coinHue3, .coinMiniCard.coinHue3,
button.ticker.coinHue3, button.assetCard.coinHue3, button.coinMiniCard.coinHue3{
  border: 0.32px solid #fbbf24 !important;
  box-shadow: 0 0 0 1px rgba(251,191,36,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(251,191,36,.3) !important;
}
.ticker.coinHue4, .assetCard.coinHue4, .coinMiniCard.coinHue4,
button.ticker.coinHue4, button.assetCard.coinHue4, button.coinMiniCard.coinHue4{
  border: 0.32px solid #34d399 !important;
  box-shadow: 0 0 0 1px rgba(52,211,153,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(52,211,153,.3) !important;
}
.ticker.coinHue5, .assetCard.coinHue5, .coinMiniCard.coinHue5,
button.ticker.coinHue5, button.assetCard.coinHue5, button.coinMiniCard.coinHue5{
  border: 0.32px solid #60a5fa !important;
  box-shadow: 0 0 0 1px rgba(96,165,250,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(96,165,250,.3) !important;
}
.ticker.coinHue6, .assetCard.coinHue6, .coinMiniCard.coinHue6,
button.ticker.coinHue6, button.assetCard.coinHue6, button.coinMiniCard.coinHue6{
  border: 0.32px solid #fb7185 !important;
  box-shadow: 0 0 0 1px rgba(251,113,133,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(251,113,133,.3) !important;
}
.ticker.coinHue7, .assetCard.coinHue7, .coinMiniCard.coinHue7,
button.ticker.coinHue7, button.assetCard.coinHue7, button.coinMiniCard.coinHue7{
  border: 0.32px solid #2dd4bf !important;
  box-shadow: 0 0 0 1px rgba(45,212,191,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(45,212,191,.3) !important;
}
.ticker.coinHue8, .assetCard.coinHue8, .coinMiniCard.coinHue8,
button.ticker.coinHue8, button.assetCard.coinHue8, button.coinMiniCard.coinHue8{
  border: 0.32px solid #c084fc !important;
  box-shadow: 0 0 0 1px rgba(192,132,252,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(192,132,252,.3) !important;
}
.ticker.coinHue9, .assetCard.coinHue9, .coinMiniCard.coinHue9,
button.ticker.coinHue9, button.assetCard.coinHue9, button.coinMiniCard.coinHue9{
  border: 0.32px solid #f59e0b !important;
  box-shadow: 0 0 0 1px rgba(245,158,11,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(245,158,11,.3) !important;
}
.ticker.coinHue10, .assetCard.coinHue10, .coinMiniCard.coinHue10,
button.ticker.coinHue10, button.assetCard.coinHue10, button.coinMiniCard.coinHue10{
  border: 0.32px solid #22d3ee !important;
  box-shadow: 0 0 0 1px rgba(34,211,238,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(34,211,238,.3) !important;
}
.ticker.coinHue11, .assetCard.coinHue11, .coinMiniCard.coinHue11,
button.ticker.coinHue11, button.assetCard.coinHue11, button.coinMiniCard.coinHue11{
  border: 0.32px solid #e879f9 !important;
  box-shadow: 0 0 0 1px rgba(232,121,249,.25), 0 8px 20px rgba(0,0,0,.4), 0 0 12px rgba(232,121,249,.3) !important;
}

/* Signal still wins when directional */
.ticker.up, .assetCard.long, .coinMiniCard.long,
button.ticker.up, button.assetCard.long, button.coinMiniCard.long{
  border: 0.32px solid #23e6a8 !important;
  box-shadow: 0 0 0 1px rgba(35,230,168,.3), 0 8px 20px rgba(0,0,0,.42), 0 0 14px rgba(35,230,168,.4) !important;
}
.ticker.down, .assetCard.short, .coinMiniCard.short,
button.ticker.down, button.assetCard.short, button.coinMiniCard.short{
  border: 0.32px solid #ff4d73 !important;
  box-shadow: 0 0 0 1px rgba(255,77,115,.3), 0 8px 20px rgba(0,0,0,.42), 0 0 14px rgba(255,77,115,.4) !important;
}

/* Fallback: any card without hue still gets a cyan border so nothing is plain */
.ticker:not([class*="coinHue"]),
.assetCard:not([class*="coinHue"]),
.coinMiniCard:not([class*="coinHue"]){
  border: 2px solid rgba(72,203,255,.55) !important;
}


/* ===== LIGHT EFFECTS + THIN BORDERS + BUY/SELL RINGS ===== */
.ticker, .assetCard, .coinMiniCard, button.ticker, button.assetCard, button.coinMiniCard {
  border-width: 0.32px !important;
}

/* Soft ambient light sweep on panels */
.topHeader, .panel, .kpi, .signalBox, .hudbox, .section, .cdBanner, .detailVisualGroup {
  position: relative;
  overflow: hidden;
}
.topHeader::after, .panel::before, .section.hud::before {
  content: "";
  position: absolute;
  top: -40%;
  left: -20%;
  width: 60%;
  height: 180%;
  background: linear-gradient(115deg, transparent 0%, rgba(255,255,255,.04) 42%, rgba(49,215,255,.07) 50%, transparent 58%);
  pointer-events: none;
  animation: lightSweep 7s ease-in-out infinite;
  z-index: 0;
}
@keyframes lightSweep {
  0% { transform: translateX(-30%) rotate(8deg); opacity: .35; }
  50% { transform: translateX(80%) rotate(8deg); opacity: .7; }
  100% { transform: translateX(140%) rotate(8deg); opacity: .35; }
}

/* Neon light bars under headers */
.panelHead, .panelTitle, .section > h2, .brand h1 {
  position: relative;
}
.section > h2::after, .panelTitle::after {
  content: "";
  display: block;
  height: 2px;
  margin-top: 6px;
  width: 42%;
  border-radius: 99px;
  background: linear-gradient(90deg, #31d7ff, #a78bfa, transparent);
  box-shadow: 0 0 12px rgba(49,215,255,.45);
}

/* Glow orbs */
.kpi::after {
  content: "";
  position: absolute;
  width: 70px; height: 70px;
  right: -12px; bottom: -18px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(49,215,255,.28), transparent 70%);
  pointer-events: none;
  filter: blur(2px);
}
.signalBox.long::before, .signalBox.short::before, .signalBox.wait::before {
  content: "";
  position: absolute;
  inset: auto auto -20px -15px;
  width: 90px; height: 90px;
  border-radius: 50%;
  pointer-events: none;
  filter: blur(22px);
  opacity: .45;
}
.signalBox.long::before { background: #23e6a8; }
.signalBox.short::before { background: #ff4d73; }
.signalBox.wait::before { background: #ffd34e; }

.statusPill {
  box-shadow: 0 0 14px rgba(49,215,255,.08), inset 0 0 12px rgba(255,255,255,.03) !important;
}
.dot {
  box-shadow: 0 0 10px currentColor, 0 0 18px currentColor !important;
}

/* Buy / Sell dual ring widget */
.bsFlowBox {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 14px;
  align-items: center;
  margin: 12px 0;
  padding: 14px;
  border-radius: 18px;
  background: linear-gradient(145deg, rgba(8,28,48,.95), rgba(5,14,26,.98));
  border: 0.32px solid rgba(72,203,255,.35);
  box-shadow: 0 0 24px rgba(49,215,255,.12), inset 0 0 30px rgba(255,255,255,.02);
  position: relative;
  overflow: hidden;
}
.bsFlowBox::before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0; height: 1px;
  background: linear-gradient(90deg, transparent, rgba(49,215,255,.55), rgba(167,139,250,.4), transparent);
  box-shadow: 0 0 10px rgba(49,215,255,.4);
}
.bsDualRing {
  width: 88px; height: 88px;
  border-radius: 50%;
  position: relative;
  background: conic-gradient(#23e6a8 0 calc(var(--buy,50) * 1%), #ff4d73 0);
  box-shadow: 0 0 18px rgba(35,230,168,.25), 0 0 18px rgba(255,77,115,.18);
}
.bsDualRing::after {
  content: "";
  position: absolute;
  inset: 11px;
  border-radius: 50%;
  background: #07111c;
  box-shadow: inset 0 0 12px rgba(0,0,0,.5);
}
.bsDualRing .bsCenter {
  position: absolute;
  inset: 0;
  z-index: 2;
  display: grid;
  place-items: center;
  text-align: center;
  font-size: 10px;
  font-weight: 1000;
  color: #e8f6ff;
  line-height: 1.25;
}
.bsDualRing .bsCenter b { display: block; font-size: 13px; color: #7dffc8; }
.bsLegend { display: grid; gap: 8px; min-width: 0; }
.bsRow {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 8px 10px; border-radius: 12px;
  background: rgba(0,0,0,.28); border: 0.32px solid rgba(255,255,255,.08);
}
.bsRow.buy { border-color: rgba(35,230,168,.35); box-shadow: 0 0 12px rgba(35,230,168,.12); }
.bsRow.sell { border-color: rgba(255,77,115,.35); box-shadow: 0 0 12px rgba(255,77,115,.12); }
.bsRow span { font-size: 12px; font-weight: 900; color: #cfe6f5; }
.bsRow b.buyPct { color: #7dffc8; font-size: 15px; }
.bsRow b.sellPct { color: #ffb0c2; font-size: 15px; }
.bsBar {
  height: 6px; border-radius: 99px; margin-top: 8px;
  background: linear-gradient(90deg, #23e6a8 0 calc(var(--buy,50)*1%), #ff4d73 0);
  box-shadow: 0 0 12px rgba(35,230,168,.25);
}

/* Light edge on modal */
.detailModal .modalC {
  border: 0.32px solid rgba(72,203,255,.4) !important;
  box-shadow: 0 30px 90px rgba(0,0,0,.7), 0 0 40px rgba(49,215,255,.12) !important;
}
.cdBanner {
  box-shadow: inset 0 -1px 0 rgba(49,215,255,.15), 0 8px 24px rgba(0,0,0,.2) !important;
}
.cdBanner.long { box-shadow: inset 0 -1px 0 rgba(35,230,168,.35), 0 0 30px rgba(35,230,168,.1) !important; }
.cdBanner.bear { box-shadow: inset 0 -1px 0 rgba(255,77,115,.35), 0 0 30px rgba(255,77,115,.1) !important; }

.glassBtn, .sideBtn, .mainTab {
  box-shadow: 0 0 14px rgba(49,215,255,.08), inset 0 1px 0 rgba(255,255,255,.06) !important;
}


/* Realtime analysis bar */
.rtAnalysisBar{
  display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;
  margin:0 0 12px;padding:11px 14px;border-radius:16px;
  background:linear-gradient(110deg,rgba(6,28,48,.95),rgba(8,18,36,.96));
  border:0.65px solid rgba(49,215,255,.35);
  box-shadow:0 0 24px rgba(49,215,255,.12), inset 0 0 20px rgba(255,255,255,.02);
  position:relative;overflow:hidden;
}
.rtAnalysisBar::before{
  content:"";position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,#31d7ff,transparent);
  box-shadow:0 0 12px rgba(49,215,255,.5);
}
.rtLeft{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:900;color:#d6eefc}
.rtLeft b{color:#fff}
.rtDot{width:9px;height:9px;border-radius:50%;background:#23e6a8;box-shadow:0 0 12px #23e6a8;animation:dotBlink 1.2s ease-in-out infinite}
.rtMid{font-size:12px;font-weight:1000;color:#cfe8f7}
.rtRight{font-size:11px;font-weight:800;color:#9ec5dc;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rtChip{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;margin:0 3px;border-radius:99px;background:rgba(0,0,0,.28);border:0.65px solid rgba(255,255,255,.1)}
.rtChip.up{color:#7dffc8;border-color:rgba(35,230,168,.4)}
.rtChip.down{color:#ffb0c2;border-color:rgba(255,77,115,.4)}
.tickerPrice.flashUp{animation:flashUp .45s ease}
.tickerPrice.flashDown{animation:flashDown .45s ease}
@keyframes flashUp{from{color:#7dffc8;text-shadow:0 0 12px rgba(35,230,168,.6)}to{color:#fff;text-shadow:none}}
@keyframes flashDown{from{color:#ffb0c2;text-shadow:0 0 12px rgba(255,77,115,.6)}to{color:#fff;text-shadow:none}}


/* ===== TOP COIN CARDS: clear glass bg (no murky yellow) + signal under-name bar ===== */
/* Background only — borders left to existing hue rules */
.ticker,
button.ticker,
.assetCard,
button.assetCard,
.ticker.neutral,
button.ticker.neutral,
.ticker.up,
button.ticker.up,
.ticker.down,
button.ticker.down,
.assetCard.wait,
button.assetCard.wait,
.assetCard.long,
button.assetCard.long,
.assetCard.short,
button.assetCard.short,
.ticker.coinHue0, .ticker.coinHue1, .ticker.coinHue2, .ticker.coinHue3,
.ticker.coinHue4, .ticker.coinHue5, .ticker.coinHue6, .ticker.coinHue7,
.ticker.coinHue8, .ticker.coinHue9, .ticker.coinHue10, .ticker.coinHue11,
.assetCard.coinHue0, .assetCard.coinHue1, .assetCard.coinHue2, .assetCard.coinHue3,
.assetCard.coinHue4, .assetCard.coinHue5, .assetCard.coinHue6, .assetCard.coinHue7,
.assetCard.coinHue8, .assetCard.coinHue9, .assetCard.coinHue10, .assetCard.coinHue11 {
  background: rgba(6, 14, 26, 0.42) !important;
  background-image: linear-gradient(160deg, rgba(12, 28, 48, 0.38), rgba(5, 12, 22, 0.28)) !important;
  backdrop-filter: blur(10px) !important;
  -webkit-backdrop-filter: blur(10px) !important;
}

/* Remove gold fill on wait — keep only border color from previous rules */
.coinMiniCard.wait,
button.coinMiniCard.wait {
  background: rgba(6, 14, 26, 0.42) !important;
  background-image: linear-gradient(160deg, rgba(12, 28, 48, 0.38), rgba(5, 12, 22, 0.28)) !important;
}

/* Signal light bar under coin name */
.ticker .tickerCoin > span:last-child,
.assetCard .assetName,
.coinMiniCard .coinMiniNameBlock {
  position: relative !important;
  padding-bottom: 7px !important;
}
.ticker .tickerCoin > span:last-child::after,
.assetCard .assetName::after,
.coinMiniCard .coinMiniNameBlock::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 2px;
  border-radius: 99px;
  background: #ffd34e;
  box-shadow: 0 0 8px rgba(255, 211, 78, 0.75), 0 0 14px rgba(255, 211, 78, 0.35);
  opacity: 0.95;
}

/* WAIT = yellow bar (default above) */
.ticker.neutral .tickerCoin > span:last-child::after,
.assetCard.wait .assetName::after,
.coinMiniCard.wait .coinMiniNameBlock::after,
.ticker[data-decision="WAIT"] .tickerCoin > span:last-child::after {
  background: #ffd34e !important;
  box-shadow: 0 0 8px rgba(255, 211, 78, 0.8), 0 0 14px rgba(255, 211, 78, 0.4) !important;
}

/* LONG = green bar */
.ticker.up .tickerCoin > span:last-child::after,
.assetCard.long .assetName::after,
.coinMiniCard.long .coinMiniNameBlock::after,
.ticker[data-decision="LONG"] .tickerCoin > span:last-child::after {
  background: #23e6a8 !important;
  box-shadow: 0 0 8px rgba(35, 230, 168, 0.85), 0 0 14px rgba(35, 230, 168, 0.45) !important;
}

/* SHORT = red bar */
.ticker.down .tickerCoin > span:last-child::after,
.assetCard.short .assetName::after,
.coinMiniCard.short .coinMiniNameBlock::after,
.ticker[data-decision="SHORT"] .tickerCoin > span:last-child::after {
  background: #ff4d73 !important;
  box-shadow: 0 0 8px rgba(255, 77, 115, 0.85), 0 0 14px rgba(255, 77, 115, 0.45) !important;
}


/* TOP TICKER CARDS: transparent glass fill, keep colored border */
.tickerRail .ticker,
.tickerRail button.ticker,
button.ticker{
  background: rgba(6, 14, 26, 0.22) !important;
  background-image: none !important;
  backdrop-filter: blur(10px) saturate(1.15) !important;
  -webkit-backdrop-filter: blur(10px) saturate(1.15) !important;
}
/* Kill yellow/green/red muddy fills on top tickers only — border stays */
.tickerRail .ticker.up,
.tickerRail .ticker.down,
.tickerRail .ticker.neutral,
.tickerRail .ticker.coinHue0,
.tickerRail .ticker.coinHue1,
.tickerRail .ticker.coinHue2,
.tickerRail .ticker.coinHue3,
.tickerRail .ticker.coinHue4,
.tickerRail .ticker.coinHue5,
.tickerRail .ticker.coinHue6,
.tickerRail .ticker.coinHue7,
.tickerRail .ticker.coinHue8,
.tickerRail .ticker.coinHue9,
.tickerRail .ticker.coinHue10,
.tickerRail .ticker.coinHue11,
.tickerRail button.ticker.up,
.tickerRail button.ticker.down,
.tickerRail button.ticker.neutral{
  background: rgba(6, 14, 26, 0.22) !important;
  background-image: none !important;
}
/* Soften inner glow so it does not look yellow muddy */
.tickerRail .ticker,
.tickerRail button.ticker{
  box-shadow: 0 0 0 0.5px rgba(255,255,255,.06), 0 8px 18px rgba(0,0,0,.25) !important;
}
.tickerRail .ticker.coinHue0{ box-shadow: 0 0 0 0.32px #31d7ff, 0 0 10px rgba(49,215,255,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue1{ box-shadow: 0 0 0 0.32px #a78bfa, 0 0 10px rgba(167,139,250,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue2{ box-shadow: 0 0 0 0.32px #f472b6, 0 0 10px rgba(244,114,182,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue3{ box-shadow: 0 0 0 0.32px #fbbf24, 0 0 10px rgba(251,191,36,.2), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue4{ box-shadow: 0 0 0 0.32px #34d399, 0 0 10px rgba(52,211,153,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue5{ box-shadow: 0 0 0 0.32px #60a5fa, 0 0 10px rgba(96,165,250,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue6{ box-shadow: 0 0 0 0.32px #fb7185, 0 0 10px rgba(251,113,133,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue7{ box-shadow: 0 0 0 0.32px #2dd4bf, 0 0 10px rgba(45,212,191,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue8{ box-shadow: 0 0 0 0.32px #c084fc, 0 0 10px rgba(192,132,252,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue9{ box-shadow: 0 0 0 0.32px #f59e0b, 0 0 10px rgba(245,158,11,.2), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue10{ box-shadow: 0 0 0 0.32px #22d3ee, 0 0 10px rgba(34,211,238,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.coinHue11{ box-shadow: 0 0 0 0.32px #e879f9, 0 0 10px rgba(232,121,249,.22), 0 8px 18px rgba(0,0,0,.25) !important; }
.tickerRail .ticker.up{ box-shadow: 0 0 0 0.32px #23e6a8, 0 0 12px rgba(35,230,168,.28), 0 8px 18px rgba(0,0,0,.25) !important; border-color:#23e6a8!important; }
.tickerRail .ticker.down{ box-shadow: 0 0 0 0.32px #ff4d73, 0 0 12px rgba(255,77,115,.28), 0 8px 18px rgba(0,0,0,.25) !important; border-color:#ff4d73!important; }
.tickerRail .ticker.neutral{ box-shadow: 0 0 0 0.32px rgba(255,211,78,.7), 0 0 10px rgba(255,211,78,.2), 0 8px 18px rgba(0,0,0,.25) !important; }

/* Signal underline under coin name */
.tickerCoin span b{ position:relative; display:inline-block; }
.sigUnderline{
  display:block!important;
  width:100%;
  height:3px!important;
  margin-top:4px!important;
  border-radius:99px!important;
  background:rgba(255,211,78,.85)!important;
  box-shadow:0 0 8px rgba(255,211,78,.75), 0 0 14px rgba(255,211,78,.35)!important;
}
.sigUnderline.up{
  background:#23e6a8!important;
  box-shadow:0 0 8px rgba(35,230,168,.85), 0 0 14px rgba(35,230,168,.4)!important;
}
.sigUnderline.down{
  background:#ff4d73!important;
  box-shadow:0 0 8px rgba(255,77,115,.85), 0 0 14px rgba(255,77,115,.4)!important;
}
.sigUnderline.neutral{
  background:#ffd34e!important;
  box-shadow:0 0 8px rgba(255,211,78,.8), 0 0 14px rgba(255,211,78,.4)!important;
}

/* 30-60m leverage window panel */
.scalp30Box{
  margin:0 0 12px;padding:12px 14px;border-radius:16px;
  background:linear-gradient(120deg,rgba(8,24,44,.92),rgba(10,16,32,.95));
  border:0.65px solid rgba(167,139,250,.35);
  box-shadow:0 0 22px rgba(167,139,250,.12), inset 0 0 18px rgba(255,255,255,.02);
}
.scalp30Head{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px}
.scalp30Head b{color:#fff;font-size:13px}
.scalp30Head span{color:#9eb8cc;font-size:11px;font-weight:800}
.scalp30Grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px}
.scalpChip{
  padding:10px;border-radius:14px;background:rgba(0,0,0,.28);
  border:0.65px solid rgba(255,255,255,.1);min-width:0;
}
.scalpChip.long{border-color:rgba(35,230,168,.5);box-shadow:0 0 12px rgba(35,230,168,.15)}
.scalpChip.short{border-color:rgba(255,77,115,.5);box-shadow:0 0 12px rgba(255,77,115,.15)}
.scalpChip .s1{font-size:13px;font-weight:1000;color:#fff}
.scalpChip .s2{font-size:11px;font-weight:900;margin-top:3px}
.scalpChip .s2.long{color:#7dffc8}
.scalpChip .s2.short{color:#ffb0c2}
.scalpChip .s3{font-size:10px;color:#8fa7bb;margin-top:4px;font-weight:800;line-height:1.4}


/* No frame around coin LOGO only */
.tickerIcon, .tickerIcon.ringIcon, .assetIcon, .coinMiniIcon,
.tickerRail .tickerIcon, .tickerRail .ringIcon {
  border: none !important;
  box-shadow: none !important;
  outline: none !important;
  background: transparent !important;
  animation: none !important;
}
.tickerIcon .sigRing, .ringIcon .sigRing, .sigRing {
  display: none !important;
  border: none !important;
  box-shadow: none !important;
}

/* Replace double lines with ONE small triangle under name */
.sigUnderline {
  display: inline-block !important;
  width: 0 !important;
  height: 0 !important;
  margin: 5px 0 0 2px !important;
  border-radius: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  border-left: 5px solid transparent !important;
  border-right: 5px solid transparent !important;
  border-top: none !important;
  border-bottom: 7px solid #ffd34e !important; /* WAIT yellow, point up */
  vertical-align: middle !important;
}
.sigUnderline.up {
  background: transparent !important;
  box-shadow: none !important;
  border-left: 5px solid transparent !important;
  border-right: 5px solid transparent !important;
  border-bottom: 7px solid #23e6a8 !important;
  border-top: none !important;
  filter: drop-shadow(0 0 4px rgba(35,230,168,.7));
}
.sigUnderline.down {
  background: transparent !important;
  box-shadow: none !important;
  /* point down for short */
  border-left: 5px solid transparent !important;
  border-right: 5px solid transparent !important;
  border-top: 7px solid #ff4d73 !important;
  border-bottom: none !important;
  filter: drop-shadow(0 0 4px rgba(255,77,115,.7));
}
.sigUnderline.neutral {
  background: transparent !important;
  box-shadow: none !important;
  border-left: 5px solid transparent !important;
  border-right: 5px solid transparent !important;
  border-bottom: 7px solid #ffd34e !important;
  border-top: none !important;
  filter: drop-shadow(0 0 4px rgba(255,211,78,.7));
}
/* Hide any extra score ring mini glow lines looking like double yellow */
.tickerRail .scoreRingMini {
  box-shadow: none !important;
}

</style>
<body>
<div class="titanApp">

  <header class="topHeader">
    <div class="brand"><div class="brandMark">◈</div><div><h1>TITAN <span>V28</span> ADVANCED</h1><small>موتور کمّی · هوش مصنوعی · فقط تحلیل</small></div></div>
    <div class="statusStrip">
      <div class="statusPill"><span class="dot"></span><b>موتور TITAN</b> فعال</div>
      <div class="statusPill"><span class="dot"></span><b>Binance</b> Live</div>
      <div class="statusPill"><span class="dot"></span><b>CoinGlass V4</b></div>
      <div class="statusPill"><span class="dot"></span><b>Gemini</b> {{ 'آماده' if gemini_status.available else 'کلید موجود نیست' }}</div>
      <div class="statusPill"><span class="dot warn"></span><b>UTC+3:30</b> · {{ gemini_status.updated_at }}</div>
    </div>
    <div class="headerActions"><a class="glassBtn" href="/rescan" onclick="try{TitanSFX&&TitanSFX.play('success')}catch(e){}">⟳ اسکن مجدد</a><button class="glassBtn" type="button" id="sfxToggleBtn" onclick="(function(b){var on=TitanSFX.toggle();b.textContent=on?'🔊 صدا':'🔇 قطع';b.title=on?'افکت صوتی روشن':'افکت صوتی خاموش';})(this)">🔊 صدا</button><button class="glassBtn gold" onclick="openM()">⚙ تنظیمات</button></div><div class="scanTelemetry" id="scanTelemetry"><div class="scanTelemetryTop"><b id="scanPhase">آماده</b><span id="scanPct">0%</span></div><div class="scanTelemetryBar"><i id="scanBar"></i></div><div class="scanTelemetryMeta"><span id="scanTime">آخرین اسکن: —</span><span id="scanAge">داده: —</span></div></div>
  </header>

<div class="rtAnalysisBar" id="rtAnalysisBar">
  <div class="rtLeft"><span class="rtDot"></span><b>تحلیل بلادرنگ</b> <span id="rtStatus">در حال اتصال…</span></div>
  <div class="rtMid" id="rtBreadth">▲ -- · ▼ -- · ◆ --</div>
  <div class="rtRight" id="rtLeaders">—</div>

<div class="scalp30Box" id="scalp30Box">
  <div class="scalp30Head">
    <b>⚡ پنجره اهرمی ۳۰–۶۰ دقیقه</b>
    <span>فقط سیگنال کوتاه‌مدت · بستن حداکثر تا ۶۰ دقیقه · تحلیل نه توصیه قطعی</span>
  </div>
  <div class="scalp30Grid" id="scalp30Grid"><div style="color:#8fa7bb;font-size:12px">در حال محاسبه فرصت‌های نیم‌ساعته…</div></div>
</div>

</div>

  <div class="appGrid">
    <aside class="sidebar">
      <div class="sideBrand"><b>◈ NAVIGATION</b><small>مرکز کنترل طبقه‌بندی‌شده</small></div>
      <button class="sideBtn active" data-side-tab="tab-market" onclick="switchMainTab('tab-market',this)"><span class="sideIcon">⌂</span><span>مرکز بازار</span></button>
      <button class="sideBtn" data-side-tab="tab-edge" onclick="switchMainTab('tab-edge',this)"><span class="sideIcon">◈</span><span>Edge Suite</span></button>
      <button class="sideBtn" data-side-tab="tab-ai" onclick="switchMainTab('tab-ai',this)"><span class="sideIcon">✦</span><span>هوش مصنوعی</span></button>
      <button class="sideBtn" data-side-tab="tab-perf" onclick="switchMainTab('tab-perf',this)"><span class="sideIcon">◌</span><span>عملکرد</span></button>
      <button class="sideBtn" data-side-tab="tab-charts" onclick="switchMainTab('tab-charts',this)"><span class="sideIcon">⌁</span><span>نمودارها</span></button>
      <button class="sideBtn" data-side-tab="tab-control" onclick="switchMainTab('tab-control',this)"><span class="sideIcon">⚙</span><span>کنترل</span></button>
      <div class="sideFilter"><label>جستجوی سریع ارز</label><input id="coinSearch" class="searchBox" placeholder="BTC / ETH / SHIB ..." oninput="filterAssets()"><div class="filterRow"><button class="filterBtn active" data-filter="ALL" onclick="setAssetFilter('ALL',this)">همه</button><button class="filterBtn" data-filter="LONG" onclick="setAssetFilter('LONG',this)">LONG</button><button class="filterBtn" data-filter="WAIT" onclick="setAssetFilter('WAIT',this)">WAIT</button></div><div class="filterRow"><button class="filterBtn" data-filter="SHORT" onclick="setAssetFilter('SHORT',this)">SHORT</button><button class="filterBtn" data-filter="TOP" onclick="setAssetFilter('TOP',this)">برتر</button><button class="filterBtn" onclick="clearAssetFilter()">پاک</button></div></div>
    </aside>

    <main class="mainArea">
      

      <section class="tabPanel active" id="tab-market">
        <div class="tickerRail">
          {% for item in market_data %}
          {% set dec=item.get('decision_tag','WAIT')|upper %}{% set cls='up' if dec=='LONG' else 'down' if dec=='SHORT' else 'neutral' %}
          <button class="ticker coinHue{{ loop.index0 % 12 }} {{ cls }}" data-decision="{{ dec }}" data-jump="{{ item.tv_symbol }}" data-symbol="{{ item.symbol }}"><div class="tickerTop"><span class="tickerCoin"><span class="tickerIcon ringIcon {{ cls }}"><i class="sigRing"></i>{{ item.coin_icon }}</span><span><b>{{ item.base_symbol }}</b><small>{{ item.coin_name }}</small><i class="sigUnderline {{ cls }}"></i></span></span><span class="tickerMove {{ cls }} sigBadge">{{ '▲ خرید' if dec=='LONG' else '▼ فروش' if dec=='SHORT' else '◆ انتظار' }}</span></div><div class="tickerTop" style="margin-top:4px"><span class="tickerPrice">{{ item.price }}</span><span class="scoreChip {{ cls }}"><span class="scoreRingMini" style="--sc:{{ item.score|default(0) }}"></span> {{ item.score }}</span></div></button>
          {% endfor %}
        </div>

        {% set board=(macro.get('signal_board') if macro else None) or {} %}{% set counts=board.get('counts') or {} %}{% set gsum=(macro.get('grade_summary') if macro else None) or {} %}
        {% set active_list = board.get('active') if board.get('active') is not none else none %}
        <div class="activeHero" id="activeHeroBoard">
          <div class="activeHeroHead">
            <h3>⚡ سیگنال‌های فعال همین لحظه · V28.5</h3>
            <span class="ahCount" id="ahCountLabel">LONG {{ counts.get('long',0) }} · SHORT {{ counts.get('short',0) }} · WAIT {{ counts.get('wait',0) }}</span>
          </div>
          <div class="activeHeroGrid" id="activeHeroGrid">
            {% for a in market_data if (a.get('decision_tag') or 'WAIT')|upper in ['LONG','SHORT'] %}
              {% if loop.index <= 12 %}
                {% set ad = (a.get('decision_tag') or 'WAIT')|upper %}
                {% set acls = 'long' if ad=='LONG' else 'short' %}
                {% set asym = a.get('symbol') or '' %}
                {% set abase = a.get('base_symbol') or (asym.split('/')[0] if asym else '—') %}
                <button class="ahCard {{ acls }}" data-symbol="{{ asym }}" onclick="jumpToCoin('{{ asym.replace('/','') }}','{{ asym }}')">
                  <div class="ahTop"><b>{{ a.get('coin_icon') or '◆' }} {{ abase }}</b><span class="ahSide">{{ '▲ LONG' if ad=='LONG' else '▼ SHORT' }}</span></div>
                  <div class="ahPrice">{{ a.get('price') or '—' }}</div>
                  <div class="ahMeta">{{ a.get('grade') or '—' }} · Q{{ a.get('signal_quality') or '—' }} · RR{{ a.get('rr_tp1') or a.get('effective_rr_tp1') or '—' }} · Trust {{ a.get('trust_index') or '—' }}</div>
                </button>
              {% endif %}
            {% else %}
              <div class="ahEmpty" style="grid-column:1/-1">الان سیگنال جهت‌دار فعال نیست — بازار در حالت انتظار است. بعد از Rescan اگر لبه واقعی باشد اینجا سبز/قرمز می‌شود.</div>
            {% endfor %}
          </div>
        </div>
        <script>
        (function(){
          try{
            var g=document.getElementById('activeHeroGrid');
            var board=document.getElementById('activeHeroBoard');
            if(g && board && !g.querySelector('.ahCard')) board.classList.add('empty');
          }catch(e){}
        })();
        </script>
        <div class="kpiGrid">
          <div class="kpi"><div class="kpiHead"><span>REGIME</span><span class="kpiIcon">◈</span></div><div class="kpiValue" id="pulse-regime">--</div><div class="kpiHint">رژیم غالب بازار</div></div>
          <div class="kpi"><div class="kpiHead"><span>MARKET SCORE</span><span class="kpiIcon">◉</span></div><div class="kpiValue" id="pulse-score">--</div><div class="kpiHint">میانگین امتیاز</div></div>
          <div class="kpi"><div class="kpiHead"><span>BREADTH</span><span class="kpiIcon">▥</span></div><div class="kpiValue" id="pulse-breadth">--</div><div class="kpiHint">عرض بازار</div></div>
          <div class="kpi"><div class="kpiHead"><span>LONG / SHORT</span><span class="kpiIcon">⇄</span></div><div class="kpiValue"><span class="up">{{ counts.get('long',0) }}</span> / <span class="down">{{ counts.get('short',0) }}</span></div><div class="kpiHint">سیگنال فعال · نه فقط A+</div></div>
          <div class="kpi"><div class="kpiHead"><span>FEAR & GREED</span><span class="kpiIcon">◉</span></div><div class="kpiValue">{{ macro.fear_greed_val|default('—') }}</div><div class="kpiHint">{{ macro.fear_greed_text|default('—') }}</div></div>
          <div class="kpi"><div class="kpiHead"><span>BTC DOMINANCE</span><span class="kpiIcon">₿</span></div><div class="kpiValue">{{ macro.dominance_btc|default('—') }}</div><div class="kpiHint">{{ market_data|length }} نماد تحت پایش</div></div>
        </div>

        <div class="commandGrid">
          <section class="panel">
            <div class="panelHead"><div><div class="panelTitle">◈ مرکز فرصت‌ها · TITAN V28.4 SIGNAL-FIRST</div><div class="panelSub">سیگنال‌های LONG/SHORT اول لیست · درجه + Trust روی کارت · برای جزئیات کلیک کنید</div></div><span class="panelAction" id="pulse-time">LIVE</span></div>
            <div class="signalSummary"><div class="signalBox long"><b>▲ LONG</b><div class="signalNum">{{ counts.get('long',0) }}</div><div class="signalMeta">فعال · همه درجات</div></div><div class="signalBox wait"><b>◆ WAIT</b><div class="signalNum">{{ counts.get('wait',0) }}</div><div class="signalMeta">صبر / EARLY / WATCH</div></div><div class="signalBox short"><b>▼ SHORT</b><div class="signalNum">{{ counts.get('short',0) }}</div><div class="signalMeta">فعال · همه درجات</div></div></div>
            {% set top3 = board.get('top3') or board.get('actionable') or [] %}
            {% if top3 %}
            <div class="topPicksBar">
              <div class="topPicksLabel">★ برترین سیگنال‌ها</div>
              <div class="topPicksRow">
              {% for t in top3[:3] %}
                {% set td = (t.get('decision') or 'WAIT')|upper %}
                <button class="topPickCard {{ 'long' if td=='LONG' else 'short' if td=='SHORT' else 'wait' }}" data-jump="{{ t.get('symbol','') }}" onclick="jumpToCoin('{{ (t.get('symbol') or '').replace('/','') }}','{{ t.get('symbol','') }}')">
                  <span class="tpIcon">{{ t.get('icon') or '◆' }}</span>
                  <span class="tpBody">
                    <b>{{ t.get('base') or t.get('symbol') }}</b>
                    <small>{{ td }} · {{ t.get('grade') or '—' }} · Q{{ t.get('quality') or '—' }} · RR{{ t.get('rr1') or '—' }}</small>
                  </span>
                </button>
              {% endfor %}
              </div>
            </div>
            {% endif %}
            <div class="assetHeader"><div class="panelTitle">ارزهای تحت پایش <span style="color:#5e7890;font-size:9px">{{ market_data|length }} نماد · A+/A={{ counts.get('actionable',0) }} · فعال={{ counts.get('active', counts.get('long',0)+counts.get('short',0)) }}</span></div><div class="assetTools"><button class="active" onclick="setAssetFilter('ALL',this)">همه</button><button onclick="setAssetFilter('LONG',this)">LONG</button><button onclick="setAssetFilter('WAIT',this)">WAIT</button><button onclick="setAssetFilter('SHORT',this)">SHORT</button></div></div>
            <div class="assetGrid" id="assetGrid">
              {% for item in market_data %}
              {% set dec=item.get('decision_tag','WAIT')|upper %}{% set cls='long' if dec=='LONG' else 'short' if dec=='SHORT' else 'wait' %}{% set sc=(item.get('score') or 0)|float %}{% set gr=item.get('grade') or (item.get('signal_grade') or {}).get('grade') or '—' %}
              <button class="assetCard coinHue{{ loop.index0 % 12 }} {{ cls }}" data-jump="{{ item.tv_symbol }}" data-symbol="{{ item.symbol }}" data-decision="{{ dec }}" data-score="{{ sc }}" data-name="{{ item.coin_name }} {{ item.base_symbol }}" onclick="jumpToCoin('{{ item.tv_symbol }}','{{ item.symbol }}')">
                <div class="assetTop"><span class="assetIdentity"><span class="assetIcon">{{ item.coin_icon }}</span><span class="assetName"><b>{{ item.base_symbol }} <span style="font-size:9px;opacity:.85;color:{% if gr in ['A+','A'] %}#4ade80{% elif gr=='B' %}#38bdf8{% else %}#94a3b8{% endif %}">{{ gr }}</span></b><small>{{ item.coin_name }}{% if item.get('opportunity_score') %} · Opp {{ item.opportunity_score|int }}{% endif %}</small></span></span><span class="decisionPill {{ cls }}">{{ '▲ LONG' if dec=='LONG' else '▼ SHORT' if dec=='SHORT' else '◆ WAIT' }}</span></div>
                <div class="assetPrice"><b>{{ item.price }}</b><span class="{{ cls }}">{{ item.bias|default('خنثی') }}</span></div>
                <div class="scoreLine"><div class="scoreRing" style="--score:{{ sc }};--ring:{{ '#23e6a8' if dec=='LONG' else '#ff4d73' if dec=='SHORT' else '#ffd34e' }}"><span>{{ item.score }}</span></div><div style="flex:1"><div style="font-size:7px;color:#607990;display:flex;justify-content:space-between"><span>Signal Quality</span><b style="color:#b9cde0">{{ item.signal_quality|default('—') }}</b></div><div class="scoreBar"><i style="width:{{ sc }}%"></i></div></div></div>
                <div class="assetTF"><span class="tfMini">15m<b>{{ item.tfs['15m'] }}</b></span><span class="tfMini">1h<b>{{ item.tfs['1h'] }}</b></span><span class="tfMini">4h<b>{{ item.tfs['4h'] }}</b></span><span class="tfMini">1D<b>{{ item.tfs['1d'] }}</b></span></div>
                <div class="assetBottom"><span>Prob {{ item.success_probability|default('—') }}%</span><span class="assetOpen">مشاهده پروفایل ⟵</span></div>
              </button>
              {% endfor %}
            </div>
          </section>

          <aside class="sidePanels">
            <section class="panel geminiCard"><div class="panelHead"><div><div class="panelTitle">✦ Gemini Intelligence</div><div class="panelSub">تحلیل کلان AI</div></div><span id="geminiStatus" class="miniChip">{{ gemini_status.label }}</span></div><div class="aiBadge"><strong>Gemini</strong><span id="geminiRefreshState">{{ gemini_status.updated_at }}</span></div><div id="geminiAnalysis" class="aiText">{{ gemini_summary if gemini_summary else 'تحلیل Gemini در حال آماده‌سازی است…' }}</div><div class="miniGauge"><i style="width:{{ 100 if gemini_status.ready else 20 }}%"></i></div><button class="glassBtn" style="width:100%;margin-top:8px;font-size:9px" onclick="refreshGemini()">↻ دریافت تحلیل Gemini</button></section>
            <section class="panel"><div class="panelHead"><div class="panelTitle">◉ وضعیت سیستم</div><span class="dot"></span></div><div class="healthList"><div class="healthRow"><span>دریافت داده بازار</span><b class="okDot">● OK</b></div><div class="healthRow"><span>تحلیل تکنیکال</span><b class="okDot">● OK</b></div><div class="healthRow"><span>AI Fusion</span><b class="okDot">● OK</b></div><div class="healthRow"><span>پیش‌بینی کندل</span><b class="okDot">● OK</b></div><div class="healthRow"><span>SQLite / Memory</span><b class="okDot">● OK</b></div></div></section>
            <section class="panel"><div class="panelHead"><div class="panelTitle">◌ شاخص‌های بازار</div></div><div class="marketMini"><div class="macroBox"><small>Fear & Greed</small><b class="neutral">{{ macro.fear_greed_val|default('—') }}</b></div><div class="macroBox"><small>BTC Dom.</small><b>{{ macro.dominance_btc|default('—') }}</b></div><div class="macroBox"><small>Actionable</small><b class="up">{{ counts.get('actionable',0) }}</b></div><div class="macroBox"><small>Best Quality</small><b id="pulse-leader">--</b></div></div></section>
            <section class="panel"><div class="panelHead"><div class="panelTitle">◷ رویدادها / زمینه بازار</div></div><div class="eventList"><div class="eventItem"><b>Macro Context</b><small>داده‌های کلان و ریسک بازار در Edge Suite</small></div><div class="eventItem"><b>AI Consensus</b><small>اجماع مدل‌ها در بخش هوش مصنوعی</small></div><div class="eventItem"><b>Opportunity Engine</b><small>READY / EARLY / WATCH در تب فرصت‌ها</small></div></div></section>
          </aside>
        </div>

        <div class="bottomGrid">
          <section class="panel"><div class="panelHead"><div><div class="panelTitle">◌ عملکرد تاریخی · خلاصه</div><div class="panelSub">جزئیات کامل در تب عملکرد</div></div><button class="panelAction" onclick="switchMainTab('tab-perf',null)">باز کردن عملکرد</button></div><div class="performanceStrip"><div class="perfStat"><small>WIN RATE</small><b class="up">{{ audit.win_rate|default(0) }}%</b></div><div class="perfStat"><small>W / L</small><b>{{ audit.wins|default(0) }} / {{ audit.losses|default(0) }}</b></div><div class="perfStat"><small>ACCURACY TIER</small><b>{{ audit.get('tier','—') }}</b></div><div class="perfStat"><small>LEADER</small><b id="pulse-leader">--</b></div></div></section>
          <section class="panel"><div class="panelHead"><div class="panelTitle">⏱ وضعیت تایم‌فریم‌ها</div><button class="panelAction" onclick="openTFWindow()">عقربه کامل</button></div><div class="gaugeDeck"><div class="tfGauge"><div class="needle"></div><b>15m</b><small>کوتاه‌مدت</small></div><div class="tfGauge"><div class="needle" style="--rot:18deg"></div><b>1h</b><small>مرجع</small></div><div class="tfGauge"><div class="needle" style="--rot:34deg"></div><b>4h</b><small>روند</small></div><div class="tfGauge"><div class="needle" style="--rot:48deg"></div><b>1D</b><small>ساختار</small></div></div></section>
        </div>
      </section>

      <section class="tabPanel" id="tab-edge">
        <div class="panel"><div class="panelHead"><div><div class="panelTitle">🧠 TITAN PROFESSIONAL EDGE SUITE</div><div class="panelSub">لایه‌های تصمیم، ریسک، اجماع AI و فرصت</div></div><span id="edge-status" class="miniChip">ACTIVE</span></div><div class="metricCards"><div class="metricBox"><small>Confluence</small><b id="edge-conf">--</b></div><div class="metricBox"><small>Meta Label</small><b id="edge-meta">--</b></div><div class="metricBox"><small>AI Consensus</small><b id="edge-ai">--</b></div><div class="metricBox"><small>Risk State</small><b id="edge-risk">--</b></div></div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px"><button class="glassBtn" onclick="loadEdgeTerminal()">🛰 Decision Terminal</button><button class="glassBtn" onclick="runProLab()">🧪 12-Layer Pro Lab</button><span id="edge-msg" style="align-self:center;font-size:8px;color:#6f879e"></span></div><pre id="edge-terminal" class="preBox">داده آماده است</pre></div>
        <div class="sectionGrid" style="margin-top:9px"><div class="panel"><div class="panelTitle">⚖️ تعادل Signal / WAIT</div><p style="font-size:9px;line-height:1.9;color:#8fa5b9">سیستم فرصت‌های نزدیک را از تصمیم نهایی جدا نگه می‌دارد تا WAIT به‌صورت بی‌دلیل غالب نشود و در عین حال LONG/SHORT بدون شواهد کافی صادر نشود.</p></div><div class="panel"><div class="panelTitle">🧩 طبقات تصمیم</div><div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:8px"><span class="signalBadge long">READY LONG</span><span class="signalBadge wait">EARLY / WATCH</span><span class="signalBadge short">READY SHORT</span></div></div></div>
      </section>

      <section class="tabPanel" id="tab-ai">
        <div class="panel geminiCard"><div class="panelHead"><div><div class="panelTitle">🤖 Gemini Global Intelligence</div><div class="panelSub">تحلیل Gemini باید در همین‌جا قابل مشاهده باشد</div></div><span id="geminiStatus">{{ gemini_status.label }}</span></div><div id="geminiAnalysis" style="font-size:10px;line-height:2;color:#c4d5e7;max-height:300px;overflow:auto">{{ gemini_summary if gemini_summary else 'تحلیل Gemini هنوز آماده نیست.' }}</div><div style="display:flex;gap:6px;margin-top:8px"><button class="glassBtn" onclick="refreshGemini()">↻ تحلیل جدید</button><span id="geminiRefreshState" class="miniChip"></span></div></div>
        <div class="panel" style="margin-top:9px"><div class="panelHead"><div><div class="panelTitle">🗳 هیئت رأی مدل‌ها</div><div class="panelSub">Gemini · Grok · Claude · DeepSeek · ChatGPT در صورت موجود بودن</div></div><span id="aiVoteSummary">در حال آماده‌سازی…</span></div><div id="modelScoreChips" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px"></div><div class="metricCards" style="margin-bottom:8px"><div class="metricBox"><small>LONG</small><b id="voteLong" class="up">--</b></div><div class="metricBox"><small>SHORT</small><b id="voteShort" class="down">--</b></div><div class="metricBox"><small>WAIT</small><b id="voteWait" class="neutral">--</b></div><div class="metricBox"><small>SYMBOLS</small><b id="voteCount">--</b></div></div><div id="providerTally" style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px"></div><div class="tableWrap"><table class="dataTable"><thead><tr><th>نماد</th><th>TITAN</th><th>AI</th><th>توافق</th><th>Gemini</th><th>Grok</th><th>Claude</th><th>DeepSeek</th></tr></thead><tbody id="aiVoteBody"><tr><td colspan="8">برای بارگذاری رأی مدل‌ها چند ثانیه صبر کنید.</td></tr></tbody></table></div></div>
      </section>

      <section class="tabPanel" id="tab-perf">
        <div class="panel"><div class="panelHead"><div><div class="panelTitle">📊 Performance Intelligence</div><div class="panelSub">Win Rate · Expectancy · Profit Factor · Drawdown · OOS · تایم‌فریم</div></div><button class="glassBtn" onclick="loadVisualPerformance(true)">↻ بروزرسانی</button></div><div class="perfGrid"><div class="perfCard"><small>WIN RATE</small><div class="ring" id="wrRing" style="--v:0"><span id="visWR">--%</span></div><div style="font-size:8px;color:#667f96" id="visWL">-- W / -- L</div></div><div class="perfCard"><small>PERFORMANCE SCORE</small><div class="perfBig" id="visScore">--/100</div><div class="tfBar"><i id="visScoreBar" style="width:0%"></i></div></div><div class="perfCard"><small>EXPECTANCY</small><div class="perfBig" id="visExp">--%</div><div style="font-size:8px;color:#667f96" id="visPF">PF: --</div></div><div class="perfCard"><small>MAX DRAWDOWN</small><div class="perfBig" id="visDD">--%</div><div style="font-size:8px;color:#667f96" id="visOOS">OOS: --</div></div></div><div class="perfCharts"><div class="chartPanel"><h3>📈 Equity / Return Curve</h3><canvas id="equityVisual" class="perfCanvas"></canvas></div><div class="chartPanel"><h3>🎯 Win / Loss / Neutral</h3><canvas id="wlVisual" class="perfCanvas"></canvas></div></div><div class="chartPanel" style="margin-top:7px"><h3>⏱ امتیاز تمام تایم‌فریم‌ها</h3><div id="tfVisual" class="tfVisual"></div></div><div id="visNote" class="perfNote">در حال دریافت داده عملکرد…</div><button class="glassBtn" style="margin-top:7px" onclick="openTFWindow()">نمایش عقربه‌های تایم‌فریم</button></div>
        <div class="panel" style="margin-top:9px"><div class="panelHead"><div class="panelTitle">🎯 Balanced Opportunity Engine</div><button class="glassBtn" onclick="loadV22Opportunities()">↻ بررسی فرصت‌ها</button></div><div class="metricCards"><div class="metricBox"><small>READY</small><b id="v22Ready" class="up">--</b></div><div class="metricBox"><small>EARLY</small><b id="v22Early">--</b></div><div class="metricBox"><small>WATCH</small><b id="v22Watch" class="neutral">--</b></div><div class="metricBox"><small>NO EDGE</small><b id="v22NoEdge">--</b></div></div><div class="tableWrap" style="margin-top:8px"><table class="dataTable"><thead><tr><th>نماد</th><th>تصمیم</th><th>فرصت</th><th>امتیاز</th><th>AI</th><th>یادگیری</th><th>دلیل</th></tr></thead><tbody id="v22OppBody"><tr><td colspan="7">در حال آماده‌سازی…</td></tr></tbody></table></div></div>
      </section>

      <section class="tabPanel" id="tab-charts">
        <div class="panel"><div class="panelHead"><div><div class="panelTitle">📈 Market Chart Gallery</div><div class="panelSub">نمودارهای واقعی برای همه نمادها · بدون حذف داده</div></div><button class="glassBtn" onclick="loadAllCoinCharts(true)">↻ بروزرسانی</button></div><div class="allGrid" id="allChartsGrid">در حال آماده‌سازی…</div></div>
      </section>

      <section class="tabPanel" id="tab-control">
        <div class="panel"><div class="panelHead"><div><div class="panelTitle">🛡 Advanced Control Center</div><div class="panelSub">بک‌تست، Walk-Forward، سلامت داده و حافظه</div></div><button class="glassBtn" onclick="refreshAdvanced()">↻ Refresh</button></div><div class="metricCards"><div class="metricBox"><small>LIVE</small><b id="adv-live">--</b></div><div class="metricBox"><small>HISTORICAL</small><b id="adv-hist">--</b></div><div class="metricBox"><small>PAPER</small><b id="adv-paper">--</b></div><div class="metricBox"><small>QUALITY</small><b id="adv-quality">--</b></div></div><div style="display:flex;gap:6px;margin-top:8px"><button class="glassBtn" onclick="runBacktest()">🧪 بک‌تست</button><button class="glassBtn" onclick="runWalkForward()">🔬 Walk-Forward</button></div><pre id="adv-result" class="preBox" style="margin-top:8px">آماده</pre></div><div class="panel"><div class="panelHead"><div><div class="panelTitle">🧠 Continuous Performance & Learning V32</div><div class="panelSub">تاریخچه واقعی بر اساس نتیجه آینده بازار، تفکیک ارز و تایم‌فریم</div></div><button class="glassBtn" onclick="refreshPerformanceLearning()">↻ بروزرسانی</button></div><div class="perfLearningGrid"><div class="perfLearnCard"><small>نمونه ثبت‌شده</small><b id="learnTotal">0</b></div><div class="perfLearnCard"><small>Win Rate جهت‌دار</small><b id="learnWR">—</b></div><div class="perfLearnCard"><small>در انتظار ارزیابی</small><b id="learnPending">0</b></div><div class="perfLearnCard"><small>WAIT از دست‌رفته</small><b id="learnWaitMiss">0</b></div></div><div style="overflow:auto;max-height:310px"><table class="perfLearnTable"><thead><tr><th>ارز/TF</th><th>تصمیم</th><th>نمونه</th><th>WR</th><th>Reliability</th><th>وضعیت</th></tr></thead><tbody id="learnTable"><tr><td colspan="6">در حال بارگذاری…</td></tr></tbody></table></div></div>
      </section>
    </main>
  </div>
</div>

<div class="legacyDashboard">

<div class="header"><div><h1>⚡ TITAN ENTERPRISE V10 PRO-GRADE</h1><div class="sub">Neural Synapse · Grade A+/A/B/C · Entry Ladder · DQ68 · AI Fusion · Ranked Signals</div></div><div style="display:flex;gap:8px"><a class="btn" href="/rescan">🔄 اسکن مجدد</a><button class="btn gold" onclick="openM()">⚙️ تنظیمات</button></div></div>

<div class="tabBar" id="mainTabs">
<button type="button" class="tabBtn active" data-tab="tab-market" onclick="switchTab('tab-market',this)">◈ بازار و سیگنال‌ها</button>
<button type="button" class="tabBtn" data-tab="tab-edge" onclick="switchTab('tab-edge',this)">🧠 Edge Suite</button>
<button type="button" class="tabBtn" data-tab="tab-ai" onclick="switchTab('tab-ai',this)">🤖 هوش مصنوعی</button>
<button type="button" class="tabBtn" data-tab="tab-perf" onclick="switchTab('tab-perf',this)">📊 عملکرد و دقت</button>
<button type="button" class="tabBtn" data-tab="tab-charts" onclick="switchTab('tab-charts',this)">📈 نمودارها</button>
<button type="button" class="tabBtn" data-tab="tab-control" onclick="switchTab('tab-control',this)">🛡️ کنترل پیشرفته</button>
</div>

<div class="tabPanel active" id="tab-market">
<div class="titanNavShell" id="coinNav">
  <div class="titanNavHead">
    <div class="navBrand">
      <span class="navBrandIcon">◈</span>
      <div><span class="titanNavTitle">ناوبری سریع دارایی‌ها</span><span class="titanNavSub">هر کارت = یک پنجره مستقل؛ اطلاعات کامل فقط داخل همان ارز</span></div>
    </div>
    <div class="titanNavFilters">
      <button type="button" class="glassFilter active" data-navfilter="all">◈ همه</button>
      <button type="button" class="glassFilter" data-navfilter="LONG">▲ LONG</button>
      <button type="button" class="glassFilter" data-navfilter="WAIT">◆ WAIT</button>
      <button type="button" class="glassFilter" data-navfilter="SHORT">▼ SHORT</button>
    </div>
  </div>
  <div class="navLegend">
    <span class="legendItem long">● LONG</span><span class="legendItem wait">● WAIT</span><span class="legendItem short">● SHORT</span>
    <span class="legendHint">← برای دیدن سایر ارزها افقی حرکت دهید →</span>
  </div>
  <div class="titanCoinRail" data-navgrid="ALL">
    {% for item in market_data %}
    {% set navtag = item.get('decision_tag') or item.get('edge', {}).get('decision_tag') or 'WAIT' %}
    {% set navcls = 'long' if navtag == 'LONG' else 'short' if navtag == 'SHORT' else 'wait' %}
    <button type="button" class="coinMiniCard coinHue{{ loop.index0 % 12 }} {{ navcls }}" data-decision="{{ navtag }}" data-jump="{{ item.tv_symbol }}" data-tv="{{ item.tv_symbol }}" data-symbol="{{ item.symbol }}" title="باز کردن پنجره تخصصی {{ item.coin_name }}">
      <span class="coinMiniGlow"></span>
      <span class="coinMiniTop">
        <span class="coinMiniIdentity">
          <span class="coinMiniIcon" aria-hidden="true">{{ item.coin_icon }}</span>
          <span class="coinMiniNameBlock">
            <b class="coinMiniSymbol">{{ item.base_symbol }}</b>
            <small class="coinMiniFullName">{{ item.coin_name }}</small>
            <em class="coinMiniPair">USDT · BINANCE</em>
          </span>
        </span>
        <span class="coinMiniDecision">{{ '▲ LONG' if navtag == 'LONG' else '▼ SHORT' if navtag == 'SHORT' else '◆ WAIT' }}</span>
      </span>
      <span class="coinMiniPriceLine">
        <span class="coinMiniPriceLabel">💰 قیمت زنده</span>
        <strong class="coinMiniPriceValue" data-live-price="{{ item.symbol }}">{{ item.price }}</strong>
        <span class="coinMiniPriceUnit">USDT</span>
        <span class="coinMiniScoreBadge">🎯 {{ item.score|default(0) }}/100</span>
        <i aria-hidden="true"><em style="width:{{ item.score|default(0) }}%"></em></i>
      </span>
      <span class="coinMiniTF">
        <span>15m<b>{{ item.tfs['15m'] }}</b></span><span>1h<b>{{ item.tfs['1h'] }}</b></span><span>4h<b>{{ item.tfs['4h'] }}</b></span><span>1D<b>{{ item.tfs['1d'] }}</b></span>
      </span>
      <span class="coinMiniOpen">⌁ جزئیات کامل</span>
    </button>
    {% endfor %}
  </div>
</div>
<div class="section hud"><h2>◈ MARKET COMMAND CENTER · V10</h2><div class="hudgrid"><div class="hudbox"><div>رژیم</div><div class="v" id="pulse-regime">--</div></div><div class="hudbox"><div>میانگین Score</div><div class="v" id="pulse-score">--</div></div><div class="hudbox"><div>Breadth</div><div class="v" id="pulse-breadth" style="font-size:15px">--</div></div><div class="hudbox"><div>بهترین کیفیت</div><div class="v" id="pulse-leader" style="font-size:15px">--</div></div></div><div id="pulse-time" style="text-align:left;color:#64748b;font-size:11px;margin-top:8px">--</div>
{% set board = (macro.get('signal_board') if macro else None) or {} %}
{% set counts = board.get('counts') or {} %}
{% set gsum = (macro.get('grade_summary') if macro else None) or {} %}
<div class="hudgrid" style="margin-top:12px">
<div class="hudbox"><div>قابل‌اقدام A+/A</div><div class="v" style="color:#4ade80">{{ counts.get('actionable', 0) }}</div></div>
<div class="hudbox"><div>واچ‌لیست B</div><div class="v" style="color:#38bdf8">{{ counts.get('watch', 0) }}</div></div>
<div class="hudbox"><div>LONG فعال</div><div class="v" style="color:#4ade80">{{ counts.get('long', 0) }}</div></div>
<div class="hudbox"><div>SHORT فعال</div><div class="v" style="color:#f43f5e">{{ counts.get('short', 0) }}</div></div>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;font-size:12px">
<span class="gradeBadge gradeAplus">A+ {{ gsum.get('A+', 0) }}</span>
<span class="gradeBadge gradeA">A {{ gsum.get('A', 0) }}</span>
<span class="gradeBadge gradeB">B {{ gsum.get('B', 0) }}</span>
<span class="gradeBadge gradeC">C {{ gsum.get('C', 0) }}</span>
<span class="gradeBadge gradeD">D {{ gsum.get('D', 0) }}</span>
<span class="gradeBadge gradeF">F {{ gsum.get('F', 0) }}</span>
</div>

</div>
<div class="grid">
{% for item in market_data %}<div class="card cardAnchor" id="card-{{ item.tv_symbol }}" data-symbol="{{ item.symbol }}" data-tv="{{ item.tv_symbol }}" data-name="{{ item.coin_name }}" data-icon="{{ item.coin_icon }}" data-base="{{ item.base_symbol }}" data-price="{{ item.price }}" data-entry="{{ item.entry_valid }}" data-sl="{{ item.stop_loss }}" data-tp1="{{ item.tp1 }}" data-tp2="{{ item.tp2 }}" data-bias="{{ item.bias }}" data-score="{{ item.score }}" data-align="{{ item.alignment }}" data-quality="{{ item.signal_quality }}" data-success="{{ item.success_probability|default(0) }}" data-decision="{{ item.get('decision_tag') or item.get('edge', {}).get('decision_tag') or 'WAIT' }}" data-tag="{{ item.signal_tag }}" data-color="{{ item.score_color }}" data-rsi="{{ item.rsi }}" data-rr1="{{ item.rr_tp1 }}" data-rr2="{{ item.rr_tp2 }}" data-oi="{{ item.coinglass_oi }}" data-fund="{{ item.coinglass_funding }}" data-buy="{% if item.get('buy_sell') %}{{ item.buy_sell.get('buy_pct', 50) }}{% else %}{{ item.get('taker_buy_pct', 50) }}{% endif %}" data-sell="{% if item.get('buy_sell') %}{{ item.buy_sell.get('sell_pct', 50) }}{% else %}{{ item.get('taker_sell_pct', 50) }}{% endif %}" data-tf15="{{ item.tfs['15m'] }}" data-tf1h="{{ item.tfs['1h'] }}" data-tf4h="{{ item.tfs['4h'] }}" data-tf1d="{{ item.tfs['1d'] }}"><div class="ch"><div class="coin"><div class="icon">{{ item.coin_icon }}</div><div><div class="name">{{ item.coin_name }}</div><div class="ticker">{{ item.base_symbol }} / USDT · BINANCE</div></div></div><div class="price" data-price>{{ item.price }} <small>USDT</small></div></div>
<div class="scoreRow" style="align-items:center">
<div style="display:flex;align-items:center;gap:10px">
<div class="ringGauge" style="--gv:{{ item.score }};--gcol:{{ item.score_color }};width:52px;height:52px;margin:0"><span style="color:{{ item.score_color }};font-size:12px">{{ item.score }}</span></div>
<div>
<span style="color:{{ item.score_color }};font-weight:900">{{ item.score_icon }} {{ item.score }}/100</span><br>
<small style="color:#94a3b8">همسویی {{ item.alignment }} · کیفیت {{ item.signal_quality }}</small>
</div>
</div>
{% set g = item.get('grade') or (item.get('signal_grade') or {}).get('grade') or '—' %}
<span class="gradeBadge {% if g=='A+' %}gradeAplus{% elif g=='A' %}gradeA{% elif g=='B' %}gradeB{% elif g=='C' %}gradeC{% elif g=='D' %}gradeD{% else %}gradeF{% endif %}">{{ g }}</span>
<span class="miniChip">{{ item.signal_tag }}</span>
<span class="miniChip">Trust {{ item.get('trust_index', (item.get('signal_grade') or {}).get('trust_index', '—')) }}</span>

</div>
<div class="bar"><i style="width:{{ item.score_bar }}%;background:{{ item.score_color }}"></i></div>
<div class="scoreOrbit" style="margin-top:6px">
<div class="orbitItem"><span class="perfEmoji">🧭</span><small>همسویی</small><b>{{ item.alignment }}</b></div>
<div class="orbitItem"><span class="perfEmoji">✨</span><small>کیفیت</small><b>{{ item.signal_quality }}</b></div>
<div class="orbitItem"><span class="perfEmoji">📐</span><small>RR1</small><b style="color:var(--green)">1:{{ item.rr_tp1 }}</b></div>
<div class="orbitItem"><span class="perfEmoji">🎯</span><small>RR2</small><b style="color:var(--green)">1:{{ item.rr_tp2 }}</b></div>
</div>
<div class="tf"><span>15m <b>{{ item.tfs['15m'] }}</b></span><span>1h <b>{{ item.tfs['1h'] }}</b></span><span>4h <b>{{ item.tfs['4h'] }}</b></span><span>1d <b>{{ item.tfs['1d'] }}</b></span></div>
{% set dtag = item.get('decision_tag') or item.get('edge', {}).get('decision_tag') or 'WAIT' %}
{% set fus = item.get('fusion') or item.get('titan_analysis', {}).get('fusion') or item.get('edge', {}).get('fusion') or {} %}
{% set sp = item.get('success_probability') or fus.get('success_probability') or 0 %}
<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px">
<span class="signalBadge {% if dtag == 'LONG' %}long{% elif dtag == 'SHORT' %}short{% else %}wait{% endif %}">
{% if dtag == 'LONG' %}▲ خرید{% elif dtag == 'SHORT' %}▼ فروش{% else %}◆ انتظار{% endif %}
· {{ item.bias }} · کیفیت {{ item.signal_quality }}
</span>
<span class="miniChip">تگ: {{ item.signal_tag }}</span>
<span class="miniChip" style="border-color:rgba(74,222,128,.4)">🎲 شانس {{ sp }}%</span>
{% if fus.get('ai_majority') %}
<span class="miniChip">🤖 AI: {{ fus.get('ai_majority') }}</span>
{% endif %}
</div>
{% if fus.get('explanation') %}
<div style="font-size:11px;color:#94a3b8;margin-top:6px;line-height:1.7">
{% for line in fus.get('explanation')[:3] %}• {{ line }}<br>{% endfor %}
</div>
{% endif %}
<div class="levels"><div class="level">🎯 Entry: <b>{{ item.entry_valid }}</b></div><div class="level">🛑 SL: <b style="color:var(--pink)">{{ item.stop_loss }}</b></div><div class="level">🟢 TP1: <b>{{ item.tp1 }}</b></div><div class="level">🚀 TP2: <b>{{ item.tp2 }}</b></div></div>
<div class="dualLevels">
<div class="dualBox longBox"><b style="color:var(--green)">سناریو Long</b><br>
ورود: {{ item.entry_valid }} · SL: {{ item.stop_loss if dtag != 'SHORT' else '—' }}<br>
TP1: {{ item.tp1 if dtag != 'SHORT' else '—' }} · TP2: {{ item.tp2 if dtag != 'SHORT' else '—' }}<br>
RR: 1:{{ item.rr_tp1 }} / 1:{{ item.rr_tp2 }}
</div>
<div class="dualBox shortBox"><b style="color:var(--pink)">سناریو Short</b><br>
{% if dtag == 'SHORT' %}
ورود: {{ item.entry_valid }} · SL: {{ item.stop_loss }}<br>
TP1: {{ item.tp1 }} · TP2: {{ item.tp2 }}<br>
RR: 1:{{ item.rr_tp1 }} / 1:{{ item.rr_tp2 }}
{% else %}
در صورت نزولی شدن: SL بالای مقاومت · TP زیر حمایت<br>
فقط با تأیید ساختار نزولی فعال می‌شود
{% endif %}
</div>
</div>
{% set tech = item.get('technical') or {} %}
{% set fib = tech.get('fibonacci') or {} %}
{% set bb = tech.get('bollinger') or {} %}
{% set tfscores = item.get('tf_scores') or {} %}
{% set bs = item.get('buy_sell') or {} %}
{% set whale = item.get('whale') or {} %}
{% set sent = item.get('sentiment') or {} %}
<div class="panelTech">
<b class="title">📐 فیبوناچی · حمایت و مقاومت · بولینگر</b>
<div style="font-size:11px;color:#94a3b8;line-height:1.7;margin-bottom:8px">
این پنل سطوح کلیدی قیمت را نشان می‌دهد. <b style="color:#cbd5e1">حمایت</b> ناحیه احتمالی توقف ریزش، <b style="color:#cbd5e1">مقاومت</b> ناحیه احتمالی توقف رشد است.
سطوح <b style="color:#cbd5e1">فیبوناچی</b> نقاط بازگشت احتمالی در اصلاح قیمت هستند (۰.۶۱۸ طلایی‌ترین سطح).
نوارهای <b style="color:#cbd5e1">بولینگر</b> محدوده نوسان را نشان می‌دهند؛ لمس باند بالا/پایین می‌تواند نشانه اشباع خرید/فروش باشد.
</div>
<div style="font-size:12px;line-height:1.9">
<div>حمایت: <b style="color:var(--green)">{{ tech.get('support','N/A') }}</b> · مقاومت: <b style="color:var(--pink)">{{ tech.get('resistance','N/A') }}</b></div>
<div>فیبو ۰.۲۳۶: <b>{{ fib.get('0.236','N/A') }}</b> · ۰.۳۸۲: <b>{{ fib.get('0.382','N/A') }}</b> · ۰.۵: <b>{{ fib.get('0.500','N/A') }}</b></div>
<div>فیبو ۰.۶۱۸: <b style="color:var(--gold)">{{ fib.get('0.618','N/A') }}</b> · ۰.۷۸۶: <b>{{ fib.get('0.786','N/A') }}</b></div>
<div>بولینگر بالا: <b>{{ bb.get('upper','N/A') }}</b> · میانه: <b>{{ bb.get('middle','N/A') }}</b> · پایین: <b>{{ bb.get('lower','N/A') }}</b></div>
{% set piv = item.get('pivots') or {} %}
{% if piv %}
<div style="margin-top:4px">پیوت: <b>{{ piv.get('pp','N/A') }}</b> · R1 {{ piv.get('r1','N/A') }} · S1 {{ piv.get('s1','N/A') }} · R2 {{ piv.get('r2','N/A') }} · S2 {{ piv.get('s2','N/A') }}</div>
{% endif %}
</div>
</div>
<div class="panelTech" style="border-color:rgba(56,189,248,.4)">
<b class="title" style="color:var(--cyan)">⏱ عقربه تایم‌فریم‌ها</b>
<div style="font-size:11px;color:#94a3b8;line-height:1.7;margin-bottom:8px">
امتیاز ۰ تا ۱۰۰ برای هر تایم‌فریم. <b style="color:var(--green)">بالای ۶۰</b> تمایل صعودی، <b style="color:var(--pink)">زیر ۴۰</b> تمایل نزولی، وسط خنثی.
همسویی چند تایم‌فریم (مثلاً ۱h و ۴h با هم) قدرت سیگنال را بیشتر می‌کند.
</div>
<div class="gaugeRow">
{% for tfname in ['15m','1h','4h','1d'] %}
{% set sc = tfscores.get(tfname, item.score) %}
<div class="gaugeBox"><small>{{ tfname }}</small><div class="gval" style="color:{% if sc|float >= 60 %}var(--green){% elif sc|float <= 40 %}var(--pink){% else %}var(--gold){% endif %}">{{ sc }}</div><div class="gaugeBar"><i style="width:{{ sc }}%"></i></div></div>
{% endfor %}
</div>
<button class="btn" style="margin-top:10px;width:100%" onclick="openTFWindow('{{ item.symbol }}')">نمایش جزئیات عقربه‌ها</button>
</div>
{% set macd = item.get('macd') or {} %}
{% set stoch = item.get('stoch_rsi') or {} %}
{% set sess = item.get('session') or {} %}
{% set obf = item.get('order_blocks_fvg') or {} %}
{% set bcorr = item.get('btc_correlation') or {} %}
{% set depth = item.get('depth') or {} %}
{% set cal = (item.get('fusion') or {}).get('probability_calibration') or {} %}
<div class="panelTech" style="border-color:rgba(251,191,36,.45)">
<b class="title" style="color:var(--gold)">📐 Order Block · FVG · همبستگی BTC · عمق بازار · کالیبراسیون</b>
<div style="font-size:11px;color:#94a3b8;line-height:1.75;margin-bottom:8px">
بلاک سفارش و FVG نواحی بالقوه تقاضا/عرضه هستند. فیلتر همبستگی BTC در نوسان بالا از سیگنال خلاف‌جهت بیت‌کوین روی آلت‌های هم‌بسته جلوگیری می‌کند.
عمق بازار فقط برای نمادهای نقدشونده (BTC/ETH/SOL/BNB/XRP) از WebSocket می‌آید. احتمال موفقیت با Platt+Isotonic روی paper trades کالیبره می‌شود.
</div>
<div class="miniGrid">
<div class="miniCard"><b style="color:#4ade80">نزدیک‌ترین Order Block</b><br>
{% if obf.get('nearest_ob') %}
{{ obf.nearest_ob.get('type') }} · {{ obf.nearest_ob.get('low') }}–{{ obf.nearest_ob.get('high') }}<br>
<span style="font-size:10px;color:#94a3b8">{{ (obf.nearest_ob.get('guide') or '')[:100] }}</span>
{% else %}یافت نشد{% endif %}
</div>
<div class="miniCard"><b style="color:#c084fc">نزدیک‌ترین FVG</b><br>
{% if obf.get('nearest_fvg') %}
{{ obf.nearest_fvg.get('type') }} · {{ obf.nearest_fvg.get('low') }}–{{ obf.nearest_fvg.get('high') }}<br>
<span style="font-size:10px;color:#94a3b8">{{ (obf.nearest_fvg.get('guide') or '')[:100] }}</span>
{% else %}یافت نشد{% endif %}
</div>
<div class="miniCard"><b style="color:#38bdf8">همبستگی با BTC</b><br>
corr: <b>{{ bcorr.get('corr', '—') }}</b> · {{ bcorr.get('corr_regime', bcorr.get('regime','—')) }}<br>
{% if bcorr.get('filter_applied') %}<span style="color:var(--pink)">فیلتر فعال: {{ bcorr.get('reason','') }}</span>{% else %}<span style="color:#94a3b8">{{ bcorr.get('reason','—') }}</span>{% endif %}
</div>
<div class="miniCard"><b style="color:#fbbf24">عمق بازار / احتمال</b><br>
{% if depth.get('available') %}
Bid {{ depth.get('bid') }} · Ask {{ depth.get('ask') }} · Spread {{ depth.get('spread_bps') }}bps<br>
Imbalance {{ depth.get('imbalance') }} · سن {{ depth.get('age_sec') }}s
{% else %}عمق فقط برای واچ‌لیست نقدشونده{% endif %}<br>
کالیبره: <b>{{ cal.get('calibrated', item.get('success_probability','—')) }}%</b>
<small>({{ cal.get('method','—') }} · n={{ cal.get('samples','—') }})</small>
</div>
</div>
</div>
<div class="panelTech" style="border-color:rgba(56,189,248,.4)">
<b class="title" style="color:var(--cyan)">⚙️ لایه فنی پیشرفته · MACD · StochRSI · جلسه</b>
<div style="font-size:11px;color:#94a3b8;line-height:1.7;margin-bottom:8px">
MACD و Stochastic RSI برای زمان‌بندی ورود؛ جلسه معاملاتی برای نقدینگی. نسبت لانگ/شورت ازدحام جمعیتی را نشان می‌دهد.
</div>
<div class="miniGrid">
<div class="miniCard"><b style="color:#38bdf8">MACD</b><br>
Hist: <b>{{ macd.get('hist', '—') }}</b> · Cross: <b>{{ macd.get('cross', '—') }}</b><br>
MACD: {{ macd.get('macd', '—') }} · Signal: {{ macd.get('signal', '—') }}
</div>
<div class="miniCard"><b style="color:#c084fc">Stoch RSI</b><br>
K: <b>{{ stoch.get('k', '—') }}</b> · D: <b>{{ stoch.get('d', '—') }}</b><br>
Zone: <b>{{ stoch.get('zone', '—') }}</b>
</div>
<div class="miniCard"><b style="color:#fbbf24">لانگ/شورت</b><br>
L/S: <b>{{ item.get('long_short_ratio', '—') }}</b><br>
Long% {{ item.get('long_ratio', '—') }} · Short% {{ item.get('short_ratio', '—') }}
</div>
<div class="miniCard"><b style="color:#4ade80">جلسه · Taker</b><br>
{{ sess.get('session', '—') }} (UTC {{ sess.get('hour_utc', '—') }})<br>
Taker Buy: <b>{{ item.get('taker_buy_pct', '—') }}%</b>
</div>
</div>
</div>
<div class="panelTech" style="border-color:rgba(74,222,128,.35)">
<b class="title" style="color:var(--green)">📊 فشار خرید / فروش · احساسات · نهنگ‌ها</b>
<div style="font-size:11px;color:#94a3b8;line-height:1.7;margin:4px 0 8px">
نوار خرید/فروش تقریبی از فشار حجم و موقعیت کندل است. <b style="color:#cbd5e1">احساسات</b> از RSI و Funding ساخته می‌شود.
<b style="color:#cbd5e1">نهنگ‌ها</b> از تغییر Open Interest و Funding خوانده می‌شوند: رشد OI با صعود = ورود پول، رشد OI با نزول = فشار فروش سنگین.
</div>
<div style="margin-top:6px;font-size:12px">خرید <b style="color:var(--green)">{{ bs.get('buy_pct',50) }}%</b> · فروش <b style="color:var(--pink)">{{ bs.get('sell_pct',50) }}%</b> · وضعیت: <b>{{ bs.get('bias','—') }}</b></div>
<div style="display:flex;gap:14px;align-items:center;justify-content:center;margin:10px 0;flex-wrap:wrap">
  <div style="text-align:center">
    <div class="ringGauge" style="--gv:{{ bs.get('buy_pct',50) }};--gcol:#4ade80;width:72px;height:72px;margin:0 auto"><span style="color:#4ade80;font-size:13px">{{ bs.get('buy_pct',50) }}%</span></div>
    <small style="color:#4ade80;font-weight:800">عقربه خرید</small>
  </div>
  <div style="text-align:center">
    <div class="ringGauge" style="--gv:{{ bs.get('sell_pct',50) }};--gcol:#f43f5e;width:72px;height:72px;margin:0 auto"><span style="color:#f43f5e;font-size:13px">{{ bs.get('sell_pct',50) }}%</span></div>
    <small style="color:#f43f5e;font-weight:800">عقربه فروش</small>
  </div>
  <div style="text-align:center;min-width:90px">
    <div style="font-size:22px;font-weight:900;color:{% if bs.get('buy_pct',50)|int >= 58 %}#4ade80{% elif bs.get('sell_pct',50)|int >= 58 %}#f43f5e{% else %}#fbbf24{% endif %}">
      {% if bs.get('buy_pct',50)|int >= 58 %}▲ خرید{% elif bs.get('sell_pct',50)|int >= 58 %}▼ فروش{% else %}◆ متعادل{% endif %}
    </div>
    <small style="color:#94a3b8">Taker {{ bs.get('taker_buy_pct', '—') }}% · ΔVol {{ bs.get('volume_delta_pct', '—') }}%</small>
  </div>
</div>
<div class="bsBar"><div class="buy" style="width:{{ bs.get('buy_pct',50) }}%"></div><div class="sell" style="width:{{ bs.get('sell_pct',50) }}%"></div></div>
<div class="miniGrid">
<div class="miniCard"><b style="color:var(--gold)">احساسات</b><div style="font-size:10px;color:#94a3b8;margin:2px 0 6px">خوانش کوتاه‌مدت هیجان بازار از RSI و فاندینگ</div>برچسب: <b>{{ sent.get('label','—') }}</b><br>RSI: {{ sent.get('rsi','—') }} · {{ sent.get('rsi_note','') }}<br>{{ sent.get('funding_note','') }}</div>
<div class="miniCard"><b style="color:#c084fc">رفتار نهنگ</b><div style="font-size:10px;color:#94a3b8;margin:2px 0 6px">تغییر موقعیت‌های بزرگ در فیوچرز (OI) و هزینه نگهداری</div><b>{{ whale.get('label','—') }}</b><br>OI: {{ whale.get('oi','N/A') }} · ΔOI: {{ whale.get('oi_delta',0) }}%<br>Funding: {{ whale.get('funding','N/A') }}</div>
</div>
</div>
<div class="deriv"><b style="color:var(--cyan)">📊 CoinGlass / مشتقات</b><div style="margin-top:4px">OI: <b>{{ item.coinglass_oi }}</b> · Funding: <b>{{ item.coinglass_funding }}</b></div><div class="metrics"><div class="mini"><small>نوسان</small><br><b>{{ item.volatility_pct }}%</b></div><div class="mini"><small>تا SL</small><br><b>{{ item.risk_distance_pct }}%</b></div><div class="mini"><small>RR1</small><br><b style="color:var(--green)">1:{{ item.rr_tp1 }}</b></div><div class="mini"><small>RR2</small><br><b style="color:var(--green)">1:{{ item.rr_tp2 }}</b></div></div><div style="font-size:11px;color:#94a3b8;margin-top:5px">وضعیت: <b style="color:var(--gold)">{{ item.signal_tag }}</b> · منبع: {{ item.derivatives_source }}</div></div>
<div class="ai"><div class="aiTitle">🧠 هوش مصنوعی متصل · هم‌جوشی تطبیقی</div>
{% set fus = item.get('titan_analysis', {}).get('fusion') or {} %}
{% if fus.get('explanation') %}
<div class="aiRow" style="border-color:rgba(56,189,248,.4);background:rgba(56,189,248,.08)">
<b style="color:#38bdf8">🔗 هم‌جوشی TITAN↔AI:</b>
{% for line in fus.get('explanation', [])[:4] %}{{ line }}{% if not loop.last %} · {% endif %}{% endfor %}
{% if fus.get('success_probability') %} · شانس موفقیت ≈ {{ fus.get('success_probability') }}%{% endif %}
{% set calx = fus.get('probability_calibration') or {} %}
{% if calx.get('honest_label') %}<div style="font-size:11px;color:#94a3b8;margin-top:4px">{{ calx.get('honest_label') }}</div>{% endif %}
{% set ladder = item.get('entry_ladder') or fus.get('entry_ladder') or {} %}
{% set dq = item.get('data_quality') or fus.get('data_quality') or {} %}
{% set gates = item.get('confidence_gates') or {} %}
<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">
  <span class="miniChip">نسخه {{ item.get('param_version', 'V9') }}</span>
  <span class="miniChip">DQ {{ dq.get('score', '—') }}{% if gates.get('dq_veto') %} · وتو{% endif %}</span>
  <span class="miniChip">Ladder {% if ladder.get('passed') %}✓{% else %}×{% endif %} · HTF {{ ladder.get('htf_score','—') }} / MTF {{ ladder.get('mtf_score','—') }}</span>
  {% set mv = item.get('meta_v8') or fus.get('meta_v8') or {} %}
  <span class="miniChip">Meta {{ mv.get('label', '—') }} · {{ mv.get('probability', '—') }}</span>
  {% set nv = item.get('neural_v9') or fus.get('neural_v9') or {} %}
  <span class="miniChip">Neural {{ nv.get('side', '—') }} · {{ nv.get('neural_score', '—') }} · conf {{ nv.get('confidence', '—') }}</span>
  {% set sg = item.get('signal_grade') or {} %}
  <span class="miniChip">درجه {{ sg.get('grade', item.get('grade','—')) }} · {{ sg.get('label_fa', item.get('grade_label','—')) }}</span>
  <span class="miniChip">{{ sg.get('action', item.get('grade_action','—')) }}</span>
  {% set fa = item.get('forecast_accuracy') or fus.get('forecast_accuracy') or {} %}
  <span class="miniChip">PathAcc {{ fa.get('dir_acc', '—') }} · n={{ fa.get('samples', 0) }}</span>
</div>
{% set checks = (item.get('grade_checklist') or (item.get('signal_grade') or {}).get('checklist') or []) %}
{% if checks %}
<div class="chkGrid">
{% for c in checks %}
<div class="chkItem {% if c.get('ok') %}chkOk{% else %}chkFail{% endif %}">{% if c.get('ok') %}✓{% else %}×{% endif %} {{ c.get('name','') }} <span style="opacity:.7">{{ c.get('detail','') }}</span></div>
{% endfor %}
</div>
{% endif %}
</div>
{% endif %}
<div class="aiRow"><b>TITAN:</b> {{ item.ai_opinions.internal }}</div><div class="aiRow" style="border-color:rgba(66,133,244,.55);background:linear-gradient(135deg,rgba(66,133,244,.11),rgba(15,23,42,.34))"><b style="color:#60a5fa">🤖 Gemini:</b> {% if item.ai_opinions.get('gemini') %}{{ item.ai_opinions.get('gemini') }}{% else %}<span style="color:#94a3b8">{{ item.ai_opinions.ai_status.get('gemini','در انتظار تحلیل') }}</span>{% endif %}</div>{% for provider,label in [('openai','ChatGPT'),('grok','Grok'),('claude','Claude'),('deepseek','DeepSeek')] %}{% if item.ai_opinions.ai_status.get(provider)=='تحلیل آماده' and item.ai_opinions.get(provider) %}<div class="aiRow"><b>{{ label }}:</b> {{ item.ai_opinions.get(provider) }}</div>{% endif %}{% endfor %}</div>
<div class="tv-wrap" data-symbol="{{ item.symbol }}" data-tv="{{ item.tv_symbol }}" style="width:100%;margin-top:10px">
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;align-items:center">
    <span class="miniChip">RSI: <b>{{ item.rsi }}</b></span>
    <span class="miniChip">MACD Hist: <b>{{ (item.macd or {}).get('hist', item.get('macd_hist','—')) }}</b></span>
    <span class="miniChip">MACD Cross: <b>{{ (item.macd or {}).get('cross', item.get('macd_cross','—')) }}</b></span>
    <button type="button" class="btn" style="padding:6px 10px;font-size:11px" onclick="reloadTV('{{ item.tv_symbol }}')">🔄 بارگذاری TradingView</button>
    <button type="button" class="btn gold" style="padding:6px 10px;font-size:11px" onclick="openPatternPanel('{{ item.symbol }}','{{ item.tv_symbol }}')">🔮 پیش‌بینی کندل و الگوها</button>
  </div>
  <div class="tv" id="tv-{{ item.tv_symbol }}" style="width:100%;height:360px;min-height:360px;display:block;position:relative;background:#0b1220;border:1px solid rgba(56,189,248,.25);border-radius:12px;overflow:hidden"></div>
  <iframe class="tv-iframe" id="tvif-{{ item.tv_symbol }}" data-symbol="{{ item.tv_symbol }}" style="display:none;width:100%;height:360px;border:1px solid rgba(56,189,248,.25);border-radius:12px;background:#0b1220" loading="lazy" allowtransparency="true" frameborder="0"></iframe>
  <canvas class="tv-fallback" id="cv-{{ item.tv_symbol }}" width="800" height="320" style="display:none;width:100%;height:320px;background:#0b1220;border:1px solid rgba(56,189,248,.25);border-radius:12px"></canvas>
  <div class="tv-status" style="font-size:11px;color:#94a3b8;margin-top:6px">در حال آماده‌سازی نمودار…</div>
</div>

{% set pats = (item.get('patterns') or {}).get('patterns') or [] %}
{% set fc = item.get('candle_forecast') or {} %}
<div class="panelTech patternPanel" id="pattern-{{ item.tv_symbol }}" style="border-color:rgba(192,132,252,.5);margin-top:12px">
  <b class="title" style="color:#c084fc">🔮 پیش‌بینی کندل آینده · تشخیص الگو · راهنما</b>
  <div style="font-size:11px;color:#94a3b8;line-height:1.75;margin:6px 0 10px">
    این بخش از تاریخچه بازده، شباهت الگویی، MACD/RSI و ساختار بازار ساخته می‌شود. <b style="color:#fbbf24">تضمین سود نیست</b> — سناریوی احتمالی برای تصمیم‌گیری آگاهانه است.
  </div>
  <div class="miniGrid">
    <div class="miniCard">
      <b style="color:#38bdf8">سناریوی کلی پیش‌بینی</b><br>
      تمایل: <b style="color:{% if fc.get('overall_bias')=='صعودی' %}var(--green){% elif fc.get('overall_bias')=='نزولی' %}var(--pink){% else %}var(--gold){% endif %}">{{ fc.get('overall_bias','—') }}</b><br>
      افق: {{ fc.get('horizon', 12) }} کندل · قیمت مبنا: {{ fc.get('last_price', item.price) }}
    </div>
    <div class="miniCard">
      <b style="color:#c084fc">الگوی اصلی</b><br>
      {% if (item.get('patterns') or {}).get('primary') %}
      <b>{{ (item.get('patterns').get('primary') or {}).get('id','—') }}</b>
      · اطمینان {{ (item.get('patterns').get('primary') or {}).get('confidence','—') }}%<br>
      <span style="color:#94a3b8;font-size:10px">{{ ((item.get('patterns').get('primary') or {}).get('guide') or {}).get('meaning','')[:90] }}</span>
      {% else %}
      الگوی استاندارد قوی تشخیص داده نشد
      {% endif %}
    </div>
  </div>
  {% if pats %}
  <div style="margin-top:10px">
    {% for p in pats[:4] %}
    <div style="padding:10px;margin:6px 0;border-radius:12px;background:rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.08);font-size:12px;line-height:1.8">
      <b style="color:#e2e8f0">{{ p.get('id') }}</b>
      <span class="miniChip">اطمینان {{ p.get('confidence') }}%</span>
      <span class="miniChip">سوگیری: {{ (p.get('guide') or {}).get('bias','—') }}</span>
      <div style="color:#94a3b8;margin-top:4px"><b style="color:#7dd3fc">یعنی چه؟</b> {{ (p.get('guide') or {}).get('meaning','') }}</div>
      <div style="color:#cbd5e1"><b style="color:#fbbf24">چه انتظاری؟</b> {{ (p.get('guide') or {}).get('expect','') }}</div>
    </div>
    {% endfor %}
  </div>
  {% endif %}
  <div style="margin-top:10px">
    <b style="color:var(--gold);font-size:12px">مسیر احتمالی کندل‌های بعدی</b>
    <div class="tableWrap" style="margin-top:6px">
      <table>
        <thead><tr><th>#</th><th>Open</th><th>High</th><th>Low</th><th>Close</th><th>جهت</th><th>اطمینان</th><th>باند پایین</th><th>باند بالا</th></tr></thead>
        <tbody>
        {% for c in (fc.get('candles') or []) %}
        <tr>
          <td>{{ c.get('step') }}</td>
          <td>{{ c.get('open') }}</td>
          <td>{{ c.get('high') }}</td>
          <td>{{ c.get('low') }}</td>
          <td><b>{{ c.get('close') }}</b></td>
          <td style="color:{% if c.get('direction')=='صعودی' %}var(--green){% else %}var(--pink){% endif %}">{{ c.get('direction') }}</td>
          <td>{{ c.get('confidence') }}%</td>
          <td>{{ c.get('band_low') }}</td>
          <td>{{ c.get('band_high') }}</td>
        </tr>
        {% else %}
        <tr><td colspan="9">پیش‌بینی هنوز آماده نیست — اسکن مجدد بزنید</td></tr>
        {% endfor %}
        </tbody>
      </table>
    </div>
    <div style="font-size:11px;color:#94a3b8;line-height:1.8;margin-top:8px">{{ fc.get('narrative','') }}</div>
    <canvas id="fc-{{ item.tv_symbol }}" width="800" height="160" style="width:100%;height:160px;margin-top:8px;border-radius:12px;background:#0b1220;border:1px solid rgba(56,189,248,.2)"></canvas>
    <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
      <button type="button" class="btn" onclick="refreshPatternForecast('{{ item.symbol }}','{{ item.tv_symbol }}')">🔄 بروزرسانی پیش‌بینی</button>
      <button type="button" class="btn" onclick="drawForecastChart('{{ item.tv_symbol }}')">📈 رسم مسیر پیش‌بینی</button>
    </div>
  </div>
</div>
</div>{% endfor %}</div>
<div class="section"><h2>📊 جدول خلاصه</h2><div class="tableWrap"><table><thead><tr><th>نماد</th><th>درجه</th><th>تصمیم</th><th>قیمت</th><th>تمایل</th><th>Score</th><th>Trust</th><th>Quality</th><th>Prob</th><th>RR1</th><th>OI</th></tr></thead><tbody>{% for item in market_data %}<tr><td><b>{{ item.coin_icon }} {{ item.coin_name }}</b><div style="font-size:11px;color:#94a3b8">{{ item.base_symbol }}/USDT</div></td><td><span class="gradeBadge {% set g = item.get('grade') or '—' %}{% if g=='A+' %}gradeAplus{% elif g=='A' %}gradeA{% elif g=='B' %}gradeB{% elif g=='C' %}gradeC{% elif g=='D' %}gradeD{% else %}gradeF{% endif %}">{{ g }}</span></td><td><b style="color:{% if item.decision_tag=='LONG' %}#4ade80{% elif item.decision_tag=='SHORT' %}#f43f5e{% else %}#fbbf24{% endif %}">{{ item.decision_tag or 'WAIT' }}</b></td><td data-table-price="{{ item.symbol }}">{{ item.price }}</td><td style="color:{{ item.score_color }}">{{ item.bias }}</td><td>{{ item.score }}</td><td>{{ item.get('trust_index', '—') }}</td><td>{{ item.signal_quality }}</td><td>{{ item.success_probability }}%</td><td style="color:var(--green)">{{ item.rr_tp1 }}</td><td>{{ item.coinglass_oi }}</td></tr>{% endfor %}</tbody></table></div></div>
<div class="foot"><div class="sb"><b style="color:var(--cyan)">ترس و طمع</b><div style="font-size:20px;color:var(--gold);margin-top:4px">{{ macro.fear_greed_val }}</div><small>{{ macro.fear_greed_text }}</small></div><div class="sb"><b style="color:var(--cyan)">BTC Dominance</b><div style="font-size:18px;margin-top:5px">{{ macro.dominance_btc }}</div></div><div class="sb"><b style="color:var(--cyan)">سیستم</b><div style="font-size:18px;color:var(--green);margin-top:5px">فعال</div><small>{{ market_data|length }} نماد</small></div><div class="sb"><b style="color:var(--cyan)">دقت تاریخی</b><div style="font-size:18px;color:var(--gold);margin-top:5px">{{ audit.win_rate }}%</div><small>{{ audit.wins }}W / {{ audit.losses }}L</small>
<div style="margin-top:6px"><span class="accTier {{ audit.get('tier','C') }}">رتبه {{ audit.get('tier','C') }} · {{ audit.get('tier_label','—') }}</span></div>
<small style="display:block;margin-top:4px">Long {{ audit.get('long_win_rate',0) }}% · Short {{ audit.get('short_win_rate',0) }}%</small>
</div></div>
</div><!-- /tab-market -->

<div class="tabPanel" id="tab-edge">
<div class="section" style="border-color:rgba(192,132,252,.55);background:linear-gradient(135deg,rgba(35,16,55,.82),rgba(5,10,22,.94))"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h2 style="margin:0;color:#c084fc">🧠 TITAN PROFESSIONAL EDGE SUITE · 12 MODULES</h2><span id="edge-status" style="font-size:12px;color:#94a3b8">ACTIVE</span></div><div class="hudgrid" style="margin-top:10px"><div class="hudbox"><div>Confluence</div><div class="v" id="edge-conf">--</div></div><div class="hudbox"><div>Meta Label</div><div class="v" id="edge-meta">--</div></div><div class="hudbox"><div>AI Consensus</div><div class="v" id="edge-ai">--</div></div><div class="hudbox"><div>Risk State</div><div class="v" id="edge-risk" style="font-size:15px">--</div></div></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn" onclick="loadEdgeTerminal()">🛰 Decision Terminal</button><button class="btn" onclick="runProLab()">🧪 12-Layer Pro Lab</button><span id="edge-msg" style="align-self:center;font-size:11px;color:#94a3b8"></span></div><pre id="edge-terminal" style="white-space:pre-wrap;background:#020617;padding:12px;border-radius:10px;color:#cbd5e1;overflow:auto;margin-top:10px;max-height:320px">داده آماده است</pre></div>
</div><!-- /tab-edge -->

<div class="tabPanel" id="tab-ai">
<div class="section" id="geminiPanel" style="border-color:rgba(66,133,244,.55);background:linear-gradient(135deg,rgba(15,23,42,.97),rgba(16,28,54,.92))"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h2 style="margin:0;color:#60a5fa">🤖 Gemini Global Intelligence</h2><span id="geminiStatus" style="font-size:12px;color:#94a3b8">{{ gemini_status.label }}</span></div><div style="margin-top:8px;font-size:11px;color:#64748b">آخرین تولید: {{ gemini_status.updated_at }} · API: {{ 'متصل' if gemini_status.available else 'غیرفعال' }}</div><div id="geminiAnalysis" style="margin-top:12px;line-height:2;color:#e0ecff;font-size:14px">{{ gemini_summary if gemini_summary else 'تحلیل کلان Gemini در حال حاضر در دسترس نیست؛ روی دریافت تحلیل Gemini بزنید.' }}</div><div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn" onclick="refreshGemini()">🤖 دریافت تحلیل Gemini</button><button class="btn" onclick="loadAiVoteBoard()">📊 خلاصه رأی مدل‌ها</button><span id="geminiRefreshState" style="align-self:center;font-size:11px;color:#94a3b8"></span></div></div>

<div class="section" style="border-color:rgba(96,165,250,.45);background:linear-gradient(135deg,rgba(12,20,40,.96),rgba(20,16,48,.94))">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
<h2 style="margin:0;color:#60a5fa">🗳️ هیئت رأی هوش مصنوعی · LONG / SHORT / WAIT</h2>
<span id="aiVoteSummary" style="font-size:12px;color:#94a3b8">در حال آماده‌سازی…</span>
<span id="modelScoreChips" class="chipRow" style="margin-top:6px;width:100%"></span>
</div>
<div class="sub" style="margin:8px 0 12px">رأی هر مدل از متن فارسی/انگلیسی استخراج می‌شود. اولویت با نشانه‌های نزولی است تا بایاس لانگ کاهش یابد. TITAN فقط با اجماع قوی ارتقا می‌گیرد.</div>
<div class="hudgrid" style="margin-bottom:12px">
<div class="hudbox"><div>اکثریت LONG</div><div class="v" id="voteLong" style="color:var(--green)">--</div></div>
<div class="hudbox"><div>اکثریت SHORT</div><div class="v" id="voteShort" style="color:var(--pink)">--</div></div>
<div class="hudbox"><div>WAIT</div><div class="v" id="voteWait" style="color:var(--gold)">--</div></div>
<div class="hudbox"><div>نمادها</div><div class="v" id="voteCount">--</div></div>
</div>
<div id="providerTally" class="chipRow" style="margin-bottom:12px"></div>
<div class="tableWrap"><table><thead><tr>
<th>نماد</th><th>TITAN</th><th>اکثریت AI</th><th>توافق</th><th>Gemini</th><th>ChatGPT</th><th>Grok</th><th>Claude</th><th>DeepSeek</th>
</tr></thead><tbody id="aiVoteBody"><tr><td colspan="9">برای بارگذاری روی «خلاصه رأی مدل‌ها» بزنید</td></tr></tbody></table></div>
<pre id="aiVoteDetail" style="white-space:pre-wrap;background:#020617;padding:12px;border-radius:10px;color:#cbd5e1;overflow:auto;margin-top:10px;max-height:280px;display:none"></pre>
</div>
</div><!-- /tab-ai -->

<div class="tabPanel" id="tab-control">
<div class="section"><h2>🛡️ Advanced Control Center</h2><div class="foot" style="border:none;padding:0"><div class="sb"><b>Live</b><div id="adv-live">--</div></div><div class="sb"><b>Historical</b><div id="adv-hist">--</div></div><div class="sb"><b>Paper</b><div id="adv-paper">--</div></div><div class="sb"><b>Quality</b><div id="adv-quality">--</div></div></div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="btn" onclick="runBacktest()">🧪 بک‌تست</button><button class="btn" onclick="runWalkForward()">🔬 Walk-Forward</button><button class="btn" onclick="refreshAdvanced()">🔄 Refresh</button></div><pre id="adv-result" style="white-space:pre-wrap;background:#020617;padding:12px;border-radius:10px;color:#cbd5e1;overflow:auto">آماده</pre></div>
</div><!-- /tab-control -->

<div class="tabPanel" id="tab-perf">
<div class="section" style="border-color:rgba(56,189,248,.45);background:linear-gradient(135deg,rgba(10,20,38,.96),rgba(20,13,38,.94));margin-bottom:12px">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
<h2 style="margin:0;color:#38bdf8">🎯 V22 BALANCED OPPORTUNITY ENGINE</h2>
<button class="btn" onclick="loadV22Opportunities()">🔄 بررسی فرصت‌ها</button>
</div>
<div class="sub" style="margin:7px 0 12px">WAIT به‌تنهایی پایان تحلیل نیست؛ فرصت‌های نزدیک به فعال‌شدن به‌صورت EARLY/WATCH نمایش داده می‌شوند و فقط با شواهد مستقل + پایداری + سلامت سطوح به سیگنال نهایی ارتقا می‌گیرند.</div>
<div class="hudgrid">
<div class="hudbox"><div>READY</div><div class="v" id="v22Ready" style="color:var(--green)">--</div></div>
<div class="hudbox"><div>EARLY</div><div class="v" id="v22Early" style="color:var(--cyan)">--</div></div>
<div class="hudbox"><div>WATCH</div><div class="v" id="v22Watch" style="color:var(--gold)">--</div></div>
<div class="hudbox"><div>NO EDGE</div><div class="v" id="v22NoEdge">--</div></div>
</div>
<div class="tableWrap" style="margin-top:12px"><table><thead><tr><th>نماد</th><th>تصمیم</th><th>فرصت</th><th>امتیاز</th><th>سمت</th><th>AI</th><th>یادگیری</th><th>دلیل</th></tr></thead>
<tbody id="v22OppBody"><tr><td colspan="8">در حال آماده‌سازی…</td></tr></tbody></table></div>
</div>

<div class="perfVisual" id="visualPerformance"><div class="perfHead"><div><h2>📊 PERFORMANCE INTELLIGENCE · امتیازدهی و عملکرد گذشته</h2><div class="perfSub">نمایش گرافیکی با حلقه، نوار و نماد · Win Rate · Equity · تایم‌فریم‌ها · رتبه دقت</div></div><button class="btn" onclick="loadVisualPerformance(true)">🔄 بروزرسانی عملکرد</button></div><div class="perfGrid"><div class="perfCard"><small>WIN RATE</small><div class="ring" id="wrRing" style="--v:0"><span id="visWR">--%</span></div><div class="metricState" id="visWL">-- W / -- L</div></div><div class="perfCard"><small>PERFORMANCE SCORE</small><div class="perfBig" id="visScore">--/100</div><div class="tfBar"><i id="visScoreBar" style="width:0%"></i></div><div class="metricState" id="visScoreState">بر اساس داده تاریخی واقعی</div></div><div class="perfCard"><small>EXPECTANCY</small><div class="perfBig" id="visExp">--%</div><div class="metricState" id="visPF">PF: --</div></div><div class="perfCard"><small>MAX DRAWDOWN</small><div class="perfBig" id="visDD">--%</div><div class="metricState" id="visOOS">OOS: --</div></div></div><div class="perfCharts"><div class="chartPanel"><h3>📈 Equity / Historical Return Curve</h3><canvas id="equityVisual" class="perfCanvas"></canvas></div><div class="chartPanel"><h3>🎯 Win / Loss / Neutral</h3><canvas id="wlVisual" class="perfCanvas"></canvas></div></div><div class="chartPanel" style="margin-top:12px"><h3>⏱ امتیاز عملکرد در تمام تایم‌فریم‌ها</h3><div id="tfVisual" class="tfVisual"></div></div><div class="perfNote" id="visNote">در حال دریافت داده عملکرد…</div><button class="btn" onclick="openTFWindow()">نمایش عقربه تایم‌فریم‌ها</button>
</div>
</div><!-- /tab-perf -->

<div class="tabPanel" id="tab-charts">
<div class="allCharts" id="allChartsSection">
<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
<h2>📈 گالری نمودار همه ارزها</h2>
<button type="button" class="btn" onclick="loadAllCoinCharts(true)">🔄 بروزرسانی نمودارها</button>
</div>
<div class="sub" style="margin-bottom:10px">کندل واقعی از چند منبع (Binance / data-api) — اگر TradingView لود نشود همین‌جا نمایش داده می‌شود</div>
<div class="allGrid" id="allChartsGrid">در حال آماده‌سازی…</div>
</div>
</div><!-- /tab-charts -->


</div>
<div id="modal" class="modal"><div class="modalC"><h2 style="color:var(--cyan);margin-top:0">تنظیمات TITAN</h2><form action="/update_settings" method="POST"><label>ضریب ریسک ATR</label><input type="number" step="0.1" min="0.2" max="5" name="risk_multiplier" value="{{ settings.risk_multiplier }}"><label>نمادها</label><input type="text" name="active_coins" value="{{ settings.active_coins|join(', ') }}"><div style="display:flex;justify-content:flex-end;gap:8px"><button type="button" class="btn" onclick="closeM()">انصراف</button><button class="btn gold">ذخیره</button></div></form></div></div>

<!-- ROOT MODALS (outside tabs so display:none ancestors cannot hide them) -->
<div id="tfWindow" class="modal glassModal"><div class="modalC glassCard">
<div class="modalHead">
<div>
<div class="modalKicker">⏱ تحلیل چندتایم‌فریمی</div>
<h2 id="tfModalTitle">عقربه‌های تایم‌فریم</h2>
</div>
<button type="button" class="btn iconBtn" onclick="closeTFWindow()">✕</button>
</div>
<div id="tfGaugeBox" class="tfGaugeGrid">در حال دریافت…</div>
<div class="modalFoot"><button type="button" class="btn" onclick="closeTFWindow()">بستن</button></div>
</div></div>

<div id="coinDetailModal" class="modal detailModal glassModal"><div class="modalC glassCard wideModal">
<div class="cdShell">
  <div id="cdBanner" class="cdBanner flat">
    <div class="cdBannerInner">
      <div class="cdTitleBlock">
        <div id="cdIcon" class="cdIconXL">●</div>
        <div><div class="modalKicker">✦ پروفایل دارایی · TITAN</div><h2 id="cdTitle" class="cdName">جزئیات ارز</h2><div id="cdPair" class="cdPair">— / USDT · BINANCE</div></div>
      </div>
      <div style="text-align:left"><div id="cdPriceBig" class="cdPriceBig">— <small>USDT</small></div><div id="cdSignalRow" class="chipRow" style="justify-content:flex-end;margin-top:8px"></div><button type="button" class="btn iconBtn" style="margin-top:8px;float:left" onclick="closeCoinDetail()">✕</button></div>
    </div>
  </div>
  <div class="cdBodyPad">
    <div class="coinDetailTabs" id="coinDetailTabs">
      <button class="coinDetailTab active" data-cdtab="overview">◈ خلاصه</button>
      <button class="coinDetailTab" data-cdtab="charts">📈 نمودار و تایم‌فریم</button>
      <button class="coinDetailTab" data-cdtab="trade">🟢 خرید / 🔴 فروش</button>
      <button class="coinDetailTab" data-cdtab="levels">🎯 ورود و خروج</button>
      <button class="coinDetailTab" data-cdtab="ai">🤖 سیستم و AI</button>
      <button class="coinDetailTab" data-cdtab="forecast">🔮 پیش‌بینی کندل</button>
      <button class="coinDetailTab" data-cdtab="full">🧩 جزئیات کامل</button>
    </div>

    <section class="coinDetailPanel active" data-cdpanel="overview">
      <div id="cdMetrics" class="cdMetrics"></div>
      <div id="cdOverviewText" class="cdInfoBox"></div>
      <div class="cdSectionLabel">⏱ وضعیت تایم‌فریم‌ها</div><div id="cdTfStrip" class="cdTfStrip"></div>
    </section>

    <section class="coinDetailPanel" data-cdpanel="charts">
      <div class="cdSectionLabel">📈 نمودار ۱ ساعته</div>
      <div class="cdChartBox"><canvas id="cdCanvas" width="720" height="240"></canvas></div>
      <div id="cdChartNote" class="cdInfoBox">داده نمودار از بازار زنده/کش معتبر TITAN دریافت می‌شود.</div>
      <div class="cdActions"><button type="button" class="btn" onclick="openTFWindow(window.currentTFSymbol)">⏱ عقربه‌های همه تایم‌فریم‌ها</button></div>
    </section>

    <section class="coinDetailPanel" data-cdpanel="trade">
      <div id="cdTradePanel" class="detailActionGrid"></div>
    </section>

    <section class="coinDetailPanel" data-cdpanel="levels">
      <div class="cdSectionLabel">🎯 سطوح ورود و خروج</div><div id="cdLevels" class="cdLevels"></div>
      <div id="cdExtra" class="chipRow" style="margin-top:12px"></div>
    </section>

    <section class="coinDetailPanel" data-cdpanel="ai">
      <div class="aiDetailGrid">
        <div class="aiDetailCard"><b>🧠 نظر TITAN</b><div id="cdSystemOpinion">—</div></div>
        <div class="aiDetailCard"><b>🤖 اجماع هوش مصنوعی</b><div id="cdAIOpinion">در حال دریافت…</div></div>
        <div class="aiDetailCard"><b>🎯 کیفیت و اطمینان</b><div id="cdAIMetrics">—</div></div>
        <div class="aiDetailCard"><b>🔍 دلایل تصمیم</b><div id="cdReasoning">—</div></div>
      </div>
    </section>

    <section class="coinDetailPanel" data-cdpanel="forecast">
      <div class="cdSectionLabel">🔮 مسیر احتمالی کندل‌های آینده · ۱۲ کندل</div>
      <div class="cdChartBox"><canvas id="cdForecastCanvas" width="720" height="220"></canvas></div>
      <div id="cdForecastText" class="cdInfoBox">در حال دریافت پیش‌بینی…</div>
    </section>

    <section class="coinDetailPanel" data-cdpanel="full">
      <div class="cdSectionLabel">🧩 جزئیات تکمیلی همین ارز · بدون تکرار در داشبورد</div>
      <div id="cdFullDetails" class="cdFullDetails"></div>
    </section>

    <div class="cdActions">
      
      <button type="button" class="btn" onclick="closeCoinDetail()">بستن</button>
    </div>
  </div>
</div></div></div>


<script>
function switchMainTab(id, btn){
  document.querySelectorAll('.mainArea .tabPanel').forEach(function(p){p.classList.remove('active')});
  document.querySelectorAll('.mainTabs .mainTab').forEach(function(b){b.classList.remove('active')});
  document.querySelectorAll('.sidebar .sideBtn').forEach(function(b){b.classList.remove('active')});
  var p=document.getElementById(id); if(p)p.classList.add('active');
  if(btn){btn.classList.add('active'); var sid=btn.getAttribute('data-side-tab'); if(sid){var s=document.querySelector('.sideBtn[data-side-tab="'+sid+'"]'); if(s)s.classList.add('active');}}
  else {var s=document.querySelector('.sideBtn[data-side-tab="'+id+'"]'); if(s)s.classList.add('active'); var t=document.querySelector('.mainTabs .mainTab[onclick*="'+id+'"]'); if(t)t.classList.add('active');}
  if(id==='tab-ai'){try{loadAiVoteBoard();refreshGemini()}catch(e){}}
  if(id==='tab-perf'){try{loadVisualPerformance();loadV22Opportunities()}catch(e){}}
  if(id==='tab-charts'){try{loadAllCoinCharts()}catch(e){}}
  if(id==='tab-edge'){try{loadEdgeTerminal()}catch(e){}}
  if(id==='tab-control'){try{refreshAdvanced()}catch(e){}}
}
function filterAssets(){
  var q=(document.getElementById('coinSearch')||{}).value||''; q=q.toLowerCase().trim();
  document.querySelectorAll('#assetGrid .assetCard').forEach(function(c){var txt=(c.getAttribute('data-name')||'').toLowerCase();var ok=!q||txt.indexOf(q)>=0;var f=window.assetFilter||'ALL';var d=c.getAttribute('data-decision')||'WAIT';if(f==='TOP')ok=ok&&Number(c.getAttribute('data-score')||0)>=70;else if(f!=='ALL')ok=ok&&d===f;c.style.display=ok?'':'none';});
}
window.assetFilter='ALL';
function setAssetFilter(f,btn){window.assetFilter=f;document.querySelectorAll('.filterBtn').forEach(function(x){x.classList.toggle('active',x.getAttribute('data-filter')===f)});document.querySelectorAll('.assetTools button').forEach(function(x){x.classList.remove('active')});if(btn&&btn.parentElement&&btn.parentElement.classList.contains('assetTools'))btn.classList.add('active');filterAssets();}
function clearAssetFilter(){window.assetFilter='ALL';var q=document.getElementById('coinSearch');if(q)q.value='';document.querySelectorAll('.filterBtn').forEach(function(x){x.classList.toggle('active',x.getAttribute('data-filter')==='ALL')});filterAssets();}
</script>
<script type="text/javascript" src="https://s3.tradingview.com/tv.js" onerror="window.__tvScriptFailed=true"></script>
<script>
(function(){
"use strict";

function switchTab(id, btn){
  try {
    document.querySelectorAll(".tabPanel").forEach(function(p){ p.classList.remove("active"); });
    document.querySelectorAll(".tabBtn").forEach(function(b){ b.classList.remove("active"); });
    var panel = document.getElementById(id);
    if(panel) panel.classList.add("active");
    if(btn) btn.classList.add("active");
    if(id === "tab-charts") { try { loadAllCoinCharts(); } catch(e){} }
    if(id === "tab-perf") { try { loadVisualPerformance(); } catch(e){} try { loadV22Opportunities(); } catch(e){} }
    if(id === "tab-edge") { try { loadEdgeTerminal(); } catch(e){} }
    if(id === "tab-control") { try { refreshAdvanced(); } catch(e){} }
    if(id === "tab-ai") { try { loadAiVoteBoard(); refreshGemini(); } catch(e){} }
  } catch(e) { console.warn(e); }
}

window.switchTab = switchTab;

async function loadAiVoteBoard(){
  var body = document.getElementById("aiVoteBody");
  var sum = document.getElementById("aiVoteSummary");
  try {
    if(sum) sum.textContent = "در حال خواندن رأی مدل‌ها…";
    var d = await fetch("/api/ai-votes", {cache:"no-store"}).then(function(r){return r.json();});
    if(!d || !d.ok){ if(sum) sum.textContent = "داده رأی در دسترس نیست"; return; }
    var t = d.tally || {};
    setText("voteLong", t.LONG != null ? t.LONG : 0);
    setText("voteShort", t.SHORT != null ? t.SHORT : 0);
    setText("voteWait", t.WAIT != null ? t.WAIT : 0);
    setText("voteCount", d.count != null ? d.count : 0);
    if(sum) sum.textContent = "به‌روز · " + (d.count||0) + " نماد";
    var pt = document.getElementById("providerTally");
    if(pt){
      pt.innerHTML = "";
      var prov = t.providers || {};
      Object.keys(prov).forEach(function(p){
        var b = prov[p] || {};
        var total = (b.LONG||0)+(b.SHORT||0)+(b.WAIT||0);
        var conf = total ? Math.round(Math.max(b.LONG||0, b.SHORT||0) / total * 100) : 0;
        var el = document.createElement("span");
        el.className = "miniChip";
        el.textContent = p + ": L" + (b.LONG||0) + " / S" + (b.SHORT||0) + " / W" + (b.WAIT||0) + " · امتیاز " + conf + "%";
        pt.appendChild(el);
      });
    }
    var msc = document.getElementById("modelScoreChips");
    if(msc){
      msc.innerHTML = "";
      var names = {gemini:"Gemini", openai:"ChatGPT", grok:"Grok", claude:"Claude", deepseek:"DeepSeek"};
      var prov2 = t.providers || {};
      Object.keys(names).forEach(function(p){
        var b = prov2[p] || {};
        var total = (b.LONG||0)+(b.SHORT||0)+(b.WAIT||0);
        var mode = "WAIT"; var sc = 50;
        if((b.LONG||0) >= (b.SHORT||0) && (b.LONG||0) >= (b.WAIT||0) && (b.LONG||0)>0){ mode="LONG"; sc = total? Math.round(b.LONG/total*100):50; }
        else if((b.SHORT||0) >= (b.LONG||0) && (b.SHORT||0) >= (b.WAIT||0) && (b.SHORT||0)>0){ mode="SHORT"; sc = total? Math.round(b.SHORT/total*100):50; }
        else { mode="WAIT"; sc = total? Math.round((b.WAIT||0)/total*100):50; }
        var col = mode==="LONG"?"#4ade80": mode==="SHORT"?"#f43f5e":"#fbbf24";
        var el = document.createElement("span");
        el.className = "miniChip";
        el.style.borderColor = col;
        el.innerHTML = "<b style='color:"+col+"'>" + names[p] + "</b> · حالت " + mode + " · امتیاز مدل " + sc + "%";
        msc.appendChild(el);
      });
    }
    function voteCell(v){
      if(v==="LONG") return '<span class="signalBadge long">LONG</span>';
      if(v==="SHORT") return '<span class="signalBadge short">SHORT</span>';
      if(v==="WAIT") return '<span class="signalBadge wait">WAIT</span>';
      return '<span style="color:#64748b">—</span>';
    }
    if(body){
      body.innerHTML = (d.board||[]).map(function(row){
        var v = row.votes || {};
        var details = row.details || {};
        function modelTitle(name, vote){
          var z = details[name] || {};
          var sn = String(z.snippet || "").replace(/</g,"&lt;").replace(/>/g,"&gt;");
          return voteCell(vote) + (sn ? "<div style='font-size:10px;color:#64748b;margin-top:4px;max-width:180px;line-height:1.5'>" + sn.slice(0,120) + "</div>" : "");
        }
        return "<tr><td><b>" + (row.symbol||"") + "</b></td><td>" + voteCell(row.titan) +
          "</td><td>" + voteCell(row.majority) + "</td><td>" + (row.agreement!=null?row.agreement:"—") +
          "%</td><td>" + modelTitle("gemini",v.gemini) + "</td><td>" + modelTitle("openai",v.openai) +
          "</td><td>" + modelTitle("grok",v.grok) + "</td><td>" + modelTitle("claude",v.claude) +
          "</td><td>" + modelTitle("deepseek",v.deepseek) + "</td></tr>";
      }).join("") || "<tr><td colspan='9'>رأیی ثبت نشده است؛ اگر اسکن پس‌زمینه هنوز تمام نشده، چند ثانیه بعد دوباره بزنید.</td></tr>";
    }
    if(!(d.board||[]).length && d.count === 0){
      if(sum) sum.textContent = "تحلیل بازار در پس‌زمینه در حال آماده‌سازی است…";
      setTimeout(function(){ loadAiVoteBoard(); }, 1800);
    }
  } catch(e) {
    if(sum) sum.textContent = "خطا: " + (e.message||e);
  }
}
window.loadAiVoteBoard = loadAiVoteBoard;

async function loadV22Opportunities(){
  try{
    var d = await fetch("/api/opportunities",{cache:"no-store"}).then(function(r){return r.json();});
    if(!d || !d.ok) return;
    setText("v22Ready", d.summary.ready||0);
    setText("v22Early", d.summary.early||0);
    setText("v22Watch", d.summary.watch||0);
    setText("v22NoEdge", d.summary.no_edge||0);
    var body = document.getElementById("v22OppBody");
    if(!body) return;
    body.innerHTML = (d.rows||[]).slice(0,15).map(function(x){
      var st = String(x.state||"NO_EDGE");
      var col = st==="READY" ? "var(--green)" : st.indexOf("EARLY")===0 ? "var(--cyan)" : st.indexOf("WATCH")===0 ? "var(--gold)" : "#94a3b8";
      var dec = String(x.decision||"WAIT");
      var dcol = dec==="LONG" ? "var(--green)" : dec==="SHORT" ? "var(--pink)" : "var(--gold)";
      var ai = x.ai||{}, lr = x.learning||{}, chosen = lr.chosen_side||{};
      var reasons = (x.reasons||[]).slice(0,3).join(" · ");
      return "<tr><td><b>"+(x.symbol||"")+"</b></td>"+
        "<td><b style='color:"+dcol+"'>"+dec+"</b></td>"+
        "<td><span style='color:"+col+"'>"+st+"</span></td>"+
        "<td><b>"+(x.score!=null?x.score:"—")+"</b></td>"+
        "<td>"+(x.side||"WAIT")+"</td>"+
        "<td>"+(ai.majority||"WAIT")+" · "+(ai.agreement!=null?ai.agreement:"—")+"%</td>"+
        "<td>"+(chosen.samples!=null?chosen.samples:0)+" n · WR "+(chosen.win_rate!=null?chosen.win_rate:"—")+"%</td>"+
        "<td style='font-size:10px;color:#94a3b8;max-width:360px'>"+reasons+"</td></tr>";
    }).join("") || "<tr><td colspan='8'>فرصتی ثبت نشده است.</td></tr>";
  }catch(e){ console.warn("V22 opportunities",e); }
}
window.loadV22Opportunities = loadV22Opportunities;



window.__tvScriptFailed = window.__tvScriptFailed || false;

function safeEl(id){ try { return document.getElementById(id); } catch(e){ return null; } }
function setText(id, v){ var el = safeEl(id); if(el) el.textContent = v; }
function qs(sel, root){ try { return (root||document).querySelector(sel); } catch(e){ return null; } }
function qsa(sel, root){ try { return Array.prototype.slice.call((root||document).querySelectorAll(sel)); } catch(e){ return []; } }

window.currentTFSymbol = window.currentTFSymbol || "BTC/USDT";
window._detailTv = window._detailTv || "BTCUSDT";

/* ---------- charts: always prefer canvas candles ---------- */
function drawCandleChart(canvas, candles, title){
  if(!canvas || !candles || !candles.length) return false;
  try {
    var dpr = window.devicePixelRatio || 1;
    var cssW = canvas.clientWidth || canvas.parentElement && canvas.parentElement.clientWidth || 320;
    var cssH = canvas.clientHeight || 220;
    if(cssW < 40) cssW = 320;
    if(cssH < 40) cssH = 220;
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
    var ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var W = cssW, H = cssH;
    ctx.fillStyle = "#0b1220";
    ctx.fillRect(0, 0, W, H);
    var padL = 6, padR = 52, padT = 24, padB = 18;
    var n = candles.length;
    var highs = candles.map(function(c){ return +c.h; });
    var lows = candles.map(function(c){ return +c.l; });
    var minP = Math.min.apply(null, lows);
    var maxP = Math.max.apply(null, highs);
    if(!isFinite(minP) || !isFinite(maxP) || minP === maxP){ minP = (minP||1)*0.99; maxP = (maxP||1)*1.01; }
    var span = maxP - minP || 1;
    function y(p){ return padT + (1 - (p - minP) / span) * (H - padT - padB); }
    var slot = (W - padL - padR) / n;
    var bodyW = Math.max(2, slot * 0.62);
    ctx.strokeStyle = "rgba(148,163,184,0.12)";
    ctx.lineWidth = 1;
    for(var g=0;g<5;g++){
      var gy = padT + g * (H - padT - padB) / 4;
      ctx.beginPath(); ctx.moveTo(padL, gy); ctx.lineTo(W - padR, gy); ctx.stroke();
      var gp = maxP - span * g / 4;
      ctx.fillStyle = "#94a3b8";
      ctx.font = "10px Tahoma,sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(gp >= 1000 ? gp.toFixed(1) : (gp >= 1 ? gp.toFixed(4) : gp.toFixed(6)), W - padR + 3, gy + 3);
    }
    for(var i=0;i<n;i++){
      var c = candles[i];
      var x = padL + i * slot + slot / 2;
      var up = (+c.c) >= (+c.o);
      ctx.strokeStyle = up ? "#4ade80" : "#f43f5e";
      ctx.fillStyle = up ? "#4ade80" : "#f43f5e";
      ctx.beginPath();
      ctx.moveTo(x, y(+c.h));
      ctx.lineTo(x, y(+c.l));
      ctx.stroke();
      var y1 = y(Math.max(+c.o, +c.c));
      var y2 = y(Math.min(+c.o, +c.c));
      ctx.fillRect(x - bodyW / 2, y1, bodyW, Math.max(1, y2 - y1));
    }
    ctx.fillStyle = "#e2e8f0";
    ctx.font = "bold 12px Tahoma,sans-serif";
    ctx.textAlign = "right";
    ctx.fillText(title || "Chart", W - padR - 4, 16);
    var last = candles[n-1];
    ctx.fillStyle = (+last.c) >= (+last.o) ? "#4ade80" : "#f43f5e";
    ctx.textAlign = "left";
    var lp = +last.c;
    ctx.fillText(lp >= 1000 ? lp.toFixed(2) : lp.toFixed(6), padL, 16);
    return true;
  } catch(err) {
    console.warn("drawCandleChart", err);
    return false;
  }
}

async function fetchCandles(symbol, tf, limit){
  tf = tf || "1h";
  limit = limit || 100;
  var url = "/api/klines?symbol=" + encodeURIComponent(symbol) + "&timeframe=" + encodeURIComponent(tf) + "&limit=" + limit;
  var res = await fetch(url, { cache: "no-store" });
  var data = await res.json();
  if(!data || !data.ok || !data.candles || !data.candles.length) throw new Error((data && data.error) || "no candles");
  return data.candles;
}

async function loadFallbackChart(tvSymbol){
  var wrap = qs('.tv-wrap[data-tv="' + tvSymbol + '"]');
  if(!wrap) return;
  var status = qs(".tv-status", wrap);
  var tvBox = safeEl("tv-" + tvSymbol);
  var canvas = safeEl("cv-" + tvSymbol);
  var pair = wrap.getAttribute("data-symbol") || (tvSymbol.indexOf("/") >= 0 ? tvSymbol : tvSymbol.replace(/USDT$/,"") + "/USDT");
  try {
    if(status) status.textContent = "در حال دریافت کندل…";
    var candles = await fetchCandles(pair, "1h", 120);
    if(tvBox) tvBox.style.display = "none";
    if(canvas){
      canvas.style.display = "block";
      canvas._candles = candles;
      canvas._title = pair + " · 1H";
      drawCandleChart(canvas, candles, canvas._title);
    }
    if(status) status.textContent = "نمودار کندل فعال · " + pair + " · " + candles.length + " شمع";
  } catch(e) {
    if(status) status.textContent = "نمودار: " + (e.message || e);
  }
}

function tryTradingViewWidget(tvSymbol, containerId){
  try {
    if(window.__tvScriptFailed || typeof TradingView === "undefined" || !TradingView.widget){
      return false;
    }
    var el = document.getElementById(containerId);
    if(!el) return false;
    el.innerHTML = "";
    el.style.display = "block";
    el.style.height = "360px";
    new TradingView.widget({
      "autosize": true,
      "symbol": "BINANCE:" + tvSymbol,
      "interval": "60",
      "timezone": "Etc/UTC",
      "theme": "dark",
      "style": "1",
      "locale": "en",
      "toolbar_bg": "#0b1220",
      "enable_publishing": false,
      "allow_symbol_change": true,
      "hide_side_toolbar": false,
      "container_id": containerId,
      "studies": [
        "RSI@tv-basicstudies",
        "MACD@tv-basicstudies",
        "MASimple@tv-basicstudies"
      ],
      "overrides": {
        "paneProperties.background": "#0b1220",
        "paneProperties.vertGridProperties.color": "#1e293b",
        "paneProperties.horzGridProperties.color": "#1e293b"
      },
      "disabled_features": ["header_symbol_search", "use_localstorage_for_settings"],
      "enabled_features": ["move_logo_to_main_pane", "side_toolbar_in_fullscreen_mode"]
    });
    return true;
  } catch(e) {
    console.warn("TV widget fail", e);
    return false;
  }
}

function loadTradingViewIframe(tvSymbol){
  try {
    var ifr = document.getElementById("tvif-" + tvSymbol);
    var tvBox = document.getElementById("tv-" + tvSymbol);
    var canvas = document.getElementById("cv-" + tvSymbol);
    if(!ifr) return false;
    var src = "https://s.tradingview.com/widgetembed/?frameElementId=tvif-" + encodeURIComponent(tvSymbol)
      + "&symbol=BINANCE%3A" + encodeURIComponent(tvSymbol)
      + "&interval=60&hidesidetoolbar=0&hidetoptoolbar=0&symboledit=1&saveimage=0"
      + "&toolbarbg=0b1220&studies=%5B%22RSI%40tv-basicstudies%22%2C%22MACD%40tv-basicstudies%22%5D"
      + "&theme=dark&style=1&timezone=Etc%2FUTC&withdateranges=1&hideideas=1&studies_overrides=%7B%7D&overrides=%7B%7D"
      + "&enabled_features=%5B%5D&disabled_features=%5B%5D&locale=en&utm_source=titan&utm_medium=widget";
    ifr.src = src;
    ifr.style.display = "block";
    if(tvBox) tvBox.style.display = "none";
    if(canvas) canvas.style.display = "none";
    return true;
  } catch(e) {
    console.warn("TV iframe fail", e);
    return false;
  }
}

function reloadTV(tvSymbol){
  var wrap = qs('.tv-wrap[data-tv="' + tvSymbol + '"]');
  var status = wrap ? qs(".tv-status", wrap) : null;
  if(status) status.textContent = "در حال بارگذاری مجدد TradingView…";
  var ok = tryTradingViewWidget(tvSymbol, "tv-" + tvSymbol);
  if(ok){
    var ifr = document.getElementById("tvif-" + tvSymbol);
    if(ifr) ifr.style.display = "none";
    var tvBox = document.getElementById("tv-" + tvSymbol);
    if(tvBox) tvBox.style.display = "block";
    if(status) status.textContent = "TradingView Widget · BINANCE:" + tvSymbol + " · RSI+MACD";
    return;
  }
  if(loadTradingViewIframe(tvSymbol)){
    if(status) status.textContent = "TradingView Embed · BINANCE:" + tvSymbol + " · RSI+MACD";
    return;
  }
  loadFallbackChart(tvSymbol);
}

function loadAllCardCharts(){
  qsa(".tv-wrap[data-tv]").forEach(function(w, idx){
    var tv = w.getAttribute("data-tv");
    if(!tv) return;
    var status = qs(".tv-status", w);
    // Stagger to avoid TV rate limits
    setTimeout(function(){
      var ok = tryTradingViewWidget(tv, "tv-" + tv);
      if(ok){
        var canvas = document.getElementById("cv-" + tv);
        if(canvas) canvas.style.display = "none";
        var ifr = document.getElementById("tvif-" + tv);
        if(ifr) ifr.style.display = "none";
        var tvBox = document.getElementById("tv-" + tv);
        if(tvBox) tvBox.style.display = "block";
        if(status) status.textContent = "TradingView فعال · BINANCE:" + tv + " · RSI + MACD";
        setTimeout(function(){
          // If widget stayed empty, fall back to embed
          var box = document.getElementById("tv-" + tv);
          if(box && box.children.length === 0){
            if(loadTradingViewIframe(tv)){
              if(status) status.textContent = "TradingView Embed · BINANCE:" + tv;
            } else {
              loadFallbackChart(tv);
            }
          }
        }, 4500);
      } else if(loadTradingViewIframe(tv)){
        if(status) status.textContent = "TradingView Embed · BINANCE:" + tv + " · RSI + MACD";
      } else {
        loadFallbackChart(tv);
      }
    }, idx * 350);
  });
}

function openPatternPanel(symbol, tv){
  var el = document.getElementById("pattern-" + tv);
  if(el){
    el.scrollIntoView({behavior:"smooth", block:"start"});
    el.style.outline = "2px solid #c084fc";
    setTimeout(function(){ el.style.outline = ""; }, 1400);
  }
  refreshPatternForecast(symbol, tv);
}

async function refreshPatternForecast(symbol, tv){
  try {
    var d = await fetch("/api/pattern-forecast?symbol=" + encodeURIComponent(symbol) + "&timeframe=1h&horizon=12", {cache:"no-store"}).then(function(r){return r.json();});
    if(!d || !d.ok) return;
    // Update narrative if present
    var panel = document.getElementById("pattern-" + tv);
    if(panel && d.forecast && d.forecast.narrative){
      var notes = panel.querySelectorAll("div");
      // soft: redraw forecast chart
    }
    if(d.forecast) window["_fc_" + tv] = d.forecast;
    drawForecastChart(tv);
  } catch(e){ console.warn(e); }
}

function drawForecastChart(tv){
  var cv = document.getElementById("fc-" + tv);
  if(!cv) return;
  var fc = window["_fc_" + tv];
  if(!fc || !fc.candles || !fc.candles.length){
    // try read from nothing - skip
    return;
  }
  var candles = fc.candles;
  try {
    var dpr = window.devicePixelRatio || 1;
    var W = cv.clientWidth || 320, H = 160;
    cv.width = Math.floor(W * dpr); cv.height = Math.floor(H * dpr);
    var ctx = cv.getContext("2d");
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.fillStyle = "#0b1220"; ctx.fillRect(0,0,W,H);
    var lows = candles.map(function(c){return +c.band_low;});
    var highs = candles.map(function(c){return +c.band_high;});
    var minP = Math.min.apply(null, lows), maxP = Math.max.apply(null, highs);
    if(minP===maxP){minP*=0.99;maxP*=1.01;}
    var pad=8;
    function y(p){ return pad + (1-(p-minP)/(maxP-minP))*(H-pad*2); }
    function x(i){ return pad + i*(W-pad*2)/Math.max(1,candles.length-1); }
    // band
    ctx.beginPath();
    candles.forEach(function(c,i){ var yy=y(+c.band_high); if(i) ctx.lineTo(x(i),yy); else ctx.moveTo(x(i),yy); });
    for(var j=candles.length-1;j>=0;j--){ ctx.lineTo(x(j), y(+candles[j].band_low)); }
    ctx.closePath();
    ctx.fillStyle = "rgba(56,189,248,0.12)"; ctx.fill();
    // mid path
    ctx.beginPath();
    candles.forEach(function(c,i){ var yy=y(+c.close); if(i) ctx.lineTo(x(i),yy); else ctx.moveTo(x(i),yy); });
    ctx.strokeStyle = "#c084fc"; ctx.lineWidth = 2; ctx.stroke();
    candles.forEach(function(c,i){
      ctx.fillStyle = c.direction==="صعودی" ? "#4ade80" : "#f43f5e";
      ctx.beginPath(); ctx.arc(x(i), y(+c.close), 4, 0, Math.PI*2); ctx.fill();
    });
    ctx.fillStyle = "#94a3b8"; ctx.font = "11px Tahoma"; ctx.textAlign="left";
    ctx.fillText("مسیر پیش‌بینی " + (fc.overall_bias||"") + " · " + candles.length + " کندل", pad, 14);
  } catch(e){ console.warn(e); }
}

window.reloadTV = reloadTV;
window.openPatternPanel = openPatternPanel;
window.refreshPatternForecast = refreshPatternForecast;
window.drawForecastChart = drawForecastChart;

async function loadAllCoinCharts(){
  var grid = safeEl("allChartsGrid");
  if(!grid) return;
  grid.innerHTML = "";
  var cards = qsa(".card[data-symbol]");
  if(!cards.length){
    grid.innerHTML = "<div style='color:#94a3b8'>ارزی در داشبورد نیست — اسکن مجدد بزنید</div>";
    return;
  }
  cards.forEach(function(card){
    var symbol = card.getAttribute("data-symbol");
    var base = card.getAttribute("data-base") || symbol;
    var icon = card.getAttribute("data-icon") || "";
    var score = card.getAttribute("data-score") || "";
    var color = card.getAttribute("data-color") || "#fbbf24";
    var bias = card.getAttribute("data-bias") || "";
    var box = document.createElement("div");
    box.className = "allCard";
    box.innerHTML = '<div class="atitle"><span>' + icon + " " + base + '</span><span style="color:' + color + '">' + score + "/100</span></div><canvas height=\"180\"></canvas><div style=\"font-size:11px;color:#94a3b8;margin-top:4px\">" + bias + "</div>";
    grid.appendChild(box);
    var cv = box.querySelector("canvas");
    fetchCandles(symbol, "1h", 60).then(function(candles){
      drawCandleChart(cv, candles, base + " 1H");
    }).catch(function(err){
      box.insertAdjacentHTML("beforeend", "<div style='color:#f43f5e;font-size:11px'>" + (err.message||err) + "</div>");
    });
  });
}

/* ---------- coin nav / detail ---------- */
function scrollToCard(tv){
  var el = safeEl("card-" + tv);
  if(!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "start" });
  el.style.outline = "2px solid #38bdf8";
  setTimeout(function(){ el.style.outline = ""; }, 1200);
}

function closeCoinDetail(){
  var m = safeEl("coinDetailModal");
  if(m) m.style.display = "none";
}

async function openCoinDetailFromCard(card){
  if(!card) return;
  var m = document.getElementById("coinDetailModal");
  if(m){ m.style.display = "flex"; m.style.zIndex = "1300"; }
  var symbol = card.getAttribute("data-symbol") || "";
  var tv = card.getAttribute("data-tv") || "";
  window.currentTFSymbol = symbol;
  window._detailTv = tv;

  var icon = card.getAttribute("data-icon") || "●";
  var name = card.getAttribute("data-name") || "";
  var base = card.getAttribute("data-base") || "";
  var color = card.getAttribute("data-color") || "#fbbf24";
  var bias = card.getAttribute("data-bias") || "";
  var score = card.getAttribute("data-score") || "—";
  var price = card.getAttribute("data-price") || "—";
  var rawDecision = (card.getAttribute("data-decision") || "").toUpperCase().trim();
  var dtag = rawDecision === "LONG" || rawDecision === "SHORT" || rawDecision === "WAIT" ? rawDecision : "WAIT";
  var mode = dtag === "LONG" ? "bull" : dtag === "SHORT" ? "bear" : "flat";

  var banner = document.getElementById("cdBanner");
  if(banner){ banner.className = "cdBanner " + mode; }
  var iconEl = document.getElementById("cdIcon");
  if(iconEl) iconEl.textContent = icon;
  var title = document.getElementById("cdTitle");
  if(title) title.textContent = name || base;
  var pair = document.getElementById("cdPair");
  if(pair) pair.textContent = (base || "—") + " / USDT · BINANCE SPOT";
  var priceEl = document.getElementById("cdPriceBig");
  if(priceEl) priceEl.innerHTML = price + " <small>USDT</small>";

  var sig = document.getElementById("cdSignalRow");
  if(sig){
    var badgeClass = dtag === "LONG" ? "long" : dtag === "SHORT" ? "short" : "wait";
    var badgeTxt = dtag === "LONG" ? "▲ خرید" : dtag === "SHORT" ? "▼ فروش" : "◆ انتظار";
    sig.innerHTML =
      '<span class="signalBadge ' + badgeClass + '">' + badgeTxt + " · " + bias + "</span>" +
      '<span class="miniChip">تگ: ' + (card.getAttribute("data-tag") || "—") + "</span>";
  }

  var metrics = document.getElementById("cdMetrics");
  if(metrics){
    metrics.innerHTML =
      '<div class="cdMetric"><div class="ico">🎯</div><div class="val" style="color:' + color + '">' + score + '</div><small>امتیاز</small></div>' +
      '<div class="cdMetric"><div class="ico">🧭</div><div class="val">' + (card.getAttribute("data-align") || "—") + '</div><small>همسویی</small></div>' +
      '<div class="cdMetric"><div class="ico">✨</div><div class="val">' + (card.getAttribute("data-quality") || "—") + '</div><small>کیفیت</small></div>' +
      '<div class="cdMetric"><div class="ico">📊</div><div class="val">' + (card.getAttribute("data-rsi") || "—") + '</div><small>قدرت نسبی</small></div>';
  }

  var levels = document.getElementById("cdLevels");
  if(levels){
    levels.innerHTML =
      '<div class="cdLevelCard entry"><div class="lbl">🎯 نقطه ورود</div><div class="num">' + (card.getAttribute("data-entry") || price) + '</div></div>' +
      '<div class="cdLevelCard sl"><div class="lbl">🛑 حد ضرر</div><div class="num" style="color:#fb7185">' + (card.getAttribute("data-sl") || "—") + '</div></div>' +
      '<div class="cdLevelCard tp1"><div class="lbl">🟢 حد سود ۱ · RR 1:' + (card.getAttribute("data-rr1") || "—") + '</div><div class="num" style="color:#4ade80">' + (card.getAttribute("data-tp1") || "—") + '</div></div>' +
      '<div class="cdLevelCard tp2"><div class="lbl">🚀 حد سود ۲ · RR 1:' + (card.getAttribute("data-rr2") || "—") + '</div><div class="num" style="color:#fbbf24">' + (card.getAttribute("data-tp2") || "—") + '</div></div>';
  }

  var tf = document.getElementById("cdTfStrip");
  if(tf){
    var cells = [
      ["۱۵ دقیقه", card.getAttribute("data-tf15")],
      ["۱ ساعت", card.getAttribute("data-tf1h")],
      ["۴ ساعت", card.getAttribute("data-tf4h")],
      ["۱ روز", card.getAttribute("data-tf1d")]
    ];
    tf.innerHTML = cells.map(function(c){
      var v = c[1] || "—";
      var col = (v.indexOf("صعود") >= 0 || v.indexOf("🟢") >= 0) ? "#4ade80" :
                (v.indexOf("نزول") >= 0 || v.indexOf("🔴") >= 0) ? "#fb7185" : "#fbbf24";
      return '<div class="cdTfCell"><small>' + c[0] + '</small><b style="color:' + col + '">' + v + '</b></div>';
    }).join("");
  }

  var extra = document.getElementById("cdExtra");
  if(extra){
    extra.innerHTML =
      '<span class="miniChip">🐋 بهره باز: ' + (card.getAttribute("data-oi") || "—") + '</span>' +
      '<span class="miniChip">💸 نرخ تأمین مالی: ' + (card.getAttribute("data-fund") || "—") + '</span>' +
      '<span class="miniChip">📐 فاصله تا حد ضرر وابسته به ATR</span>';
  }

  var sys = document.getElementById("cdSystemOpinion");
  if(sys) sys.innerHTML = '<b style="color:' + color + '">' + dtag + '</b> · ' + (bias || "خنثی") +
      '<br>امتیاز ' + score + '/100 · همسویی ' + (card.getAttribute("data-align")||"—") +
      ' · کیفیت ' + (card.getAttribute("data-quality")||"—");
  var ai = document.getElementById("cdAIOpinion");
  if(ai) ai.textContent = 'در حال بارگذاری اجماع مدل‌ها…';
  var aim = document.getElementById("cdAIMetrics");
  
  // Buy/Sell graphical dual ring (shape + text)
  var buyP = parseFloat(card.getAttribute("data-buy") || "50");
  var sellP = parseFloat(card.getAttribute("data-sell") || "");
  if(!isFinite(buyP)) buyP = 50;
  if(!isFinite(sellP)) sellP = Math.max(0, 100 - buyP);
  buyP = Math.max(0, Math.min(100, buyP));
  sellP = Math.max(0, Math.min(100, sellP));
  var bsHost = document.getElementById("cdBuySellFlow");
  if(!bsHost){
    var metricsEl2 = document.getElementById("cdMetrics");
    if(metricsEl2 && metricsEl2.parentNode){
      bsHost = document.createElement("div");
      bsHost.id = "cdBuySellFlow";
      metricsEl2.parentNode.insertBefore(bsHost, metricsEl2.nextSibling);
    }
  }
  if(bsHost){
    bsHost.innerHTML =
      '<div class="bsFlowBox" style="--buy:'+buyP+'">'+
        '<div class="bsDualRing" style="--buy:'+buyP+'"><div class="bsCenter"><b>'+Math.round(buyP)+'%</b>خرید</div></div>'+
        '<div class="bsLegend">'+
          '<div class="bsRow buy"><span>▲ فشار خرید</span><b class="buyPct">'+buyP.toFixed(1)+'%</b></div>'+
          '<div class="bsRow sell"><span>▼ فشار فروش</span><b class="sellPct">'+sellP.toFixed(1)+'%</b></div>'+
          '<div class="bsBar" style="--buy:'+buyP+'"></div>'+
          '<div style="font-size:11px;color:#8fb0c6;margin-top:4px;font-weight:800">حلقه سبز = خرید · حلقه قرمز = فروش · داده سفارش‌گیر</div>'+
        '</div>'+
      '</div>';
  }

  if(aim) aim.innerHTML = 'شانس موفقیت: <b>' + (card.getAttribute("data-success")||"—") + '</b><br>RR1: 1:' + (card.getAttribute("data-rr1")||"—") + ' · RR2: 1:' + (card.getAttribute("data-rr2")||"—");

  var schema = document.getElementById("cdSchemaBoard");
  if(!schema){
    var metricsEl = document.getElementById("cdMetrics");
    if(metricsEl && metricsEl.parentNode){
      schema = document.createElement("div");
      schema.id = "cdSchemaBoard";
      schema.className = "cdSchemaGrid";
      metricsEl.parentNode.insertBefore(schema, metricsEl.nextSibling);
    }
  }
  if(schema){
    var sc = card.getAttribute("data-success")||"—";
    var q = card.getAttribute("data-quality")||"—";
    var al = card.getAttribute("data-align")||"—";
    var entry = card.getAttribute("data-entry")||"—";
    var slv = card.getAttribute("data-sl")||"—";
    var t1 = card.getAttribute("data-tp1")||"—";
    var t2 = card.getAttribute("data-tp2")||"—";
    var r1 = card.getAttribute("data-rr1")||"—";
    var r2 = card.getAttribute("data-rr2")||"—";
    var sigColor = dtag==="LONG"?"#23e6a8":dtag==="SHORT"?"#ff4d73":"#ffd34e";
    schema.innerHTML =
      '<div class="cdSchemaCard" style="border-color:'+sigColor+'55"><div class="h">🚦 سیگنال نهایی</div><div class="b" style="color:'+sigColor+'">'+dtag+' · '+(bias||"خنثی")+'</div><div class="t">تصمیم هسته + فرصت‌محور V22</div></div>' +
      '<div class="cdSchemaCard"><div class="h">🎲 شانس مدل</div><div class="b">'+sc+'%</div><div class="t">کالیبره‌شده · نه تضمین سود</div></div>' +
      '<div class="cdSchemaCard"><div class="h">✨ کیفیت / همسویی</div><div class="b">'+q+' / '+al+'</div><div class="t">فیلتر نویز و انسجام چندتایم‌فریم</div></div>' +
      '<div class="cdSchemaCard"><div class="h">🟦 نقطه ورود</div><div class="b">'+entry+'</div><div class="t">محدوده ورود معتبر سیستم</div></div>' +
      '<div class="cdSchemaCard"><div class="h">🛑 حد ضرر</div><div class="b" style="color:#ff8fa3">'+slv+'</div><div class="t">ریسک ساختاری</div></div>' +
      '<div class="cdSchemaCard"><div class="h">🎯 اهداف</div><div class="b" style="color:#7dffc8">TP1 '+t1+'<br>TP2 '+t2+'</div><div class="t">RR 1:'+r1+' · 1:'+r2+'</div></div>';
  }

  var reason = document.getElementById("cdReasoning");
  if(reason) reason.textContent = card.getAttribute("data-tag") || "منطق تصمیم در کارت اصلی و Edge Suite موجود است.";
  var overview = document.getElementById("cdOverviewText");
  if(overview) overview.innerHTML = '<b>وضعیت:</b> ' + dtag + ' · <b>روند:</b> ' + (bias||"خنثی") +
      '<br><b>قیمت:</b> ' + price + ' USDT · <b>RR:</b> 1:' + (card.getAttribute("data-rr1")||"—") +
      ' / 1:' + (card.getAttribute("data-rr2")||"—");

  var trade = document.getElementById("cdTradePanel");
  if(trade){
    var entry = card.getAttribute("data-entry") || price, sl = card.getAttribute("data-sl") || "—", tp1 = card.getAttribute("data-tp1") || "—", tp2 = card.getAttribute("data-tp2") || "—";
    var longActive = dtag === "LONG", shortActive = dtag === "SHORT";
    trade.innerHTML =
      '<div class="aiDetailCard" style="border-color:' + (longActive?'rgba(74,222,128,.65)':'rgba(148,163,184,.16)') + '"><b style="color:#4ade80">🟢 LONG · ' + (longActive?'فعال':'غیرفعال در تصمیم فعلی') + '</b>' +
      '<div>' + (longActive ? ('ورود: '+entry+'<br>SL: '+sl+'<br>TP1: '+tp1+'<br>TP2: '+tp2) : 'این ارز در تصمیم نهایی فعلی SHORT/WAIT است؛ سطوح LONG در این نما اعمال نمی‌شوند.') + '</div></div>' +
      '<div class="aiDetailCard" style="border-color:' + (shortActive?'rgba(248,113,113,.65)':'rgba(148,163,184,.16)') + '"><b style="color:#f87171">🔴 SHORT · ' + (shortActive?'فعال':'غیرفعال در تصمیم فعلی') + '</b>' +
      '<div>' + (shortActive ? ('ورود: '+entry+'<br>SL: '+sl+'<br>TP1: '+tp1+'<br>TP2: '+tp2) : 'این ارز در تصمیم نهایی فعلی LONG/WAIT است؛ سطوح SHORT در این نما اعمال نمی‌شوند.') + '</div></div>' +
      '<div class="aiDetailCard"><b style="color:#facc15">⚖️ تصمیم نهایی TITAN</b><div style="font-size:18px;font-weight:950;color:' + (dtag==='LONG'?'#4ade80':dtag==='SHORT'?'#f87171':'#fde047') + '">' + dtag + '</div><div style="margin-top:4px">' + (bias||'خنثی') + ' · ' + (card.getAttribute("data-tag")||'—') + '</div></div>';
  }

  var full = document.getElementById("cdFullDetails");
  if(full){
    var clone = card.cloneNode(true);
    clone.removeAttribute("id");
    clone.style.margin = "0";
    var fscore = card.getAttribute("data-score") || "—";
    var falign = card.getAttribute("data-align") || "—";
    var fqual = card.getAttribute("data-quality") || "—";
    var fsucc = card.getAttribute("data-success") || "—";
    var fr1 = card.getAttribute("data-rr1") || "—";
    var fr2 = card.getAttribute("data-rr2") || "—";
    var frsi = card.getAttribute("data-rsi") || "—";
    var foi = card.getAttribute("data-oi") || "—";
    var ffund = card.getAttribute("data-fund") || "—";
    full.innerHTML = '<div class="cdVisualSummary">' +
      '<div class="cdVisualHero"><div><span class="cdVisualKicker">📌 خلاصه تخصصی دارایی</span><strong>'+base+' / USDT</strong><small>'+dtag+' · '+(bias||"خنثی")+' · '+(card.getAttribute("data-tag")||"—")+'</small></div><div class="cdVisualDecision '+(dtag==='LONG'?'long':dtag==='SHORT'?'short':'wait')+'">'+(dtag==='LONG'?'▲ LONG':dtag==='SHORT'?'▼ SHORT':'◆ WAIT')+'</div></div>' +
      '<div class="cdVisualGrid"><div class="cdVisualStat"><span>🎯 امتیاز</span><b>'+fscore+'<small>/100</small></b></div><div class="cdVisualStat"><span>🧭 همسویی</span><b>'+falign+'</b></div><div class="cdVisualStat"><span>🛡️ کیفیت</span><b>'+fqual+'</b></div><div class="cdVisualStat"><span>🎲 شانس مدل</span><b>'+fsucc+'<small>%</small></b></div><div class="cdVisualStat"><span>📐 RR1</span><b>1:'+fr1+'</b></div><div class="cdVisualStat"><span>🚀 RR2</span><b>1:'+fr2+'</b></div><div class="cdVisualStat"><span>📊 RSI</span><b>'+frsi+'</b></div><div class="cdVisualStat"><span>🌐 OI</span><b>'+foi+'</b></div></div>' +
      '<div class="cdVisualLevels"><div><span>🟦 ورود</span><b>'+entry+'</b></div><div><span>🛑 حد ضرر</span><b>'+sl+'</b></div><div><span>🟢 TP1</span><b>'+tp1+'</b></div><div><span>🚀 TP2</span><b>'+tp2+'</b></div></div>' +
      '<div class="cdVisualFlow"><span>🔎 داده واقعی</span><i></i><span>🧠 TITAN</span><i></i><span>🤖 AI</span><i></i><span>🎯 تصمیم</span></div></div>';
    var groups=[{title:"🪙 هویت و وضعیت بازار",keys:["ch","scoreRow","bar","scoreOrbit","tf"]},{title:"🎯 نقاط ورود و خروج",keys:["levels","dualLevels"]},{title:"📐 تحلیل تکنیکال و ساختار",keys:["panelTech"]},{title:"🧠 داده‌های تخصصی و بازار",keys:["miniGrid","table","gaugeRow"]}];
    var holder=document.createElement("div"); holder.className="detailVisualLegacy";
    var topChildren=Array.prototype.slice.call(clone.children||[]), used=new Set();
    groups.forEach(function(g){var sec=document.createElement("section");sec.className="detailVisualGroup";var h=document.createElement("div");h.className="detailVisualGroupTitle";h.textContent=g.title;sec.appendChild(h);topChildren.forEach(function(el){if(used.has(el))return;var cls=String(el.className||"");var match=g.keys.some(function(k){return cls.indexOf(k)>=0||(k==="table"&&el.tagName==="TABLE");});if(match){sec.appendChild(el);used.add(el);}});if(sec.children.length>1)holder.appendChild(sec);});
    topChildren.forEach(function(el){if(!used.has(el))holder.appendChild(el);});
    full.appendChild(holder);
  }

  try {
    var candles = await fetchCandles(symbol, "1h", 90);
    var cv = document.getElementById("cdCanvas");
    if(cv) drawCandleChart(cv, candles, (base || symbol) + " · ۱ ساعته");
  } catch(e) {
    console.warn("cd chart", e);
  }
  try {
    var fd = await fetch("/api/pattern-forecast?symbol=" + encodeURIComponent(symbol) + "&timeframe=1h&horizon=12", {cache:"no-store"}).then(function(r){return r.json();});
    var ft = document.getElementById("cdForecastText");
    if(fd && fd.ok && fd.forecast){
      if(ft) ft.textContent = fd.forecast.narrative || ("روند احتمالی: " + (fd.forecast.overall_bias||"—") + " · حرکت مورد انتظار " + (fd.forecast.expected_move_pct||0) + "%");
      var fc = document.getElementById("cdForecastCanvas");
      if(fc){ window._cdForecast = fd.forecast; drawForecastIntoCanvas(fc, fd.forecast); }
    } else if(ft) ft.textContent = "پیش‌بینی برای این لحظه داده کافی ندارد.";
  } catch(e){ var ft2=document.getElementById("cdForecastText"); if(ft2) ft2.textContent="پیش‌بینی کندل در دسترس نیست."; }
  try {
    var av = await fetch("/api/ai-votes", {cache:"no-store"}).then(function(r){return r.json();});
    var row = (av && av.board || []).find(function(x){return x.symbol===symbol;});
    var aiEl = document.getElementById("cdAIOpinion");
    if(aiEl && row){
      aiEl.innerHTML = '<b>' + (row.majority||"WAIT") + '</b> · اجماع ' + (row.agreement||0) + '% · وضعیت ' + (row.status||"—") +
        '<br><small>Gemini: ' + ((row.gemini||"—").toString().slice(0,220)) + '</small>';
    }
  } catch(e){}
}

function drawForecastIntoCanvas(cv, fc){
  try{
    var candles=fc.candles||[]; if(!candles.length) return;
    var dpr=window.devicePixelRatio||1,W=cv.clientWidth||320,H=220;
    cv.width=Math.floor(W*dpr);cv.height=Math.floor(H*dpr);
    var ctx=cv.getContext("2d");ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,W,H);
    var lo=Math.min.apply(null,candles.map(function(c){return +c.band_low;}));
    var hi=Math.max.apply(null,candles.map(function(c){return +c.band_high;})); if(lo===hi){lo*=.99;hi*=1.01;}
    var pad=12, x=function(i){return pad+i*(W-pad*2)/Math.max(1,candles.length-1)}, y=function(v){return pad+(1-(v-lo)/(hi-lo))*(H-pad*2)};
    ctx.strokeStyle="rgba(56,189,248,.18)";ctx.lineWidth=1;
    for(var g=0;g<4;g++){var gy=pad+g*(H-pad*2)/3;ctx.beginPath();ctx.moveTo(pad,gy);ctx.lineTo(W-pad,gy);ctx.stroke();}
    ctx.beginPath();candles.forEach(function(c,i){i?ctx.lineTo(x(i),y(+c.band_high)):ctx.moveTo(x(i),y(+c.band_high));});
    for(var j=candles.length-1;j>=0;j--)ctx.lineTo(x(j),y(+candles[j].band_low));ctx.closePath();ctx.fillStyle="rgba(56,189,248,.10)";ctx.fill();
    ctx.beginPath();candles.forEach(function(c,i){i?ctx.lineTo(x(i),y(+c.close)):ctx.moveTo(x(i),y(+c.close));});ctx.strokeStyle="#c084fc";ctx.lineWidth=2.4;ctx.stroke();
    candles.forEach(function(c,i){ctx.fillStyle=c.direction==="صعودی"?"#22c55e":c.direction==="نزولی"?"#ef4444":"#facc15";ctx.beginPath();ctx.arc(x(i),y(+c.close),3.2,0,Math.PI*2);ctx.fill();});
    ctx.fillStyle="#cbd5e1";ctx.font="11px Tahoma";ctx.fillText("پیش‌بینی "+(fc.overall_bias||"—")+" · "+candles.length+" کندل",pad,12);
  }catch(e){}
}

function initCoinDetailTabs(){
  document.querySelectorAll("#coinDetailTabs .coinDetailTab").forEach(function(btn){
    btn.addEventListener("click",function(){
      var id=btn.getAttribute("data-cdtab");
      document.querySelectorAll("#coinDetailTabs .coinDetailTab").forEach(function(b){b.classList.toggle("active",b===btn);});
      document.querySelectorAll(".coinDetailPanel").forEach(function(p){p.classList.toggle("active",p.getAttribute("data-cdpanel")===id);});
      if(id==="charts"){var cv=document.getElementById("cdCanvas");if(cv&&cv._candles)drawCandleChart(cv,cv._candles,window.currentTFSymbol||"");}
      if(id==="forecast"&&window._cdForecast){var fcv=document.getElementById("cdForecastCanvas");if(fcv)drawForecastIntoCanvas(fcv,window._cdForecast);}
    });
  });
}

function initTitanCoinNavigation(){
  var root=document.getElementById("coinNav"); if(!root) return;
  var rail=root.querySelector(".titanCoinRail");
  if(!rail) return;
  function applyFilter(filter){
    root.querySelectorAll(".glassFilter").forEach(function(b){
      b.classList.toggle("active",b.getAttribute("data-navfilter")===filter);
    });
    rail.querySelectorAll(".coinMiniCard").forEach(function(card){
      var tag=card.getAttribute("data-decision")||"WAIT";
      card.style.display=(filter==="all" || filter===tag)?"":"none";
    });
  }
  root.querySelectorAll(".glassFilter").forEach(function(btn){
    btn.addEventListener("click",function(){applyFilter(btn.getAttribute("data-navfilter")||"all");});
  });
  applyFilter("all");
}

function jumpToCoin(tv, symbol){
  window.currentTFSymbol = symbol || window.currentTFSymbol;
  window._detailTv = tv || window._detailTv;
  var card = safeEl("card-" + tv) || qs('.card[data-symbol="' + symbol + '"]');
  if(card) openCoinDetailFromCard(card);
  else scrollToCard(tv);
}

window.jumpToCoin = jumpToCoin;
window.scrollToCard = scrollToCard;
window.closeCoinDetail = closeCoinDetail;
window.openTFWindow = openTFWindow;
window.closeTFWindow = closeTFWindow;
window.loadAllCoinCharts = loadAllCoinCharts;
window.loadVisualPerformance = loadVisualPerformance;
window.refreshGemini = refreshGemini;
window.refreshAdvanced = refreshAdvanced;
window.runBacktest = runBacktest;
window.runWalkForward = runWalkForward;
window.loadEdgeTerminal = loadEdgeTerminal;
window.runProLab = runProLab;
window.openM = openM;
window.closeM = closeM;

/* ---------- TF gauge ---------- */
function openTFWindow(symbol){
  window.currentTFSymbol = symbol || window.currentTFSymbol || "BTC/USDT";
  var m = document.getElementById("tfWindow");
  if(m){
    m.style.display = "flex";
    m.style.zIndex = "1300";
  }
  try { loadTFGauge(); } catch(e){ console.warn(e); }
}
function closeTFWindow(){
  var m = safeEl("tfWindow");
  if(m) m.style.display = "none";
}
async function loadTFGauge(){
  var box = safeEl("tfGaugeBox");
  var title = safeEl("tfModalTitle");
  if(box) box.innerHTML = "<div style='color:#94a3b8;grid-column:1/-1'>در حال دریافت عقربه‌های گرافیکی…</div>";
  try {
    var sym = window.currentTFSymbol || "BTC/USDT";
    if(title) title.textContent = "عقربه‌های تایم‌فریم · " + sym;
    var d = await fetch("/api/tf-gauge?symbol=" + encodeURIComponent(sym), { cache: "no-store" }).then(function(r){ return r.json(); });
    if(!box) return;
    if(d && d.ok && d.timeframes && d.timeframes.length){
      box.innerHTML = d.timeframes.map(function(x){
        var sc = Number(x.score)||0;
        var col = sc>=60 ? "#4ade80" : sc<=40 ? "#f43f5e" : "#fbbf24";
        var emoji = sc>=60 ? "🚀" : sc<=40 ? "🔻" : "⚖️";
        var label = sc>=60 ? "صعودی" : sc<=40 ? "نزولی" : "خنثی";
        var mode = sc>=60 ? "▲ خرید" : sc<=40 ? "▼ فروش" : "◆ انتظار";
        var modeCol = sc>=60 ? "#4ade80" : sc<=40 ? "#f43f5e" : "#fbbf24";
        return '<div class="tfGaugeCard">' +
          '<div style="font-weight:900;color:#e2e8f0">' + emoji + " " + x.name + "</div>" +
          '<div class="ringGauge" style="--gv:' + sc + ";--gcol:" + col + '"><span style="color:' + col + '">' + sc + "</span></div>" +
          '<div style="font-weight:900;color:' + modeCol + ';margin-bottom:4px;font-size:15px">' + mode + "</div>" +
          '<div style="font-weight:800;color:' + col + ';margin-bottom:6px">' + label + " · " + sc + "/100</div>" +
          '<div class="scoreOrbit">' +
            '<div class="orbitItem"><small>روند</small><b style="color:#38bdf8">' + x.trend + "</b></div>" +
            '<div class="orbitItem"><small>مومنتوم</small><b style="color:#c084fc">' + x.momentum + "</b></div>" +
            '<div class="orbitItem"><small>حجم</small><b style="color:#fbbf24">' + x.volume + "</b></div>" +
            '<div class="orbitItem"><small>همسویی</small><b style="color:#4ade80">' + x.alignment + "</b></div>" +
          "</div></div>";
      }).join("");
    } else {
      box.innerHTML = "<div style='grid-column:1/-1;color:#fbbf24'>داده تایم‌فریم هنوز آماده نیست… <button class='btn' style='margin-top:10px' onclick='loadTFGauge()'>🔄 دریافت دوباره</button></div>";
      setTimeout(function(){ if(safeEl("tfWindow") && safeEl("tfWindow").style.display !== "none") loadTFGauge(); }, 1000);
    }
  } catch(e) {
    if(box) box.innerHTML = "<div style='grid-column:1/-1;color:#f43f5e'>خطا: " + (e.message||e) + "</div>";
  }
}

/* ---------- settings modal ---------- */
function openM(){ var m = safeEl("modal"); if(m) m.style.display = "flex"; }
function closeM(){ var m = safeEl("modal"); if(m) m.style.display = "none"; }

/* ---------- other API buttons ---------- */
async function loadEdgeTerminal(){
  var msg = safeEl("edge-msg"), out = safeEl("edge-terminal");
  try {
    if(msg) msg.textContent = "در حال خواندن Decision Terminal…";
    var sym = window.currentTFSymbol || "BTC/USDT";
    var d = await fetch("/api/titan-terminal?symbol=" + encodeURIComponent(sym), { cache: "no-store" }).then(function(r){ return r.json(); });
    if(d && d.ok){
      var t = d.terminal || {};
      setText("edge-conf", (t.confluence!=null?t.confluence:0));
      setText("edge-meta", (t.meta_probability!=null?t.meta_probability:0) + "%");
      setText("edge-ai", (t.ai_consensus!=null?t.ai_consensus:0) + "%");
      setText("edge-risk", t.final_state || t.signal_tag || "--");
      if(out) out.textContent = JSON.stringify(t, null, 2);
      if(msg) msg.textContent = "ترمینال آماده · " + sym;
    } else if(msg) msg.textContent = (d && d.error) || "داده‌ای موجود نیست";
  } catch(e) { if(msg) msg.textContent = "خطا در Decision Terminal"; }
}
async function runProLab(){
  var msg = safeEl("edge-msg"), out = safeEl("edge-terminal");
  try {
    if(msg) msg.textContent = "در حال اجرای Pro Lab…";
    var sym = window.currentTFSymbol || "BTC/USDT";
    var d = await fetch("/api/pro-lab?symbol=" + encodeURIComponent(sym) + "&timeframe=1h&limit=800", { cache: "no-store" }).then(function(r){ return r.json(); });
    if(out) out.textContent = JSON.stringify(d, null, 2);
    if(msg) msg.textContent = (d && d.ok) ? "Pro Lab تکمیل شد" : "Pro Lab داده کافی ندارد";
  } catch(e) { if(msg) msg.textContent = "خطا در Pro Lab"; }
}

async function refreshScalpWindow(){
  try{
    var grid = document.getElementById("scalp30Grid");
    if(!grid) return;
    var d = await fetch("/api/scalp-window",{cache:"no-store"}).then(function(r){return r.json();});
    if(!d || !d.ok){
      grid.innerHTML = '<div style="color:#f43f5e;font-size:12px">خطا در تحلیل نیم‌ساعته</div>';
      return;
    }
    var rows = (d.rows||[]).slice(0,2);
    if(!rows.length){
      grid.innerHTML = '<div style="color:#8fa7bb;font-size:12px;font-weight:800">الان فرصت قوی ۳۰–۶۰ دقیقه‌ای نیست — صبر منطقی است</div>';
      return;
    }
    grid.innerHTML = rows.map(function(r){
      var cls = r.side==="LONG"?"long":"short";
      var lab = r.side==="LONG"?"▲ لانگ اهرمی":"▼ شورت اهرمی";
      return '<div class="scalpChip '+cls+'">'+
        '<div class="s1">'+(r.base||r.symbol)+'</div>'+
        '<div class="s2 '+cls+'">'+lab+' · '+Math.round(r.confidence||0)+'%</div>'+
        '<div class="s3">⏱ '+(r.hold_minutes||30)+'–'+(r.max_hold_minutes||60)+' دقیقه<br>'+(r.reason||'')+'</div>'+
        '</div>';
    }).join("");
  }catch(e){
    var g=document.getElementById("scalp30Grid");
    if(g) g.innerHTML = '<div style="color:#f43f5e;font-size:12px">'+(e.message||e)+'</div>';
  }
}
window.refreshScalpWindow = refreshScalpWindow;

async function refreshLive(){
  var priceNodes = [];
  qsa(".card[data-symbol], .ticker[data-symbol], .assetCard[data-symbol], .coinMiniCard[data-symbol]").forEach(function(card){
    var sym = card.getAttribute("data-symbol");
    if(!sym) return;
    var el = qs("[data-price]", card) || qs(".tickerPrice", card) || qs(".coinMiniPriceValue", card) || qs(".assetPrice b", card);
    if(el) priceNodes.push({ symbol: sym, el: el, card: card });
  });
  try {
    var d = await fetch("/api/realtime-analysis", { cache: "no-store" }).then(function(r){ return r.json(); });
    if(!d || !d.ok){
      // fallback to simple live prices
      if(!priceNodes.length) return;
      var d2 = await fetch("/api/live-prices?symbols=" + encodeURIComponent(priceNodes.map(function(x){return x.symbol;}).join(",")), {cache:"no-store"}).then(function(r){return r.json();});
      if(!d2||!d2.ok) return;
      priceNodes.forEach(function(x){
        var n = Number((d2.prices||{})[x.symbol]);
        if(isFinite(n)&&n>0){ x.el.textContent = (n>=1000?n.toLocaleString("en-US",{maximumFractionDigits:2}):n.toLocaleString("en-US",{maximumFractionDigits:8})); }
      });
      return;
    }
    var by = {};
    (d.rows||[]).forEach(function(r){ by[r.symbol]=r; });
    priceNodes.forEach(function(x){
      var r = by[x.symbol];
      if(!r || !(r.price>0)) return;
      var n = Number(r.price);
      var prev = parseFloat(String(x.el.textContent||"").replace(/[^0-9.\-]/g, ""));
      var txt = (n>=1000?n.toLocaleString("en-US",{maximumFractionDigits:2}):n.toLocaleString("en-US",{maximumFractionDigits:8}));
      if(x.el.classList && x.el.classList.contains("coinMiniPriceValue")) x.el.textContent = txt;
      else if(x.el.tagName==="B") x.el.textContent = txt;
      else x.el.innerHTML = txt + (x.el.innerHTML.indexOf("USDT")>=0 ? " <small>USDT</small>" : "");
      if(isFinite(prev) && prev>0){
        x.el.classList.remove("flashUp","flashDown");
        void x.el.offsetWidth;
        if(n>prev*1.00005) x.el.classList.add("flashUp");
        else if(n<prev*0.99995) x.el.classList.add("flashDown");
      }
      if(x.card){
        if(r.change_pct!=null) x.card.setAttribute("data-live-chg", r.change_pct);
        // Keep the modal/detail source attributes synchronized with the same
        // live snapshot used by the price display.
        if(r.price>0) x.card.setAttribute("data-price", r.price);
        if(r.entry>0) x.card.setAttribute("data-entry", r.entry);
        if(r.stop_loss>0) x.card.setAttribute("data-sl", r.stop_loss);
        if(r.tp1>0) x.card.setAttribute("data-tp1", r.tp1);
        if(r.tp2>0) x.card.setAttribute("data-tp2", r.tp2);
        if(r.rr_tp1>0) x.card.setAttribute("data-rr1", r.rr_tp1);
        if(r.rr_tp2>0) x.card.setAttribute("data-rr2", r.rr_tp2);
        x.card.setAttribute("data-live-sync", r.live_sync ? "1" : "0");
      }
    });
    var st = document.getElementById("rtStatus");
    var br = document.getElementById("rtBreadth");
    var ld = document.getElementById("rtLeaders");
    var b = d.breadth||{};
    var live = d.live||{};
    if(st) st.textContent = (live.status||"LIVE") + (live.median_age_ms!=null ? (" · "+Math.round(live.median_age_ms/1000)+"s") : "") + " · " + (live.websocket?"WS+REST":"REST");
    if(br) br.innerHTML = '<span style="color:#7dffc8">▲ '+((b.up)||0)+'</span> · <span style="color:#ffb0c2">▼ '+((b.down)||0)+'</span> · <span style="color:#ffe9a3">◆ '+((b.flat)||0)+'</span>';
    if(ld){
      ld.innerHTML = (d.leaders||[]).slice(0,4).map(function(r){
        var cls = (r.change_pct||0)>=0 ? "up" : "down";
        var ch = (r.change_pct||0);
        var sign = ch>=0?"+":"";
        return '<span class="rtChip '+cls+'">'+(r.symbol||"").replace("/USDT","")+' '+sign+ch.toFixed(2)+'%</span>';
      }).join("") || "بدون حرکت تند";
    }
  } catch(e) {}
}
async function refreshPulse(){
  try {
    var d = await fetch("/api/market-pulse", { cache: "no-store" }).then(function(r){ return r.json(); });
    if(!d || !d.ok) return;
    var p = d.pulse || {}, b = p.breadth || {}, l = p.leader || {};
    setText("pulse-regime", p.regime || "--");
    setText("pulse-score", (p.avg_score != null ? p.avg_score : "--") + "/100");
    setText("pulse-breadth", (b.bullish||0) + " 🟢 · " + (b.bearish||0) + " 🔴 · " + (b.neutral||0) + " 🟡");
    setText("pulse-leader", l.symbol ? (l.symbol + " · " + (l.quality||0)) : "--");
    setText("pulse-time", p.timestamp || "--");
  } catch(e) {}
}
async function refreshGemini(){
  try {
    var el = safeEl("geminiRefreshState");
    if(el) el.textContent = "در حال دریافت تحلیل Gemini…";
    var d = await fetch("/api/gemini-analysis?refresh=1", { cache: "no-store" }).then(function(r){ return r.json(); });
    var box = safeEl("geminiAnalysis");
    var st = safeEl("geminiStatus");
    if(d && d.ok){
      if(box) box.textContent = d.analysis || d.error || "تحلیل خالی بود";
      if(st) st.textContent = d.analysis ? "تحلیل آماده" : "داده‌ای دریافت نشد";
      if(el) el.textContent = d.ready ? "Gemini تحلیل جدید تولید کرد" : (d.available ? "Gemini متصل است ولی پاسخی آماده نیست" : "کلید Gemini تنظیم نشده است");
    } else if(el) el.textContent = "Gemini در دسترس نیست";
  } catch(e) {
    var el2 = safeEl("geminiRefreshState");
    if(el2) el2.textContent = "خطا: " + (e.message||e);
  }
}
async function refreshAdvanced(){
  try {
    var d = await fetch("/api/advanced-metrics", { cache: "no-store" }).then(function(r){ return r.json(); });
    if(!d || !d.ok) return;
    var m = d.metrics || {}, l = m.live || {}, h = m.historical || {}, p = m.paper || {}, q = m.data_quality || {};
    setText("adv-live", (l.status||"--") + " · " + (l.median_age_ms != null ? l.median_age_ms : "-") + "ms");
    setText("adv-hist", (h.win_rate||0) + "% · " + (h.wins||0) + "W/" + (h.losses||0) + "L");
    setText("adv-paper", (p.win_rate||0) + "% · PF=" + (p.profit_factor != null ? p.profit_factor : "-") + " · O=" + (p.open||0));
    setText("adv-quality", (q.healthy||0) + " / " + (q.samples||0));
  } catch(e) {}
}
async function runBacktest(){
  var out = safeEl("adv-result");
  if(out) out.textContent = "در حال اجرای بک‌تست…";
  try {
    var sym = window.currentTFSymbol || "BTC/USDT";
    var j = await fetch("/api/backtest?symbol=" + encodeURIComponent(sym) + "&timeframe=1h&limit=800").then(function(r){ return r.json(); });
    if(out) out.textContent = JSON.stringify(j, null, 2);
  } catch(e) { if(out) out.textContent = String(e); }
}
async function runWalkForward(){
  var out = safeEl("adv-result");
  if(out) out.textContent = "در حال اجرای Walk-Forward…";
  try {
    var sym = window.currentTFSymbol || "BTC/USDT";
    var j = await fetch("/api/walk-forward?symbol=" + encodeURIComponent(sym) + "&timeframe=1h&limit=800&train=250&test=80").then(function(r){ return r.json(); });
    if(out) out.textContent = JSON.stringify(j, null, 2);
  } catch(e) { if(out) out.textContent = String(e); }
}

function performanceScore(m){
  m = m || {};
  var wr = Number(m.win_rate) || 0;
  var pf = Number(m.profit_factor);
  var exp = Number(m.expectancy) || 0;
  var s = wr * 0.45 + Math.min(100, Math.max(0, (isFinite(pf) ? pf : 0) * 50)) * 0.30 + Math.min(100, Math.max(0, 50 + exp * 50)) * 0.25;
  return Math.max(0, Math.min(100, s));
}
function drawEquityVisual(values){
  var c = safeEl("equityVisual"); if(!c) return;
  var ctx = c.getContext("2d"), dpr = window.devicePixelRatio||1, w = c.clientWidth||500, h = c.clientHeight||220;
  c.width = w*dpr; c.height = h*dpr; ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle = "#ffffff18"; ctx.lineWidth = 1;
  for(var i=1;i<5;i++){ var y=i*h/5; ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
  if(!values || !values.length) return;
  var min = Math.min(0, Math.min.apply(null, values)), max = Math.max(0, Math.max.apply(null, values));
  if(min===max){ min-=1; max+=1; }
  function x(i){ return 8 + i*(w-16)/Math.max(1, values.length-1); }
  function y(v){ return h-18 - (v-min)/(max-min)*(h-35); }
  ctx.beginPath();
  values.forEach(function(v,i){ if(i) ctx.lineTo(x(i),y(v)); else ctx.moveTo(x(i),y(v)); });
  ctx.strokeStyle = "#38bdf8"; ctx.lineWidth = 2.5; ctx.stroke();
}
function drawWLVisual(wins, losses, neutral){
  var c = safeEl("wlVisual"); if(!c) return;
  var ctx = c.getContext("2d"), dpr = window.devicePixelRatio||1, w = c.clientWidth||300, h = c.clientHeight||220;
  c.width = w*dpr; c.height = h*dpr; ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.clearRect(0,0,w,h);
  var vals = [Math.max(0,wins), Math.max(0,losses), Math.max(0,neutral)];
  var total = Math.max(1, vals[0]+vals[1]+vals[2]);
  var cx = w/2, cy = h/2-8, r = Math.min(w,h)*0.32, a = -Math.PI/2;
  var colors = ["#4ade80","#f43f5e","#64748b"];
  vals.forEach(function(v,i){ var da=v/total*Math.PI*2; ctx.beginPath(); ctx.moveTo(cx,cy); ctx.arc(cx,cy,r,a,a+da); ctx.closePath(); ctx.fillStyle=colors[i]; ctx.fill(); a+=da; });
  ctx.beginPath(); ctx.arc(cx,cy,r*0.58,0,Math.PI*2); ctx.fillStyle="#071020"; ctx.fill();
  ctx.fillStyle="#eef2ff"; ctx.font="900 18px Tahoma"; ctx.textAlign="center";
  ctx.fillText((vals[0]/total*100).toFixed(1)+"%", cx, cy+6);
}
async function loadVisualPerformance(){
  var note = safeEl("visNote");
  if(note) note.textContent = "در حال تحلیل عملکرد…";
  var sym = window.currentTFSymbol || "BTC/USDT";
  var tfs = ["15m","1h","4h","1d"];
  try {
    var results = {};
    for(var i=0;i<tfs.length;i++){
      try {
        results[tfs[i]] = await fetch("/api/performance?symbol="+encodeURIComponent(sym)+"&timeframe="+tfs[i]+"&limit=600",{cache:"no-store"}).then(function(r){return r.json();});
      } catch(err){ results[tfs[i]] = {ok:false}; }
    }
    var base = results["1h"] || {};
    var m = (base.backtest && base.backtest.metrics) || base.historical || {};
    var hist = base.historical || {};
    var wr = Number(m.win_rate || hist.win_rate || 0);
    var wins = Number(m.wins || hist.wins || 0);
    var losses = Number(m.losses || hist.losses || 0);
    var neutral = Number(m.neutral_trades || hist.neutral || 0);
    var score = performanceScore(m);
    setText("visWR", wr.toFixed(1)+"%");
    var ring = safeEl("wrRing"); if(ring) ring.style.setProperty("--v", Math.max(0, Math.min(100, wr)));
    setText("visWL", wins+" W / "+losses+" L");
    setText("visScore", score.toFixed(0)+"/100");
    var sb = safeEl("visScoreBar"); if(sb) sb.style.width = score+"%";
    setText("visExp", (Number(m.expectancy)||0).toFixed(3)+"%");
    setText("visPF", "PF: " + (m.profit_factor==null?"—":Number(m.profit_factor).toFixed(2)));
    setText("visDD", (Number(m.max_drawdown)||0).toFixed(2)+"%");
    var oos = (base.walk_forward && base.walk_forward.professional && base.walk_forward.professional.out_of_sample && base.walk_forward.professional.out_of_sample.status) || "—";
    setText("visOOS", "OOS: "+oos);
    var tfEl = safeEl("tfVisual");
    if(tfEl){
      tfEl.innerHTML = "";
      tfs.forEach(function(tf){
        var d = results[tf] || {};
        var mm = (d.backtest && d.backtest.metrics) || {};
        var sc = performanceScore(mm);
        var wr2 = Number(mm.win_rate)||0;
        var div = document.createElement("div");
        div.className = "tfBox";
        div.innerHTML = "<b>"+tf+"</b><div style='font-size:18px;font-weight:900;margin-top:4px'>"+sc.toFixed(0)+"/100</div><small style='color:#94a3b8'>WR "+wr2.toFixed(1)+"%</small><div class='tfBar'><i style='width:"+sc+"%'></i></div>";
        tfEl.appendChild(div);
      });
    }
    var rs = (base.backtest && base.backtest.return_series_pct) || [];
    var equity = [0], eq = 1;
    (rs||[]).forEach(function(x){
      var r = Number(x);
      if(!isFinite(r)) return;
      eq *= (1 + r/100);
      equity.push((eq-1)*100);
    });
    drawEquityVisual(equity.length > 1 ? equity : [0]);
    drawWLVisual(wins, losses, neutral);
    if(note) note.textContent = "منبع: بک‌تست برای "+sym;
  } catch(e) {
    if(note) note.textContent = "خطا: "+(e.message||e);
  }
}

async function refreshScanTelemetry(){
  try{
    var j=await fetch("/api/scan-progress",{cache:"no-store"}).then(function(r){return r.json();});
    var p=(j&&j.progress)||{};
    var pct=Math.max(0,Math.min(100,Number(p.percent)||0));
    var bar=safeEl("scanBar"); if(bar) bar.style.width=pct+"%";
    setText("scanPct",pct.toFixed(0)+"%");
    setText("scanPhase",p.message||p.phase||"آماده");
    var finished=Number(p.last_success_at||p.finished_at||0);
    if(finished){
      var d=new Date(finished*1000);
      setText("scanTime","آخرین اسکن: "+d.toLocaleString("fa-IR"));
    } else if(p.status==="running") setText("scanTime","اسکن جدید در حال اجراست…");
    else setText("scanTime","آخرین اسکن: ثبت نشده");
    var age=(j&&j.progress&&j.progress.cache_age_sec!=null)?Number(j.progress.cache_age_sec):null;
    if(age!=null) setText("scanAge",age<60?"داده: "+age.toFixed(0)+" ثانیه پیش":"داده: "+(age/60).toFixed(1)+" دقیقه پیش");
    var box=safeEl("scanTelemetry"); if(box){ box.style.opacity=(p.status==="running"?"1":".94"); }
  }catch(e){}
}
function refreshPerformanceLearning(){
  var sym=window.currentTFSymbol||"";
  fetch("/api/performance-learning"+(sym?"?symbol="+encodeURIComponent(sym):""),{cache:"no-store"}).then(function(r){return r.json();}).then(function(j){
    if(!j||!j.ok)return;
    var s=j.summary||{};
    setText("learnTotal",String(s.total||0)); setText("learnWR",s.directional_win_rate==null?"—":s.directional_win_rate+"%"); setText("learnPending",String(s.pending||0)); setText("learnWaitMiss",String(s.wait_missed||0));
    var tb=safeEl("learnTable"); if(!tb)return;
    var rows=(j.matrix&&j.matrix.items)||[];
    tb.innerHTML=rows.slice(0,24).map(function(x){return "<tr><td>"+(x.symbol||"")+(x.timeframe?" · "+x.timeframe:"")+"</td><td>"+(x.decision||"")+"</td><td>"+(x.samples||0)+"</td><td>"+(x.win_rate==null?"—":x.win_rate+"%")+"</td><td>"+(x.reliability||50)+"</td><td>"+(x.sample_status||"")+(x.wait_missed?" · miss "+x.wait_missed:"")+"</td></tr>";}).join("")||"<tr><td colspan='6'>هنوز نمونه تاریخی کافی ثبت نشده است.</td></tr>";
  }).catch(function(){});
}

/* ---------- fast bootstrap: show cached dashboard first, then refresh once data is ready ---------- */
function pollDashboardReady(){
  try {
    if(document.querySelectorAll(".card[data-symbol]").length > 0) return;
    fetch("/api/dashboard-status", {cache:"no-store"}).then(function(r){return r.json();}).then(function(d){
      if(d && d.ready){ window.location.reload(); }
      else if(d && d.refreshing){ setTimeout(pollDashboardReady, 1800); }
    }).catch(function(){ setTimeout(pollDashboardReady, 2500); });
  } catch(e){ setTimeout(pollDashboardReady, 2500); }
}

/* ---------- boot: charts + live first ---------- */
function bootUI(){
  try{initTitanCoinNavigation();}catch(e){}
  try { initCoinDetailTabs(); } catch(e){ console.warn(e); }
  try { loadAllCardCharts(); } catch(e){ console.warn(e); }
  // Draw server-rendered forecast paths
  try {
    qsa(".patternPanel").forEach(function(p){
      var id = p.id || "";
      var tv = id.replace("pattern-","");
      if(!tv) return;
      // fetch once for chart
      var card = document.getElementById("card-" + tv);
      var sym = card ? card.getAttribute("data-symbol") : null;
      if(sym) setTimeout(function(){ refreshPatternForecast(sym, tv); }, 1200);
    });
  } catch(e){}
  // First paint is kept lightweight. Heavy analytics start only after the UI is visible.
  try { setTimeout(loadAllCoinCharts, 900); } catch(e){}
  try { setTimeout(refreshLive, 50); } catch(e){}
  try { setTimeout(refreshScalpWindow, 400); } catch(e){}
  try { setInterval(refreshScalpWindow, 45000); } catch(e){}
  try { setTimeout(refreshPulse, 250); } catch(e){}
  try { setTimeout(refreshAdvanced, 700); } catch(e){}
  try { setTimeout(refreshScanTelemetry, 200); setInterval(refreshScanTelemetry, 2500); } catch(e){}
  try { setTimeout(refreshPerformanceLearning, 1200); setInterval(refreshPerformanceLearning, 30000); } catch(e){}
  try { setTimeout(loadVisualPerformance, 2500); } catch(e){}
  try { setTimeout(pollDashboardReady, 1200); } catch(e){}

  try {
    var sb = document.getElementById("sfxToggleBtn");
    if(sb && window.TitanSFX){
      var on = TitanSFX.isEnabled();
      sb.textContent = on ? "🔊 صدا" : "🔇 قطع";
    }
  } catch(e){}

  setInterval(refreshLive, 2500);
  setInterval(refreshPulse, 15000);
  setInterval(refreshAdvanced, 30000);
}

if(document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", bootUI);
} else {
  bootUI();
}

window.addEventListener("resize", function(){
  qsa(".tv-fallback").forEach(function(cv){
    if(cv.style.display !== "none" && cv._candles) drawCandleChart(cv, cv._candles, cv._title || "");
  });
});

/* event delegation so chips/buttons always work */
document.addEventListener("click", function(ev){
  var t = ev.target;
  if(!t) return;
  var chip = t.closest ? t.closest(".coinMiniCard, .coinChip, [data-jump]") : null;
  if(chip){
    ev.preventDefault();
    var tv = chip.getAttribute("data-jump") || chip.getAttribute("data-tv");
    var sym = chip.getAttribute("data-symbol");
    if(!sym && tv){
      var card = safeEl("card-" + tv);
      if(card) sym = card.getAttribute("data-symbol");
    }
    jumpToCoin(tv, sym);
    return;
  }
});


/* ===== TITAN SFX: Web-Audio UI sounds (no external files) ===== */
window.TitanSFX = (function(){
  var ctx = null, unlocked = false, enabled = true, lastTs = 0;
  function ensure(){
    if(!ctx){
      var AC = window.AudioContext || window.webkitAudioContext;
      if(!AC) return null;
      ctx = new AC();
    }
    if(ctx.state === "suspended"){
      try { ctx.resume(); } catch(e){}
    }
    unlocked = true;
    return ctx;
  }

  function tone(freq, dur, type, vol, slide){
    if(!enabled) return;
    var c = ensure();
    if(!c) return;
    var now = c.currentTime;
    var o = c.createOscillator();
    var g = c.createGain();
    o.type = type || "sine";
    o.frequency.setValueAtTime(freq, now);
    if(slide){
      o.frequency.linearRampToValueAtTime(slide, now + dur);
    }
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol || 0.06), now + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    o.connect(g); g.connect(c.destination);
    o.start(now);
    o.stop(now + dur + 0.02);
  }

  function play(kind){
    if(!enabled) return;
    var t = Date.now();
    if(t - lastTs < 35) return; // debounce spam
    lastTs = t;
    try {
      if(kind === "click"){
        tone(520, 0.05, "triangle", 0.045);
      } else if(kind === "tab"){
        tone(380, 0.06, "sine", 0.04);
        setTimeout(function(){ tone(520, 0.05, "sine", 0.03); }, 40);
      } else if(kind === "open"){
        tone(280, 0.09, "sine", 0.05, 520);
      } else if(kind === "long"){
        tone(360, 0.08, "triangle", 0.05);
        setTimeout(function(){ tone(540, 0.1, "triangle", 0.045); }, 55);
      } else if(kind === "short"){
        tone(480, 0.08, "sawtooth", 0.035);
        setTimeout(function(){ tone(300, 0.1, "triangle", 0.04); }, 55);
      } else if(kind === "wait"){
        tone(400, 0.07, "sine", 0.035);
      } else if(kind === "success"){
        tone(440, 0.07, "sine", 0.05);
        setTimeout(function(){ tone(660, 0.1, "sine", 0.045); }, 70);
      } else if(kind === "hover"){
        tone(700, 0.025, "sine", 0.018);
      } else {
        tone(480, 0.04, "sine", 0.03);
      }
    } catch(e){}
  }

  function setEnabled(v){
    enabled = !!v;
  }

  function toggle(){
    setEnabled(!enabled);
    play(enabled ? "success" : "click");
    return enabled;
  }

  // Unlock audio on first user gesture (required by browsers)
  ["pointerdown","touchstart","keydown"].forEach(function(ev){
    window.addEventListener(ev, function once(){
      ensure();
      window.removeEventListener(ev, once, true);
    }, true);
  });

  return { play: play, toggle: toggle, setEnabled: setEnabled, isEnabled: function(){ return enabled; }, unlock: ensure };
})();

/* Wire sounds to common UI actions */
(function(){
  function decisionSound(el){
    if(!el || !window.TitanSFX) return;
    var d = (el.getAttribute("data-decision") || el.getAttribute("data-side") || "").toUpperCase();
    if(d === "LONG") TitanSFX.play("long");
    else if(d === "SHORT") TitanSFX.play("short");
    else if(d === "WAIT") TitanSFX.play("wait");
    else TitanSFX.play("open");
  }

  document.addEventListener("click", function(ev){
    if(!window.TitanSFX) return;
    var t = ev.target;
    if(!t || !t.closest) return;
    var card = t.closest(".coinMiniCard, .assetCard, .ticker, [data-jump]");
    if(card){
      decisionSound(card);
      return;
    }
    var tab = t.closest(".sideBtn, .mainTab, .coinDetailTab, .assetTools button");
    if(tab){
      TitanSFX.play("tab");
      return;
    }
    var btn = t.closest(".glassBtn, button, a.glassBtn");
    if(btn){
      TitanSFX.play("click");
    }
  }, true);

  // Subtle hover ticks only on fine pointers (desktop)
  if(window.matchMedia && window.matchMedia("(hover:hover) and (pointer:fine)").matches){
    var hoverLast = 0;
    document.addEventListener("mouseover", function(ev){
      if(!window.TitanSFX || !TitanSFX.isEnabled()) return;
      var t = ev.target;
      if(!t || !t.closest) return;
      var el = t.closest(".ticker, .assetCard, .coinMiniCard, .glassBtn, .sideBtn");
      if(!el) return;
      var now = Date.now();
      if(now - hoverLast < 120) return;
      hoverLast = now;
      TitanSFX.play("hover");
    }, true);
  }
})();

})();

/* Ensure colored borders on cards even if class missing */
(function(){
  function paintBorders(){
    var nodes = document.querySelectorAll(".ticker, .assetCard, .coinMiniCard");
    nodes.forEach(function(el, i){
      var has = false;
      for(var h=0;h<12;h++){ if(el.classList.contains("coinHue"+h)){ has=true; break; } }
      if(!has) el.classList.add("coinHue" + (i % 12));
    });
  }
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", paintBorders);
  else paintBorders();
  setTimeout(paintBorders, 800);
})();

</script></body></html>

</body></html>
'''

# ============================================================
# TITAN V10.5 — COGNITIVE NEXUS / EVIDENCE GRAPH
# ------------------------------------------------------------------
# Final arbitration layer above the existing V10 engine.
# Analysis-only: no live order execution and no fabricated market data.
#
# It connects:
# live freshness -> multi-TF spine -> structure/regime -> derivatives
# -> precision -> forecast/patterns -> AI ensemble -> historical outcomes
# -> neural V9 -> Cognitive Nexus -> one canonical decision.
# ============================================================

CNS_VERSION = "TITAN-CNS-10.6-BALANCED"
CNS_HISTORY_LIMIT = 320
CNS_MIN_HISTORY = 5
CNS_PROMOTE_MIN_STRENGTH = 0.40
CNS_PROMOTE_MIN_MARGIN = 0.07
CNS_PROMOTE_MIN_QUALITY = 48.0
CNS_PROMOTE_MIN_DQ = 50.0
CNS_PROMOTE_MIN_NEURAL = 42.0
CNS_PROMOTE_MIN_RR = 1.02
CNS_HARD_CONFLICT = 0.85


class TitanCognitiveNexusV10:
    """Evidence-graph arbitration with Bayesian historical shrinkage.

    Each evidence source is normalized to [-1,+1].
    Historical win rates use Beta(2,2) shrinkage so small samples cannot
    become artificial 0%/100% certainty. Historical data calibrates fresh
    evidence; it never creates a trade by itself.
    """

    TF_WEIGHTS = {"15m": 0.15, "1h": 0.28, "4h": 0.30, "1d": 0.27}

    def _beta_wr(self, wins: float, losses: float) -> float:
        wins = max(0.0, float(wins))
        losses = max(0.0, float(losses))
        return ((wins + 2.0) / (wins + losses + 4.0)) * 100.0

    def _history(self, symbol: str, direction: str, timeframe: str = "") -> dict[str, Any]:
        """Recency-aware historical evidence from evaluated forecasts."""
        out = {
            "samples": 0, "wins": 0, "losses": 0,
            "win_rate": 50.0, "recent_wr": 50.0,
            "confidence": 0.0, "source": "sqlite",
        }
        try:
            params = [symbol, direction]
            sql = (
                "SELECT outcome,created_at FROM forecasts "
                "WHERE symbol=? AND direction=? AND outcome IN ('WIN','LOSS') "
            )
            if timeframe:
                sql += "AND timeframe=? "
                params.append(timeframe)
            sql += "ORDER BY created_at DESC LIMIT ?"
            params.append(CNS_HISTORY_LIMIT)

            with DB_LOCK, db_conn() as con:
                rows = con.execute(sql, params).fetchall()

            if not rows:
                return out

            wins = sum(1 for r in rows if str(r["outcome"]) == "WIN")
            losses = sum(1 for r in rows if str(r["outcome"]) == "LOSS")

            # Recent observations receive more weight, while old observations
            # remain useful for regime-independent baseline calibration.
            now = time.time()
            rw = rl = 0.0
            for i, r in enumerate(rows):
                age_days = max(
                    0.0,
                    (now - safe_float(r["created_at"], now)) / 86400.0,
                )
                w = math.exp(-age_days / 21.0) * (0.985 ** i)
                if str(r["outcome"]) == "WIN":
                    rw += w
                else:
                    rl += w

            out.update({
                "samples": wins + losses,
                "wins": wins,
                "losses": losses,
                "win_rate": round(self._beta_wr(wins, losses), 2),
                "recent_wr": round(self._beta_wr(rw, rl), 2),
                "confidence": round(clamp((wins + losses) / 40.0, 0, 1), 3),
            })
        except Exception as exc:
            LOGGER.debug("CNS history failed %s/%s: %s", symbol, direction, exc)
        return out

    def _ai_reliability(self, symbol: str, direction: str) -> dict[str, Any]:
        """Provider-specific historical alignment from persisted AI votes."""
        out = {
            "samples": 0,
            "aligned": 0,
            "alignment_pct": 50.0,
            "providers": {},
        }
        try:
            with DB_LOCK, db_conn() as con:
                rows = con.execute(
                    "SELECT provider,direction,aligned,created_at "
                    "FROM ai_votes WHERE symbol=? "
                    "ORDER BY created_at DESC LIMIT 160",
                    (symbol,),
                ).fetchall()

            aligned = 0
            total = 0
            providers: dict[str, list[int]] = {}
            for r in rows:
                if str(r["direction"] or "") != direction:
                    continue
                total += 1
                aligned += int(bool(r["aligned"]))
                providers.setdefault(str(r["provider"]), []).append(
                    int(bool(r["aligned"]))
                )

            out["samples"] = total
            out["aligned"] = aligned
            out["alignment_pct"] = round(aligned / total * 100, 1) if total else 50.0
            out["providers"] = {
                k: round(sum(v) / len(v) * 100, 1)
                for k, v in providers.items()
                if v
            }
        except Exception as exc:
            LOGGER.debug("CNS AI reliability failed %s: %s", symbol, exc)
        return out

    def _tf_evidence(
        self, tf_scores: dict[str, Any]
    ) -> tuple[float, float, dict[str, Any]]:
        long_e = short_e = 0.0
        used = 0.0
        rows = {}

        for tf, w in self.TF_WEIGHTS.items():
            if tf not in tf_scores:
                continue
            s = clamp(safe_float(tf_scores.get(tf), 50), 0, 100)
            e = (s - 50.0) / 50.0
            long_e += max(0.0, e) * w
            short_e += max(0.0, -e) * w
            used += w
            rows[tf] = {
                "score": round(s, 1),
                "edge": round(e, 3),
                "weight": w,
            }

        if used <= 0:
            return 0.0, 0.0, {"coherence": 0.0, "frames": rows}

        long_e /= used
        short_e /= used

        active = [v["edge"] for v in rows.values() if abs(v["edge"]) >= 0.08]
        if len(active) <= 1:
            coherence = 0.35 if active else 0.0
        else:
            signs = [1 if x > 0 else -1 for x in active]
            dominant = max(signs.count(1), signs.count(-1))
            coherence = dominant / len(signs)

        return (
            long_e,
            short_e,
            {"coherence": round(coherence, 3), "frames": rows},
        )

    def evaluate(self, item: dict[str, Any]) -> dict[str, Any]:
        symbol = str(item.get("symbol") or "")
        tf_scores = item.get("tf_scores") or {}
        tf_long, tf_short, tf_meta = self._tf_evidence(tf_scores)

        edge = item.get("edge") or {}
        structure = edge.get("structure") or {}
        confluence = edge.get("confluence") or {}
        regime = edge.get("regime") or {}
        precision = item.get("precision") or {}
        neural = (
            item.get("neural_v9")
            or (item.get("fusion") or {}).get("neural_v9")
            or {}
        )
        forecast = item.get("candle_forecast") or {}
        pattern = item.get("patterns") or {}
        ai = edge.get("ai") or {}
        dq = item.get("data_quality") or {}
        ladder = item.get("entry_ladder") or {}

        evidence = []

        def add(
            name: str,
            edge_value: float,
            weight: float,
            quality: float = 1.0,
            note: str = "",
        ):
            evidence.append({
                "name": name,
                "edge": clamp(edge_value, -1, 1),
                "weight": max(0.0, weight),
                "quality": clamp(quality, 0, 1),
                "note": note,
            })

        # 1) Multi-timeframe spine
        add(
            "multi_tf",
            tf_long - tf_short,
            0.22,
            tf_meta["coherence"],
            f"coherence={tf_meta['coherence']:.2f}",
        )

        # 2) Market structure
        sb = str(structure.get("bias") or "")
        sc = clamp(
            safe_float(structure.get("confirmation_score"), 50),
            0, 100,
        )
        structure_edge = 0.0
        if sb == "صعودی":
            structure_edge = (sc - 50) / 50
        elif sb == "نزولی":
            structure_edge = -(sc - 50) / 50
        add("structure", structure_edge, 0.13, sc / 100.0, sb or "neutral")

        # 3) Regime
        rn = str(regime.get("regime") or "").lower()
        reg_edge = 0.0
        if "up" in rn or "bull" in rn:
            reg_edge = 0.45
        elif "down" in rn or "bear" in rn:
            reg_edge = -0.45
        add(
            "regime",
            reg_edge,
            0.08,
            0.85 if reg_edge else 0.45,
            rn or "unknown",
        )

        # 4) Confluence
        cs = clamp(safe_float(confluence.get("score"), 50), 0, 100)
        qbias = str(item.get("bias") or "")
        confluence_edge = 0.0
        if qbias == "صعودی":
            confluence_edge = (cs - 50) / 50
        elif qbias == "نزولی":
            confluence_edge = -(cs - 50) / 50
        add(
            "confluence",
            confluence_edge,
            0.12,
            cs / 100.0,
            f"score={cs:.1f}",
        )

        # 5) Entry precision
        ps = clamp(safe_float(precision.get("score"), 50), 0, 100)
        pside = 1 if qbias == "صعودی" else -1 if qbias == "نزولی" else 0
        add(
            "precision",
            pside * (ps - 50) / 50,
            0.10,
            ps / 100.0,
            str(precision.get("entry_timing") or ""),
        )

        # 6) Probabilistic forecast path
        fb = str(forecast.get("overall_bias") or "")
        fstrength = clamp(
            safe_float(forecast.get("path_strength"), 0) / 40.0,
            0, 1,
        )
        add(
            "forecast",
            fstrength if fb == "صعودی" else -fstrength if fb == "نزولی" else 0,
            0.09,
            1.0 if forecast.get("ok") else 0.0,
            f"corr={safe_float(forecast.get('analogue_corr'), 0):.2f}",
        )

        # 7) Chart pattern
        primary = pattern.get("primary") or {}
        pb = str((primary.get("guide") or {}).get("bias") or "")
        pc = clamp(
            safe_float(primary.get("confidence"), 0) / 100.0,
            0, 1,
        )
        add(
            "pattern",
            pc if pb == "صعودی" else -pc if pb == "نزولی" else 0,
            0.06,
            pc,
            pb or "neutral",
        )

        # 8) Existing neural V9
        nside = str(neural.get("side") or "WAIT")
        nconf = clamp(
            safe_float(neural.get("confidence"), 0) / 100.0,
            0, 1,
        )
        add(
            "neural_v9",
            nconf if nside == "LONG" else -nconf if nside == "SHORT" else 0,
            0.12,
            nconf,
            f"confidence={nconf * 100:.1f}",
        )

        # 9) AI ensemble
        amaj = str(
            ai.get("majority")
            or ai.get("ai_majority")
            or item.get("ai_majority")
            or "WAIT"
        )
        aagree = clamp(
            safe_float(
                ai.get(
                    "majority_agreement",
                    ai.get(
                        "agreement",
                        (item.get("fusion") or {}).get(
                            "ai_agreement", 0
                        ),
                    ),
                ),
                0,
            ) / 100.0,
            0, 1,
        )
        add(
            "ai_ensemble",
            aagree if amaj == "LONG" else -aagree if amaj == "SHORT" else 0,
            0.10,
            aagree,
            f"majority={amaj}",
        )

        # 10) Historical memory
        long_h = self._history(symbol, "صعودی")
        short_h = self._history(symbol, "نزولی")
        hist_edge = (
            (long_h["recent_wr"] - short_h["recent_wr"]) / 50.0
        ) * 0.5
        hist_quality = min(
            1.0,
            (long_h["samples"] + short_h["samples"]) / 30.0,
        )
        add(
            "historical_memory",
            hist_edge,
            0.08,
            hist_quality,
            f"L={long_h['recent_wr']:.1f}%/{long_h['samples']} "
            f"S={short_h['recent_wr']:.1f}%/{short_h['samples']}",
        )

        total_w = sum(
            x["weight"] * max(0.05, x["quality"])
            for x in evidence
        )
        net = (
            sum(
                x["edge"] * x["weight"] * max(0.05, x["quality"])
                for x in evidence
            ) / max(total_w, 1e-9)
        )
        strength = abs(net)
        side = (
            "LONG"
            if net >= CNS_PROMOTE_MIN_MARGIN
            else "SHORT"
            if net <= -CNS_PROMOTE_MIN_MARGIN
            else "WAIT"
        )

        vetoes = []
        dq_score = safe_float(dq.get("score"), 100)

        if dq.get("hard_veto"):
            vetoes.append("data_quality")
        elif dq_score < MIN_DATA_QUALITY_SCORE:
            vetoes.append("data_quality_soft")

        if precision.get("hard_blocks"):
            # Only invalid blocks are hard; others soft
            hard_p = [x for x in precision.get("hard_blocks")[:4] if x == "invalid_price_or_atr"]
            soft_p = [x for x in precision.get("hard_blocks")[:4] if x != "invalid_price_or_atr"]
            if hard_p:
                vetoes.extend([f"precision:{x}" for x in hard_p])
            if soft_p:
                vetoes.extend([f"precision_soft:{x}" for x in soft_p])

        if safe_float(item.get("effective_rr_tp1"), 0) < CNS_MIN_RR:
            # Soft RR below floor — does not block promote alone when other edges strong
            if safe_float(item.get("effective_rr_tp1"), 0) < 0.85:
                vetoes.append("rr")
            else:
                vetoes.append("rr_soft")

        if (
            ladder
            and side in {"LONG", "SHORT"}
            and not ladder.get("passed", True)
        ):
            # Soft ladder unless HTF is strongly opposite
            htf_s = safe_float(ladder.get("htf_score"), 50)
            if (side == "LONG" and htf_s <= 36) or (side == "SHORT" and htf_s >= 64):
                vetoes.append("entry_ladder")
            else:
                vetoes.append("entry_ladder_soft")

        if (
            amaj in {"LONG", "SHORT"}
            and side in {"LONG", "SHORT"}
            and amaj != side
            and aagree >= CNS_HARD_CONFLICT
        ):
            vetoes.append("ai_hard_conflict")

        chosen_hist = (
            long_h if side == "LONG" else short_h
        )
        hist_penalty = (
            chosen_hist["samples"] >= CNS_MIN_HISTORY
            and chosen_hist["recent_wr"] < 42
        )
        if hist_penalty:
            vetoes.append("weak_historical_side")

        # Promotion from WAIT requires independent evidence, not one large score.
        # Soft vetoes (suffix _soft) do not block promotion.
        quality = safe_float(item.get("signal_quality"), 0)
        hard_veto_names = {
            v for v in vetoes
            if not str(v).endswith("_soft") and "soft:" not in str(v)
        }
        promote = (
            side in {"LONG", "SHORT"}
            and strength >= CNS_PROMOTE_MIN_STRENGTH
            and abs(net) >= CNS_PROMOTE_MIN_MARGIN
            and quality >= CNS_PROMOTE_MIN_QUALITY
            and dq_score >= CNS_PROMOTE_MIN_DQ
            and nconf * 100 >= CNS_PROMOTE_MIN_NEURAL
            and safe_float(item.get("effective_rr_tp1"), 0) >= CNS_PROMOTE_MIN_RR
            and tf_meta["coherence"] >= 0.50
            and not hard_veto_names
            and not hist_penalty
        )

        existing = str(item.get("decision_tag") or "WAIT")
        opposite = (
            "SHORT"
            if existing == "LONG"
            else "LONG"
            if existing == "SHORT"
            else ""
        )

        strong_contradiction = (
            existing in {"LONG", "SHORT"}
            and side == opposite
            and strength >= 0.72
            and abs(net) >= 0.28
        )

        # Evidence-strength index; this is NOT a guaranteed win probability.
        confidence = clamp(
            50
            + strength * 45
            + tf_meta["coherence"] * 10
            - len(vetoes) * 8,
            5, 95,
        )
        if chosen_hist["samples"] < CNS_MIN_HISTORY:
            confidence = min(confidence, 82)

        action = "WAIT"
        reason = "شواهد مستقل برای تصمیم جهتی کافی نیست"

        if strong_contradiction:
            reason = "شبکه شواهد مستقل خلاف تصمیم قبلی است"
        elif existing in {"LONG", "SHORT"}:
            action = existing
            reason = "تصمیم موجود توسط شبکه شواهد مستقل بررسی و تأیید شد"
        elif promote:
            action = side
            reason = "فرصت مرزی با اجماع چندلایه و کیفیت داده کافی ارتقا یافت"

        entry_mode = "WAIT"
        if action in {"LONG", "SHORT"}:
            timing = str(precision.get("entry_timing") or "").upper()
            if (
                bool(ladder.get("passed", False))
                and timing in {"READY", "TRIGGER", "OPTIMAL", "GOOD"}
            ):
                entry_mode = "READY"
            else:
                entry_mode = "EARLY"

        return {
            "version": CNS_VERSION,
            "action": action,
            "side": side,
            "entry_mode": entry_mode,
            "net_score": round(net, 4),
            "directional_strength": round(strength, 3),
            "confidence": round(confidence, 1),
            "promoted": bool(promote and existing == "WAIT"),
            "contradiction": bool(strong_contradiction),
            "vetoes": vetoes,
            "reason": reason,
            "tf_coherence": tf_meta["coherence"],
            "tf": tf_meta["frames"],
            "historical": {"long": long_h, "short": short_h},
            "ai_reliability": (
                self._ai_reliability(symbol, amaj)
                if amaj in {"LONG", "SHORT"}
                else {"samples": 0, "aligned": 0, "alignment_pct": 50.0, "providers": {}, "mode": "neutral"}
            ),
            "evidence": evidence,
            "independent_layers": len(
                [e for e in evidence if e["quality"] >= 0.55]
            ),
        }


TITAN_CNS = TitanCognitiveNexusV10()

# Preserve the original V10 analyzer as the audited core. The wrapper is the
# final arbitration layer used by update_cache, so the existing dashboard/API
# contract remains backward compatible.
_analyze_asset_core = analyze_asset


def _v12_parse_price(value: Any) -> float:
    """Parse dashboard-formatted prices without assuming a fixed decimal format."""
    try:
        if isinstance(value, (int, float)):
            return float(value)
        s = str(value or "").replace(",", "").replace(" ", "")
        return float(s)
    except Exception:
        return 0.0


def _v12_rebuild_directional_levels(item: dict[str, Any], direction: str) -> tuple[float, float, float]:
    """Rebuild directional SL/TP when the final arbitration changes a neutral side.

    The core analyzer normally has full ATR/structure context. If a final CNS
    promotion changes WAIT -> LONG/SHORT, this guard reconstructs a conservative
    directional set from the already-computed neutral risk distance instead of
    leaving a bullish signal with bullish TP but a neutral/inconsistent SL.
    """
    price = _v12_parse_price(item.get("price"))
    old_sl = _v12_parse_price(item.get("stop_loss"))
    if price <= 0:
        return 0.0, 0.0, 0.0

    # A neutral core uses approximately 1.6 ATR plus friction. Recover a safe
    # ATR estimate from that distance, with a volatility-based floor.
    neutral_dist = abs(price - old_sl)
    vol_pct = safe_float(item.get("volatility_pct"), 0.0)
    atr_est = max(
        neutral_dist / 1.6 if neutral_dist > 0 else 0.0,
        price * max(vol_pct / 100.0, 0.0025),
        price * 0.0005,
    )

    # Use a conservative local swing proxy. This is deliberately derived from
    # existing validated price/risk data; it never invents a market level.
    swing_low = price - 2.0 * atr_est
    swing_high = price + 2.0 * atr_est

    titan = item.get("titan_analysis") or {}
    adv = titan.get("adv_layers") or {}
    # These values are optional; missing values are allowed.
    vwap = safe_float(adv.get("vwap"), 0.0)
    if direction == "LONG":
        bias = "صعودی"
    elif direction == "SHORT":
        bias = "نزولی"
    else:
        return 0.0, 0.0, 0.0

    sl, tp1, tp2 = calculate_levels(
        price=price,
        atr=atr_est,
        swing_low=swing_low,
        swing_high=swing_high,
        bias=bias,
        vwap=vwap,
        ema20=0.0,
        ema50=0.0,
        structure=(item.get("edge") or {}).get("structure") or {},
        confluence=safe_float((item.get("edge") or {}).get("confluence", {}).get("score"), 50.0),
        order_blocks_fvg=None,
        fibonacci=None,
        forecast=item.get("candle_forecast") or {},
    )
    return float(sl), float(tp1), float(tp2)


def _v12_level_integrity(price: float, sl: float, tp1: float, tp2: float, direction: str) -> dict[str, Any]:
    """Hard validation of direction/levels/RR before a directional signal is exposed."""
    if not all(math.isfinite(x) for x in (price, sl, tp1, tp2)) or price <= 0:
        return {"ok": False, "reason": "invalid_numeric_levels", "rr1": 0.0, "rr2": 0.0}

    risk = abs(price - sl)
    if risk <= price * 0.0002:
        return {"ok": False, "reason": "risk_distance_too_small", "rr1": 0.0, "rr2": 0.0}

    if direction == "LONG":
        orientation = sl < price < tp1 <= tp2
    elif direction == "SHORT":
        orientation = tp2 <= tp1 < price < sl
    else:
        orientation = False

    rr1 = abs(tp1 - price) / risk
    rr2 = abs(tp2 - price) / risk
    ok = bool(orientation and rr1 >= MIN_EFFECTIVE_RR and rr2 >= rr1)
    return {
        "ok": ok,
        "reason": "ok" if ok else ("bad_orientation" if not orientation else "rr_below_threshold"),
        "rr1": round(rr1, 3),
        "rr2": round(rr2, 3),
    }


def _v12_persist_ai_votes(symbol: str, item: dict[str, Any]) -> None:
    """Persist provider votes without creating scan-by-scan duplicate spam."""
    try:
        ai_obj = item.get("ai_opinions") or {}
        titan_side = str(item.get("decision_tag") or "WAIT")
        now = time.time()

        with DB_LOCK, db_conn() as con:
            for provider, raw in ai_obj.items():
                if (
                    provider in {"providers", "ai_status", "internal", "titan"}
                    or not isinstance(raw, str)
                    or not raw.strip()
                ):
                    continue

                vote = extract_structured_ai_vote(raw).get("side", "WAIT")
                recent = con.execute(
                    "SELECT 1 FROM ai_votes "
                    "WHERE symbol=? AND provider=? AND direction=? AND titan_direction=? "
                    "AND created_at>? LIMIT 1",
                    (symbol, provider, vote, titan_side, now - 90.0),
                ).fetchone()
                if recent:
                    continue

                con.execute(
                    "INSERT INTO ai_votes("
                    "created_at,symbol,provider,direction,titan_direction,aligned,latency_ms"
                    ") VALUES(?,?,?,?,?,?,?)",
                    (
                        now,
                        symbol,
                        provider,
                        vote,
                        titan_side,
                        int(vote == titan_side),
                        None,
                    ),
                )
    except Exception as exc:
        LOGGER.debug("V12 AI vote persistence failed %s: %s", symbol, exc)


def _v12_finalize_signal(item: dict[str, Any], cns: dict[str, Any]) -> None:
    """Apply CNS action only when the final public signal remains internally coherent."""
    current = str(item.get("decision_tag") or "WAIT")
    action = str(cns.get("action") or "WAIT")
    fusion = item.setdefault("fusion", {})
    integrity = {
        "version": "V12-CNS-PRO-MAX",
        "core_decision": current,
        "cns_proposal": action,
        "applied": False,
        "level_rebuilt": False,
        "reason": "",
    }

    if action in {"LONG", "SHORT"} and action != current:
        # If CNS proposes a new direction, rebuild levels first.
        sl, tp1, tp2 = _v12_rebuild_directional_levels(item, action)
        price = _v12_parse_price(item.get("price"))
        check = _v12_level_integrity(price, sl, tp1, tp2, action)

        if check["ok"]:
            item["stop_loss"] = smart_format(sl)
            item["tp1"] = smart_format(tp1)
            item["tp2"] = smart_format(tp2)
            item["effective_rr_tp1"] = check["rr1"]
            item["effective_rr_tp2"] = check["rr2"]
            item["rr_tp1"] = check["rr1"]
            item["rr_tp2"] = check["rr2"]
            item["decision_tag"] = action
            item["bias"] = "صعودی" if action == "LONG" else "نزولی"
            item["signal_tag"] = "CNS OPPORTUNITY" if cns.get("promoted") else "CNS CONFIRMED"
            fusion["cns_override"] = True
            fusion["cns_override_reason"] = cns.get("reason")
            integrity.update(applied=True, level_rebuilt=True, reason="directional_levels_rebuilt_and_validated")
        else:
            # Never expose a direction with stale/inconsistent levels.
            integrity["reason"] = f"CNS proposal rejected by level integrity: {check['reason']}"
            fusion["cns_override"] = False
            fusion["cns_override_reason"] = integrity["reason"]

    elif action == "WAIT" and current in {"LONG", "SHORT"}:
        # A strong independent contradiction is materially different from a
        # neutral/soft disagreement. Never keep a directional signal when the
        # evidence graph itself has a high-strength opposite side.
        severe = [v for v in (cns.get("vetoes") or []) if str(v) in {"data_quality", "ai_hard_conflict"}]
        contradiction = bool(cns.get("contradiction"))
        strength = safe_float(cns.get("directional_strength"), 0)
        if contradiction or (severe and strength < 0.35):
            item["decision_tag"] = "WAIT"
            item["bias"] = "خنثی"
            item["signal_tag"] = "CNS BLOCK"
            fusion["cns_override"] = True
            fusion["cns_override_reason"] = cns.get("reason") or "strong independent contradiction"
            integrity.update(applied=True, reason="independent_evidence_blocked_core_direction")
        else:
            fusion["cns_soft_block"] = True
            fusion["cns_override_reason"] = cns.get("reason")
            integrity.update(applied=False, reason="cns_soft_block_direction_kept")

    else:
        integrity["reason"] = "core_and_cns_decision_consistent"

    # Rebuild the canonical object after the final action, not before it.
    item["decision_integrity"] = integrity
    item["canonical_decision"] = {
        "decision": item.get("decision_tag", "WAIT"),
        "bias": item.get("bias", "خنثی"),
        "confidence": cns.get("confidence", 0),
        "signal_quality": item.get("signal_quality", 0),
        "success_probability": item.get("success_probability", 50),
        "cns_version": CNS_VERSION,
        "reason": cns.get("reason", ""),
        "entry_mode": cns.get("entry_mode", "WAIT"),
        "level_integrity": integrity["reason"],
    }


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """V12 CNS PRO MAX public analyzer.

    The V10/V11 core remains the data/indicator/forecast engine. This final
    layer performs evidence arbitration, decision integrity, and learning-memory
    hygiene so no final LONG/SHORT can be emitted with contradictory levels.
    """
    item = _analyze_asset_core(symbol, btc_trend)
    if not item:
        return None

    try:
        cns = TITAN_CNS.evaluate(item)
        item["cognitive_nexus"] = cns
        item.setdefault("fusion", {})["cognitive_nexus"] = cns
        item["cns_action"] = cns.get("action", "WAIT")
        item["cns_confidence"] = cns.get("confidence", 0)
        item["cns_strength"] = cns.get("directional_strength", 0)
        item["entry_mode"] = cns.get("entry_mode", "WAIT")

        _v12_finalize_signal(item, cns)

        # If a promoted signal changed direction, cap displayed confidence until
        # its first live outcome exists. This avoids presenting a fresh promotion
        # as if it were historically proven.
        if cns.get("promoted") and item.get("decision_tag") in {"LONG", "SHORT"}:
            item["signal_quality"] = int(clamp(
                safe_float(item.get("signal_quality"), 0), 0, 92
            ))

        _v12_persist_ai_votes(symbol, item)

        return item

    except Exception as exc:
        LOGGER.exception("V12 CNS arbitration failed for %s: %s", symbol, exc)
        item["decision_integrity"] = {
            "version": "V12-CNS-PRO-MAX",
            "applied": False,
            "reason": "CNS failure; original core decision retained",
        }
        item["cognitive_nexus"] = {
            "version": CNS_VERSION,
            "action": item.get("decision_tag", "WAIT"),
            "confidence": 0,
            "reason": "CNS unavailable; core decision retained",
        }
        return item



# ============================================================
# TITAN V21 TRUST MAX
# Data Integrity + Regime Intelligence + Memory + AI Reliability
# + Probability Calibration + Walk-Forward Audit + Risk Governor
#
# This layer is deliberately additive: the existing V12 dashboard/theme/API
# remain intact. The engine gains a closed-loop audit and trust architecture.
# ============================================================

V21_VERSION = "TITAN-V21-TRUST-MAX-BALANCED"
V21_MIN_DATA_TRUST = 50.0
V21_MIN_SIGNAL_TRUST = 46.0
V21_MIN_HISTORY_SAMPLES = 6
V21_CALIBRATION_MIN_SAMPLES = 10
V21_WALK_FORWARD_MIN_SAMPLES = 16
V21_MAX_STALE_SEC = 60.0
V21_HISTORY_DECAY_DAYS = 45.0


def _v21_now_ts() -> float:
    return time.time()


def _v21_num(x: Any, default: float = 0.0) -> float:
    return safe_float(x, default)


def _v21_direction(x: Any) -> str:
    s = str(x or "").upper().strip()
    return s if s in {"LONG", "SHORT", "WAIT"} else "WAIT"


def _v21_nested(obj: Any, *keys: str, default: Any = None) -> Any:
    cur = obj
    for key in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(key)
    return default if cur is None else cur


class TitanDataIntegrityV21:
    """Independent data-trust gate.

    It never fabricates missing market data. Missing evidence reduces trust and
    can veto a directional decision.
    """

    def evaluate(self, item: dict[str, Any]) -> dict[str, Any]:
        checks = {}
        price = _v21_num(item.get("price"))
        checks["price"] = price > 0

        dq = _v21_num(item.get("data_quality"), 0)
        if dq == 0:
            dq = _v21_num(item.get("data_quality_score"), 0)
        checks["reported_quality"] = dq >= MIN_DATA_QUALITY_SCORE

        # Missing age is unknown, not fresh. Treating it as age=0 silently
        # converted stale/missing live prices into trusted data.
        raw_age = item.get("price_age_sec")
        age = _v21_num(raw_age, -1.0)
        checks["price_fresh"] = 0 <= age <= V21_MAX_STALE_SEC

        tf_scores = item.get("tf_scores") or {}
        valid_tfs = []
        for tf in ("15m", "1h", "4h", "1d"):
            v = _v21_num(tf_scores.get(tf), -1)
            if 0 <= v <= 100:
                valid_tfs.append(tf)
        checks["multi_tf"] = len(valid_tfs) >= 3

        forecast = item.get("candle_forecast") or item.get("forecast") or {}
        checks["forecast"] = bool(forecast.get("ok", False)) and bool(
            forecast.get("candles") or forecast.get("overall_bias") or forecast.get("expected_move_pct") is not None
        )

        derivatives = item.get("derivatives") or {}
        checks["derivatives"] = bool(derivatives) or bool(item.get("oi_delta") is not None)

        passed = sum(bool(v) for v in checks.values())
        completeness = passed / max(len(checks), 1) * 100.0

        # Quality is not allowed to exceed the evidence actually present.
        trust = 0.55 * completeness + 0.45 * min(max(dq, 0), 100)
        trust = clamp(trust, 0, 100)

        hard_fail = []
        if not checks["price"]:
            hard_fail.append("invalid_price")
        if not checks["multi_tf"]:
            hard_fail.append("insufficient_timeframes")
        if age >= 0 and age > V21_MAX_STALE_SEC:
            hard_fail.append("stale_price")
        elif age < 0:
            # Closed-candle price is still real market data; absence of a live
            # tick lowers completeness/trust but is not an invented price.
            pass

        return {
            "version": V21_VERSION,
            "trust": round(trust, 1),
            "completeness": round(completeness, 1),
            "checks": checks,
            "valid_timeframes": valid_tfs,
            "hard_fail": hard_fail,
            "passed": not hard_fail and trust >= V21_MIN_DATA_TRUST,
        }


class TitanRegimeIntelligenceV21:
    """Market-regime classifier using existing item evidence.

    Regime is descriptive; it does not directly force a direction.
    """

    def evaluate(self, item: dict[str, Any]) -> dict[str, Any]:
        tf = item.get("tf_scores") or {}
        vals = [_v21_num(tf.get(k), 50) for k in ("15m", "1h", "4h", "1d")]
        spread = max(vals) - min(vals) if vals else 0
        avg = sum(vals) / max(len(vals), 1)

        edge = item.get("edge") or {}
        regime_obj = edge.get("regime") or {}
        name = str(regime_obj.get("regime") or regime_obj.get("name") or "").lower()

        if "trend" in name or "bull" in name or "bear" in name:
            regime = "TREND"
        elif "range" in name or "side" in name:
            regime = "RANGE"
        elif "break" in name:
            regime = "BREAKOUT"
        elif spread >= 28:
            regime = "TRANSITION"
        elif 43 <= avg <= 57:
            regime = "RANGE"
        else:
            regime = "TREND"

        coherence = 100.0 - clamp(spread * 2.0, 0, 75)
        if regime == "TRANSITION":
            coherence *= 0.75

        return {
            "version": V21_VERSION,
            "regime": regime,
            "tf_average": round(avg, 1),
            "tf_spread": round(spread, 1),
            "coherence": round(coherence, 1),
        }


class TitanHistoricalMemoryV21:
    """Outcome memory with recency weighting and regime/direction separation."""

    def _rows(self, symbol: str, direction: str, limit: int = 400):
        try:
            with DB_LOCK, db_conn() as con:
                return con.execute(
                    "SELECT created_at, outcome, timeframe FROM forecasts "
                    "WHERE symbol=? AND direction=? AND outcome IN ('WIN','LOSS') "
                    "ORDER BY created_at DESC LIMIT ?",
                    (symbol, direction, limit),
                ).fetchall()
        except Exception as exc:
            LOGGER.debug("V21 memory read failed %s: %s", symbol, exc)
            return []

    def evaluate(self, symbol: str, direction: str) -> dict[str, Any]:
        direction = _v21_direction(direction)
        if direction not in {"LONG", "SHORT"}:
            return {"samples": 0, "win_rate": 50.0, "recent_win_rate": 50.0, "confidence": 0, "status": "NEUTRAL"}

        rows = self._rows(symbol, direction)
        if not rows:
            return {"samples": 0, "win_rate": 50.0, "recent_win_rate": 50.0, "confidence": 0, "status": "NO_HISTORY"}

        now = _v21_now_ts()
        weighted_wins = weighted_total = 0.0
        wins = 0
        for row in rows:
            try:
                ts = float(row[0])
            except Exception:
                ts = now
            age_days = max(0.0, (now - ts) / 86400.0) if ts > 1_000_000_000 else 0.0
            w = math.exp(-age_days / V21_HISTORY_DECAY_DAYS)
            outcome = str(row[1] or "").upper()
            weighted_total += w
            if outcome == "WIN":
                weighted_wins += w
                wins += 1

        n = len(rows)
        # Beta(2,2) shrinkage protects against tiny samples.
        posterior = (weighted_wins + 2.0) / (weighted_total + 4.0) if weighted_total else 0.5
        recent = rows[:min(20, n)]
        recent_wins = sum(1 for r in recent if str(r[1]).upper() == "WIN")
        recent_wr = recent_wins / len(recent) if recent else 0.5

        confidence = clamp(
            25.0 + min(55.0, n * 3.0) + abs(posterior - 0.5) * 80.0,
            0, 95
        )
        return {
            "samples": n,
            "wins": wins,
            "losses": n - wins,
            "win_rate": round(posterior * 100, 1),
            "recent_win_rate": round(recent_wr * 100, 1),
            "confidence": round(confidence, 1),
            "status": "ESTABLISHED" if n >= V21_MIN_HISTORY_SAMPLES else "LIMITED",
        }


class TitanAICredibilityV21:
    """Provider-specific historical reliability.

    AI output is evidence, never an unconditional override.
    """

    def evaluate(self, symbol: str, titan_direction: str) -> dict[str, Any]:
        titan_direction = _v21_direction(titan_direction)
        if titan_direction not in {"LONG", "SHORT"}:
            return {"samples": 0, "agreement": 50.0, "providers": {}, "status": "NEUTRAL"}

        try:
            with DB_LOCK, db_conn() as con:
                rows = con.execute(
                    "SELECT provider, direction, aligned FROM ai_votes "
                    "WHERE symbol=? ORDER BY created_at DESC LIMIT 500",
                    (symbol,),
                ).fetchall()
        except Exception as exc:
            LOGGER.debug("V21 AI history failed %s: %s", symbol, exc)
            rows = []

        providers = {}
        total = aligned = 0
        for provider, direction, _stored_titan_direction, is_aligned, _created_at in rows:
            p = str(provider or "").strip().lower()
            if not p:
                continue
            bucket = providers.setdefault(p, {"samples": 0, "aligned": 0})
            bucket["samples"] += 1
            bucket["aligned"] += int(bool(is_aligned))
            total += 1
            aligned += int(bool(is_aligned))

        return {
            "samples": total,
            "agreement": round(aligned / total * 100, 1) if total else 50.0,
            "providers": providers,
            "status": "ESTABLISHED" if total >= V21_MIN_HISTORY_SAMPLES else "LIMITED",
        }


class TitanProbabilityCalibrationV21:
    """Converts historical forecast outcomes into a conservative calibration layer."""

    def evaluate(self, item: dict[str, Any], direction: str) -> dict[str, Any]:
        raw = _v21_num(item.get("success_probability"), 50.0)
        raw = clamp(raw, 1, 99)

        hist = TITAN_MEMORY_V21.evaluate(str(item.get("symbol", "")), direction)
        n = int(hist.get("samples", 0))
        if n < V21_CALIBRATION_MIN_SAMPLES:
            calibrated = 0.70 * raw + 0.30 * 50.0
            status = "INSUFFICIENT_HISTORY"
        else:
            empirical = _v21_num(hist.get("win_rate"), 50.0)
            calibrated = 0.55 * raw + 0.45 * empirical
            status = "CALIBRATED"

        # Never let a small historical sample create extreme certainty.
        cap = 78.0 if n < 30 else 88.0
        calibrated = clamp(calibrated, 22.0, cap)
        return {
            "raw": round(raw, 1),
            "calibrated": round(calibrated, 1),
            "samples": n,
            "status": status,
        }


class TitanWalkForwardAuditV21:
    """Lightweight outcome audit.

    It does not optimize parameters on the same observations it evaluates.
    It reports sample sufficiency rather than pretending a tiny backtest is proof.
    """

    def evaluate(self, symbol: str, direction: str, limit: int = 300) -> dict[str, Any]:
        direction = _v21_direction(direction)
        if direction not in {"LONG", "SHORT"}:
            return {"status": "NEUTRAL", "samples": 0}

        try:
            with DB_LOCK, db_conn() as con:
                rows = con.execute(
                    "SELECT outcome FROM forecasts WHERE symbol=? AND direction=? "
                    "AND outcome IN ('WIN','LOSS') ORDER BY created_at ASC LIMIT ?",
                    (symbol, direction, limit),
                ).fetchall()
        except Exception as exc:
            LOGGER.debug("V21 walk-forward audit failed %s", symbol)
            rows = []

        n = len(rows)
        if n < V21_WALK_FORWARD_MIN_SAMPLES:
            return {
                "status": "INSUFFICIENT",
                "samples": n,
                "oos_win_rate": None,
                "max_losing_streak": None,
            }

        outcomes = [str(r[0]).upper() for r in rows]
        split = max(10, int(n * 0.70))
        test = outcomes[split:]
        wins = sum(1 for x in test if x == "WIN")
        wr = wins / max(len(test), 1) * 100

        streak = best = 0
        for x in test:
            if x == "LOSS":
                streak += 1
                best = max(best, streak)
            else:
                streak = 0

        return {
            "status": "AUDITED",
            "samples": n,
            "train_samples": split,
            "oos_samples": len(test),
            "oos_win_rate": round(wr, 1),
            "max_losing_streak": best,
        }


class TitanRiskGovernorV21:
    """Final independent governor.

    It can downgrade a proposed signal but never upgrades it by itself.
    """

    def evaluate(self, item: dict[str, Any], cns: dict[str, Any],
                 data: dict[str, Any], regime: dict[str, Any],
                 calibration: dict[str, Any], wf: dict[str, Any]) -> dict[str, Any]:
        proposed = _v21_direction(cns.get("action"))
        reasons = []
        score = 100.0

        if data.get("trust", 0) < V21_MIN_DATA_TRUST:
            reasons.append("DATA_TRUST_LOW")
            score -= 35

        if data.get("hard_fail"):
            reasons.extend(data["hard_fail"])
            score -= 30

        if regime.get("regime") == "TRANSITION":
            score -= 10
            reasons.append("REGIME_TRANSITION")

        if proposed in {"LONG", "SHORT"}:
            rr = _v21_num(item.get("effective_rr_tp1"), 0)
            if rr < MIN_EFFECTIVE_RR:
                score -= 30
                reasons.append("RR_LOW")

            cal = _v21_num(calibration.get("calibrated"), 50)
            if cal < 52:
                score -= 20
                reasons.append("CALIBRATION_WEAK")

            if wf.get("status") == "AUDITED" and _v21_num(wf.get("oos_win_rate"), 50) < 45:
                score -= 15
                reasons.append("OOS_WEAK")

        score = clamp(score, 0, 100)
        action = proposed
        if proposed in {"LONG", "SHORT"} and score < V21_MIN_SIGNAL_TRUST:
            action = "WAIT"

        return {
            "version": V21_VERSION,
            "action": action,
            "trust": round(score, 1),
            "reasons": reasons,
            "governed": action != proposed,
        }


class TitanTrustMaxV21:
    """Closed-loop final evidence graph."""

    def evaluate(self, item: dict[str, Any]) -> dict[str, Any]:
        symbol = str(item.get("symbol") or "")
        cns = item.get("cognitive_nexus") or {}
        proposed = _v21_direction(cns.get("action") or item.get("decision_tag"))

        data = TITAN_DATA_V21.evaluate(item)
        regime = TITAN_REGIME_V21.evaluate(item)
        direction = proposed if proposed in {"LONG", "SHORT"} else _v21_direction(item.get("decision_tag"))

        history = (
            TITAN_MEMORY_V21.evaluate(symbol, direction)
            if direction in {"LONG", "SHORT"}
            else {"samples": 0, "win_rate": 50.0, "confidence": 0, "status": "NEUTRAL"}
        )
        ai = TITAN_AI_CRED_V21.evaluate(symbol, direction)
        calibration = TITAN_CALIBRATION_V21.evaluate(item, direction)
        wf = TITAN_WF_V21.evaluate(symbol, direction)
        governor = TITAN_GOVERNOR_V21.evaluate(item, cns, data, regime, calibration, wf)

        # Trust is an evidence quality metric, not a guaranteed probability.
        trust = (
            0.28 * data["trust"]
            + 0.18 * regime["coherence"]
            + 0.18 * _v21_num(cns.get("confidence"), 0)
            + 0.16 * calibration["calibrated"]
            + 0.10 * _v21_num(history.get("confidence"), 0)
            + 0.10 * ai["agreement"]
        )
        trust = clamp(trust, 0, 100)

        final_action = governor["action"]
        if final_action in {"LONG", "SHORT"} and trust < V21_MIN_SIGNAL_TRUST:
            final_action = "WAIT"

        reasons = []
        if not data["passed"]:
            reasons.append("اعتماد داده کافی نیست")
        if governor["governed"]:
            reasons.extend(governor["reasons"])
        if regime["regime"] == "TRANSITION":
            reasons.append("رژیم بازار در حال انتقال است")

        return {
            "version": V21_VERSION,
            "action": final_action,
            "trust": round(trust, 1),
            "proposed_action": proposed,
            "data_integrity": data,
            "regime": regime,
            "historical_memory": history,
            "ai_credibility": ai,
            "calibration": calibration,
            "walk_forward": wf,
            "risk_governor": governor,
            "reasons": list(dict.fromkeys(reasons)),
            "audit_note": "Trust is evidence quality, not a profit guarantee.",
        }


TITAN_DATA_V21 = TitanDataIntegrityV21()
TITAN_REGIME_V21 = TitanRegimeIntelligenceV21()
TITAN_MEMORY_V21 = TitanHistoricalMemoryV21()
TITAN_AI_CRED_V21 = TitanAICredibilityV21()
TITAN_CALIBRATION_V21 = TitanProbabilityCalibrationV21()
TITAN_WF_V21 = TitanWalkForwardAuditV21()
TITAN_GOVERNOR_V21 = TitanRiskGovernorV21()
TITAN_TRUST_V21 = TitanTrustMaxV21()


# Preserve the V12 public analyzer and put Trust Max above it.
_analyze_asset_v12 = analyze_asset


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    item = _analyze_asset_v12(symbol, btc_trend)
    if not item:
        return None

    try:
        trust = TITAN_TRUST_V21.evaluate(item)
        item["trust_max_v21"] = trust
        item.setdefault("fusion", {})["trust_max_v21"] = trust

        # V21 is a governor. V28.4: only hard data failure kills direction;
        # otherwise keep LONG/SHORT and attach risk reasons.
        action = trust["action"]
        hard_data = bool((trust.get("data_integrity") or {}).get("hard_fail"))
        if action == "WAIT" and str(item.get("decision_tag")) in {"LONG", "SHORT"}:
            if hard_data or safe_float(trust.get("trust"), 100) < 35:
                item["decision_tag"] = "WAIT"
                item["bias"] = "خنثی"
                item["signal_tag"] = "V21 RISK GOVERNOR"
                item["entry_mode"] = "WAIT"
                item["fusion"]["v21_override"] = True
                item["fusion"]["v21_reason"] = trust["reasons"]
            else:
                item["fusion"]["v21_soft"] = True
                item["fusion"]["v21_reason"] = trust["reasons"]
                item["signal_tag"] = str(item.get("signal_tag") or "CONFIRMED SETUP")
                if item.get("signal_quality") is not None:
                    item["signal_quality"] = int(min(safe_float(item.get("signal_quality"), 50), 74))

        item["canonical_decision"] = {
            **(item.get("canonical_decision") or {}),
            "decision": item.get("decision_tag", "WAIT"),
            "bias": item.get("bias", "خنثی"),
            "trust_max": trust["trust"],
            "trust_version": V21_VERSION,
            "risk_governor": trust["risk_governor"],
            "data_integrity": trust["data_integrity"],
            "regime": trust["regime"],
            "calibration": trust["calibration"],
        }

        # Expose a compact audit object for the dashboard without changing the UI.
        item["decision_audit"] = {
            "final": item.get("decision_tag", "WAIT"),
            "trust": trust["trust"],
            "data_trust": trust["data_integrity"]["trust"],
            "regime": trust["regime"]["regime"],
            "calibrated_probability": trust["calibration"]["calibrated"],
            "history_samples": trust["historical_memory"].get("samples", 0),
            "oos_status": trust["walk_forward"].get("status"),
            "reasons": trust["reasons"],
        }

        return item
    except Exception as exc:
        LOGGER.exception("V21 Trust Max failed for %s: %s", symbol, exc)
        return item


# ============================================================
# TITAN V22 — ADAPTIVE OPPORTUNITY & SELF-LEARNING ENGINE
#
# Goal:
#   1) Avoid arbitrary WAIT.
#   2) Avoid arbitrary LONG/SHORT.
#   3) Preserve a real directional signal when evidence is sufficient.
#   4) Surface strong pre-trigger opportunities as EARLY/WATCH instead of
#      hiding them behind WAIT.
#   5) Learn from realized outcomes and recalibrate thresholds/AI influence.
#   6) Produce a complete reason tree for every final decision.
#
# This layer is analysis-only. It never executes orders and never invents
# market data, levels, or outcomes.
# ============================================================

V22_VERSION = "TITAN-V22-ADAPTIVE-OPPORTUNITY-BALANCED"
V22_JOURNAL_COOLDOWN = 90.0
V22_CANDIDATE_MEMORY_MINUTES = 24.0
V22_PROMOTE_SCORE = 56.0
V22_STRONG_TRIGGER_SCORE = 64.0
V22_EARLY_SCORE = 48.0
V22_WATCH_SCORE = 40.0
V22_MIN_DATA = 48.0
V22_MIN_QUALITY = 44.0
V22_MIN_NEURAL = 40.0
V22_MIN_RR = 1.02
V22_MIN_AI_AGREEMENT = 48.0
V22_MAX_AI_CONFLICT = 92.0
V22_MAX_HARD_VETOES = 1


def _v22_init_tables() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS decision_journal_v22(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    candidate_side TEXT DEFAULT 'WAIT',
                    opportunity_state TEXT DEFAULT 'NO_EDGE',
                    opportunity_score REAL DEFAULT 0,
                    trust REAL DEFAULT 0,
                    quality REAL DEFAULT 0,
                    ai_majority TEXT DEFAULT 'WAIT',
                    ai_agreement REAL DEFAULT 0,
                    regime TEXT DEFAULT '',
                    reason_json TEXT DEFAULT '{}',
                    outcome TEXT DEFAULT 'PENDING'
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_v22_journal_symbol ON decision_journal_v22(symbol, created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v22_journal_outcome ON decision_journal_v22(outcome, created_at)")
            con.execute("""
                CREATE TABLE IF NOT EXISTS v22_learning_state(
                    state_key TEXT PRIMARY KEY,
                    updated_at REAL NOT NULL,
                    payload TEXT NOT NULL
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS v22_candidate_state(
                    symbol TEXT PRIMARY KEY,
                    side TEXT DEFAULT 'WAIT',
                    first_seen REAL DEFAULT 0,
                    last_seen REAL DEFAULT 0,
                    streak INTEGER DEFAULT 0,
                    best_score REAL DEFAULT 0,
                    last_reason TEXT DEFAULT ''
                )
            """)
    except Exception as exc:
        LOGGER.warning("V22 table initialization failed: %s", exc)


_v22_init_tables()


class TitanLearningEngineV22:
    """Outcome-driven calibration.

    It deliberately uses shrinkage and minimum samples. A tiny winning streak
    cannot make the engine aggressively lower its thresholds.
    """

    def _rows(self, symbol: str = "", direction: str = ""):
        sql = (
            "SELECT id,symbol,direction,outcome,score,alignment,ai_majority,"
            "ai_agreement,fused_score,success_prob,created_at "
            "FROM forecasts WHERE outcome IN ('WIN','LOSS')"
        )
        params = []
        if symbol:
            sql += " AND symbol=?"
            params.append(symbol)
        if direction:
            sql += " AND direction=?"
            params.append(direction)
        sql += " ORDER BY created_at DESC LIMIT 1200"
        try:
            with DB_LOCK, db_conn() as con:
                return con.execute(sql, params).fetchall()
        except Exception as exc:
            LOGGER.debug("V22 learning rows failed: %s", exc)
            return []

    @staticmethod
    def _beta(wins: float, losses: float) -> float:
        return (wins + 2.0) / (wins + losses + 4.0) * 100.0

    def side_profile(self, symbol: str, side: str) -> dict[str, Any]:
        db_side = "صعودی" if side == "LONG" else "نزولی"
        rows = self._rows(symbol, db_side)
        n = len(rows)
        wins = sum(1 for r in rows if str(r["outcome"]) == "WIN")
        losses = n - wins
        recent = rows[:20]
        rw = sum(1 for r in recent if str(r["outcome"]) == "WIN")
        wr = self._beta(wins, losses)
        recent_wr = self._beta(rw, max(0, len(recent) - rw))

        # Calibration: are high model probabilities actually associated with wins?
        high_p = [r for r in rows if safe_float(r["success_prob"], 0) >= 60]
        high_p_wr = (
            self._beta(
                sum(1 for r in high_p if str(r["outcome"]) == "WIN"),
                sum(1 for r in high_p if str(r["outcome"]) == "LOSS"),
            )
            if high_p else 50.0
        )

        # AI ensemble accuracy for this side.
        ai_rows = [
            r for r in rows
            if str(r["ai_majority"] or "").upper() in {side, "LONG" if side == "LONG" else "SHORT"}
        ]
        ai_w = sum(1 for r in ai_rows if str(r["outcome"]) == "WIN")
        ai_l = sum(1 for r in ai_rows if str(r["outcome"]) == "LOSS")
        ai_wr = self._beta(ai_w, ai_l) if ai_rows else 50.0

        # Stable adaptive threshold shift. Positive means be stricter.
        shift = 0.0
        if n >= 10:
            if recent_wr < 45:
                shift += min(4.0, (45.0 - recent_wr) * 0.18)
            elif recent_wr > 61:
                shift -= min(3.0, (recent_wr - 61.0) * 0.12)
            if high_p_wr < 45:
                shift += 1.5
            elif high_p_wr > 62:
                shift -= 1.0
        return {
            "samples": n,
            "wins": wins,
            "losses": losses,
            "win_rate": round(wr, 1),
            "recent_win_rate": round(recent_wr, 1),
            "high_probability_wr": round(high_p_wr, 1),
            "ai_aligned_wr": round(ai_wr, 1),
            "ai_samples": len(ai_rows),
            "threshold_shift": round(shift, 2),
            "confidence": round(min(1.0, n / 40.0), 3),
        }

    def global_profile(self) -> dict[str, Any]:
        rows = self._rows()
        n = len(rows)
        wins = sum(1 for r in rows if str(r["outcome"]) == "WIN")
        losses = n - wins
        ai_rows = [r for r in rows if str(r["ai_majority"] or "").upper() in {"LONG", "SHORT"}]
        ai_w = sum(1 for r in ai_rows if str(r["outcome"]) == "WIN")
        ai_l = sum(1 for r in ai_rows if str(r["outcome"]) == "LOSS")
        return {
            "samples": n,
            "win_rate": round(self._beta(wins, losses), 1),
            "ai_win_rate": round(self._beta(ai_w, ai_l), 1) if ai_rows else 50.0,
            "ai_samples": len(ai_rows),
        }


class TitanOpportunityEngineV22:
    """Balances action vs patience using a two-threshold + persistence model."""

    def _ai(self, item: dict[str, Any]) -> tuple[str, float]:
        edge_ai = (item.get("edge") or {}).get("ai") or {}
        fusion = item.get("fusion") or {}
        majority = str(
            edge_ai.get("majority")
            or edge_ai.get("ai_majority")
            or fusion.get("ai_majority")
            or "WAIT"
        ).upper()
        agreement = safe_float(
            edge_ai.get("majority_agreement")
            or edge_ai.get("agreement")
            or fusion.get("ai_agreement"),
            0,
        )
        return majority if majority in {"LONG", "SHORT", "WAIT"} else "WAIT", clamp(agreement, 0, 100)

    def _candidate_edges(self, item: dict[str, Any]) -> dict[str, float]:
        tf = item.get("tf_scores") or {}
        tf_long = tf_short = 0.0
        weights = {"15m": 0.18, "1h": 0.30, "4h": 0.28, "1d": 0.24}
        used = 0.0
        for k, w in weights.items():
            if k not in tf:
                continue
            e = (safe_float(tf.get(k), 50) - 50) / 50
            if e > 0:
                tf_long += e * w
            elif e < 0:
                tf_short += -e * w
            used += w
        if used:
            tf_long /= used
            tf_short /= used

        structure = (item.get("edge") or {}).get("structure") or {}
        confluence = (item.get("edge") or {}).get("confluence") or {}
        precision = item.get("precision") or {}
        neural = item.get("neural_v9") or {}
        fc = item.get("candle_forecast") or {}
        patterns = item.get("patterns") or {}
        primary = patterns.get("primary") or {}
        guide = primary.get("guide") or {}

        struct_side = str(structure.get("bias") or "")
        struct_sc = safe_float(structure.get("confirmation_score"), 50)
        conf_sc = safe_float(confluence.get("score"), 50)
        prec_sc = safe_float(precision.get("score"), 50)
        nside = str(neural.get("side") or "WAIT")
        nconf = safe_float(neural.get("confidence"), 0) / 100
        fb = str(fc.get("overall_bias") or "")
        fs = clamp(safe_float(fc.get("path_strength"), 0) / 40, 0, 1)
        pb = str(guide.get("bias") or "")
        pc = clamp(safe_float(primary.get("confidence"), 0) / 100, 0, 1)

        def side_score(side: str) -> float:
            s = 0.0
            # TF spine
            s += (tf_long if side == "LONG" else tf_short) * 100 * .25
            # Structure
            if (side == "LONG" and struct_side == "صعودی") or (side == "SHORT" and struct_side == "نزولی"):
                s += max(0, struct_sc - 50) * .18
            # Confluence follows current bias but is still a useful independent vote.
            current_bias = str(item.get("bias") or "")
            if (side == "LONG" and current_bias == "صعودی") or (side == "SHORT" and current_bias == "نزولی"):
                s += max(0, conf_sc - 50) * .14
            # Precision
            s += max(0, prec_sc - 50) * .10
            # Neural
            if nside == side:
                s += nconf * 12
            # Forecast
            if (side == "LONG" and fb == "صعودی") or (side == "SHORT" and fb == "نزولی"):
                s += fs * 8
            # Pattern
            if (side == "LONG" and pb == "صعودی") or (side == "SHORT" and pb == "نزولی"):
                s += pc * 5
            return clamp(s, 0, 100)

        return {"LONG": side_score("LONG"), "SHORT": side_score("SHORT")}

    def _persistence(self, symbol: str, side: str, score: float) -> dict[str, Any]:
        # WAIT is not a directional candidate and must not build persistence
        # that can later be mistaken for an entry setup.
        if side not in {"LONG", "SHORT"}:
            return {"streak": 0, "age_min": 0.0, "persistent": False}
        now = time.time()
        try:
            with DB_LOCK, db_conn() as con:
                row = con.execute(
                    "SELECT * FROM v22_candidate_state WHERE symbol=?",
                    (symbol,),
                ).fetchone()
                if not row:
                    con.execute(
                        "INSERT INTO v22_candidate_state(symbol,side,first_seen,last_seen,streak,best_score,last_reason) VALUES(?,?,?,?,?,?,?)",
                        (symbol, side, now, now, 1, score, ""),
                    )
                    return {"streak": 1, "age_min": 0.0, "persistent": False}
                old_side = str(row["side"] or "WAIT")
                last = safe_float(row["last_seen"], now)
                age_min = max(0.0, (now - last) / 60.0)
                if old_side == side and age_min <= V22_CANDIDATE_MEMORY_MINUTES:
                    streak = int(row["streak"] or 0) + 1
                    first = safe_float(row["first_seen"], now)
                else:
                    streak = 1
                    first = now
                con.execute(
                    "UPDATE v22_candidate_state SET side=?,first_seen=?,last_seen=?,streak=?,best_score=?,last_reason=? WHERE symbol=?",
                    (side, first, now, streak, max(score, safe_float(row["best_score"], 0)), "", symbol),
                )
                return {
                    "streak": streak,
                    "age_min": round((now - first) / 60.0, 1),
                    "persistent": streak >= 2 and (now - first) <= V22_CANDIDATE_MEMORY_MINUTES * 60,
                }
        except Exception as exc:
            LOGGER.debug("V22 persistence failed %s: %s", symbol, exc)
            return {"streak": 1, "age_min": 0.0, "persistent": False}

    def evaluate(self, item: dict[str, Any], learning: TitanLearningEngineV22) -> dict[str, Any]:
        symbol = str(item.get("symbol") or "")
        v21 = item.get("trust_max_v21") or {}
        data = v21.get("data_integrity") or {}
        regime = v21.get("regime") or {}
        cns = item.get("cognitive_nexus") or {}
        quality = safe_float(item.get("signal_quality"), 0)
        neural = item.get("neural_v9") or {}
        neural_conf = safe_float(neural.get("confidence"), 0)
        rr = safe_float(item.get("effective_rr_tp1"), safe_float(item.get("rr_tp1"), 0))
        ai_side, ai_agree = self._ai(item)
        edges = self._candidate_edges(item)

        # Add AI only as a weighted partner. Historical AI performance can move
        # this influence, but never above a bounded ceiling.
        prof_long = learning.side_profile(symbol, "LONG")
        prof_short = learning.side_profile(symbol, "SHORT")
        chosen = "LONG" if edges["LONG"] >= edges["SHORT"] else "SHORT"
        prof = prof_long if chosen == "LONG" else prof_short
        global_prof = learning.global_profile()

        ai_bonus = 0.0
        if ai_side == chosen:
            base_ai = 4.0 + ai_agree * 0.07
            if prof.get("ai_samples", 0) >= 8:
                ai_quality = prof.get("ai_aligned_wr", 50)
                base_ai *= clamp(0.75 + (ai_quality - 45) / 80.0, 0.65, 1.35)
            ai_bonus = min(10.0, base_ai)
        elif ai_side in {"LONG", "SHORT"} and ai_agree >= 65:
            ai_bonus = -min(9.0, ai_agree * 0.06)

        score = clamp(max(edges.values()) + ai_bonus, 0, 100)
        raw_margin = edges["LONG"] - edges["SHORT"]
        # Never resolve an exact/near tie into SHORT merely because of a Python
        # else branch. A direction requires a measurable edge over the other side.
        side = "LONG" if raw_margin >= 1.0 else "SHORT" if raw_margin <= -1.0 else "WAIT"
        margin = abs(raw_margin)

        history_shift = prof.get("threshold_shift", 0.0)
        promote_threshold = V22_PROMOTE_SCORE + history_shift
        if prof.get("samples", 0) >= 20 and prof.get("recent_win_rate", 50) >= 60:
            promote_threshold -= 2.0
        # Balanced band: allow real edges through; history can still raise the bar a bit.
        promote_threshold = clamp(promote_threshold, 52.0, 72.0)

        hard_vetoes = []
        hard_vetoes.extend(data.get("hard_fail") or [])
        # Soften: only keep the most severe CNS vetoes as hard blockers
        for v in (cns.get("vetoes") or []):
            if str(v) in {"data_quality", "ai_hard_conflict", "rr"}:
                hard_vetoes.append(v)
        if rr < V22_MIN_RR:
            hard_vetoes.append("RR")
        if ai_side in {"LONG", "SHORT"} and ai_side != side and ai_agree >= V22_MAX_AI_CONFLICT:
            hard_vetoes.append("AI_HARD_CONFLICT")
        # Allow at most V22_MAX_HARD_VETOES soft issues without killing the signal
        if len(hard_vetoes) > max(0, int(V22_MAX_HARD_VETOES)):
            pass  # keep list; trigger logic still checks emptiness for strongest path
        else:
            # With balanced mode, a single mild veto does not zero the opportunity
            hard_vetoes = [v for v in hard_vetoes if str(v) in {"data_quality", "AI_HARD_CONFLICT", "invalid_price"}]

        persistence = self._persistence(symbol, side, score)

        # A strong candidate can be promoted on the first scan; otherwise two
        # consecutive observations are required. This is the anti-noise hysteresis.
        strong_trigger = (
            side in {"LONG", "SHORT"}
            and score >= V22_STRONG_TRIGGER_SCORE
            and data.get("trust", 0) >= V22_MIN_DATA
            and quality >= V22_MIN_QUALITY
            and neural_conf >= V22_MIN_NEURAL
            and rr >= V22_MIN_RR
            and len(hard_vetoes) <= V22_MAX_HARD_VETOES
            and ai_agree < V22_MAX_AI_CONFLICT
        )
        stable_trigger = (
            side in {"LONG", "SHORT"}
            and score >= promote_threshold
            and margin >= 3.5
            and data.get("trust", 0) >= V22_MIN_DATA
            and quality >= V22_MIN_QUALITY
            and neural_conf >= V22_MIN_NEURAL
            and rr >= V22_MIN_RR
            and (persistence["persistent"] or score >= V22_STRONG_TRIGGER_SCORE - 2)
            and len(hard_vetoes) <= V22_MAX_HARD_VETOES
        )

        core_decision = _v21_direction(item.get("decision_tag"))
        action = core_decision
        promoted = False
        if core_decision == "WAIT" and (strong_trigger or stable_trigger):
            action = side
            promoted = True

        # If the core already has a directional decision, V22 never changes its
        # direction merely because AI is louder; it only verifies/grades it.
        if core_decision in {"LONG", "SHORT"}:
            side = core_decision

        if action in {"LONG", "SHORT"}:
            state = "READY" if (data.get("trust", 0) >= 80 and quality >= 72 and neural_conf >= 65 and rr >= 1.35) else "EARLY"
        elif side in {"LONG", "SHORT"} and score >= V22_EARLY_SCORE and not hard_vetoes:
            state = "EARLY_" + side
        elif side in {"LONG", "SHORT"} and score >= V22_WATCH_SCORE:
            state = "WATCH_" + side
        else:
            state = "NO_EDGE"

        # Complete reason tree — every positive/negative contribution is visible.
        reasons = []
        reasons.append(f"سمت کاندید: {side}")
        reasons.append(f"امتیاز فرصت: {score:.1f}/100")
        reasons.append(f"اختلاف دو سمت: {margin:.1f}")
        reasons.append(f"اعتماد داده: {safe_float(data.get('trust'),0):.1f}")
        reasons.append(f"کیفیت سیگنال: {quality:.1f}")
        reasons.append(f"اعتماد عصبی: {neural_conf:.1f}")
        reasons.append(f"RR1: {rr:.2f}")
        reasons.append(f"رأی AI: {ai_side} با توافق {ai_agree:.1f}%")
        reasons.append(f"پایداری کاندید: {persistence['streak']} اسکن / {persistence['age_min']:.1f} دقیقه")
        reasons.append(f"رژیم: {regime.get('regime','—')}")
        if hard_vetoes:
            reasons.append("موانع سخت: " + ", ".join(dict.fromkeys(hard_vetoes)))
        if promoted:
            reasons.append("فرصت WAIT به سیگنال ارتقا یافت چون آستانه فرصت + شواهد مستقل + پایداری/تریگر برقرار شد")
        elif core_decision == "WAIT" and state.startswith(("EARLY_", "WATCH_")):
            reasons.append("سیگنال نهایی هنوز WAIT است؛ فرصت پنهان نشده و به‌عنوان پیش‌هشدار ثبت شد")
        elif core_decision == "WAIT":
            reasons.append("شواهد برای جهت‌دهی نهایی کافی نیست")

        return {
            "version": V22_VERSION,
            "action": action,
            "core_action": core_decision,
            "candidate_side": side,
            "opportunity_state": state,
            "opportunity_score": round(score, 1),
            "margin": round(margin, 1),
            "edges": {k: round(v, 1) for k, v in edges.items()},
            "ai": {"majority": ai_side, "agreement": round(ai_agree, 1), "bonus": round(ai_bonus, 2)},
            "learning": {
                "chosen_side": prof,
                "global": global_prof,
                "threshold": round(promote_threshold, 1),
            },
            "persistence": persistence,
            "hard_vetoes": list(dict.fromkeys(hard_vetoes)),
            "promoted": promoted,
            "reason_tree": reasons,
            "balance": {
                "actionable": action in {"LONG", "SHORT"},
                "opportunity_visible": state != "NO_EDGE",
                "false_signal_protection": bool(hard_vetoes or not promoted),
            },
        }


class TitanDecisionAuditV22:
    """Persistent decision ledger and self-review metrics."""

    def record(self, item: dict[str, Any], opp: dict[str, Any]) -> None:
        try:
            now = time.time()
            symbol = str(item.get("symbol") or "")
            with DB_LOCK, db_conn() as con:
                recent = con.execute(
                    "SELECT 1 FROM decision_journal_v22 WHERE symbol=? AND created_at>? LIMIT 1",
                    (symbol, now - V22_JOURNAL_COOLDOWN),
                ).fetchone()
                if recent:
                    return
                fusion = item.get("fusion") or {}
                con.execute(
                    "INSERT INTO decision_journal_v22("
                    "created_at,symbol,decision,candidate_side,opportunity_state,opportunity_score,"
                    "trust,quality,ai_majority,ai_agreement,regime,reason_json,outcome"
                    ") VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        now, symbol, str(item.get("decision_tag") or "WAIT"),
                        opp.get("candidate_side","WAIT"),
                        opp.get("opportunity_state","NO_EDGE"),
                        safe_float(opp.get("opportunity_score"),0),
                        safe_float((item.get("trust_max_v21") or {}).get("trust"),0),
                        safe_float(item.get("signal_quality"),0),
                        str((opp.get("ai") or {}).get("majority","WAIT")),
                        safe_float((opp.get("ai") or {}).get("agreement"),0),
                        str((opp.get("regime") or {}).get("regime") or (item.get("trust_max_v21") or {}).get("regime",{}).get("regime","")),
                        json.dumps({"reasons": opp.get("reason_tree",[]), "edges": opp.get("edges",{}), "learning": opp.get("learning",{})}, ensure_ascii=False),
                        "PENDING",
                    ),
                )
        except Exception as exc:
            LOGGER.debug("V22 journal write failed %s: %s", item.get("symbol"), exc)

    def summary(self) -> dict[str, Any]:
        try:
            with DB_LOCK, db_conn() as con:
                rows = con.execute(
                    "SELECT opportunity_state,decision,outcome,opportunity_score,trust,quality,ai_majority,ai_agreement "
                    "FROM decision_journal_v22 ORDER BY created_at DESC LIMIT 1000"
                ).fetchall()
            total = len(rows)
            ready = sum(1 for r in rows if str(r["decision"]) in {"LONG","SHORT"})
            visible = sum(1 for r in rows if str(r["opportunity_state"]) != "NO_EDGE")
            pending = sum(1 for r in rows if str(r["outcome"]) == "PENDING")
            return {
                "journal_rows": total,
                "directional_decisions": ready,
                "opportunities_visible": visible,
                "pending_reviews": pending,
                "coverage_pct": round(visible / total * 100, 1) if total else 0.0,
            }
        except Exception:
            return {"journal_rows": 0, "directional_decisions": 0, "opportunities_visible": 0, "pending_reviews": 0, "coverage_pct": 0.0}


TITAN_LEARNING_V22 = TitanLearningEngineV22()
TITAN_OPPORTUNITY_V22 = TitanOpportunityEngineV22()
TITAN_AUDIT_V22 = TitanDecisionAuditV22()


_analyze_asset_v21 = analyze_asset


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    item = _analyze_asset_v21(symbol, btc_trend)
    if not item:
        return None
    try:
        opp = TITAN_OPPORTUNITY_V22.evaluate(item, TITAN_LEARNING_V22)

        # If V22 legitimately promotes a WAIT, rebuild levels before exposing it.
        if opp.get("promoted") and opp.get("action") in {"LONG", "SHORT"} and item.get("decision_tag") == "WAIT":
            sl, tp1, tp2 = _v12_rebuild_directional_levels(item, opp["action"])
            price = _v12_parse_price(item.get("price"))
            chk = _v12_level_integrity(price, sl, tp1, tp2, opp["action"])
            if chk.get("ok"):
                item["stop_loss"] = smart_format(sl)
                item["tp1"] = smart_format(tp1)
                item["tp2"] = smart_format(tp2)
                item["effective_rr_tp1"] = chk["rr1"]
                item["effective_rr_tp2"] = chk["rr2"]
                item["rr_tp1"] = chk["rr1"]
                item["rr_tp2"] = chk["rr2"]
                item["decision_tag"] = opp["action"]
                item["bias"] = "صعودی" if opp["action"] == "LONG" else "نزولی"
                item["signal_tag"] = "V22 ADAPTIVE OPPORTUNITY"
                item["entry_mode"] = "EARLY"
                item.setdefault("fusion", {})["v22_promotion"] = True
                opp["level_integrity"] = chk
            else:
                opp["promoted"] = False
                opp["action"] = "WAIT"
                opp["level_integrity"] = chk
                opp["reason_tree"].append("ارتقا لغو شد چون SL/TP/RR نهایی معتبر نبود")

        # If V22 does not promote, preserve the real V21 decision but expose
        # the opportunity state so a strong setup is not hidden as a blank WAIT.
        item["opportunity_v22"] = opp
        item.setdefault("fusion", {})["opportunity_v22"] = opp
        item["decision_audit_v22"] = {
            "decision": item.get("decision_tag","WAIT"),
            "core_decision": opp.get("core_action","WAIT"),
            "candidate_side": opp.get("candidate_side","WAIT"),
            "state": opp.get("opportunity_state","NO_EDGE"),
            "score": opp.get("opportunity_score",0),
            "margin": opp.get("margin",0),
            "reasons": opp.get("reason_tree",[]),
            "learning": opp.get("learning",{}),
            "ai": opp.get("ai",{}),
        }
        item["opportunity_score"] = opp.get("opportunity_score",0)
        item["opportunity_state"] = opp.get("opportunity_state","NO_EDGE")
        item["opportunity_side"] = opp.get("candidate_side","WAIT")
        item["decision_reason"] = " | ".join(opp.get("reason_tree",[])[:12])

        # Final integrity: bias ↔ decision_tag ↔ grade stay coherent for the UI
        dec = str(item.get("decision_tag") or "WAIT").upper()
        if dec == "LONG":
            item["bias"] = "صعودی"
        elif dec == "SHORT":
            item["bias"] = "نزولی"
        elif dec == "WAIT":
            if item.get("bias") in {"صعودی", "نزولی"} and safe_float(item.get("opportunity_score"), 0) < 48:
                item["bias"] = "خنثی"
        # Ensure grade string is always present for templates
        if not item.get("grade"):
            sg = item.get("signal_grade") or {}
            item["grade"] = sg.get("grade") or "—"
            item["trust_index"] = item.get("trust_index") or sg.get("trust_index") or 0
        # Clamp display probability
        try:
            item["success_probability"] = round(float(clamp(safe_float(item.get("success_probability"), 50), 1, 95)), 1)
        except Exception:
            item["success_probability"] = 50.0
        item["param_version"] = TITAN_PARAM_VERSION

        TITAN_AUDIT_V22.record(item, opp)
        return item
    except Exception as exc:
        LOGGER.exception("V22 adaptive opportunity failed for %s: %s", symbol, exc)
        item["opportunity_v22"] = {
            "version": V22_VERSION,
            "action": item.get("decision_tag","WAIT"),
            "opportunity_state": "UNKNOWN",
            "opportunity_score": 0,
            "reason_tree": ["V22 خطا داد؛ تصمیم هسته بدون تغییر حفظ شد"],
        }
        return item


@app.get("/api/trust-max")
def api_trust_max():
    data, _summary, _macro = _fast_market_snapshot()
    return jsonify({
        "ok": True,
        "version": V22_VERSION,
        "summary": TITAN_AUDIT_V22.summary(),
        "learning": TITAN_LEARNING_V22.global_profile(),
        "items": [
            {
                "symbol": x.get("symbol"),
                "decision": x.get("decision_tag","WAIT"),
                "opportunity": x.get("opportunity_v22") or {},
                "audit": x.get("decision_audit_v22") or {},
            }
            for x in (data or [])
        ],
    })


@app.get("/api/opportunities")
def api_v22_opportunities():
    data, _summary, macro = _fast_market_snapshot()
    rows = []
    for x in data or []:
        o = x.get("opportunity_v22") or {}
        rows.append({
            "symbol": x.get("symbol"),
            "decision": x.get("decision_tag","WAIT"),
            "side": o.get("candidate_side","WAIT"),
            "state": o.get("opportunity_state","NO_EDGE"),
            "score": o.get("opportunity_score",0),
            "margin": o.get("margin",0),
            "ai": o.get("ai",{}),
            "learning": o.get("learning",{}),
            "reasons": o.get("reason_tree",[]),
            "vetoes": o.get("hard_vetoes",[]),
        })
    rows.sort(key=lambda r: safe_float(r.get("score"),0), reverse=True)
    return jsonify({
        "ok": True,
        "version": V22_VERSION,
        "rows": rows,
        "summary": {
            "ready": sum(1 for r in rows if r["decision"] in {"LONG","SHORT"}),
            "early": sum(1 for r in rows if str(r["state"]).startswith("EARLY")),
            "watch": sum(1 for r in rows if str(r["state"]).startswith("WATCH")),
            "no_edge": sum(1 for r in rows if r["state"] == "NO_EDGE"),
        },
        "macro": macro or {},
    })



# ============================================================
# TITAN V29 — EVIDENCE FUSION / "MAGIC" ARBITRATOR
# ------------------------------------------------------------
# This is deliberately NOT a mystical predictor. "Magic" means that the
# engine combines independent evidence, regime-aware weights, uncertainty,
# contradiction detection, hysteresis and hard data gates in one auditable
# final pass. It can surface a strong opportunity hidden by a soft WAIT, but
# it cannot manufacture a trade from missing data or from AI text alone.
# ============================================================
V29_VERSION = "TITAN-V29-EVIDENCE-FUSION-MAGIC"
V29_MIN_DQ = 52.0
V29_MIN_QUALITY = 54.0
V29_MIN_RR = 1.08
V29_PROMOTE_SCORE = 0.34
V29_EARLY_SCORE = 0.25
V29_WATCH_SCORE = 0.18
V29_MIN_INDEPENDENT = 3
V29_AI_MAX_WEIGHT = 0.12
V29_HARD_CONTRADICTION = 0.82


def _v29_side_value(value: Any, side: str, positive_words=(), negative_words=()) -> float:
    """Return signed evidence in [-1,1] without guessing on unknown values."""
    if isinstance(value, (int, float)):
        return clamp(float(value), -1.0, 1.0)
    text = str(value or "").strip().lower()
    if not text:
        return 0.0
    if side == "LONG":
        if text in {"صعودی", "bull", "bullish", "up", "long", "buy", "strong_long"} or any(w in text for w in positive_words):
            return 1.0
        if text in {"نزولی", "bear", "bearish", "down", "short", "sell", "strong_short"} or any(w in text for w in negative_words):
            return -1.0
    else:
        if text in {"نزولی", "bear", "bearish", "down", "short", "sell", "strong_short"} or any(w in text for w in positive_words):
            return 1.0
        if text in {"صعودی", "bull", "bullish", "up", "long", "buy", "strong_long"} or any(w in text for w in negative_words):
            return -1.0
    return 0.0


class TitanEvidenceFusionV29:
    """Final auditable evidence arbiter.

    Core principles:
      * no evidence is treated as neutral, never as bullish/bearish;
      * AI is capped and cannot manufacture a direction;
      * correlated indicators are grouped so five indicators do not count as
        five independent confirmations;
      * regime changes weights rather than changing the underlying evidence;
      * a direction needs both edge and independent confirmation;
      * confidence is evidence quality, not a guaranteed probability.
    """

    def _regime_profile(self, item: dict[str, Any]) -> tuple[str, dict[str, float]]:
        reg = str(((item.get("edge") or {}).get("regime") or {}).get("regime") or "").lower()
        if any(k in reg for k in ("trend", "bull", "bear", "uptrend", "downtrend")):
            return "TREND", {"tf":1.10,"structure":1.08,"flow":1.00,"forecast":0.92,"precision":0.90,"neural":1.05,"ai":0.90}
        if any(k in reg for k in ("range", "sideway", "mean")):
            return "RANGE", {"tf":0.78,"structure":0.88,"flow":1.00,"forecast":0.75,"precision":1.15,"neural":0.82,"ai":0.82}
        if any(k in reg for k in ("transition", "volatile", "chaos")):
            return "TRANSITION", {"tf":0.92,"structure":0.92,"flow":1.10,"forecast":0.70,"precision":1.05,"neural":0.78,"ai":0.72}
        return "NEUTRAL", {"tf":1.0,"structure":1.0,"flow":1.0,"forecast":0.9,"precision":1.0,"neural":0.9,"ai":0.82}

    def _build(self, item: dict[str, Any], side: str) -> dict[str, Any]:
        tf = item.get("tf_scores") or item.get("tfs") or {}
        edge = item.get("edge") or {}
        structure = edge.get("structure") or {}
        regime = edge.get("regime") or {}
        precision = item.get("precision") or edge.get("precision") or {}
        neural = (item.get("neural_v9") or (item.get("fusion") or {}).get("neural_v9") or {})
        forecast = item.get("candle_forecast") or {}
        derivatives = item.get("derivatives") or {}
        # Production payload also exposes derivatives at top level. Merge them so
        # V29 never loses live flow evidence simply because the transport shape changed.
        if not derivatives:
            derivatives = {k: item.get(k) for k in ("long_short_ratio","taker_buy_pct","taker_sell_pct","funding","coinglass_funding","oi_delta") if item.get(k) is not None}
        if "funding" not in derivatives and item.get("coinglass_funding") is not None:
            derivatives["funding"] = item.get("coinglass_funding")
        ai = edge.get("ai") or {}
        fusion = item.get("fusion") or {}
        profile, mult = self._regime_profile(item)

        ev=[]
        def add(name, group, raw, weight, quality=1.0, note=""):
            ev.append({"name":name,"group":group,"raw":clamp(raw,-1,1),"weight":max(0.0,weight),"quality":clamp(quality,0,1),"note":note})

        # Multi-timeframe spine: one independent group, not four votes.
        vals=[]
        tf_used=0.0
        for tf_name, w in (("15m",.16),("1h",.30),("4h",.30),("1d",.24)):
            if tf_name in tf:
                vals.append((safe_float(tf.get(tf_name),50)-50)/50*w)
                tf_used += w
        tf_edge=sum(vals)/max(tf_used,1e-9) if vals else 0.0
        add("multi_tf","tf",tf_edge,.23*mult["tf"],min(1,tf_used/.99),f"frames={len(vals)}")

        sb=str(structure.get("bias") or "")
        sc=clamp(safe_float(structure.get("confirmation_score"),50),0,100)
        st=_v29_side_value(sb,side)
        add("structure","structure",st*((sc-50)/50 if sc>=50 else 0.35*((sc-50)/50)),.17*mult["structure"],sc/100,sb or "neutral")

        # Flow/derivatives group. Use explicit directional ratios when available.
        ls=safe_float(derivatives.get("long_short_ratio"),0)
        taker_buy=safe_float(derivatives.get("taker_buy_pct"),50)
        funding=safe_float(derivatives.get("funding"),0)
        flow=0.0
        flow_parts=0
        if ls>0:
            # ratio >1 is long-heavy; map smoothly and symmetrically.
            flow += clamp(math.log(ls),-1,1); flow_parts += 1
        if "taker_buy_pct" in derivatives:
            flow += clamp((taker_buy-50)/20,-1,1); flow_parts += 1
        if "funding" in derivatives:
            # Positive funding is crowded long; therefore mildly bearish, and vice versa.
            flow += clamp(-funding/0.0015,-1,1); flow_parts += 1
        flow = flow/max(flow_parts,1)
        add("market_flow","flow",flow,.13*mult["flow"],min(1,flow_parts/3),f"parts={flow_parts}")

        # Precision/entry location group.
        timing=str(precision.get("entry_timing") or "").upper()
        pscore=clamp(safe_float(precision.get("score"),50),0,100)
        pe=(pscore-50)/50
        if timing in {"AVOID","DANGER","LATE"}: pe*=0.55
        add("entry_precision","precision",pe,.14*mult["precision"],pscore/100,timing or "unknown")

        # Forecast group: only count it when an actual directional path exists.
        fb=str(forecast.get("overall_bias") or "")
        fs=clamp(safe_float(forecast.get("path_strength"),0)/40,0,1)
        add("future_path","forecast",_v29_side_value(fb,side)*fs,.10*mult["forecast"],fs,fb or "neutral")

        # Neural group.
        ns=str(neural.get("side") or "WAIT").upper()
        nc=clamp(safe_float(neural.get("confidence"),0)/100,0,1)
        add("neural","neural",(1 if ns==side else -1 if ns in {"LONG","SHORT"} else 0)*nc,.13*mult["neural"],nc,ns)

        # AI group is deliberately capped. AI text can enrich evidence but cannot
        # override market data or hard safety gates.
        am=str(ai.get("majority") or ai.get("ai_majority") or fusion.get("ai_majority") or "WAIT").upper()
        aa=clamp(safe_float(ai.get("agreement") or ai.get("majority_agreement") or fusion.get("ai_agreement"),0)/100,0,1)
        add("ai_ensemble","ai",(1 if am==side else -1 if am in {"LONG","SHORT"} else 0)*aa,V29_AI_MAX_WEIGHT*mult["ai"],aa,am)

        total_w=sum(x["weight"] for x in ev)
        weighted=sum(x["raw"]*x["weight"]*x["quality"] for x in ev)
        score=weighted/max(total_w,1e-9)
        # Contradiction is group-level, so correlated indicators cannot inflate it.
        active=[x for x in ev if abs(x["raw"])>=0.22 and x["quality"]>=0.45]
        support=[x for x in active if x["raw"]>0]
        oppose=[x for x in active if x["raw"]<0]
        contradiction=(min(len(support),len(oppose))/max(len(active),1)) if active else 0.0
        independent_support=len({x["group"] for x in support})
        independent_oppose=len({x["group"] for x in oppose})
        margin=abs(score)
        quality=clamp(safe_float(item.get("signal_quality"),50),0,100)
        dq=clamp(safe_float((item.get("data_quality") or {}).get("score") or (fusion.get("data_quality") or {}).get("score"),50),0,100)
        rr= safe_float(item.get("effective_rr_tp1") or item.get("rr_tp1"),0)
        hard=[]
        if dq < V29_MIN_DQ: hard.append("DATA_QUALITY")
        if rr > 0 and rr < V29_MIN_RR: hard.append("RR_LOW")
        if price_invalid := (safe_float(str(item.get("price")).replace(",",""),0) <= 0): hard.append("PRICE_INVALID")
        if contradiction>=V29_HARD_CONTRADICTION: hard.append("EVIDENCE_CONTRADICTION")
        return {
            "version":V29_VERSION,"regime":profile,"score":round(score,4),
            "strength":round(margin*100,1),"independent_support":independent_support,
            "independent_oppose":independent_oppose,"contradiction":round(contradiction,3),
            "quality":round(quality,1),"data_quality":round(dq,1),"rr":round(rr,2),
            "hard_blocks":list(dict.fromkeys(hard)),"evidence":ev,
            "support_groups":sorted({x["group"] for x in support}),
            "oppose_groups":sorted({x["group"] for x in oppose}),
            "regime": profile,
        }

    def evaluate(self,item:dict[str,Any])->dict[str,Any]:
        long=self._build(item,"LONG"); short=self._build(item,"SHORT")
        # Choose the side by absolute evidence edge. Near ties remain neutral.
        side="LONG" if long["score"]-short["score"]>=0.10 else "SHORT" if short["score"]-long["score"]>=0.10 else "WAIT"
        chosen=long if side=="LONG" else short if side=="SHORT" else {"score":0,"strength":0,"independent_support":0,"hard_blocks":list(dict.fromkeys(long["hard_blocks"]+short["hard_blocks"])),"contradiction":max(long["contradiction"],short["contradiction"]),"quality":max(long["quality"],short["quality"]),"data_quality":min(long["data_quality"],short["data_quality"]),"rr":max(long["rr"],short["rr"]),"support_groups":[],"oppose_groups":[]}
        current=str(item.get("decision_tag") or "WAIT").upper()
        candidate=side
        # Independent evidence is the key anti-noise mechanism.
        promote=(
            candidate in {"LONG","SHORT"}
            and chosen["score"]>=V29_PROMOTE_SCORE
            and chosen["independent_support"]>=V29_MIN_INDEPENDENT
            and chosen["quality"]>=V29_MIN_QUALITY
            and chosen["data_quality"]>=V29_MIN_DQ
            and chosen["rr"]>=V29_MIN_RR
            and not chosen["hard_blocks"]
        )
        early=(candidate in {"LONG","SHORT"} and chosen["score"]>=V29_EARLY_SCORE and chosen["independent_support"]>=2 and not chosen["hard_blocks"])
        watch=(candidate in {"LONG","SHORT"} and chosen["score"]>=V29_WATCH_SCORE and chosen["independent_support"]>=2)
        if promote: state="MAGIC_READY"
        elif early: state="MAGIC_EARLY_"+candidate
        elif watch: state="MAGIC_WATCH_"+candidate
        else: state="MAGIC_NO_EDGE"
        confidence=clamp(50 + chosen["strength"]*0.42 + max(0,chosen["independent_support"]-1)*5 - chosen["contradiction"]*28,0,96)
        return {"version":V29_VERSION,"candidate":candidate,"current":current,"promote":promote,"state":state,"confidence":round(confidence,1),"long":long,"short":short,"chosen":chosen,"explanation":[
            f"رژیم: {chosen.get('regime','—')}",
            f"لبه خالص: {chosen.get('strength',0):.1f}%",
            f"شواهد مستقل هم‌جهت: {chosen.get('independent_support',0)} گروه",
            f"تناقض گروهی: {chosen.get('contradiction',0)*100:.1f}%",
            f"اعتماد شواهد: {confidence:.1f}/100",
            "AI فقط نقش تقویتی محدود دارد و جایگزین داده بازار نیست.",
        ]}


TITAN_MAGIC_V29 = TitanEvidenceFusionV29()

# Preserve V22 as the complete prior pipeline, then put one transparent final
# arbitration layer above it. This avoids touching the dashboard contract.
_analyze_asset_v22 = analyze_asset

def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    item = _analyze_asset_v22(symbol, btc_trend)
    if not item:
        return None
    try:
        magic = TITAN_MAGIC_V29.evaluate(item)
        item["magic_v29"] = magic
        item.setdefault("fusion", {})["magic_v29"] = magic
        item["magic_confidence"] = magic.get("confidence", 0)
        item["magic_state"] = magic.get("state", "MAGIC_NO_EDGE")

        current=str(item.get("decision_tag") or "WAIT").upper()
        candidate=str(magic.get("candidate") or "WAIT").upper()
        chosen=magic.get("chosen") or {}
        # A promotion is allowed only for a current WAIT and only when V29 has
        # enough independent evidence. If levels cannot be made valid, it stays WAIT.
        if current=="WAIT" and magic.get("promote") and candidate in {"LONG","SHORT"}:
            try:
                price=_v12_parse_price(item.get("price"))
                sl,tp1,tp2=_v12_rebuild_directional_levels(item,candidate)
                chk=_v12_level_integrity(price,sl,tp1,tp2,candidate)
                if chk.get("ok") and safe_float(chk.get("rr1"),0)>=V29_MIN_RR:
                    item["stop_loss"]=smart_format(sl); item["tp1"]=smart_format(tp1); item["tp2"]=smart_format(tp2)
                    item["effective_rr_tp1"]=chk["rr1"]; item["effective_rr_tp2"]=chk["rr2"]
                    item["rr_tp1"]=chk["rr1"]; item["rr_tp2"]=chk["rr2"]
                    item["decision_tag"]=candidate
                    item["bias"]="صعودی" if candidate=="LONG" else "نزولی"
                    item["signal_tag"]="V29 MAGIC READY"
                    item["entry_mode"]="EARLY"
                    item["signal_quality"]=max(safe_float(item.get("signal_quality"),50),min(86,safe_float(chosen.get("quality"),50)+8))
                    magic["applied"]=True
                else:
                    magic["applied"]=False
                    magic["explanation"].append("ارتقای V29 لغو شد: سطوح نهایی یا RR معتبر نبود.")
            except Exception as exc:
                magic["applied"]=False
                magic["explanation"].append("ارتقای V29 به‌دلیل خطای کنترل سطوح انجام نشد.")
                LOGGER.debug("V29 promotion failed for %s: %s",symbol,exc)
        elif current in {"LONG","SHORT"}:
            # Existing directional decisions are never flipped by the magic layer.
            magic["applied"]=False
            magic["explanation"].append("تصمیم جهت‌دار موجود حفظ شد؛ V29 فقط آن را ممیزی کرد.")
        else:
            magic["applied"]=False

        # Final consistency fields for dashboard/API consumers.
        item["canonical_decision"]={**(item.get("canonical_decision") or {}),"decision":item.get("decision_tag","WAIT"),"bias":item.get("bias","خنثی"),"magic_confidence":magic.get("confidence",0),"magic_state":magic.get("state")}
        item["decision_audit_v29"]={
            "decision":item.get("decision_tag","WAIT"),"candidate":candidate,
            "state":magic.get("state"),"confidence":magic.get("confidence",0),
            "independent_support":chosen.get("independent_support",0),
            "contradiction":chosen.get("contradiction",0),
            "hard_blocks":chosen.get("hard_blocks",[]),
            "explanation":magic.get("explanation",[]),
        }
        return item
    except Exception as exc:
        LOGGER.exception("V29 magic arbitration failed for %s: %s",symbol,exc)
        item["magic_v29"]={"version":V29_VERSION,"state":"ERROR","confidence":0,"error":"internal arbitration failure"}
        return item


# ============================================================
# TITAN V30 — DEEP CONSENSUS / MARKET DEBATE / ADAPTIVE DECISION CORE
# ------------------------------------------------------------
# V30 is a second-stage meta-arbiter. It does not pretend that an AI model
# can predict price with certainty. It makes the existing stack compete in
# an auditable debate: trend, structure, flow, volatility, forecast, neural,
# precision, BTC context and AI. Correlated evidence is compressed into
# families; missing/stale evidence is penalized rather than guessed.
# ============================================================
V30_VERSION = "TITAN-V30-DEEP-CONSENSUS"
V30_MIN_DATA = 58.0
V30_MIN_QUALITY = 56.0
V30_MIN_READY = 0.30
V30_MIN_EARLY = 0.20
V30_MIN_WATCH = 0.12
V30_MAX_AI = 0.10
V30_DEMOTE_EDGE = -0.30
V30_DEMOTE_OPPOSITION = 3


def _v30_num(v, default=0.0):
    try:
        if v is None or v == "":
            return float(default)
        return float(str(v).replace("%", "").replace(",", "").strip())
    except Exception:
        return float(default)


def _v30_direction(v):
    t=str(v or "").strip().lower()
    if t in {"long","bull","bullish","up","صعودی","buy","strong_long"}: return "LONG"
    if t in {"short","bear","bearish","down","نزولی","sell","strong_short"}: return "SHORT"
    return "WAIT"


class TitanDeepConsensusV30:
    """Adaptive, auditable final decision debate.

    Important design rule: V30 can *remove* a weak directional decision when
    independent evidence strongly contradicts it, but it never flips LONG to
    SHORT (or vice versa) merely because a model says so. A fresh evaluation
    must establish the opposite side before a later scan can select it.
    """

    TF_W = {"15m": .14, "1h": .31, "4h": .32, "1d": .23}

    def _regime(self, item):
        reg=str(((item.get("edge") or {}).get("regime") or {}).get("regime") or "").lower()
        if any(x in reg for x in ("trend","bull","bear","uptrend","downtrend")):
            return "TREND", {"tf":1.12,"structure":1.12,"flow":1.02,"vol":.90,"forecast":.95,"neural":1.05,"precision":.92,"btc":1.00}
        if any(x in reg for x in ("range","sideway","mean")):
            return "RANGE", {"tf":.80,"structure":.90,"flow":1.02,"vol":1.08,"forecast":.78,"neural":.84,"precision":1.15,"btc":.88}
        if any(x in reg for x in ("transition","volatile","chaos")):
            return "TRANSITION", {"tf":.88,"structure":.88,"flow":1.12,"vol":1.12,"forecast":.70,"neural":.78,"precision":1.06,"btc":1.02}
        return "NEUTRAL", {k:1.0 for k in ("tf","structure","flow","vol","forecast","neural","precision","btc")}

    def _flow(self, item, side):
        # V29 expected a nested derivatives dict, but the production item also
        # exposes these fields at top level. V30 intentionally supports both.
        d=item.get("derivatives") or {}
        def get(k, default=None):
            if k in d: return d.get(k)
            if k == "funding" and item.get("coinglass_funding") is not None: return item.get("coinglass_funding")
            return item.get(k, default)
        parts=[]
        ls=_v30_num(get("long_short_ratio"),0)
        if ls>0:
            e=clamp(math.log(ls),-1,1)
            parts.append(e)
        if get("taker_buy_pct") is not None:
            parts.append(clamp((_v30_num(get("taker_buy_pct"),50)-50)/20,-1,1))
        if get("funding") is not None:
            # crowded positive funding is mildly bearish; negative funding mildly bullish
            parts.append(clamp(-_v30_num(get("funding"),0)/0.0015,-1,1))
        oi=_v30_num(get("oi_delta"),0)
        if oi:
            parts.append(clamp(oi/6,-1,1))
        e=sum(parts)/len(parts) if parts else 0.0
        return e if side=="LONG" else -e, min(1,len(parts)/4), parts

    def _tf(self,item,side):
        tf=item.get("tf_scores") or item.get("tfs") or {}
        vals=[]; used=0
        for k,w in self.TF_W.items():
            if k not in tf: continue
            e=clamp((_v30_num(tf.get(k),50)-50)/50,-1,1)
            vals.append((e,w)); used+=1
        if not vals: return 0.0,0.0,{"frames":0,"coherence":0}
        total_w=sum(w for _,w in vals)
        signed=sum(e*w for e,w in vals)/max(total_w,1e-9)
        signs=[1 if e>.08 else -1 if e<-.08 else 0 for e,_ in vals]
        active=[x for x in signs if x]
        coherence=max(active.count(1),active.count(-1))/len(active) if active else .35
        return (signed if side=="LONG" else -signed), min(1,used/4), {"frames":used,"coherence":round(coherence,3),"signed":round(signed,3)}

    def _build_side(self,item,side,reg,mult):
        ev=[]
        def add(name, family, edge, weight, quality, source):
            ev.append({"name":name,"family":family,"edge":clamp(edge,-1,1),"weight":max(0,weight),"quality":clamp(quality,0,1),"source":source})

        tf,tfq,tfm=self._tf(item,side)
        add("multi_timeframe","trend",tf,.25*mult["tf"],tfq,f"{tfm['frames']} frames / coherence {tfm['coherence']}")

        edge=item.get("edge") or {}
        st=edge.get("structure") or {}
        sb=_v30_direction(st.get("bias"))
        sc=clamp(_v30_num(st.get("confirmation_score"),50),0,100)
        se=((sc-50)/50) if sc>=50 else .35*((sc-50)/50)
        if sb!=side: se=-abs(se) if sb in {"LONG","SHORT"} else 0
        add("market_structure","structure",se,.17*mult["structure"],sc/100,sb or "WAIT")

        fe,fq,fp=self._flow(item,side)
        add("derivatives_flow","flow",fe,.14*mult["flow"],fq,f"parts={len(fp)}")

        # Precision + volatility are deliberately separate: entry quality does
        # not become a directional vote just because volatility is high.
        pr=item.get("precision") or {}
        ps=clamp(_v30_num(pr.get("score"),50),0,100)
        pe=(ps-50)/50
        timing=str(pr.get("entry_timing") or "").upper()
        if timing in {"AVOID","DANGER","LATE"}: pe*=.45
        add("entry_precision","precision",pe,.10*mult["precision"],ps/100,timing or "unknown")

        vol=_v30_num(item.get("volatility_pct"),0)
        # Volatility is a confidence modifier, not a fake directional signal.
        vol_quality=1.0 if 0.05 <= vol <= 8 else .62 if vol>0 else .45
        add("volatility_context","vol",0,.08*mult["vol"],vol_quality,f"vol={vol:.3f}%")

        fc=item.get("candle_forecast") or {}
        fb=_v30_direction(fc.get("overall_bias"))
        fs=clamp(_v30_num(fc.get("path_strength"),0)/40,0,1)
        add("future_path","forecast",fs if fb==side else -fs if fb in {"LONG","SHORT"} else 0,.10*mult["forecast"],fs,fb)

        neural=item.get("neural_v9") or (item.get("fusion") or {}).get("neural_v9") or {}
        ns=_v30_direction(neural.get("side")); nc=clamp(_v30_num(neural.get("confidence"),0)/100,0,1)
        add("neural_model","neural",nc if ns==side else -nc if ns in {"LONG","SHORT"} else 0,.11*mult["neural"],nc,ns)

        # BTC context is a filter, not an absolute veto. This avoids blocking
        # strong idiosyncratic setups while still accounting for market beta.
        btc=_v30_direction(item.get("btc_trend"))
        btc_e=.45 if btc==side else -.45 if btc in {"LONG","SHORT"} else 0
        add("btc_context","btc",btc_e,.07*mult["btc"],.75 if btc!="WAIT" else .35,btc)

        ai=edge.get("ai") or {}
        am=_v30_direction(ai.get("majority") or ai.get("ai_majority") or item.get("ai_majority"))
        aa=clamp(_v30_num(ai.get("agreement") or ai.get("majority_agreement"),0)/100,0,1)
        add("ai_ensemble","ai",aa if am==side else -aa if am in {"LONG","SHORT"} else 0,V30_MAX_AI*mult.get("ai",.9),aa,am)

        # Data integrity is a global quality multiplier; it never creates direction.
        dq=clamp(_v30_num((item.get("data_quality") or {}).get("score") or ((item.get("fusion") or {}).get("data_quality") or {}).get("score"),50),0,100)
        global_q=.55+.45*(dq/100)
        for x in ev: x["quality"]*=global_q

        total=sum(x["weight"] for x in ev)
        score=sum(x["edge"]*x["weight"]*x["quality"] for x in ev)/max(total,1e-9)
        active=[x for x in ev if abs(x["edge"])>=.12 and x["quality"]>=.40 and x["weight"]>0]
        support=[x for x in active if x["edge"]>0]
        oppose=[x for x in active if x["edge"]<0]
        support_f={x["family"] for x in support}; oppose_f={x["family"] for x in oppose}
        contradiction=(min(len(support_f),len(oppose_f))/max(len(support_f|oppose_f),1)) if (support_f or oppose_f) else 0
        # Debate quality: agreement among independent families, not raw vote count.
        family_edges={}
        for x in ev:
            family_edges.setdefault(x["family"],[]).append(x["edge"])
        fam={k:sum(v)/len(v) for k,v in family_edges.items()}
        consensus=sum(1 for v in fam.values() if v>.10)/max(sum(1 for v in fam.values() if abs(v)>.10),1)
        disagreement=sum(1 for v in fam.values() if v<-.10)/max(sum(1 for v in fam.values() if abs(v)>.10),1)
        quality=clamp(_v30_num(item.get("signal_quality"),50),0,100)
        rr=_v30_num(item.get("effective_rr_tp1") or item.get("rr_tp1"),0)
        hard=[]
        if dq<V30_MIN_DATA: hard.append("DATA_QUALITY")
        if rr>0 and rr<1.08: hard.append("RR_LOW")
        if _v30_num(item.get("price"),0)<=0: hard.append("PRICE_INVALID")
        return {"side":side,"score":round(score,4),"strength":round(abs(score)*100,1),"support":len(support_f),"oppose":len(oppose_f),"support_families":sorted(support_f),"oppose_families":sorted(oppose_f),"contradiction":round(contradiction,3),"consensus":round(consensus,3),"quality":round(quality,1),"data_quality":round(dq,1),"rr":round(rr,2),"hard_blocks":hard,"evidence":ev,"debate":fam}

    def evaluate(self,item):
        reg,mult=self._regime(item)
        long=self._build_side(item,"LONG",reg,mult); short=self._build_side(item,"SHORT",reg,mult)
        delta=long["score"]-short["score"]
        candidate="LONG" if delta>=.08 else "SHORT" if delta<=-.08 else "WAIT"
        chosen=long if candidate=="LONG" else short if candidate=="SHORT" else (long if long["score"]>=short["score"] else short)
        ready=(candidate in {"LONG","SHORT"} and chosen["score"]>=V30_MIN_READY and chosen["support"]>=3 and chosen["quality"]>=V30_MIN_QUALITY and chosen["data_quality"]>=V30_MIN_DATA and chosen["rr"]>=1.08 and not chosen["hard_blocks"] and chosen["contradiction"]<.70)
        early=(candidate in {"LONG","SHORT"} and chosen["score"]>=V30_MIN_EARLY and chosen["support"]>=2 and chosen["data_quality"]>=50 and not chosen["hard_blocks"])
        watch=(candidate in {"LONG","SHORT"} and chosen["score"]>=V30_MIN_WATCH and chosen["support"]>=2)
        state="READY" if ready else "EARLY" if early else "WATCH" if watch else "WAIT"
        # Confidence is explicitly evidence confidence, not a win probability.
        conf=clamp(50+abs(delta)*38+chosen["support"]*5-chosen["oppose"]*4-chosen["contradiction"]*22+(chosen["data_quality"]-50)*.15,0,96)
        return {"version":V30_VERSION,"regime":reg,"candidate":candidate,"state":state,"confidence":round(conf,1),"delta":round(delta,4),"long":long,"short":short,"chosen":chosen,"discussion":{"agreement":round(chosen["consensus"]*100,1),"disagreement":round(chosen["contradiction"]*100,1),"independent_support":chosen["support"],"independent_opposition":chosen["oppose"],"active_families":sorted(set(chosen["support_families"]+chosen["oppose_families"]))},"explanation":[f"رژیم بازار: {reg}",f"اختلاف شواهد LONG/SHORT: {delta:.3f}",f"حمایت مستقل: {chosen['support']} خانواده",f"مخالفت مستقل: {chosen['oppose']} خانواده",f"اعتماد شواهد: {conf:.1f}/100","AI در سقف وزن 10٪ باقی می‌ماند و به‌تنهایی جهت نمی‌سازد.","Volatility فقط کیفیت را تعدیل می‌کند و به‌تنهایی سیگنال نمی‌سازد."]}


TITAN_DEEP_V30 = TitanDeepConsensusV30()
_analyze_asset_v29 = analyze_asset

def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    item=_analyze_asset_v29(symbol,btc_trend)
    if not item: return None
    try:
        debate=TITAN_DEEP_V30.evaluate(item)
        item["deep_consensus_v30"]=debate
        item.setdefault("fusion",{})["deep_consensus_v30"]=debate
        item["decision_confidence_v30"]=debate["confidence"]
        item["decision_state_v30"]=debate["state"]
        item["decision_discussion_v30"]=debate["discussion"]
        current=str(item.get("decision_tag") or "WAIT").upper()
        cand=debate.get("candidate")
        chosen=debate.get("chosen") or {}
        # Safety demotion: if an existing LONG/SHORT is strongly contradicted
        # by several independent families, remove it rather than silently keep
        # a stale signal. V30 never directly reverses direction.
        if current in {"LONG","SHORT"}:
            opposite=debate["short"] if current=="LONG" else debate["long"]
            if (opposite["score"]>=.30 and opposite["support"]>=V30_DEMOTE_OPPOSITION and opposite["data_quality"]>=V30_MIN_DATA and opposite["quality"]>=V30_MIN_QUALITY and not opposite["hard_blocks"]):
                item["decision_tag"]="WAIT"
                item["bias"]="خنثی"
                item["signal_tag"]="V30 DEBATE — WAIT"
                item["entry_mode"]="WAIT"
                item["decision_demoted_v30"]=True
                debate["explanation"].append("تصمیم قبلی به WAIT تنزل یافت: چند خانواده مستقل شواهد معتبر در جهت مخالف داشتند.")
        elif current=="WAIT" and cand in {"LONG","SHORT"} and debate["state"]=="READY":
            # V30 is intentionally stricter than V29 for final promotion.
            try:
                price=_v12_parse_price(item.get("price")); sl,tp1,tp2=_v12_rebuild_directional_levels(item,cand)
                chk=_v12_level_integrity(price,sl,tp1,tp2,cand)
                if chk.get("ok") and _v30_num(chk.get("rr1"),0)>=1.08:
                    item["stop_loss"]=smart_format(sl); item["tp1"]=smart_format(tp1); item["tp2"]=smart_format(tp2)
                    item["effective_rr_tp1"]=chk["rr1"]; item["effective_rr_tp2"]=chk["rr2"]; item["rr_tp1"]=chk["rr1"]; item["rr_tp2"]=chk["rr2"]
                    item["decision_tag"]=cand; item["bias"]="صعودی" if cand=="LONG" else "نزولی"; item["signal_tag"]="V30 DEEP CONSENSUS READY"; item["entry_mode"]="EARLY"; item["decision_promoted_v30"]=True
                    item["signal_quality"]=max(_v30_num(item.get("signal_quality"),50),min(90,chosen.get("quality",50)+8))
                    debate["applied"]=True
                else: debate["applied"]=False
            except Exception as exc:
                debate["applied"]=False; debate["explanation"].append("ارتقای V30 به‌علت کنترل سطوح انجام نشد."); LOGGER.debug("V30 promotion failed %s: %s",symbol,exc)
        else:
            debate["applied"]=False
        item["canonical_decision"]={**(item.get("canonical_decision") or {}),"decision":item.get("decision_tag","WAIT"),"bias":item.get("bias","خنثی"),"v30_confidence":debate["confidence"],"v30_state":debate["state"]}
        item["decision_audit_v30"]={"version":V30_VERSION,"decision":item.get("decision_tag","WAIT"),"candidate":cand,"state":debate["state"],"confidence":debate["confidence"],"discussion":debate["discussion"],"explanation":debate["explanation"]}
        return item
    except Exception as exc:
        LOGGER.exception("V30 deep consensus failed for %s: %s",symbol,exc)
        item["deep_consensus_v30"]={"version":V30_VERSION,"state":"ERROR","confidence":0,"error":"internal consensus failure"}
        return item


# ============================================================
# V31 — CANONICAL DECISION GOVERNOR
# One brain / many evidence channels. All upstream modules are evidence only;
# none of them is allowed to publish an independent final decision.
# ============================================================
V31_VERSION = "TITAN-V31-CANONICAL-DECISION-GOVERNOR"
V31_MIN_MARGIN = 0.065
V31_READY_MARGIN = 0.145
V31_STRONG_MARGIN = 0.24
V31_MIN_DATA = 54.0
V31_MIN_QUALITY = 50.0
V31_MIN_RR = 1.02
V31_MAX_CONTRADICTION = 0.70
V31_PRIOR_MAX = 0.08

class TitanCanonicalDecisionV31:
    """Single final decision brain.

    Upstream engines may disagree internally. Their outputs are compressed into
    common evidence and evaluated together. Only this governor is authoritative
    for the final LONG/SHORT/WAIT decision exposed to the dashboard/API.
    """
    def _side(self, debate, side):
        return (debate or {}).get(side.lower()) or {}

    def _score(self, debate, side):
        return float(self._side(debate, side).get("score", 0.0) or 0.0)

    def decide(self, item, debate):
        long = self._side(debate, "LONG")
        short = self._side(debate, "SHORT")
        ls = self._score(debate, "LONG")
        ss = self._score(debate, "SHORT")
        margin = ls - ss
        abs_margin = abs(margin)
        candidate = "LONG" if margin >= V31_MIN_MARGIN else "SHORT" if margin <= -V31_MIN_MARGIN else "WAIT"
        chosen = long if candidate == "LONG" else short if candidate == "SHORT" else (long if ls >= ss else short)
        opposite = short if candidate == "LONG" else long if candidate == "SHORT" else {}

        dq = float(chosen.get("data_quality", 0) or 0)
        quality = float(chosen.get("quality", 0) or 0)
        rr = float(chosen.get("rr", 0) or 0)
        contradiction = float(chosen.get("contradiction", 0) or 0)
        support = int(chosen.get("support", 0) or 0)
        oppose = int(chosen.get("oppose", 0) or 0)
        hard = list(chosen.get("hard_blocks") or [])

        # Confidence is an evidence-confidence score, not a probability of profit.
        base = 50.0 + abs_margin * 105.0
        base += min(18.0, support * 4.5)
        base -= min(18.0, oppose * 4.0)
        base -= contradiction * 24.0
        base += max(-10.0, min(10.0, (dq - 60.0) * 0.18))
        base += max(-7.0, min(7.0, (quality - 60.0) * 0.14))
        if rr >= V31_MIN_RR: base += min(5.0, (rr - V31_MIN_RR) * 5.0)
        confidence = clamp(base, 0.0, 96.0)

        reasons=[]
        if candidate == "WAIT": reasons.append("اختلاف LONG و SHORT برای تصمیم جهت‌دار کافی نیست.")
        if dq < V31_MIN_DATA: reasons.append("کیفیت/اعتبار داده برای تصمیم جهت‌دار کافی نیست.")
        if quality < V31_MIN_QUALITY: reasons.append("کیفیت سیگنال ترکیبی پایین‌تر از حد لازم است.")
        if rr and rr < V31_MIN_RR: reasons.append("نسبت ریسک به بازده مؤثر کافی نیست.")
        if contradiction >= V31_MAX_CONTRADICTION: reasons.append("بین خانواده‌های مستقل شواهد تضاد معنادار وجود دارد.")
        if hard: reasons.append("یک یا چند کنترل سخت کیفیت/ریسک فعال است.")
        if support < 2 and candidate != "WAIT": reasons.append("پشتیبانی مستقل برای جهت انتخابی محدود است.")

        # A direction becomes authoritative only when the combined evidence is
        # coherent. No individual model, indicator, or AI provider can promote it.
        directional_ok = (
            candidate in {"LONG","SHORT"}
            and abs_margin >= V31_MIN_MARGIN
            and dq >= V31_MIN_DATA
            and quality >= V31_MIN_QUALITY
            and rr >= V31_MIN_RR
            and support >= 1
            and contradiction < V31_MAX_CONTRADICTION
            and not hard
        )

        if not directional_ok:
            final = "WAIT"
            state = "WAIT"
        elif abs_margin >= V31_STRONG_MARGIN and support >= 3 and quality >= 60 and dq >= 62:
            final = candidate
            state = "STRONG"
        elif abs_margin >= V31_READY_MARGIN and support >= 2:
            final = candidate
            state = "READY"
        else:
            final = candidate
            state = "EARLY"

        # Hysteresis: an existing valid direction may survive a small temporary
        # margin loss, but it cannot survive a clear opposite consensus.
        prior = str(item.get("decision_tag") or "WAIT").upper()
        if final == "WAIT" and prior in {"LONG","SHORT"}:
            prior_side = self._side(debate, prior)
            prior_score = float(prior_side.get("score",0) or 0)
            opp_score = float((short if prior=="LONG" else long).get("score",0) or 0)
            prior_valid = (
                prior_score >= 0.16 and dq >= V31_MIN_DATA and quality >= V31_MIN_QUALITY
                and rr >= V31_MIN_RR and int(prior_side.get("support",0) or 0) >= 1
                and float(prior_side.get("contradiction",0) or 0) < V31_MAX_CONTRADICTION
                and not (prior_side.get("hard_blocks") or [])
            )
            clear_opposite = (opp_score - prior_score) >= V31_READY_MARGIN and int((short if prior=="LONG" else long).get("support",0) or 0) >= 3
            if prior_valid and not clear_opposite:
                final = prior
                state = "HOLDING"
                reasons.append("تصمیم قبلی فقط به‌عنوان hysteresis معتبر حفظ شد؛ هیچ موتور مستقلی تصمیم را تحمیل نکرد.")

        if not reasons:
            reasons.append("تصمیم از ادغام واحد همه خانواده‌های شواهد حاصل شد.")

        return {
            "version": V31_VERSION,
            "decision": final,
            "state": state,
            "candidate": candidate,
            "confidence": round(confidence,1),
            "margin": round(margin,4),
            "long_score": round(ls,4),
            "short_score": round(ss,4),
            "support": support,
            "opposition": oppose,
            "data_quality": round(dq,1),
            "signal_quality": round(quality,1),
            "rr": round(rr,2),
            "contradiction": round(contradiction,3),
            "authoritative": True,
            "reason": reasons,
            "architecture": "ONE_BRAIN_MANY_EVIDENCE_CHANNELS",
        }

TITAN_CANONICAL_V31 = TitanCanonicalDecisionV31()
_analyze_asset_v30 = analyze_asset

def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """Public analyzer: exactly one authoritative final decision."""
    item = _analyze_asset_v30(symbol, btc_trend)
    if not item:
        return None
    try:
        debate = item.get("deep_consensus_v30") or TITAN_DEEP_V30.evaluate(item)
        canonical = TITAN_CANONICAL_V31.decide(item, debate)

        # Preserve every upstream analysis as evidence/audit, but overwrite the
        # public decision fields from ONE canonical governor only.
        decision = canonical["decision"]
        item["decision_tag"] = decision
        item["bias"] = "صعودی" if decision == "LONG" else "نزولی" if decision == "SHORT" else "خنثی"
        item["entry_mode"] = "EARLY" if decision in {"LONG","SHORT"} else "WAIT"
        item["decision_confidence"] = canonical["confidence"]
        item["decision_state"] = canonical["state"]
        item["signal_tag"] = f"V31 CANONICAL — {decision}"
        item["canonical_decision"] = {
            **(item.get("canonical_decision") or {}),
            "decision": decision,
            "bias": item["bias"],
            "confidence": canonical["confidence"],
            "state": canonical["state"],
            "version": V31_VERSION,
            "authoritative": True,
        }
        item["decision_audit_v31"] = canonical
        item.setdefault("fusion", {})["canonical_decision_v31"] = canonical

        # Explicitly mark upstream outputs as evidence, preventing downstream UI
        # code from treating them as separate final decisions.
        item["decision_architecture"] = {
            "type": "ONE_BRAIN_MANY_EVIDENCE_CHANNELS",
            "authoritative_source": V31_VERSION,
            "upstream_are_evidence_only": True,
            "final_decision": decision,
        }
        return item
    except Exception as exc:
        LOGGER.exception("V31 canonical governor failed for %s: %s", symbol, exc)
        # Fail closed: never invent a directional signal when the single
        # authoritative governor cannot complete.
        item["decision_tag"] = "WAIT"
        item["bias"] = "خنثی"
        item["entry_mode"] = "WAIT"
        item["decision_confidence"] = 0.0
        item["decision_state"] = "ERROR_SAFE_WAIT"
        item["signal_tag"] = "V31 CANONICAL — WAIT"
        item["canonical_decision"] = {
            "decision":"WAIT","state":"ERROR_SAFE_WAIT","confidence":0.0,
            "version":V31_VERSION,"authoritative":True,
            "reason":["موتور تصمیم واحد با خطای داخلی متوقف شد؛ fail-closed به WAIT انجام شد."]
        }
        return item



# ============================================================
# TITAN V32 — CONTINUOUS PERFORMANCE / TIMEFRAME LEARNING / SCAN TELEMETRY
# ---------------------------------------------------------------------------
# V32 does NOT create a second decision brain. It supplies a measured,
# outcome-based historical calibration evidence channel to the single V31
# governor, while separately auditing every canonical forecast by symbol and
# timeframe. This makes the system learn from realized outcomes without
# pretending that a tiny sample is proof.
# ============================================================
V32_VERSION = "TITAN-V32-CONTINUOUS-LEARNING-AUDIT"
V32_TFS = ("15m", "1h", "4h", "1d")
V32_HORIZON_MIN = {"15m": 60, "1h": 240, "4h": 960, "1d": 2880}
V32_COOLDOWN_MIN = {"15m": 20, "1h": 75, "4h": 300, "1d": 1500}
V32_MIN_LEARN_SAMPLES = 12
V32_LEARN_CAP = 0.10
V32_WAIT_MOVE_THRESHOLD = 0.0035


def _tf_minutes(tf: str) -> int:
    return {"15m":15,"1h":60,"4h":240,"1d":1440}.get(str(tf),60)


def _v32_init_tables() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS v32_forecast_audit(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    decision TEXT NOT NULL,
                    confidence REAL DEFAULT 0,
                    price REAL NOT NULL,
                    horizon_minutes INTEGER NOT NULL,
                    outcome TEXT DEFAULT 'PENDING',
                    return_pct REAL,
                    max_favorable_pct REAL,
                    max_adverse_pct REAL,
                    evaluated_at REAL,
                    reason TEXT DEFAULT '',
                    UNIQUE(symbol,timeframe,created_at)
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_v32_pending ON v32_forecast_audit(outcome,created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v32_perf ON v32_forecast_audit(symbol,timeframe,outcome,created_at)")
            con.execute("""
                CREATE TABLE IF NOT EXISTS v32_learning_state(
                    key TEXT PRIMARY KEY,
                    updated_at REAL NOT NULL,
                    payload TEXT NOT NULL
                )
            """)
    except Exception as exc:
        LOGGER.warning("V32 table initialization failed: %s", exc)


_v32_init_tables()


def _v32_tf_price_direction(df: pd.DataFrame, decision: str, entry: float) -> tuple[str, float, float, float]:
    if df is None or df.empty or entry <= 0:
        return "PENDING", 0.0, 0.0, 0.0
    close = pd.to_numeric(df.get("close"), errors="coerce").dropna()
    high = pd.to_numeric(df.get("high"), errors="coerce").dropna()
    low = pd.to_numeric(df.get("low"), errors="coerce").dropna()
    if close.empty:
        return "PENDING", 0.0, 0.0, 0.0
    final_px = float(close.iloc[-1])
    ret = (final_px / entry - 1.0) if entry else 0.0
    if decision == "SHORT":
        ret = -ret
        favorable = max(0.0, (entry - float(low.min())) / entry) if not low.empty else max(0.0, ret)
        adverse = max(0.0, (float(high.max()) - entry) / entry) if not high.empty else 0.0
    elif decision == "LONG":
        favorable = max(0.0, (float(high.max()) - entry) / entry) if not high.empty else max(0.0, ret)
        adverse = max(0.0, (entry - float(low.min())) / entry) if not low.empty else 0.0
    else:
        favorable = adverse = abs(ret)
    # A directional forecast is correct only if price moved beyond a friction/
    # noise band in the predicted direction. Small moves are NEUTRAL, not wins.
    if decision in {"LONG", "SHORT"}:
        if ret > V32_WAIT_MOVE_THRESHOLD:
            outcome = "WIN"
        elif ret < -V32_WAIT_MOVE_THRESHOLD:
            outcome = "LOSS"
        else:
            outcome = "NEUTRAL"
    else:
        outcome = "WAIT_CORRECT" if abs(ret) <= V32_WAIT_MOVE_THRESHOLD else "WAIT_MISSED"
    return outcome, ret * 100.0, favorable * 100.0, adverse * 100.0


def v32_record_scan_predictions(market_data: list[dict[str, Any]]) -> None:
    """Record one *timeframe-specific* prediction per symbol.

    The previous implementation wrote the same canonical decision into all four
    timeframe rows. That made the performance matrix look like 15m/1h/4h/1d
    were independently tested when they were not. Here each row is derived from
    that timeframe's own score; the canonical multi-TF decision remains separate.
    """
    now = time.time()
    if not market_data:
        return
    with DB_LOCK, db_conn() as con:
        for item in market_data:
            symbol = _normalize_symbol(item.get("symbol", ""))
            price = safe_float(str(item.get("live_price") or item.get("price") or "0").replace(",", ""), 0.0)
            tf_scores = item.get("tf_scores") or {}
            if not symbol or price <= 0:
                continue
            for tf in V32_TFS:
                score = safe_float(tf_scores.get(tf), 50.0)
                if score >= 55.0:
                    decision = "LONG"
                elif score <= 45.0:
                    decision = "SHORT"
                else:
                    decision = "WAIT"
                confidence = clamp(50.0 + abs(score - 50.0) * 2.0, 50.0, 90.0)
                cooldown = V32_COOLDOWN_MIN[tf] * 60
                recent = con.execute(
                    "SELECT 1 FROM v32_forecast_audit WHERE symbol=? AND timeframe=? AND created_at>=? LIMIT 1",
                    (symbol, tf, now - cooldown),
                ).fetchone()
                if recent:
                    continue
                con.execute(
                    """INSERT OR IGNORE INTO v32_forecast_audit(
                        symbol,timeframe,created_at,decision,confidence,price,horizon_minutes,outcome
                    ) VALUES(?,?,?,?,?,?,?,'PENDING')""",
                    (symbol, tf, now, decision, confidence, price, V32_HORIZON_MIN[tf]),
                )


def v32_evaluate_pending() -> int:
    """Resolve historical predictions from actual Binance OHLC, never from later model output."""
    now = time.time(); learned = 0
    with DB_LOCK, db_conn() as con:
        rows = con.execute("SELECT * FROM v32_forecast_audit WHERE outcome='PENDING' AND created_at <= ? ORDER BY created_at LIMIT 250", (now,)).fetchall()
    for row in rows:
        end = float(row["created_at"]) + int(row["horizon_minutes"]) * 60
        if now < end:
            continue
        try:
            tf = str(row["timeframe"]); symbol = str(row["symbol"]); decision = str(row["decision"])
            start_ms = int(float(row["created_at"]) * 1000); end_ms = int(end * 1000)
            # Small bounded pull: enough bars for the horizon, with no look-ahead
            # beyond the evaluation endpoint.
            bars = max(12, min(1000, int(math.ceil(row["horizon_minutes"] / max(1, _tf_minutes(tf)))) + 4))
            df = fetch_klines(symbol, tf, bars, start_ms=start_ms, end_ms=end_ms)
            window = df[(df["t"] >= start_ms) & (df["t"] <= end_ms)] if df is not None and not df.empty else pd.DataFrame()
            outcome, ret, fav, adv = _v32_tf_price_direction(window, decision, safe_float(row["price"], 0.0))
            if outcome == "PENDING":
                continue
            with DB_LOCK, db_conn() as con:
                con.execute("UPDATE v32_forecast_audit SET outcome=?,return_pct=?,max_favorable_pct=?,max_adverse_pct=?,evaluated_at=? WHERE id=?",
                            (outcome, ret, fav, adv, now, row["id"]))
            if outcome in {"WIN", "LOSS"}:
                learned += 1
        except Exception as exc:
            LOGGER.debug("V32 forecast evaluation failed #%s: %s", row["id"], exc)
    return learned


def _v32_beta_rate(wins: int, losses: int, prior: float = 0.5) -> float:
    # Conservative Beta prior. It avoids turning 1/1 into an apparent 50% oracle.
    a = 6.0 * prior + max(0, wins); b = 6.0 * (1.0-prior) + max(0, losses)
    return a / max(a + b, 1e-9)


def v32_performance_matrix(symbol: str | None = None) -> dict[str, Any]:
    """Detailed correctness by symbol/timeframe/direction with sample sufficiency."""
    where=[]; args=[]
    if symbol:
        where.append("symbol=?"); args.append(_normalize_symbol(symbol))
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    with DB_LOCK, db_conn() as con:
        rows = con.execute(f"SELECT * FROM v32_forecast_audit {clause} ORDER BY created_at DESC LIMIT 5000", args).fetchall()
    groups={}
    for r in rows:
        key=(str(r["symbol"]),str(r["timeframe"]),str(r["decision"]))
        g=groups.setdefault(key,{"symbol":key[0],"timeframe":key[1],"decision":key[2],"samples":0,"wins":0,"losses":0,"neutral":0,"wait_correct":0,"wait_missed":0,"returns":[]})
        outcome=str(r["outcome"])
        if outcome == "PENDING": continue
        g["samples"] += 1
        if outcome == "WIN": g["wins"] += 1
        elif outcome == "LOSS": g["losses"] += 1
        elif outcome == "NEUTRAL": g["neutral"] += 1
        elif outcome == "WAIT_CORRECT": g["wait_correct"] += 1
        elif outcome == "WAIT_MISSED": g["wait_missed"] += 1
        if r["return_pct"] is not None: g["returns"].append(float(r["return_pct"]))
    items=[]
    for g in groups.values():
        decisive=g["wins"]+g["losses"]
        g["win_rate"]=round(g["wins"]/decisive*100,1) if decisive else None
        total_group = sum(
            1 for r in rows
            if str(r["symbol"]) == g["symbol"] and str(r["timeframe"]) == g["timeframe"]
        )
        g["coverage"] = round(g["samples"] / max(1, total_group) * 100, 1)
        g["avg_return_pct"]=round(float(np.mean(g["returns"])),4) if g["returns"] else 0.0
        g["reliability"]=round(_v32_beta_rate(g["wins"],g["losses"])*100,1) if decisive else 50.0
        g["sample_status"]="ROBUST" if decisive>=30 else "DEVELOPING" if decisive>=V32_MIN_LEARN_SAMPLES else "INSUFFICIENT"
        g.pop("returns",None)
        items.append(g)
    items.sort(key=lambda x:(x["symbol"], V32_TFS.index(x["timeframe"]) if x["timeframe"] in V32_TFS else 99, x["decision"]))
    return {"version":V32_VERSION,"items":items,"count":len(items)}


def v32_learning_profile(symbol: str) -> dict[str, Any]:
    """Return conservative per-timeframe reliability used as one evidence adjustment."""
    matrix=v32_performance_matrix(symbol).get("items",[])
    profile={"symbol":symbol,"timeframes":{},"aggregate":50.0,"samples":0}
    weighted=[]
    for tf in V32_TFS:
        rows=[x for x in matrix if x["timeframe"]==tf and x["decision"] in {"LONG","SHORT"}]
        wins=sum(int(x["wins"]) for x in rows); losses=sum(int(x["losses"]) for x in rows); n=wins+losses
        rel=_v32_beta_rate(wins,losses)*100 if n else 50.0
        recent_score=rel
        if rows:
            recent_score=float(np.mean([x["reliability"] for x in rows]))
        weight=1.0 + (clamp(recent_score,35,65)-50)/50.0 * V32_LEARN_CAP if n>=V32_MIN_LEARN_SAMPLES else 1.0
        profile["timeframes"][tf]={"samples":n,"wins":wins,"losses":losses,"reliability":round(rel,1),"weight":round(weight,4),"status":"LEARNED" if n>=V32_MIN_LEARN_SAMPLES else "WARMING"}
        if n: weighted.append((rel,n))
        profile["samples"] += n
    profile["aggregate"]=round(sum(r*n for r,n in weighted)/sum(n for _,n in weighted),1) if weighted else 50.0
    return profile


def v32_adaptive_evidence(item: dict[str, Any]) -> dict[str, Any]:
    """Create one historical-calibration evidence channel for the V31 brain."""
    symbol=_normalize_symbol(item.get("symbol", "")); profile=v32_learning_profile(symbol)
    tf_scores=(item.get("tf_scores") or {})
    # If the live item does not expose tf scores, derive a neutral profile only;
    # never invent direction from history.
    long_boost=short_boost=0.0; used=[]
    for tf in V32_TFS:
        p=profile["timeframes"].get(tf,{})
        if p.get("samples",0) < V32_MIN_LEARN_SAMPLES: continue
        sc=safe_float(tf_scores.get(tf),50.0)
        direction="LONG" if sc>=55 else "SHORT" if sc<=45 else "WAIT"
        delta=(safe_float(p.get("reliability"),50)-50)/100.0
        if direction=="LONG": long_boost += delta * 0.025; used.append(tf)
        elif direction=="SHORT": short_boost += delta * 0.025; used.append(tf)
    return {"symbol":symbol,"long_adjustment":round(long_boost,4),"short_adjustment":round(short_boost,4),"profile":profile,"used_timeframes":used}


def v32_register_learning_maintenance() -> None:
    try:
        v32_evaluate_pending()
        # Rebuild the authoritative adaptive state from outcomes only. Existing
        # engines remain intact; V32 adds a small measured calibration signal.
        with DB_LOCK, db_conn() as con:
            state={"updated_at":time.time(),"symbols":{}}
            syms=[r[0] for r in con.execute("SELECT DISTINCT symbol FROM v32_forecast_audit").fetchall()]
        for sym in syms:
            state["symbols"][sym]=v32_learning_profile(sym)
        with DB_LOCK, db_conn() as con:
            con.execute("INSERT OR REPLACE INTO v32_learning_state(key,updated_at,payload) VALUES('global',?,?)",(time.time(),json.dumps(state,ensure_ascii=False)))
    except Exception as exc:
        LOGGER.debug("V32 maintenance failed: %s", exc)


# Extend the single V31 brain with one conservative historical-calibration channel.
_v32_analyze_asset_v31 = analyze_asset

def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    item=_v32_analyze_asset_v31(symbol,btc_trend)
    if not item: return None
    try:
        # The prediction being learned is always the canonical V31 output from
        # this same scan. Learning never gets to create an independent signal.
        learning=v32_adaptive_evidence(item)
        debate=dict(item.get("deep_consensus_v30") or {})
        for side, adj in (("long",learning["long_adjustment"]),("short",learning["short_adjustment"])):
            if isinstance(debate.get(side),dict):
                debate[side]=dict(debate[side]); debate[side]["score"]=float(debate[side].get("score",0) or 0)+adj
        canonical=TITAN_CANONICAL_V31.decide(item,debate)
        decision=canonical["decision"]
        item["decision_tag"]=decision
        item["bias"]="صعودی" if decision=="LONG" else "نزولی" if decision=="SHORT" else "خنثی"
        item["entry_mode"]="EARLY" if decision in {"LONG","SHORT"} else "WAIT"
        item["decision_confidence"]=canonical["confidence"]
        item["decision_state"]=canonical["state"]
        item["signal_tag"]=f"V32 LEARNED CANONICAL — {decision}"
        item["v32_learning"]=learning
        item["canonical_decision"]={**(item.get("canonical_decision") or {}),"decision":decision,"bias":item["bias"],"confidence":canonical["confidence"],"state":canonical["state"],"version":V32_VERSION,"authoritative":True}
        item["decision_audit_v32"]={"version":V32_VERSION,"decision":decision,"learning":learning,"canonical":canonical,"authoritative":True}
        item["decision_architecture"]={"type":"ONE_BRAIN_MANY_EVIDENCE_CHANNELS","authoritative_source":V32_VERSION,"upstream_are_evidence_only":True,"learning_is_evidence_only":True,"final_decision":decision}
        return item
    except Exception as exc:
        LOGGER.exception("V32 learned canonical failed for %s: %s",symbol,exc)
        return item


# ============================================================
# ROUTES
# ============================================================

def _query_int(name: str, default: int, lo: int, hi: int) -> int:
    """Parse bounded integer query parameters without turning bad URLs into 500s."""
    try:
        value = int(request.args.get(name, default))
    except (TypeError, ValueError):
        value = int(default)
    return max(int(lo), min(int(value), int(hi)))


def _query_timeframe(name: str = "timeframe", default: str = "1h") -> str:
    value = str(request.args.get(name, default) or default).strip()
    # Binance-supported TITAN analysis frames. Reject arbitrary strings early.
    return value if value in {"15m", "1h", "4h", "1d"} else default

_MAINTENANCE_LOCK = threading.Lock()

def _safe_background_forecast_maintenance():
    if not _MAINTENANCE_LOCK.acquire(blocking=False):
        return
    try:
        v32_evaluate_pending()
        v32_register_learning_maintenance()
    except Exception as exc:
        LOGGER.warning("V32 learning maintenance failed: %s", exc)
    try:
        evaluate_pending_forecasts()
    except Exception as exc:
        LOGGER.warning("Background forecast maintenance failed: %s", exc)
    try:
        evaluate_paper_trades()
    except Exception as exc:
        LOGGER.warning("Background paper-trade maintenance failed: %s", exc)
    try:
        autonomous_performance_maintenance(False)
    except Exception as exc:
        LOGGER.debug("Autonomous performance maintenance failed: %s", exc)
    finally:
        _MAINTENANCE_LOCK.release()

# --- Render speed: compile the huge dashboard template once ---
_DASHBOARD_TEMPLATE = None

def _get_dashboard_template():
    """Compile the large dashboard HTML once; reuse Flask's Jinja env (filters/globals)."""
    global _DASHBOARD_TEMPLATE
    if _DASHBOARD_TEMPLATE is None:
        try:
            _DASHBOARD_TEMPLATE = app.jinja_env.from_string(HTML)
        except Exception as exc:
            LOGGER.warning("dashboard template compile failed: %s", exc)
            return None
    return _DASHBOARD_TEMPLATE


@app.route("/")
def index():
    # Fast-but-complete bootstrap: if a usable snapshot exists, render it immediately.
    # On a cold start, wait for the market engine ONCE so the user receives the full coin
    # dashboard exactly like the original build. The engine itself is parallelized and
    # Gemini is non-blocking, making the cold start substantially faster without a blank UI.
    try:
        t0 = time.perf_counter()
        market_data, gemini_summary, macro = _fast_market_snapshot()
        with CACHE_LOCK:
            cache_age = time.time() - float(CACHE.get("timestamp") or 0) if CACHE.get("timestamp") else 1e9
        # Never block the first paint on a full multi-coin analyze when any snapshot exists.
        # Cold start without disk cache: kick background refresh and render lightweight empty shell.
        if not market_data:
            # One fast blocking scan (LLM skipped via DASHBOARD_FAST_SCAN) so first paint has coins.
            try:
                market_data, gemini_summary, macro = update_cache(False)
            except Exception as _uc_exc:
                LOGGER.warning("cold update_cache: %s", _uc_exc)
                _background_market_refresh(False)
        elif cache_age >= MARKET_CACHE_TTL:
            _background_market_refresh(False)
        if RENDER_PERF_LOG:
            LOGGER.info("index snapshot ready in %.0fms coins=%s age=%.1fs",
                        (time.perf_counter() - t0) * 1000, len(market_data or []), cache_age if market_data else -1)
    except Exception as exc:
        LOGGER.exception("Index market bootstrap error: %s", exc)
        market_data, gemini_summary, macro = _fast_market_snapshot()
        if not market_data:
            _background_market_refresh(False)
    # Historical evaluation is maintenance work; never hold up dashboard rendering.
    threading.Thread(target=lambda: _safe_background_forecast_maintenance(), name="titan-forecast-maint", daemon=True).start()
    try:
        audit = get_audit_stats()
    except Exception as exc:
        LOGGER.exception("Audit stats failed on index: %s", exc)
        audit = {"evaluated": 0, "wins": 0, "losses": 0, "neutral": 0, "ambiguous": 0, "win_rate": 0.0, "tp_hits": 0, "sl_hits": 0, "label": "در حال آماده‌سازی"}
    try:
        tpl = _get_dashboard_template()
        ctx = dict(market_data=market_data or [], gemini_summary=gemini_summary or "", gemini_status=_gemini_dashboard_status(gemini_summary or ""), macro=macro or {}, settings=USER_SETTINGS, audit=audit)
        if tpl is not None:
            return tpl.render(**ctx)
        return render_template_string(HTML, **ctx)
    except Exception as exc:
        # Last-resort visible page so the dashboard never degenerates into a blank JSON response.
        LOGGER.exception("Dashboard render failed: %s", exc)
        safe_detail = str(exc).replace("<", "&lt;").replace(">", "&gt;")
        return (
            "<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'>"
            "<title>TITAN Enterprise</title>"
            "<body style='background:#050812;color:#eef2ff;font-family:Tahoma;padding:24px'>"
            "<h1 style='color:#38bdf8'>⚡ TITAN ENTERPRISE</h1>"
            "<p>موتور داده فعال است، ولی رندر یکی از بخش‌های داشبورد خطا داده است.</p>"
            f"<pre style='white-space:pre-wrap;background:#0b1220;padding:16px;border-radius:12px'>{safe_detail}</pre>"
            "<p>این خطا در لاگ TITAN نیز ثبت شده است.</p></body></html>", 500, {"Content-Type": "text/html; charset=utf-8"}
        )


@app.get("/api/dashboard-status")
def api_dashboard_status():
    """Tiny non-blocking status endpoint used by the fast dashboard bootstrap."""
    with CACHE_LOCK:
        data = CACHE.get("data") or []
        ts = float(CACHE.get("timestamp") or 0)
    return jsonify({"ok": True, "ready": bool(data), "count": len(data), "age": round(max(0.0, time.time()-ts), 1) if ts else None, "refreshing": bool(_BACKGROUND_REFRESH_RUNNING), "scan": _scan_progress_snapshot()})

@app.get("/api/scan-progress")
def api_scan_progress():
    p=_scan_progress_snapshot()
    with CACHE_LOCK:
        ts=float(CACHE.get("timestamp") or 0)
    if not p.get("last_success_at") and ts:
        p["last_success_at"]=ts
        p["finished_at"]=ts
    p["cache_age_sec"]=round(max(0.0,time.time()-ts),1) if ts else None
    p["server_now"]=time.time()
    return jsonify({"ok":True,"progress":p})

@app.get("/api/performance-learning")
def api_performance_learning():
    try:
        symbol=request.args.get("symbol","").strip() or None
        v32_evaluate_pending()
        matrix=v32_performance_matrix(symbol)
        learning=v32_learning_profile(_normalize_symbol(symbol)) if symbol else None
        with DB_LOCK, db_conn() as con:
            total=con.execute("SELECT COUNT(*) FROM v32_forecast_audit").fetchone()[0]
            pending=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='PENDING'").fetchone()[0]
            wins=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='WIN'").fetchone()[0]
            losses=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='LOSS'").fetchone()[0]
            wait_ok=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='WAIT_CORRECT'").fetchone()[0]
            wait_missed=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='WAIT_MISSED'").fetchone()[0]
        dec=wins+losses
        return jsonify({"ok":True,"version":V32_VERSION,"matrix":matrix,"learning":learning,"summary":{"total":total,"pending":pending,"wins":wins,"losses":losses,"directional_win_rate":round(wins/dec*100,1) if dec else None,"wait_correct":wait_ok,"wait_missed":wait_missed}})
    except Exception as exc:
        LOGGER.exception("V32 performance endpoint failed")
        return jsonify({"ok":False,"error":str(exc)}),500

@app.get("/api/forecast-audit")
def api_forecast_audit():
    symbol=request.args.get("symbol","").strip()
    limit=_query_int("limit",100,10,500)
    where="WHERE symbol=?" if symbol else ""; args=[_normalize_symbol(symbol)] if symbol else []
    with DB_LOCK, db_conn() as con:
        rows=con.execute(f"SELECT * FROM v32_forecast_audit {where} ORDER BY created_at DESC LIMIT ?",args+[limit]).fetchall()
    return jsonify({"ok":True,"items":[dict(r) for r in rows]})

@app.route("/api/tf-gauge")
def api_tf_gauge():
    symbol = _normalize_symbol(request.args.get("symbol", "") or (USER_SETTINGS.get("active_coins") or DEFAULT_COINS)[0])
    frames = ["15m", "1h", "4h", "1d"]
    out = []
    try:
        data, _, _ = _fast_market_snapshot()
        if not data:
            _background_market_refresh(False)
        item = next((x for x in (data or []) if x.get("symbol") == symbol), None)
        if not item:
            bare = symbol.replace("/", "")
            item = next((x for x in (data or []) if str(x.get("tv_symbol", "")).replace("/", "") == bare), {}) or {}
        tf_scores = (item or {}).get("tf_scores") or {}
        base = float((item or {}).get("score") or 50)
        alignment_all = float((item or {}).get("alignment") or 50)
        vol_spike = bool((item or {}).get("volume_spike"))
    except Exception as exc:
        LOGGER.warning("TF gauge snapshot failed for %s: %s", symbol, exc)
        tf_scores, base, alignment_all, vol_spike = {}, 50.0, 50.0, False
    # The gauge must be independently reliable even when the dashboard cache is cold.
    # Build missing timeframe scores directly from closed Binance candles.
    if not tf_scores:
        try:
            fresh_scores = {}
            for f in frames:
                df = fetch_klines(symbol, f, 140 if f in ("15m", "1h") else 100)
                if df is not None and len(df) >= 55:
                    _d, _sc, _m = _tf_forecast(df)
                    fresh_scores[f] = float(_sc)
            tf_scores = fresh_scores
        except Exception as exc:
            LOGGER.debug("fresh TF gauge fallback failed: %s", exc)
    if not tf_scores and not data:
        return jsonify({"ok": False, "ready": False, "symbol": symbol, "error": "داده تایم‌فریم هنوز آماده نشده است"}), 202
    for f in frames:
        score = float(tf_scores.get(f, base))
        trend = int(clamp(score, 0, 100))
        momentum = int(clamp(score * 0.92 + (5 if score >= 60 else -5 if score <= 40 else 0), 0, 100))
        volume = int(clamp((75 if vol_spike else 45) + (score - 50) * 0.35, 0, 100))
        alignment = int(clamp(alignment_all * 0.7 + score * 0.3, 0, 100))
        final = int(round(trend * 0.35 + momentum * 0.25 + volume * 0.15 + alignment * 0.25))
        out.append({"name": f, "trend": trend, "momentum": momentum, "volume": volume, "alignment": alignment, "score": final})
    return jsonify({"ok": True, "symbol": symbol, "timeframes": out})

@app.route("/rescan")
def rescan():
    global CACHE
    with CACHE_LOCK:
        CACHE = {"timestamp": 0.0, "data": [], "gemini_summary": "", "macro": {}}
    _scan_progress_update(status="queued",phase="در صف اسکن",started_at=0.0,finished_at=0.0,completed=0,total=len(USER_SETTINGS.get("active_coins") or DEFAULT_COINS),percent=0,message="اسکن جدید درخواست شد…",fresh=False)
    return redirect(url_for("index"))

@app.route("/update_settings", methods=["POST"])
def update_settings():
    global USER_SETTINGS, CACHE
    risk = clamp(safe_float(request.form.get("risk_multiplier"), 1.2), 0.2, 5.0)
    coins: list[str] = []
    for raw in request.form.get("active_coins", "").split(","):
        symbol = _normalize_symbol(raw)
        if symbol and symbol not in coins:
            coins.append(symbol)
    USER_SETTINGS = {"risk_multiplier": risk, "active_coins": coins or DEFAULT_COINS.copy()}
    save_settings()
    with CACHE_LOCK:
        CACHE = {"timestamp": 0.0, "data": [], "gemini_summary": "", "macro": {}}
    return redirect(url_for("index"))






@app.get("/api/depth")
def api_depth():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    return jsonify({"ok": True, "depth": get_depth_snapshot(symbol), "watchlist": DEPTH_WATCHLIST})

@app.get("/api/calibration")
def api_calibration():
    symbol = _normalize_symbol(request.args.get("symbol", ""))
    direction = str(request.args.get("direction", "") or "")
    raw = safe_float(request.args.get("raw", 55), 55)
    return jsonify({"ok": True, "calibration": calibrate_success_probability(symbol, direction, raw)})


@app.get("/api/pattern-forecast")
def api_pattern_forecast():
    """Pattern detection + probabilistic future candle path for one symbol."""
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    horizon = min(max(int(request.args.get("horizon", 12)), 3), 12)
    try:
        df = fetch_klines(symbol, tf, 200 if tf in ("15m", "1h") else 150)
        rsi_s = wilder_rsi(df["close"])
        patterns = detect_chart_patterns(df, rsi_s)
        forecast = forecast_future_candles(df, horizon=horizon, patterns=patterns)
        macd = calc_macd(df["close"])
        stoch = calc_stoch_rsi(df["close"])
        return jsonify({
            "ok": True,
            "symbol": symbol,
            "timeframe": tf,
            "rsi": round(float(rsi_s.iloc[-1]), 2) if len(rsi_s) else None,
            "macd": macd,
            "stoch_rsi": stoch,
            "patterns": patterns,
            "forecast": forecast,
            "guide_catalog": PATTERN_GUIDE,
        })
    except Exception as exc:
        LOGGER.warning("pattern-forecast failed %s: %s", symbol, exc)
        return jsonify({"ok": False, "error": str(exc)[:300], "symbol": symbol}), 500


@app.get("/api/klines")
def api_klines():
    """OHLCV for dashboard chart fallback (Binance)."""
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    limit = min(max(int(request.args.get("limit", 120)), 20), 300)
    try:
        df = fetch_klines(symbol, tf, limit)
        candles = []
        for _, row in df.iterrows():
            candles.append({
                "t": int(row["t"]),
                "o": float(row["open"]),
                "h": float(row["high"]),
                "l": float(row["low"]),
                "c": float(row["close"]),
                "v": float(row["vol"]),
            })
        return jsonify({"ok": True, "symbol": symbol, "timeframe": tf, "candles": candles})
    except Exception as exc:
        LOGGER.warning("api_klines failed %s: %s", symbol, exc)
        return jsonify({"ok": False, "error": str(exc)[:300], "symbol": symbol}), 500





@app.get("/api/scalp-window")
def api_scalp_window():
    """Short-horizon (30-60 min) leverage suitability from 15m/1h scores + live micro bias.

    Analysis-only. Designed for holding a position roughly 30 minutes, max ~60.
    """
    try:
        data, _, macro = _fast_market_snapshot()
        rows = []
        for item in data or []:
            sym = str(item.get("symbol") or "")
            tfs = item.get("tfs") or item.get("tf_scores") or {}
            s15 = safe_float(tfs.get("15m"), safe_float(item.get("score"), 50))
            s1h = safe_float(tfs.get("1h"), 50)
            rsi = safe_float(item.get("rsi"), 50)
            buy = safe_float((item.get("buy_sell") or {}).get("buy_pct"), item.get("taker_buy_pct", 50))
            sell = 100.0 - buy
            decision = str(item.get("decision_tag") or "WAIT").upper()
            score = safe_float(item.get("score"), 50)
            # Short-horizon edge: prefer 15m direction with 1h not strongly against
            success = safe_float(item.get("success_probability"), safe_float(item.get("signal_quality"), 50))
            long_edge = (s15 - 50) * 1.35 + (s1h - 50) * 0.55 + (buy - 50) * 0.30 + (success - 50) * 0.20
            short_edge = (50 - s15) * 1.35 + (50 - s1h) * 0.55 + (sell - 50) * 0.30 + (success - 50) * 0.20
            # RSI extremes: continuation bias for scalp window
            if rsi >= 70:
                short_edge += 5
                long_edge -= 4
            elif rsi <= 30:
                long_edge += 5
                short_edge -= 4
            side = "WAIT"
            edge = 0.0
            # Stricter gate: only clear 15m lean + non-conflicting 1h
            if long_edge >= 10 and long_edge > short_edge + 1.5 and s15 >= 55 and s1h >= 48:
                side = "LONG"
                edge = long_edge
            elif short_edge >= 10 and short_edge > long_edge + 1.5 and s15 <= 45 and s1h <= 52:
                side = "SHORT"
                edge = short_edge
            if side == decision and side in {"LONG", "SHORT"}:
                edge += 4
            conf = float(clamp(50 + edge * 2.0 + (success - 50) * 0.15, 0, 92))
            if side == "WAIT" or conf < 62:
                continue
            hold_min = 30 if conf >= 75 else 40 if conf >= 68 else 50
            rows.append({
                "symbol": sym,
                "base": sym.split("/")[0] if "/" in sym else sym,
                "side": side,
                "confidence": round(conf, 1),
                "success": round(success, 1),
                "hold_minutes": hold_min,
                "max_hold_minutes": 60,
                "score_15m": round(s15, 1),
                "score_1h": round(s1h, 1),
                "rsi": round(rsi, 1),
                "buy_pct": round(buy, 1),
                "reason": (
                    f"۱۵م={s15:.0f} · ۱س={s1h:.0f} · RSI={rsi:.0f} · موفقیت~{success:.0f} · "
                    f"{'خرید' if side=='LONG' else 'فروش'} {(buy if side=='LONG' else sell):.0f}% · "
                    f"نگهداری ~{hold_min}–۶۰ دقیقه"
                ),
            })
        rows.sort(key=lambda r: (
            -safe_float(r.get("confidence"), 0),
            -safe_float(r.get("success"), 0),
            -safe_float(r.get("score_15m"), 0),
        ))
        # Only the single best LONG and/or SHORT — hard cap 2 total
        top2 = rows[:2]
        return jsonify({
            "ok": True,
            "horizon": "30-60m",
            "count": len(top2),
            "rows": top2,
            "note": "ویژه معاملات اهرمی کوتاه‌مدت؛ خروج حداکثر تا ۶۰ دقیقه. تضمین سود نیست.",
            "macro": {"btc_trend": (macro or {}).get("btc_trend")},
        })
    except Exception as exc:
        LOGGER.exception("scalp-window failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500


@app.get("/api/realtime-analysis")
def api_realtime_analysis():
    """Real-time snapshot: live prices, micro-moves, breadth, and per-symbol live bias."""
    try:
        coins = USER_SETTINGS.get("active_coins") or DEFAULT_COINS
        # Refresh a batch of live prices (non-blocking-ish, short timeout path)
        try:
            prices = _fetch_live_prices(list(coins)[:40])
            for sym, px in prices.items():
                if px and px > 0:
                    _register_live_price(sym, px, "REST-rt")
        except Exception as exc:
            LOGGER.debug("realtime price batch: %s", exc)

        live_status = _live_status()
        rows = []
        up = down = flat = 0
        with LIVE_LOCK:
            live_map = dict(LIVE_PRICES)

        # Merge with last cache decisions for context
        cached, _, macro = _fast_market_snapshot()
        by_sym = {str(x.get("symbol")): x for x in (cached or [])}

        for sym in coins:
            ns = _normalize_symbol(sym)
            bare = _normalize_symbol_for_binance(ns)
            info = live_map.get(ns) or live_map.get(bare) or live_map.get(bare.replace("USDT", "/USDT")) or {}
            # try alternate keys
            if not info:
                for k, v in live_map.items():
                    if k.replace("/", "") == bare:
                        info = v
                        break
            px = safe_float(info.get("price"), 0)
            ch = safe_float(info.get("change_pct"), 0)
            age = time.time() - safe_float(info.get("ts"), 0) if info.get("ts") else None
            item = by_sym.get(ns) or {}
            decision = str(item.get("decision_tag") or "WAIT")
            score = safe_float(item.get("score"), 50)
            buy = safe_float((item.get("buy_sell") or {}).get("buy_pct"), item.get("taker_buy_pct", 50))
            sell = safe_float((item.get("buy_sell") or {}).get("sell_pct"), 100 - buy)

            # Micro live bias from last tick change
            if ch > 0.08:
                micro = "صعودی"
                up += 1
            elif ch < -0.08:
                micro = "نزولی"
                down += 1
            else:
                micro = "خنثی"
                flat += 1

            # Build the realtime row from the same cached signal plus the newest
            # live snapshot so Entry/SL/TP shown by the UI cannot lag the price.
            live_item = dict(item)
            if px > 0:
                live_item = _v35_rebase_price_dependent_outputs(
                    live_item, {"price": px, "ts": safe_float(info.get("ts"), time.time()),
                                "source": info.get("source") or "Binance"}
                )
            rows.append({
                "symbol": ns,
                "price": px if px > 0 else safe_float(str(item.get("price") or "0").replace(",", ""), 0),
                "entry": safe_float(live_item.get("entry_raw"), px),
                "stop_loss": safe_float(live_item.get("stop_loss_raw"), 0),
                "tp1": safe_float(live_item.get("tp1_raw"), 0),
                "tp2": safe_float(live_item.get("tp2_raw"), 0),
                "rr_tp1": safe_float(live_item.get("rr_tp1"), 0),
                "rr_tp2": safe_float(live_item.get("rr_tp2"), 0),
                "change_pct": round(ch, 4),
                "age_sec": round(age, 2) if age is not None else None,
                "source": info.get("source") or "cache",
                "decision": str(live_item.get("decision_tag") or decision),
                "score": score,
                "buy_pct": round(buy, 1),
                "sell_pct": round(sell, 1),
                "micro_bias": micro,
                "fresh": bool(age is not None and age <= 8),
                "live_sync": bool(live_item.get("live_sync", False)),
            })

        rows.sort(key=lambda r: abs(safe_float(r.get("change_pct"), 0)), reverse=True)
        leaders = [r for r in rows if r.get("fresh") and abs(safe_float(r.get("change_pct"), 0)) >= 0.05][:5]
        return jsonify({
            "ok": True,
            "mode": "realtime",
            "server_time": int(time.time() * 1000),
            "live": live_status,
            "breadth": {"up": up, "down": down, "flat": flat},
            "leaders": leaders,
            "rows": rows,
            "macro": {
                "fear": (macro or {}).get("fear_greed_val"),
                "btc_dom": (macro or {}).get("dominance_btc"),
                "btc_trend": (macro or {}).get("btc_trend"),
            },
            "note": "تحلیل بلادرنگ بر اساس تیک زنده + آخرین سیگنال کش‌شده؛ سفارش اجرا نمی‌شود.",
        })
    except Exception as exc:
        LOGGER.exception("realtime-analysis failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500


@app.get("/api/live-prices")
def api_live_prices():
    symbols = [_normalize_symbol(x) for x in request.args.get("symbols", "").split(",") if x.strip()][:100]
    return jsonify({"ok": True, "source": "Binance Spot Ticker", "prices": _fetch_live_prices(symbols), "server_time": int(time.time() * 1000)})

@app.get("/api/market-pulse")
def api_market_pulse():
    data, _summary, macro = update_cache(False)
    return jsonify({"ok": True, "pulse": _market_pulse_snapshot(data, macro)})

@app.get("/api/advanced-metrics")
def api_advanced_metrics():
    evaluate_paper_trades()
    return jsonify({"ok": True, "metrics": get_advanced_metrics()})

@app.get("/api/backtest")
def api_backtest():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT")); tf = _query_timeframe(); limit = _query_int("limit", 1000, 100, MAX_BACKTEST_CANDLES)
    return jsonify(backtest_signal_logic(symbol, tf, limit))

@app.get("/api/walk-forward")
def api_walk_forward():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT")); tf = _query_timeframe(); limit = _query_int("limit", 1000, 200, MAX_BACKTEST_CANDLES)
    train = _query_int("train", 300, 100, MAX_BACKTEST_CANDLES); test = _query_int("test", 100, 20, MAX_BACKTEST_CANDLES)
    return jsonify(walk_forward_backtest(symbol, tf, limit, train, test))

@app.get("/api/titan-terminal")
def api_titan_terminal():
    symbol = _normalize_symbol(request.args.get("symbol", USER_SETTINGS.get("active_coins", DEFAULT_COINS)[0]))
    data, _summary, _macro = update_cache(False)
    item = next((x for x in data if x.get("symbol") == symbol), None)
    if not item:
        return jsonify({"ok": False, "error": "نماد در کش فعلی موجود نیست"}), 404
    return jsonify({"ok": True, "terminal": item.get("decision_terminal", TITAN_EDGE_SUITE.decision_terminal(item))})


@app.get("/api/all-performance")
def api_all_performance():
    symbols = USER_SETTINGS.get("active_coins") or DEFAULT_COINS
    out = []
    audit = get_audit_stats()
    for symbol in symbols:
        try:
            sym = _normalize_symbol(symbol)
            result = backtest_signal_logic(sym, "1h", 800)
            m = result.get("metrics", {}) if isinstance(result, dict) and result.get("ok") else {}
            out.append({
                "symbol": sym,
                "win_rate": m.get("win_rate", audit.get("win_rate", 0)),
                "wins": m.get("wins", audit.get("wins", 0)),
                "losses": m.get("losses", audit.get("losses", 0)),
                "expectancy": m.get("expectancy", 0),
                "profit_factor": m.get("profit_factor", 0),
            })
        except Exception as e:
            out.append({"symbol": symbol, "error": str(e)})
    return jsonify({"ok": True, "items": out})

@app.get("/api/performance-history")
def api_performance_history():
    symbol = _normalize_symbol(request.args.get("symbol", "")) if request.args.get("symbol") else ""
    tf = request.args.get("timeframe", "")
    limit = _query_int("limit", 120, 1, 500)
    return jsonify(get_performance_history(symbol, tf, limit))


@app.get("/api/performance")
def api_performance():
    symbol = _normalize_symbol(request.args.get("symbol", USER_SETTINGS.get("active_coins", DEFAULT_COINS)[0]))
    tf = _query_timeframe(); limit = _query_int("limit", 1200, 200, MAX_BACKTEST_CANDLES)
    result = backtest_signal_logic(symbol, tf, limit)
    wf = walk_forward_backtest(symbol, tf, limit, max(200, min(300, limit//3)), max(50, min(100, limit//8))) if result.get("ok") else {"ok": False}
    audit = get_audit_stats()
    strategies = result.get("professional", {}).get("strategy_lab", {}) if result.get("ok") else {}
    return jsonify({"ok": bool(result.get("ok")), "symbol": symbol, "timeframe": tf, "backtest": result, "walk_forward": wf, "historical": audit, "strategies": strategies})

@app.get("/api/pro-lab")
def api_pro_lab():
    symbol = _normalize_symbol(request.args.get("symbol", USER_SETTINGS.get("active_coins", DEFAULT_COINS)[0]))
    tf = _query_timeframe()
    limit = _query_int("limit", 1000, 200, MAX_BACKTEST_CANDLES)
    result = backtest_signal_logic(symbol, tf, limit)
    return jsonify({"ok": bool(result.get("ok")), "suite": {"modules": 12, "status": "ACTIVE"}, "result": result})

@app.get("/api/ai-votes")
def api_ai_votes():
    """Aggregate AI model votes across active symbols for dashboard AI tab."""
    data, _summary, _macro = _fast_market_snapshot()
    if not data:
        _background_market_refresh(False)
    board = []
    tally = {"LONG": 0, "SHORT": 0, "WAIT": 0, "providers": {}}
    for item in data or []:
        ai = item.get("ai_opinions") or {}
        ens = (item.get("edge") or {}).get("ai") or TITAN_EDGE_SUITE.ai_ensemble(ai, item.get("bias", "خنثی"))
        votes = ens.get("votes") or {}
        details = ens.get("details") or {}
        row = {
            "symbol": item.get("symbol"),
            "bias": item.get("bias"),
            "decision_tag": item.get("decision_tag") or "WAIT",
            "score": item.get("score"),
            "titan": "LONG" if item.get("bias") == "صعودی" else "SHORT" if item.get("bias") == "نزولی" else "WAIT",
            "majority": ens.get("majority", "WAIT"),
            "agreement": ens.get("agreement", 0),
            "status": ens.get("status", "NO_AI_DATA"),
            "votes": votes,
            "details": details,
            "gemini": ai.get("gemini") or "",
            "openai": ai.get("openai") or "",
            "grok": ai.get("grok") or "",
            "claude": ai.get("claude") or "",
            "deepseek": ai.get("deepseek") or "",
        }
        board.append(row)
        maj = row["majority"]
        if maj in tally:
            tally[maj] += 1
        for p, v in votes.items():
            bucket = tally["providers"].setdefault(p, {"LONG": 0, "SHORT": 0, "WAIT": 0})
            if v in bucket:
                bucket[v] += 1
    return jsonify({"ok": True, "board": board, "tally": tally, "count": len(board)})


@app.get("/api/gemini-analysis")
def api_gemini_analysis():
    """Return fresh Gemini global analysis instead of only reading the cache.

    This endpoint is intentionally fail-safe: cached market data is reused when
    available, and a fresh Gemini request is attempted whenever the caller asks
    for a refresh or the cached summary is empty.
    """
    reload_keys()
    data, summary, macro = _load_market_cache()
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes", "on"}
    if not data:
        try:
            data, summary, macro = update_cache(False)
        except Exception as exc:
            LOGGER.exception("Gemini endpoint cache update failed: %s", exc)
    if GEMINI_API_KEY and data and (force or not str(summary or "").strip()):
        try:
            fresh = _global_ai_summary(data, macro)
            if fresh:
                summary = fresh
                _save_json(MARKET_CACHE_PATH, {"timestamp": time.time(), "data": data, "gemini_summary": summary, "macro": macro})
                with CACHE_LOCK:
                    CACHE.update(timestamp=time.time(), data=data, gemini_summary=summary, macro=macro)
        except Exception as exc:
            LOGGER.exception("Gemini global refresh failed: %s", exc)
    return jsonify({
        "ok": True,
        "provider": "Gemini",
        "available": bool(GEMINI_API_KEY),
        "ready": bool(str(summary or "").strip()),
        "analysis": summary or "",
        "macro": macro,
        "error": (GEMINI_LAST_ERROR if not str(summary or '').strip() else ""),
    })

@app.get("/api/gemini-debug")
def api_gemini_debug():
    reload_keys()
    models = _gemini_available_models() if GEMINI_API_KEY else []
    return jsonify({
        "ok": True,
        "available": bool(GEMINI_API_KEY),
        "models": models[:20],
        "last_error": GEMINI_LAST_ERROR,
        "storage": str(APP_HOME),
    })

@app.route("/health")
def health():
    with CACHE_LOCK:
        age = time.time() - CACHE["timestamp"] if CACHE.get("timestamp") else None
    return jsonify({"status": "ok", "home": str(APP_HOME), "gemini": bool(GEMINI_API_KEY), "openai": bool(OPENAI_API_KEY), "grok": bool(GROK_API_KEY), "claude": bool(CLAUDE_API_KEY), "deepseek": bool(DEEPSEEK_API_KEY), "coinglass": bool(COINGLASS_API_KEY), "cache_age_seconds": round(age, 2) if age is not None else None, "assets": len(CACHE.get("data") or []), "live": _live_status(), "storage_enforced": True})

# ============================================================
# STARTUP
# ============================================================



# =============================================================================
# TITAN V29.3 — CENTRAL GOVERNOR (single decision authority)
# - All upstream engines (V29..V32, CNS, patterns, AI) = evidence only
# - Central Governor = sole LONG / SHORT / WAIT publisher
# - Timestamped predictions + automatic outcome audit + component reward/penalty
# - Auto scan / learn / score — no manual button required
# - Emergency live-price cards so Android dashboard is never blank
# - Analysis only. No order execution. Signals are probabilistic, not guarantees.
# =============================================================================

TITAN_CENTRAL_VERSION = "TITAN-CENTRAL-GOVERNOR-V29.5-EDGE"
TITAN_PARAM_VERSION = globals().get("TITAN_PARAM_VERSION", "V36.0-ANDROID-QUANTUM-RESONANCE")  # keep V36
TITAN_PUBLIC_AUTHORITY = TITAN_CENTRAL_VERSION
TITAN_ENGINE_MODE = "CENTRAL_GOVERNOR_ONLY"
TITAN_LEGACY_ENGINES_ARE_EVIDENCE_ONLY = True

_CENTRAL_WEIGHT_LOCK = threading.RLock()
_CENTRAL_WEIGHTS_DEFAULT = {
    "htf_trend": 1.30,
    "mtf_setup": 1.15,
    "ltf_trigger": 0.85,
    "momentum": 1.05,
    "structure": 1.05,
    "volume_flow": 0.95,
    "derivatives": 0.90,
    "pattern": 0.80,
    "forecast_path": 0.70,
    "ai_vote": 0.75,
    "data_trust": 1.20,
    "learning_v32": 0.95,
}
_CENTRAL_WEIGHTS: dict[str, float] = dict(_CENTRAL_WEIGHTS_DEFAULT)
_CENTRAL_MIN_EDGE = 0.12
_CENTRAL_MIN_MARGIN = 0.08
_CENTRAL_MIN_TRUST = 42.0


# ============================================================
# TITAN V29.5 EDGE LAB — ten hardened decision-quality layers
# 1) honest online probability calibration
# 2) MAE/MFE + time-to-event telemetry
# 3) regime-conditioned performance
# 4) overlapping-signal suppression
# 5) Monte-Carlo risk analysis
# 6) friction-aware expectancy / profit factor
# 7) champion / challenger governance
# 8) immutable parameter/version provenance
# 9) purged walk-forward style validation on realized central outcomes
# 10) entry-quality vs directional-bias separation + component attribution
# ============================================================

EDGE_LAB_VERSION = "V30-REAL-EDGE-22X"
EDGE_MAX_PENDING_PER_SYMBOL = 1
EDGE_MAX_PENDING_SAME_SIDE = 4
EDGE_MC_RUNS = 2000


def _edge_lab_init_schema() -> None:
    """Create additive analytics tables; never destroys legacy data."""
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS central_trade_metrics(
                prediction_id INTEGER PRIMARY KEY,
                regime TEXT,
                volatility_pct REAL,
                trend_strength REAL,
                mae_pct REAL,
                mfe_pct REAL,
                time_to_event_min REAL,
                exit_price REAL,
                net_return_pct REAL,
                r_multiple REAL,
                entry_quality REAL,
                directional_bias REAL,
                ambiguity INTEGER DEFAULT 0,
                friction_pct REAL,
                evaluated_at REAL,
                param_version TEXT,
                edge_lab_version TEXT
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS central_model_registry(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                model_name TEXT NOT NULL,
                version TEXT NOT NULL,
                role TEXT NOT NULL,
                weights_json TEXT,
                sample_count INTEGER DEFAULT 0,
                win_rate REAL,
                expectancy_pct REAL,
                profit_factor REAL,
                status TEXT DEFAULT 'CANDIDATE',
                created_at REAL,
                promoted_at REAL,
                UNIQUE(model_name,version)
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS central_overlap_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at REAL,
                symbol TEXT,
                decision TEXT,
                blocked INTEGER,
                reason TEXT,
                pending_same_symbol INTEGER,
                pending_same_side INTEGER
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_ctm_regime ON central_trade_metrics(regime)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_ctm_eval ON central_trade_metrics(evaluated_at)")
            con.commit()
    except Exception as exc:
        LOGGER.debug("edge lab schema: %s", exc)


def _edge_regime_from_window(window) -> tuple[str, float, float]:
    """Derive a conservative realized regime from the exact evaluation window."""
    try:
        closes = window["close"].astype(float).dropna()
        if len(closes) < 4:
            return "unknown", 0.0, 0.0
        rets = closes.pct_change().dropna()
        vol_pct = float(np.std(rets) * math.sqrt(max(1, len(rets))) * 100.0)
        base = max(float(closes.iloc[0]), 1e-12)
        slope_pct = float((float(closes.iloc[-1]) / base - 1.0) * 100.0)
        if vol_pct >= 3.0:
            regime = "high_volatility"
        elif slope_pct >= 1.2:
            regime = "trend_up"
        elif slope_pct <= -1.2:
            regime = "trend_down"
        else:
            regime = "range"
        strength = clamp(abs(slope_pct) / max(vol_pct, 0.25) * 50.0, 0.0, 100.0)
        return regime, vol_pct, strength
    except Exception:
        return "unknown", 0.0, 0.0


def _edge_first_touch_detail(window, decision: str, sl: float, tp1: float, tp2: float):
    """Return first touch type/price/time; same conservative ambiguity rule."""
    for _, r in window.iterrows():
        hi = safe_float(r.get("high"), 0.0); lo = safe_float(r.get("low"), 0.0)
        ts = safe_float(r.get("t"), 0.0) / 1000.0
        if decision == "LONG":
            sl_hit = sl > 0 and lo <= sl
            tp_hit = tp1 > 0 and hi >= tp1
            if sl_hit and tp_hit:
                return "AMBIGUOUS", None, ts
            if sl_hit:
                return "LOSS", sl, ts
            if tp_hit:
                return "WIN", tp1, ts
        else:
            sl_hit = sl > 0 and hi >= sl
            tp_hit = tp1 > 0 and lo <= tp1
            if sl_hit and tp_hit:
                return "AMBIGUOUS", None, ts
            if sl_hit:
                return "LOSS", sl, ts
            if tp_hit:
                return "WIN", tp1, ts
    return "TIME_EXIT", None, None


def _edge_calibrate_central(raw_conf: float, direction: str = "", symbol: str = "") -> dict[str, Any]:
    """Calibrate central confidence only from already-realized historical central labels."""
    raw = float(clamp(raw_conf, 5.0, 95.0))
    pairs = []
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                "SELECT confidence,outcome FROM central_predictions "
                "WHERE outcome IN ('WIN','LOSS') AND confidence IS NOT NULL "
                "ORDER BY evaluated_at ASC,id ASC LIMIT 1200"
            ).fetchall()
        for conf, out in rows:
            pairs.append((clamp(safe_float(conf, 50.0)/100.0, 0.01, 0.99), 1.0 if out == "WIN" else 0.0))
    except Exception:
        pairs = []
    if len(pairs) < 20:
        return {"raw": round(raw,1), "calibrated": None, "samples": len(pairs),
                "method":"insufficient_history", "is_calibrated":False}
    probs=[x for x,_ in pairs]; labels=[y for _,y in pairs]
    platt=_platt_scale(probs, labels, raw/100.0)
    # 12-bin weighted isotonic estimate.
    bins=[]
    for k in range(12):
        lo=k/12; hi=(k+1)/12
        vals=[y for x,y in pairs if lo <= x < hi or (k==11 and lo <= x <= hi)]
        if vals:
            bins.append((lo+hi/2, (sum(vals)+2)/(len(vals)+4), len(vals)))
    iso=None
    if bins:
        xs=[b[0] for b in bins]; ys=[b[1] for b in bins]; ws=[b[2] for b in bins]
        iy=_pava_isotonic(xs,ys,ws)
        x=raw/100.0
        if x <= xs[0]: iso=iy[0]
        elif x >= xs[-1]: iso=iy[-1]
        else:
            for j in range(len(xs)-1):
                if xs[j] <= x <= xs[j+1]:
                    t=(x-xs[j])/max(xs[j+1]-xs[j],1e-12)
                    iso=iy[j]+t*(iy[j+1]-iy[j]); break
    vals=[v for v in (platt,iso) if v is not None]
    if not vals:
        return {"raw":round(raw,1),"calibrated":None,"samples":len(pairs),"method":"failed","is_calibrated":False}
    cal=clamp(float(np.mean(vals))*100.0, 5.0, 88.0)
    # Shrink extreme estimates until the sample is large enough.
    if len(pairs) < 60: cal=50.0+(cal-50.0)*0.70
    elif len(pairs) < 120: cal=50.0+(cal-50.0)*0.85
    return {"raw":round(raw,1),"calibrated":round(cal,1),"samples":len(pairs),
            "method":"platt+isotonic_online", "is_calibrated":True}


def _edge_overlap_gate(symbol: str, candidate: str) -> dict[str, Any]:
    """Block duplicate active setups and cap same-side portfolio concentration."""
    if candidate not in {"LONG","SHORT"}:
        return {"ok":True,"reason":"","same_symbol":0,"same_side":0}
    same_symbol=same_side=0
    try:
        with DB_LOCK, db_conn() as con:
            same_symbol=int(con.execute(
                "SELECT COUNT(*) FROM central_predictions WHERE outcome='PENDING' AND symbol=?",(symbol,)
            ).fetchone()[0])
            same_side=int(con.execute(
                "SELECT COUNT(*) FROM central_predictions WHERE outcome='PENDING' AND decision=?",(candidate,)
            ).fetchone()[0])
            blocked = same_symbol >= EDGE_MAX_PENDING_PER_SYMBOL or same_side >= EDGE_MAX_PENDING_SAME_SIDE
            reason = (f"سیگنال فعال تکراری برای {symbol}" if same_symbol >= EDGE_MAX_PENDING_PER_SYMBOL
                      else f"تراکم سیگنال {candidate}: {same_side} نمونه فعال" if same_side >= EDGE_MAX_PENDING_SAME_SIDE else "")
            con.execute("INSERT INTO central_overlap_log(created_at,symbol,decision,blocked,reason,pending_same_symbol,pending_same_side) VALUES(?,?,?,?,?,?,?)",
                        (time.time(),symbol,candidate,int(blocked),reason,same_symbol,same_side))
            con.commit()
            return {"ok":not blocked,"reason":reason,"same_symbol":same_symbol,"same_side":same_side}
    except Exception:
        return {"ok":True,"reason":"","same_symbol":0,"same_side":0}


def _edge_performance_report() -> dict[str, Any]:
    """Friction-aware expectancy/PF plus regime and attribution summaries."""
    out={"samples":0,"win_rate":None,"expectancy_pct":None,"profit_factor":None,"regimes":{},"components":{}}
    try:
        with DB_LOCK, db_conn() as con:
            rows=con.execute("SELECT outcome,net_return_pct,r_multiple,regime FROM central_trade_metrics JOIN central_predictions ON central_predictions.id=central_trade_metrics.prediction_id WHERE outcome IN ('WIN','LOSS') ORDER BY evaluated_at ASC").fetchall()
            out["samples"]=len(rows)
            rs=[safe_float(r[1],0) for r in rows]; rms=[safe_float(r[2],0) for r in rows]
            wins=[x for x in rs if x>0]; losses=[abs(x) for x in rs if x<0]
            out["win_rate"]=round(sum(1 for r in rows if r[0]=='WIN')/max(1,len(rows))*100,2)
            out["expectancy_pct"]=round(float(np.mean(rs)),4) if rs else None
            out["profit_factor"]=round(sum(wins)/max(sum(losses),1e-9),3) if losses else (None if not wins else 99.0)
            for regime in sorted({str(r[3] or 'unknown') for r in rows}):
                rr=[safe_float(r[1],0) for r in rows if str(r[3] or 'unknown')==regime]
                out["regimes"][regime]={"samples":len(rr),"expectancy_pct":round(float(np.mean(rr)),4) if rr else None,
                    "win_rate":round(sum(1 for x in rr if x>0)/max(1,len(rr))*100,2)}
            comp=con.execute("SELECT component,samples,wins,losses,reward_sum,penalty_sum,weight FROM central_component_stats ORDER BY component").fetchall()
            for r in comp:
                out["components"][r[0]]={"samples":r[1],"wins":r[2],"losses":r[3],"reward":round(safe_float(r[4]),3),"penalty":round(safe_float(r[5]),3),"weight":round(safe_float(r[6]),4)}
    except Exception as exc:
        out["error"]=str(exc)[:180]
    return out


def _edge_monte_carlo(runs: int = EDGE_MC_RUNS) -> dict[str, Any]:
    """Bootstrap/shuffle risk envelope from realized net R-multiples."""
    try:
        with DB_LOCK, db_conn() as con:
            vals=[safe_float(r[0]) for r in con.execute("SELECT r_multiple FROM central_trade_metrics WHERE r_multiple IS NOT NULL ORDER BY evaluated_at").fetchall()]
        vals=[v for v in vals if math.isfinite(v)]
        if len(vals)<20: return {"samples":len(vals),"runs":0,"status":"insufficient"}
        rng=np.random.default_rng(29)
        finals=[]; max_dd=[]
        for _ in range(int(max(100,min(runs,10000)))):
            seq=rng.choice(vals,size=len(vals),replace=True)
            eq=np.cumsum(seq); peak=np.maximum.accumulate(np.r_[0.0,eq]); dd=peak[1:]-eq
            finals.append(float(eq[-1])); max_dd.append(float(np.max(dd)) if len(dd) else 0.0)
        return {"samples":len(vals),"runs":len(finals),"status":"ok",
                "final_r_p50":round(float(np.percentile(finals,50)),3),
                "final_r_p05":round(float(np.percentile(finals,5)),3),
                "final_r_p95":round(float(np.percentile(finals,95)),3),
                "max_dd_r_p50":round(float(np.percentile(max_dd,50)),3),
                "max_dd_r_p95":round(float(np.percentile(max_dd,95)),3)}
    except Exception as exc:
        return {"status":"error","error":str(exc)[:180]}


def _edge_champion_challenger() -> dict[str, Any]:
    """Keep a reproducible registry; challenger never silently changes live weights."""
    report=_edge_performance_report(); now=time.time()
    try:
        with DB_LOCK, db_conn() as con:
            weights=json.dumps(_CENTRAL_WEIGHTS,ensure_ascii=False,sort_keys=True)
            con.execute("INSERT OR IGNORE INTO central_model_registry(model_name,version,role,weights_json,sample_count,win_rate,expectancy_pct,profit_factor,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        ("TITAN_CENTRAL","V29.5-LIVE","CHAMPION",weights,report.get("samples",0),report.get("win_rate"),report.get("expectancy_pct"),report.get("profit_factor"),"LIVE",now))
            con.execute("INSERT OR IGNORE INTO central_model_registry(model_name,version,role,weights_json,status,created_at) VALUES(?,?,?,?,?,?)",
                        ("TITAN_CENTRAL","V29.5-CHALLENGER","CHALLENGER",weights,"SHADOW",now))
            con.commit()
        return {"champion":"V29.5-LIVE","challenger":"V29.5-CHALLENGER","promotion":"manual_after_OOS_validation","metrics":report}
    except Exception as exc:
        return {"error":str(exc)[:180]}


def _edge_walk_forward_report(train_frac: float = 0.60, test_frac: float = 0.20,
                               embargo_minutes: int = 240) -> dict[str, Any]:
    """Chronological, purged/embargoed stability check on realized central trades.

    This does not pretend to be a full historical strategy backtest: it measures
    whether realized central outcomes remain stable when later observations are
    kept out of the earlier training window.
    """
    try:
        with DB_LOCK, db_conn() as con:
            rows=con.execute("SELECT p.created_at,p.outcome,m.net_return_pct,m.r_multiple,p.confidence "
                             "FROM central_predictions p JOIN central_trade_metrics m ON m.prediction_id=p.id "
                             "WHERE p.outcome IN ('WIN','LOSS') ORDER BY p.created_at ASC,p.id ASC").fetchall()
        n=len(rows)
        if n < 30:
            return {"status":"insufficient","samples":n,"minimum":30}
        cut1=max(10,int(n*train_frac)); cut2=min(n-10,int(n*(train_frac+test_frac)))
        if cut2<=cut1: return {"status":"insufficient","samples":n}
        train=list(rows[:cut1]); test=list(rows[cut2:])
        # Purge test observations too close to the end of training.
        train_end=safe_float(train[-1][0],0)
        test=[r for r in test if safe_float(r[0],0) >= train_end + embargo_minutes*60]
        def stats(rr):
            vals=[safe_float(r[2],0) for r in rr]
            if not vals:return {"samples":0,"expectancy_pct":None,"win_rate":None,"profit_factor":None}
            gains=sum(v for v in vals if v>0); losses=abs(sum(v for v in vals if v<0))
            return {"samples":len(vals),"expectancy_pct":round(float(np.mean(vals)),4),
                    "win_rate":round(sum(v>0 for v in vals)/len(vals)*100,2),
                    "profit_factor":round(gains/max(losses,1e-9),3) if losses else 99.0}
        return {"status":"ok","samples":n,"embargo_minutes":embargo_minutes,
                "train":stats(train),"test":stats(test),
                "purged":True,"note":"فقط برای سنجش پایداری realized outcomes؛ تضمین عملکرد آینده نیست."}
    except Exception as exc:
        return {"status":"error","error":str(exc)[:180]}


def _edge_api_report() -> dict[str, Any]:
    return {"ok":True,"version":EDGE_LAB_VERSION,"metrics":_edge_performance_report(),
            "monte_carlo":_edge_monte_carlo(),"governance":_edge_champion_challenger(),
            "walk_forward":_edge_walk_forward_report(),
            "friction":{"fee_rate":FEE_RATE,"spread_rate":SPREAD_RATE,"slippage_rate":SLIPPAGE_RATE,
                         "round_trip_pct":round(TOTAL_ENTRY_BUFFER*2*100,4)},
            "note":"کالیبراسیون و عملکرد فقط بر مبنای نمونه‌های realized گذشته است؛ پیش‌بینی تضمینی نیست."}


def _central_init_schema() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS central_predictions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    bias TEXT,
                    price REAL,
                    stop_loss REAL,
                    tp1 REAL,
                    tp2 REAL,
                    confidence REAL,
                    score REAL,
                    margin REAL,
                    reasons_json TEXT,
                    components_json TEXT,
                    weights_json TEXT,
                    horizon_minutes INTEGER DEFAULT 240,
                    outcome TEXT DEFAULT 'PENDING',
                    evaluated_at REAL,
                    return_pct REAL,
                    lesson TEXT,
                    version TEXT
                )"""
            )
            con.execute(
                """CREATE TABLE IF NOT EXISTS central_component_stats (
                    component TEXT PRIMARY KEY,
                    samples INTEGER DEFAULT 0,
                    wins INTEGER DEFAULT 0,
                    losses INTEGER DEFAULT 0,
                    reward_sum REAL DEFAULT 0,
                    penalty_sum REAL DEFAULT 0,
                    weight REAL DEFAULT 1.0,
                    updated_at REAL
                )"""
            )
            con.execute(
                """CREATE TABLE IF NOT EXISTS central_arbiter_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL,
                    symbol TEXT,
                    decision TEXT,
                    verdict TEXT,
                    score REAL,
                    notes TEXT
                )"""
            )
            con.commit()
    except Exception as exc:
        LOGGER.debug("central schema: %s", exc)


def _central_load_weights() -> None:
    global _CENTRAL_WEIGHTS
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                "SELECT component,samples,wins,losses,reward_sum,penalty_sum,weight FROM central_component_stats"
            ).fetchall()
        weights = dict(_CENTRAL_WEIGHTS_DEFAULT)
        for row in rows:
            name, samples, wins, losses, reward, penalty, w = row
            # Ignore components from retired decision generations.  Otherwise an
            # old DB can silently resurrect removed/circular voters.
            if name not in _CENTRAL_WEIGHTS_DEFAULT:
                continue
            n = int(samples or 0)
            if n >= 12:
                wr = (wins or 0) / max(1, (wins or 0) + (losses or 0))
                reliability = clamp(0.55 + (wr - 0.5) * 1.4, 0.35, 1.55)
                # mild reward/penalty tilt
                tilt = 1.0 + 0.04 * safe_float(reward, 0) - 0.05 * safe_float(penalty, 0)
                w = clamp(safe_float(_CENTRAL_WEIGHTS_DEFAULT.get(name), 1.0) * reliability * tilt, 0.25, 2.4)
            else:
                w = safe_float(_CENTRAL_WEIGHTS_DEFAULT.get(name), 1.0)
            weights[name] = float(w)
        with _CENTRAL_WEIGHT_LOCK:
            _CENTRAL_WEIGHTS = weights
    except Exception as exc:
        LOGGER.debug("central weight load: %s", exc)


_central_init_schema()
_edge_lab_init_schema()
_central_load_weights()


def _central_votes(item: dict[str, Any]) -> dict[str, dict[str, Any]]:
    votes: dict[str, dict[str, Any]] = {}
    tf = item.get("tf_scores") or item.get("tfs") or {}
    s15 = safe_float(tf.get("15m"), 50.0)
    s1h = safe_float(tf.get("1h"), 50.0)
    s4h = safe_float(tf.get("4h"), 50.0)
    s1d = safe_float(tf.get("1d"), 50.0)
    htf = 0.55 * s4h + 0.45 * s1d
    mtf = s1h
    ltf = s15

    def _from_score(sc: float) -> tuple[float, float, str]:
        lean = clamp((sc - 50.0) / 50.0, -1.0, 1.0)
        conf = clamp(abs(sc - 50.0) / 50.0, 0.0, 1.0)
        side = "LONG" if lean > 0.08 else "SHORT" if lean < -0.08 else "WAIT"
        return lean, conf, side

    for key, sc, label in (
        ("htf_trend", htf, "روند کلان 4h/1d"),
        ("mtf_setup", mtf, "ستاپ 1h"),
        ("ltf_trigger", ltf, "تریگر 15m"),
    ):
        lean, conf, side = _from_score(sc)
        votes[key] = {"lean": lean, "confidence": conf, "side": side, "raw": sc, "label": label}

    score = safe_float(item.get("score"), 50.0)
    lean, conf, side = _from_score(score)
    votes["momentum"] = {"lean": lean, "confidence": conf, "side": side, "raw": score, "label": "مومنتوم هسته"}

    structure = item.get("structure") or {}
    sb = str(structure.get("bias") or item.get("structure_bias") or item.get("bias") or "")
    if sb in {"صعودی", "LONG"}:
        lean, conf = 0.55, 0.55
    elif sb in {"نزولی", "SHORT"}:
        lean, conf = -0.55, 0.55
    else:
        lean, conf = 0.0, 0.2
    votes["structure"] = {
        "lean": lean, "confidence": conf,
        "side": "LONG" if lean > 0 else "SHORT" if lean < 0 else "WAIT",
        "raw": sb or "خنثی", "label": "ساختار قیمت",
    }

    taker_buy = safe_float(item.get("taker_buy_pct"), 50.0)
    if taker_buy == 50 and isinstance(item.get("buy_sell"), dict):
        taker_buy = safe_float((item.get("buy_sell") or {}).get("buy_pct"), 50.0)
    vol_lean = clamp((taker_buy - 50.0) / 35.0, -1.0, 1.0)
    votes["volume_flow"] = {
        "lean": vol_lean,
        "confidence": clamp(abs(taker_buy - 50.0) / 35.0, 0.0, 1.0),
        "side": "LONG" if vol_lean > 0.12 else "SHORT" if vol_lean < -0.12 else "WAIT",
        "raw": taker_buy, "label": "جریان حجم",
    }

    deriv = item.get("derivatives") if isinstance(item.get("derivatives"), dict) else {}
    funding = safe_float(item.get("funding_value"), safe_float(deriv.get("funding_value"), 0.0))
    oi_delta = safe_float(item.get("oi_delta"), safe_float(deriv.get("oi_delta"), 0.0))
    fund_lean = clamp(-funding * 8.0, -1.0, 1.0)
    oi_lean = clamp(oi_delta / 8.0, -1.0, 1.0)
    d_lean = clamp(0.6 * fund_lean + 0.4 * oi_lean, -1.0, 1.0)
    votes["derivatives"] = {
        "lean": d_lean, "confidence": clamp(abs(d_lean), 0.0, 1.0),
        "side": "LONG" if d_lean > 0.12 else "SHORT" if d_lean < -0.12 else "WAIT",
        "raw": {"funding": funding, "oi_delta": oi_delta}, "label": "مشتقات",
    }

    patterns = item.get("patterns") or item.get("pattern_pack") or {}
    pbias = safe_float(patterns.get("score_bias") if isinstance(patterns, dict) else 0.0, safe_float(item.get("pattern_bias"), 0.0))
    p_lean = clamp(pbias / 4.0, -1.0, 1.0)
    votes["pattern"] = {
        "lean": p_lean, "confidence": clamp(abs(p_lean), 0.0, 1.0),
        "side": "LONG" if p_lean > 0.15 else "SHORT" if p_lean < -0.15 else "WAIT",
        "raw": pbias, "label": "الگوی نموداری",
    }

    fc = item.get("candle_forecast") or item.get("forecast") or {}
    fc_bias = str(fc.get("overall_bias") or "")
    if fc_bias == "صعودی":
        f_lean, f_conf = 0.45, 0.4
    elif fc_bias == "نزولی":
        f_lean, f_conf = -0.45, 0.4
    else:
        f_lean, f_conf = 0.0, 0.15
    path_strength = safe_float(fc.get("path_strength"), 0.0) / 40.0
    f_conf = clamp(f_conf + path_strength * 0.3, 0.0, 1.0)
    votes["forecast_path"] = {
        "lean": f_lean, "confidence": f_conf,
        "side": "LONG" if f_lean > 0 else "SHORT" if f_lean < 0 else "WAIT",
        "raw": fc_bias or "خنثی", "label": "مسیر پیش‌بینی",
    }

    # Do NOT vote the previous canonical decision back into the new canonical
    # decision.  It is derived from many of the same inputs and would create
    # circular reinforcement.  It remains available in the audit payload only.

    learning = item.get("v32_learning") or {}
    long_adj = safe_float(learning.get("long_adjustment"), 0.0)
    short_adj = safe_float(learning.get("short_adjustment"), 0.0)
    learn_lean = clamp((long_adj - short_adj) / 8.0, -1.0, 1.0)
    votes["learning_v32"] = {
        "lean": learn_lean,
        "confidence": clamp(abs(learn_lean), 0.0, 1.0),
        "side": "LONG" if learn_lean > 0.12 else "SHORT" if learn_lean < -0.12 else "WAIT",
        "raw": {"long_adj": long_adj, "short_adj": short_adj},
        "label": "یادگیری تاریخی",
    }

    ai = item.get("ai_ensemble") or item.get("ai_opinions") or (item.get("edge") or {}).get("ai") or {}
    ai_side = str(ai.get("majority") or ai.get("side") or item.get("ai_majority") or "WAIT").upper()
    if ai_side in {"صعودی", "BUY", "LONG"}:
        a_lean, a_side = 0.5, "LONG"
    elif ai_side in {"نزولی", "SELL", "SHORT"}:
        a_lean, a_side = -0.5, "SHORT"
    else:
        a_lean, a_side = 0.0, "WAIT"
    a_conf = clamp(safe_float(ai.get("agreement"), 0.0) / 100.0, 0.0, 1.0)
    votes["ai_vote"] = {
        "lean": a_lean, "confidence": max(a_conf, 0.15 if a_side != "WAIT" else 0.05),
        "side": a_side, "raw": ai_side, "label": "رأی AI",
    }

    dq = item.get("data_quality") or {}
    trust = safe_float(dq.get("score"), safe_float(item.get("data_trust"), safe_float(item.get("trust_index"), 70.0)))
    votes["data_trust"] = {
        "lean": 0.0, "confidence": clamp(trust / 100.0, 0.0, 1.0),
        "side": "WAIT", "raw": trust, "label": "اعتماد داده", "trust": trust,
    }
    return votes


def _central_decide(item: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    votes = _central_votes(item)
    with _CENTRAL_WEIGHT_LOCK:
        weights = dict(_CENTRAL_WEIGHTS)

    long_score = short_score = weight_sum = 0.0
    details = []
    for name, v in votes.items():
        if name == "data_trust":
            continue
        w = safe_float(weights.get(name), 1.0)
        lean = safe_float(v.get("lean"), 0.0)
        conf = safe_float(v.get("confidence"), 0.0)
        effective = w * conf
        weight_sum += effective
        if lean > 0:
            long_score += effective * lean
        elif lean < 0:
            short_score += effective * abs(lean)
        details.append({
            "component": name, "label": v.get("label"), "side": v.get("side"),
            "lean": round(lean, 4), "confidence": round(conf, 4), "weight": round(w, 4),
            "contribution": round(effective * lean, 4), "raw": v.get("raw"),
        })
    if weight_sum > 0:
        long_score /= weight_sum
        short_score /= weight_sum

    trust = safe_float((votes.get("data_trust") or {}).get("trust"), 70.0)
    margin = abs(long_score - short_score)
    edge = max(long_score, short_score)
    reasons: list[str] = []
    candidate = "LONG" if long_score > short_score else "SHORT" if short_score > long_score else "WAIT"

    overlap = _edge_overlap_gate(_normalize_symbol(item.get("symbol") or ""), candidate)
    if candidate in {"LONG", "SHORT"} and not overlap.get("ok", True):
        reasons.append(str(overlap.get("reason") or "overlap risk"))
        candidate = "WAIT"

    price = safe_float(str(item.get("price_raw") or item.get("live_price") or item.get("price") or "0").replace(",", ""), 0.0)
    if price <= 0:
        reasons.append("قیمت نامعتبر")
    if trust < _CENTRAL_MIN_TRUST:
        reasons.append(f"اعتماد داده پایین ({trust:.0f})")
    if edge < _CENTRAL_MIN_EDGE:
        reasons.append(f"لبه تصمیم ناکافی ({edge:.3f})")
    if margin < _CENTRAL_MIN_MARGIN:
        reasons.append(f"حاشیه LONG/SHORT کم ({margin:.3f})")

    htf_side = str((votes.get("htf_trend") or {}).get("side") or "WAIT")
    htf_conf = safe_float((votes.get("htf_trend") or {}).get("confidence"), 0)
    if candidate == "LONG" and htf_side == "SHORT" and htf_conf >= 0.35:
        reasons.append("روند کلان مخالف لانگ")
        candidate = "WAIT"
    if candidate == "SHORT" and htf_side == "LONG" and htf_conf >= 0.35:
        reasons.append("روند کلان مخالف شورت")
        candidate = "WAIT"

    # Level integrity / rebuild
    rr1 = safe_float(item.get("rr_tp1"), 0.0)
    if candidate in {"LONG", "SHORT"} and price > 0:
        sl = safe_float(str(item.get("stop_loss") or "0").replace(",", ""), 0.0)
        tp1 = safe_float(str(item.get("tp1") or "0").replace(",", ""), 0.0)
        tp2 = safe_float(str(item.get("tp2") or "0").replace(",", ""), 0.0)
        atr = safe_float(item.get("atr"), price * 0.012) or price * 0.012
        if candidate == "LONG":
            bad = (
                sl <= 0 or tp1 <= 0 or tp2 <= 0
                or not (sl < price < tp1 < tp2)
            )
            if bad:
                sl, tp1, tp2 = price - 1.35 * atr, price + 2.3 * atr, price + 3.5 * atr
        else:
            bad = (
                sl <= 0 or tp1 <= 0 or tp2 <= 0
                or not (tp2 < tp1 < price < sl)
            )
            if bad:
                sl, tp1, tp2 = price + 1.35 * atr, price - 2.3 * atr, price - 3.5 * atr
        item["stop_loss"] = round(sl, 8)
        item["tp1"] = round(tp1, 8)
        item["tp2"] = round(tp2, 8)
        item["stop_loss_raw"] = float(sl)
        item["tp1_raw"] = float(tp1)
        item["tp2_raw"] = float(tp2)
        rr1 = abs(tp1 - price) / max(abs(price - sl), 1e-12)
        rr2 = abs(tp2 - price) / max(abs(price - sl), 1e-12)
        item["rr_tp1"] = round(rr1, 3)
        item["rr_tp2"] = round(rr2, 3)
        item["effective_rr_tp1"] = round(rr1, 3)
        item["effective_rr_tp2"] = round(rr2, 3)
        if rr1 < 1.05:
            reasons.append(f"R:R ضعیف ({rr1:.2f})")
            candidate = "WAIT"

    decision = candidate if not reasons and candidate in {"LONG", "SHORT"} else "WAIT"
    if decision in {"LONG", "SHORT"}:
        reasons.append("داور مرکزی: اجماع وزنی شواهد کافی است")
    elif not reasons:
        reasons.append("شواهد برای ورود جهت‌دار کافی نیست")

    conf100 = clamp(50.0 + edge * 40.0 + margin * 25.0 + (trust - 50.0) * 0.15, 5.0, 92.0)
    if decision == "WAIT":
        conf100 = min(conf100, 55.0)

    scorecard = []
    for d in details:
        aligned = decision != "WAIT" and d["side"] == decision
        opposed = decision != "WAIT" and d["side"] in {"LONG", "SHORT"} and d["side"] != decision
        scorecard.append({**d, "aligned": aligned, "opposed": opposed,
                          "preview": "reward" if aligned else "penalty" if opposed else "neutral"})

    meta = {
        "version": TITAN_CENTRAL_VERSION,
        "decision": decision,
        "long_score": round(long_score, 5),
        "short_score": round(short_score, 5),
        "edge": round(edge, 5),
        "margin": round(margin, 5),
        "confidence": round(conf100, 2),
        "trust": round(trust, 2),
        "rr1": round(rr1, 3),
        "reasons": reasons,
        "components": scorecard,
        "weights": {k: round(v, 4) for k, v in weights.items()},
        "entry_quality": round(clamp((edge * 45.0 + margin * 30.0 + trust * 0.25), 0.0, 100.0), 2),
        "directional_bias": round((long_score - short_score) * 100.0, 2),
        "overlap": overlap,
        "authoritative": True,
        "timestamp": time.time(),
    }
    return decision, meta



def _real_edge_engine(item: dict[str, Any], decision: str, meta: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """Final real-edge gate: regime + structure + liquidity + MTF + entry + risk.

    This layer is deliberately conservative.  It does not invent probability;
    it can only confirm an existing directional candidate or demote it to WAIT.
    """
    x = item or {}
    d = str(decision or "WAIT").upper()
    price = safe_float(x.get("price_raw"), 0.0)
    atr = safe_float(x.get("atr"), 0.0)
    regime = x.get("regime") if isinstance(x.get("regime"), dict) else {}
    structure = x.get("structure") if isinstance(x.get("structure"), dict) else {}
    liquidity = x.get("liquidity") if isinstance(x.get("liquidity"), dict) else {}
    precision = x.get("precision") if isinstance(x.get("precision"), dict) else {}
    fusion = x.get("fusion") if isinstance(x.get("fusion"), dict) else {}
    tf = x.get("tf_results") if isinstance(x.get("tf_results"), dict) else {}

    reg_name = str(regime.get("regime") or "unknown").lower()
    reg_conf = clamp(safe_float(regime.get("confidence"), 0), 0, 100)
    struct_event = str(structure.get("event") or "UNKNOWN").upper()
    struct_conf = clamp(safe_float(structure.get("confirmation_score"), 0), 0, 100)
    liq_pressure = safe_float(liquidity.get("pressure"), 0)
    liq_bias = str(liquidity.get("liquidity_bias") or "unknown").lower()
    precision_score = clamp(safe_float(precision.get("score"), 50), 0, 100)
    alignment = clamp(safe_float(x.get("alignment"), safe_float(meta.get("alignment"), 50)), 0, 100)

    # 1) True trend/regime compatibility.
    if d == "LONG":
        regime_side_ok = reg_name in {"trend_up", "breakout_watch"} or "up" in reg_name
        structure_ok = struct_event in {"BOS_UP", "BULL_STRUCTURE"}
        flow_ok = liq_pressure >= -0.05
    elif d == "SHORT":
        regime_side_ok = reg_name in {"trend_down", "breakout_watch"} or "down" in reg_name
        structure_ok = struct_event in {"BOS_DOWN", "BEAR_STRUCTURE"}
        flow_ok = liq_pressure <= 0.05
    else:
        regime_side_ok = structure_ok = flow_ok = False

    # 2) Multi-timeframe alignment: use existing per-TF evidence when present.
    tf_sides=[]
    for key,val in tf.items():
        if isinstance(val, dict):
            side=str(val.get("side") or val.get("bias") or "").upper()
            if side in {"LONG","SHORT"}: tf_sides.append(side)
    if tf_sides and d in {"LONG","SHORT"}:
        aligned_n=sum(1 for side in tf_sides if side==d)
        mtf_pct=aligned_n/max(1,len(tf_sides))*100.0
    else:
        mtf_pct=alignment

    # 3) Dynamic entry zone.  Current live price is the anchor; the zone is not
    # a promise of fill, it is a bounded pullback/confirmation area.
    if price > 0 and atr > 0:
        zone_width=max(price*0.0012, atr*0.30)
        if d == "LONG":
            entry_low, entry_high = price-zone_width, price+zone_width*0.20
        elif d == "SHORT":
            entry_low, entry_high = price-zone_width*0.20, price+zone_width
        else:
            entry_low, entry_high = price-zone_width, price+zone_width
    else:
        zone_width=0.0; entry_low=entry_high=price

    overextended = "overextended_entry" in [str(v) for v in (precision.get("hard_blocks") or [])]
    if price > 0 and atr > 0:
        vwap=safe_float(x.get("vwap"), price)
        stretch_atr=abs(price-vwap)/atr if vwap > 0 else 0.0
    else:
        stretch_atr=0.0
    entry_state="OPTIMAL"
    if overextended or stretch_atr > 2.2:
        entry_state="LATE"
    elif stretch_atr > 1.25:
        entry_state="EARLY/EXTENDED"

    # 4) Risk/exit integrity.
    sl=safe_float(x.get("stop_loss_raw"), safe_float(x.get("stop_loss"), 0))
    tp1=safe_float(x.get("tp1_raw"), safe_float(x.get("tp1"), 0))
    tp2=safe_float(x.get("tp2_raw"), safe_float(x.get("tp2"), 0))
    risk_dist=abs(price-sl) if price>0 and sl>0 else 0.0
    rr1=abs(tp1-price)/max(risk_dist,1e-12) if risk_dist else 0.0
    rr2=abs(tp2-price)/max(risk_dist,1e-12) if risk_dist else 0.0
    level_ok=(d=="LONG" and sl<price<tp1<tp2) or (d=="SHORT" and tp2<tp1<price<sl)

    # 5) Correlation/portfolio concentration already maintained by overlap gate;
    # surface its live state rather than hiding it.
    corr=fusion.get("btc_correlation") if isinstance(fusion.get("btc_correlation"),dict) else {}
    corr_blocked=bool(corr.get("blocked") or corr.get("veto"))

    # 6) No-trade intelligence: reasons are explicit and auditable.
    blocks=[]
    if d in {"LONG","SHORT"}:
        if not regime_side_ok: blocks.append("regime_conflict")
        if not structure_ok: blocks.append("structure_not_confirmed")
        if mtf_pct < 55: blocks.append("mtf_alignment_low")
        if struct_conf < 48: blocks.append("structure_confidence_low")
        if reg_conf < 45: blocks.append("regime_confidence_low")
        if not flow_ok: blocks.append("liquidity_flow_conflict")
        if corr_blocked: blocks.append("correlation_risk")
        if overextended or entry_state == "LATE": blocks.append("late_entry")
        if not level_ok: blocks.append("invalid_levels")
        if rr1 < 1.15 or rr2 < 1.50: blocks.append("weak_rr")
        if precision_score < 42: blocks.append("entry_quality_low")

    # 7) Composite quality.  This is a quality score, NOT a win probability.
    regime_component=reg_conf if regime_side_ok else max(0.0, reg_conf-35)
    structure_component=struct_conf if structure_ok else max(0.0, struct_conf-30)
    liquidity_component=50 + liq_pressure*200
    liquidity_component=clamp(liquidity_component if d=="LONG" else 100-liquidity_component,0,100)
    rr_component=clamp(50 + (rr1-1)*20 + (rr2-1.5)*10,0,100)
    real_quality=clamp(
        regime_component*0.20 + structure_component*0.22 + mtf_pct*0.18
        + precision_score*0.18 + liquidity_component*0.10 + rr_component*0.12,
        0,100)
    if d=="WAIT": real_quality=min(real_quality,55)

    # 8) Path simulation is a transparent ATR/level proxy, never labeled as realized.
    expected_mae_r=0.65 if atr>0 else None
    expected_mfe_r=rr2 if rr2>0 else None
    path_quality=clamp((safe_float(expected_mfe_r,0)/max(safe_float(expected_mae_r,1),1e-9))*30,0,100) if expected_mfe_r else 0

    # 9) Conservative final gate. Existing Central Governor remains authoritative;
    # this layer only demotes a candidate when the evidence is materially unsafe.
    final=d
    if d in {"LONG","SHORT"} and (blocks or real_quality < 58):
        final="WAIT"
    if final != d and d in {"LONG","SHORT"}:
        blocks.append("REAL_EDGE_FINAL_GATE")

    lifecycle="WAITING_ENTRY" if final in {"LONG","SHORT"} and entry_state!="OPTIMAL" else "READY" if final in {"LONG","SHORT"} else "NO_TRADE"
    return final, {
        "version":"V30-REAL-EDGE",
        "direction":final,
        "candidate_direction":d,
        "regime":reg_name,
        "regime_confidence":round(reg_conf,1),
        "structure_event":struct_event,
        "structure_confidence":round(struct_conf,1),
        "mtf_alignment_pct":round(mtf_pct,1),
        "liquidity_bias":liq_bias,
        "liquidity_pressure":round(liq_pressure,4),
        "entry_quality":round(precision_score,1),
        "entry_zone":{"low":round(entry_low,8),"high":round(entry_high,8),"width":round(zone_width,8)},
        "entry_state":entry_state,
        "rr_tp1":round(rr1,3),"rr_tp2":round(rr2,3),"levels_valid":bool(level_ok),
        "correlation":corr,
        "real_edge_quality":round(real_quality,1),
        "path_quality":round(path_quality,1),
        "expected_mae_r_proxy":expected_mae_r,
        "expected_mfe_r_proxy":round(expected_mfe_r,3) if expected_mfe_r is not None else None,
        "no_trade_reasons":blocks,
        "lifecycle":lifecycle,
        "probability_note":"کیفیت تصمیم است، نه احتمال برد؛ probability فقط از calibration realized استفاده می‌شود.",
        "champion_challenger":"shadow_only_until_OOS_validation",
        "signal_invalidation":"ساختار/رژیم/سطح حدضرر نقض شود یا قیمت خارج از منطق ورود شود.",
    }

def _central_seal(item: dict[str, Any]) -> dict[str, Any]:
    x = dict(item or {})
    # refresh live price if possible
    try:
        sym = str(x.get("symbol") or "")
        with LIVE_LOCK:
            info = LIVE_PRICES.get(_normalize_symbol(sym)) or {}
        live_px = safe_float(info.get("price"), 0.0)
        if live_px > 0:
            x["price_raw"] = live_px
            x["live_price"] = live_px
            x["entry_raw"] = live_px
            x["price"] = smart_format(live_px)
            x["entry_valid"] = smart_format(live_px)
            age = time.time() - safe_float(info.get("ts"), time.time())
            x["live_price_age_sec"] = round(age, 2)
    except Exception:
        pass

    decision, meta = _central_decide(x)
    # V30 Real Edge Engine: final quality/no-trade gate. It never creates a
    # direction from nothing; it only confirms or demotes the Central decision.
    try:
        edge_decision, edge_pack = _real_edge_engine(x, decision, meta)
        if edge_decision != decision:
            meta = dict(meta)
            meta.setdefault("reasons", [])
            meta["reasons"] = list(meta.get("reasons") or []) + [
                "V30 REAL EDGE: " + ", ".join(edge_pack.get("no_trade_reasons") or ["quality_gate"])
            ]
            meta["entry_quality"] = edge_pack.get("real_edge_quality", meta.get("entry_quality", 50))
            meta["real_edge"] = edge_pack
            meta["decision_before_real_edge"] = decision
            decision = edge_decision
        else:
            meta = dict(meta)
            meta["real_edge"] = edge_pack
            meta["entry_quality"] = edge_pack.get("real_edge_quality", meta.get("entry_quality", 50))
    except Exception as _re_exc:
        LOGGER.debug("V30 real edge gate failed: %s", _re_exc)
        meta = dict(meta)
        meta["real_edge"] = {"version":"V30-REAL-EDGE","status":"degraded","error":str(_re_exc)[:180]}
    bias = "صعودی" if decision == "LONG" else "نزولی" if decision == "SHORT" else "خنثی"
    x["decision"] = decision
    x["decision_tag"] = decision
    x["bias"] = bias
    x["entry_mode"] = "EARLY" if decision in {"LONG", "SHORT"} else "WAIT"
    x["signal_tag"] = f"CENTRAL — {decision}"
    x["decision_state"] = f"CENTRAL_{decision}"
    x["authority"] = TITAN_CENTRAL_VERSION
    x["architecture"] = "SINGLE_CENTRAL_GOVERNOR"
    conf = safe_float(meta.get("confidence"), 50.0)
    x["decision_confidence"] = conf
    # This number is a model-confidence proxy, not a calibrated probability
    # of profit.  Keep the legacy fields for dashboard compatibility but expose
    # the distinction explicitly so users do not read 80 as "80% win chance".
    cal_pack = _edge_calibrate_central(conf, str(decision), str(x.get("symbol") or ""))
    x["calibrated_probability"] = cal_pack.get("calibrated")
    x["success_prob"] = conf
    x["success_probability"] = safe_float(cal_pack.get("calibrated"), conf)
    x["success_probability_is_calibrated"] = bool(cal_pack.get("is_calibrated"))
    x["probability_calibration"] = cal_pack
    x["entry_quality"] = safe_float(meta.get("entry_quality"), 50.0)
    x["directional_bias"] = safe_float(meta.get("directional_bias"), 0.0)
    x["edge_lab_version"] = EDGE_LAB_VERSION
    x["central_decision"] = meta
    x["decision_reasons"] = list(meta.get("reasons") or [])
    x["central_reason_fa"] = " · ".join(x["decision_reasons"][:4])
    x["decision_architecture"] = {
        "type": "SINGLE_CENTRAL_GOVERNOR",
        "authoritative_source": TITAN_CENTRAL_VERSION,
        "final_decision": decision,
        "legacy_engines_are_evidence_only": True,
    }
    for key in ("canonical_decision", "v32_decision", "v31_decision", "arbiter_verdict"):
        prev = x.get(key)
        if isinstance(prev, dict):
            prev = dict(prev)
            prev["decision"] = decision
            prev["overridden_by"] = TITAN_CENTRAL_VERSION
            x[key] = prev
    return x


def _central_record_prediction(item: dict[str, Any]) -> None:
    """Persist only independent directional observations.

    A scan can run every ~45s, but the same setup must not become dozens of
    pseudo-samples.  WAIT is kept in the arbiter log for auditability, while
    only LONG/SHORT observations enter the learning dataset with a cooldown.
    """
    try:
        meta = item.get("central_decision") or {}
        decision = str(item.get("decision_tag") or "WAIT").upper()
        symbol = _normalize_symbol(item.get("symbol") or "")
        now = time.time()

        with DB_LOCK, db_conn() as con:
            con.execute(
                """INSERT INTO central_arbiter_log(created_at,symbol,decision,verdict,score,notes)
                   VALUES(?,?,?,?,?,?)""",
                (
                    now, symbol, decision,
                    "ACCEPT" if decision in {"LONG", "SHORT"} else "WAIT",
                    safe_float(meta.get("confidence"), 0.0),
                    " · ".join((meta.get("reasons") or [])[:4]),
                ),
            )

            # Learning samples must represent distinct setups, not scan frequency.
            if decision not in {"LONG", "SHORT"}:
                con.commit()
                return

            recent = con.execute(
                """SELECT 1 FROM central_predictions
                   WHERE symbol=? AND created_at>=?
                   LIMIT 1""",
                (symbol, now - SIGNAL_COOLDOWN_SECONDS),
            ).fetchone()
            if recent:
                con.commit()
                return

            con.execute(
                """INSERT INTO central_predictions(
                    created_at,symbol,decision,bias,price,stop_loss,tp1,tp2,confidence,score,margin,
                    reasons_json,components_json,weights_json,horizon_minutes,outcome,version)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    now,
                    symbol,
                    decision,
                    item.get("bias"),
                    safe_float(item.get("price_raw"), safe_float(str(item.get("price") or "0").replace(",", ""), 0.0)),
                    safe_float(item.get("stop_loss_raw"), safe_float(str(item.get("stop_loss") or "0").replace(",", ""), 0.0)) or None,
                    safe_float(item.get("tp1_raw"), safe_float(str(item.get("tp1") or "0").replace(",", ""), 0.0)) or None,
                    safe_float(item.get("tp2_raw"), safe_float(str(item.get("tp2") or "0").replace(",", ""), 0.0)) or None,
                    safe_float(meta.get("confidence"), 0.0),
                    safe_float(item.get("score"), 50.0),
                    safe_float(meta.get("margin"), 0.0),
                    json.dumps(meta.get("reasons") or [], ensure_ascii=False),
                    json.dumps(meta.get("components") or [], ensure_ascii=False, default=str),
                    json.dumps(meta.get("weights") or {}, ensure_ascii=False),
                    240,
                    "PENDING",
                    TITAN_CENTRAL_VERSION,
                ),
            )
            con.commit()
    except Exception as exc:
        LOGGER.debug("central record: %s", exc)


def _central_evaluate_pending() -> dict[str, Any]:
    """Evaluate predictions only inside their original, exact forward horizon.

    The old evaluator fetched the latest candles after the horizon and therefore
    could accidentally judge a 4-hour prediction using price action from much
    later.  It also used max/min over the whole window, which cannot tell which
    barrier was touched first.  This version uses a bounded OHLC window and the
    same chronological first-touch logic used by paper trades.
    """
    done = 0
    try:
        now = time.time()
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """SELECT id,created_at,symbol,decision,price,stop_loss,tp1,tp2,
                          horizon_minutes,components_json,confidence
                   FROM central_predictions
                   WHERE outcome='PENDING' AND created_at<=?
                   ORDER BY created_at LIMIT 200""",
                (now - 60,),
            ).fetchall()

        for row in rows:
            (rid, created, symbol, decision, entry, sl, tp1, tp2,
             horizon, comp_json, prediction_confidence) = row
            created = float(created)
            horizon = int(horizon or 240)
            horizon_end = created + horizon * 60.0
            if now < horizon_end:
                continue

            entry = safe_float(entry, 0.0)
            if entry <= 0 or decision not in {"LONG", "SHORT"}:
                continue

            start_ms = int(created * 1000)
            end_ms = int(horizon_end * 1000)

            try:
                bars_needed = max(20, min(1000, int(math.ceil(horizon / 15.0)) + 4))
                df = fetch_klines(
                    str(symbol), "15m", bars_needed,
                    start_ms=start_ms, end_ms=end_ms,
                )
                if df is None or df.empty or "t" not in df.columns:
                    continue
                window = df[
                    (df["t"].astype(float) >= start_ms) &
                    (df["t"].astype(float) < end_ms)
                ].sort_values("t")
                if window.empty:
                    continue
            except Exception as exc:
                LOGGER.debug("central horizon fetch failed #%s: %s", rid, exc)
                continue

            # Chronological barrier evaluation.  If SL and TP are both inside
            # one OHLC candle, ordering is unknowable at this timeframe; do not
            # manufacture a WIN/LOSS sample from ambiguous data.
            touch, hit_type, exit_px = _first_touch_ohlc(
                window, decision,
                safe_float(sl, np.nan),
                safe_float(tp1, np.nan),
                safe_float(tp2, np.nan),
            )

            last = safe_float(window["close"].iloc[-1], entry)
            if decision == "LONG":
                ret = (last / entry - 1.0) * 100.0
            else:
                ret = (entry / last - 1.0) * 100.0 if last > 0 else 0.0

            if touch == "WIN":
                outcome = "WIN"
            elif touch == "LOSS":
                outcome = "LOSS"
            elif touch == "AMBIGUOUS":
                outcome = "AMBIGUOUS"
            else:
                # No barrier was touched inside the declared horizon.  This is
                # a time-expiry observation, not a binary WIN/LOSS training label.
                outcome = "TIME_EXIT"

            lesson = {
                "WIN": "اولین لمس هدف داخل پنجره پیش‌بینی رخ داد.",
                "LOSS": "اولین لمس حد ضرر داخل پنجره پیش‌بینی رخ داد.",
                "AMBIGUOUS": "حد ضرر و هدف در یک کندل لمس شدند؛ ترتیب قابل تشخیص نیست.",
                "TIME_EXIT": "هیچ سطحی تا پایان افق لمس نشد؛ نمونه برای یادگیری دودویی استفاده نمی‌شود.",
            }.get(outcome, "")

            # Edge Lab telemetry: MAE/MFE, time-to-event, realized regime and friction-aware R.
            regime_name, vol_pct, trend_strength = _edge_regime_from_window(window)
            mae_pct = mfe_pct = 0.0
            try:
                highs = window["high"].astype(float); lows = window["low"].astype(float)
                if decision == "LONG":
                    mae_pct = (float(lows.min()) / entry - 1.0) * 100.0
                    mfe_pct = (float(highs.max()) / entry - 1.0) * 100.0
                else:
                    mae_pct = (entry / float(highs.max()) - 1.0) * 100.0
                    mfe_pct = (entry / float(lows.min()) - 1.0) * 100.0
            except Exception:
                pass
            touch_d, touch_px, touch_ts = _edge_first_touch_detail(window, decision, safe_float(sl,np.nan), safe_float(tp1,np.nan), safe_float(tp2,np.nan))
            event_time = ((touch_ts - created) / 60.0) if touch_ts is not None else float(horizon)
            friction_pct = TOTAL_ENTRY_BUFFER * 2.0 * 100.0
            gross_ret = ret
            net_ret = gross_ret - friction_pct if math.isfinite(gross_ret) else gross_ret
            risk_dist = abs(entry - safe_float(sl, entry))
            r_mult = ((touch_px-entry)/max(risk_dist,1e-12) if decision=="LONG" and touch_px else (entry-touch_px)/max(risk_dist,1e-12) if decision=="SHORT" and touch_px else net_ret/max((risk_dist/max(entry,1e-12))*100.0,1e-12))
            entry_quality = clamp(50.0 + abs(safe_float(prediction_confidence,50.0)-50.0)*0.6 + trend_strength*0.2, 0.0, 100.0)
            directional_bias = 100.0 if decision=="LONG" else -100.0
            with DB_LOCK, db_conn() as con:
                con.execute("INSERT OR REPLACE INTO central_trade_metrics(prediction_id,regime,volatility_pct,trend_strength,mae_pct,mfe_pct,time_to_event_min,exit_price,net_return_pct,r_multiple,entry_quality,directional_bias,ambiguity,friction_pct,evaluated_at,param_version,edge_lab_version) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (rid,regime_name,vol_pct,trend_strength,mae_pct,mfe_pct,event_time,touch_px or last,net_ret,r_mult,entry_quality,directional_bias,1 if outcome=="AMBIGUOUS" else 0,friction_pct,now,TITAN_PARAM_VERSION,EDGE_LAB_VERSION))
                con.commit()

            try:
                comps = json.loads(comp_json or "[]")
            except Exception:
                comps = []

            # Only unambiguous barrier outcomes are allowed to change weights.
            if outcome in {"WIN", "LOSS"} and isinstance(comps, list):
                for c in comps:
                    name = str(c.get("component") or "")
                    if not name or name not in _CENTRAL_WEIGHTS_DEFAULT:
                        continue
                    side = str(c.get("side") or "WAIT")
                    aligned = side == decision
                    win = outcome == "WIN"
                    reward = (
                        1.0 if (win and aligned)
                        else 0.5 if ((not win) and side in {"LONG", "SHORT"} and not aligned)
                        else 0.0
                    )
                    penalty = (
                        1.0 if ((not win) and aligned)
                        else 0.5 if (win and side in {"LONG", "SHORT"} and not aligned)
                        else 0.0
                    )
                    with DB_LOCK, db_conn() as con:
                        con.execute(
                            """INSERT INTO central_component_stats(
                               component,samples,wins,losses,reward_sum,penalty_sum,weight,updated_at)
                               VALUES(?,?,?,?,?,?,?,?)
                               ON CONFLICT(component) DO UPDATE SET
                                 samples=samples+1,
                                 wins=wins+excluded.wins,
                                 losses=losses+excluded.losses,
                                 reward_sum=reward_sum+excluded.reward_sum,
                                 penalty_sum=penalty_sum+excluded.penalty_sum,
                                 updated_at=excluded.updated_at""",
                            (
                                name, 1,
                                1 if (win and aligned) else 0,
                                1 if ((not win) and aligned) else 0,
                                reward, penalty,
                                safe_float(_CENTRAL_WEIGHTS_DEFAULT.get(name), 1.0),
                                now,
                            ),
                        )

            with DB_LOCK, db_conn() as con:
                con.execute(
                    """UPDATE central_predictions
                       SET outcome=?,evaluated_at=?,return_pct=?,lesson=?
                       WHERE id=?""",
                    (outcome, now, ret, lesson, rid),
                )
                con.commit()
            done += 1

        if done:
            _central_load_weights()
        return {"ok": True, "evaluated": done}
    except Exception as exc:
        LOGGER.debug("central evaluate: %s", exc)
        return {"ok": False, "error": str(exc)[:200]}

def _emergency_live_cards(coins: list | None = None) -> list[dict[str, Any]]:
    """Never leave Android dashboard blank — live prices + WAIT."""
    coins = list(coins or USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
    cards: list[dict[str, Any]] = []
    prices: dict[str, float] = {}
    try:
        prices = dict(_fetch_live_prices(list(coins)) or {})
    except Exception as exc:
        LOGGER.warning("emergency prices: %s", exc)
    now = time.time()
    for sym in coins:
        px = safe_float(prices.get(sym), 0.0)
        if px <= 0:
            for k, v in prices.items():
                if _normalize_symbol(k) == _normalize_symbol(sym):
                    px = safe_float(v, 0.0)
                    break
        if px <= 0:
            continue
        base = sym.split("/")[0] if "/" in sym else sym
        meta = COIN_META.get(base, (base, ""))
        cards.append({
            "symbol": sym, "name": meta[0], "icon": meta[1] if len(meta) > 1 else "",
            "price": smart_format(px), "price_raw": px, "live_price": px,
            "entry_raw": px, "entry_valid": smart_format(px),
            "decision": "WAIT", "decision_tag": "WAIT", "bias": "خنثی",
            "score": 50, "score_color": "#94a3b8", "signal_quality": 0,
            "success_probability": 50, "success_prob": 50, "trust_index": 40,
            "stop_loss": "—", "tp1": "—", "tp2": "—", "rr_tp1": "—",
            "authority": TITAN_CENTRAL_VERSION,
            "signal_tag": "LIVE-PRICE ONLY · WAIT",
            "central_reason_fa": "اسکن کامل در حال اجرا؛ فقط قیمت زنده",
            "scan_timestamp": now, "emergency_card": True,
        })
    return cards



# ============================================================
# TITAN V31 ADVANCED EDGE SUITE — 21 production modules
# Research/decision-support only. No order execution.
# ============================================================
V31_EDGE_VERSION = "TITAN-V31-21-EDGE-SUITE"
_V31_MEMORY = {}
_V31_LOCK = threading.RLock()


def _v31_num(x, default=0.0):
    try:
        v=float(x)
        return default if not math.isfinite(v) else v
    except Exception:
        return default


def _v31_side(item):
    d=str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
    return d if d in {"LONG","SHORT"} else "WAIT"

# 1) Signal DNA: immutable snapshot of the setup, so every realized result is attributable.
def _v31_signal_dna(item):
    side=_v31_side(item); r=_v31_num(item.get("rsi"),50); score=_v31_num(item.get("score"),50)
    return {"side":side,"score":round(score,2),"rsi":round(r,2),
            "regime":(item.get("regime") or item.get("market_regime") or "unknown"),
            "structure":(item.get("structure") or {}).get("bias", item.get("structure_bias","unknown")) if isinstance(item.get("structure"),dict) else item.get("structure_bias","unknown"),
            "entry":_v31_num(item.get("price") or item.get("entry_raw")),
            "rr1":_v31_num(item.get("rr_tp1")),"rr2":_v31_num(item.get("rr_tp2")),
            "quality":_v31_num(item.get("signal_quality"),0),"timestamp":time.time()}

# 2) Evidence fusion: correlated evidence is discounted; independent evidence is rewarded.
def _v31_evidence_fusion(item):
    dna=_v31_signal_dna(item); side=dna["side"]
    raw=[]
    for k,v in ((item.get("fusion") or {}).items() if isinstance(item.get("fusion"),dict) else []):
        if isinstance(v,(int,float)): raw.append((k,float(v)))
    support=[]
    if side=="LONG": support=[_v31_num(item.get("score"),50)/100,_v31_num(item.get("alignment"),50)/100]
    elif side=="SHORT": support=[1-_v31_num(item.get("score"),50)/100,1-_v31_num(item.get("alignment"),50)/100]
    else: support=[.5]
    # two strong but dependent price-derived signals never count as two full independent votes.
    independent=min(1.0,0.55*max(support)+0.45*(sum(support)/len(support)))
    return {"independence_score":round(independent,4),"raw_components":len(raw),"discount":round(1.0-0.35*max(0,len(raw)-3)/max(1,len(raw)),4)}

# 3) Counterfactual engine: explicit reasons the thesis can fail.
def _v31_counterfactual(item):
    side=_v31_side(item); score=_v31_num(item.get("score"),50); rr=_v31_num(item.get("rr_tp1"),0)
    risks=[]
    if side=="LONG" and score<55: risks.append("جهت صعودی ضعیف")
    if side=="SHORT" and score>45: risks.append("جهت نزولی ضعیف")
    if rr and rr<0.9: risks.append("R/R ضعیف")
    if str(item.get("regime") or "").lower() in {"transition","shock","unknown"}: risks.append("رژیم ناپایدار")
    return {"failure_risks":risks,"counterfactual_score":round(max(0,100-20*len(risks)),1),"thesis_fragile":len(risks)>=2}

# 4) Adversarial robustness: deterministic perturbation envelope, not a fake Monte-Carlo forecast.
def _v31_adversarial(item):
    q=_v31_num(item.get("signal_quality"),50); rr=_v31_num(item.get("rr_tp1"),1.0); side=_v31_side(item)
    if side=="WAIT": return {"robustness":50.0,"stress_cases":0,"failures":0}
    cases=[q-5,q-10,q-15, q-(2 if rr<1.2 else 0)]
    failures=sum(x<45 for x in cases)
    return {"robustness":round(max(0,min(100,100-15*failures-5*max(0,1.0-rr))),1),"stress_cases":len(cases),"failures":failures}

# 5) Entry stability: small price perturbations must not flip the thesis.
def _v31_entry_stability(item):
    p=_v31_num(item.get("price") or item.get("entry_raw")); sl=_v31_num(item.get("stop_loss")); tp=_v31_num(item.get("tp1")); side=_v31_side(item)
    if not p or side=="WAIT": return {"score":50.0,"band_pct":0.0}
    band=0.0025; vals=[]
    for f in (1-band,1-band/2,1,1+band/2,1+band):
        ep=p*f
        if side=="LONG": vals.append(float(sl<p and ep>sl and (not tp or ep<tp)))
        else: vals.append(float(sl>p and ep<sl and (not tp or ep>tp)))
    return {"score":round(100*sum(vals)/len(vals),1),"band_pct":band*100}

# 6) Exit intelligence: structure/risk/time/liquidity aware exit mode.
def _v31_exit_intelligence(item):
    side=_v31_side(item); rr1=_v31_num(item.get("rr_tp1"),0); rr2=_v31_num(item.get("rr_tp2"),0)
    regime=str(item.get("regime") or "").lower(); mode="HOLD_TO_TARGET"
    if side=="WAIT": mode="NONE"
    elif "shock" in regime: mode="DEFENSIVE_REDUCE"
    elif rr1<1.0: mode="EARLY_EXIT_BIAS"
    elif rr2>=1.8: mode="RUNNER_TO_TP2"
    return {"mode":mode,"rr_tp1":rr1,"rr_tp2":rr2,"invalidation":"structure_break_or_SL"}

# 7) Confidence decay: stale evidence loses weight with time.
def _v31_confidence_decay(item):
    ts=_v31_num(item.get("scan_timestamp"),time.time()); age=max(0,time.time()-ts); half=900.0
    decay=math.exp(-math.log(2)*age/half)
    return {"age_sec":round(age,1),"decay":round(decay,4),"effective_quality":round(_v31_num(item.get("signal_quality"),0)*decay,2)}

# 8) Market shock detector: uses available live/quality features conservatively.
def _v31_shock(item):
    atr=_v31_num(item.get("atr")); vol=bool(item.get("volume_spike")); spread=_v31_num(item.get("spread_pct"),0)
    flags=[]
    if vol: flags.append("volume_spike")
    if spread>0.25: flags.append("wide_spread")
    if atr<=0: flags.append("atr_missing")
    return {"mode":"SHOCK" if len(flags)>=2 else "NORMAL","flags":flags,"severity":min(1.0,len(flags)/3)}

# 9) Asset personality: persistent in-process profile, updated from each signal DNA.
def _v31_personality(item):
    sym=str(item.get("symbol") or "UNKNOWN"); side=_v31_side(item)
    with _V31_LOCK:
        st=_V31_MEMORY.setdefault(sym,{"samples":0,"long":0,"short":0,"quality_sum":0.0})
        st["samples"]+=1; st["long"]+=int(side=="LONG"); st["short"]+=int(side=="SHORT"); st["quality_sum"]+=_v31_num(item.get("signal_quality"),0)
        return {"samples":st["samples"],"long_share":round(st["long"]/st["samples"],3),"avg_quality":round(st["quality_sum"]/st["samples"],2)}

# 10) Session intelligence: UTC session bucket is deterministic and timezone-safe.
def _v31_session(item):
    h=datetime.now(timezone.utc).hour
    bucket="ASIA" if h<8 else "EUROPE" if h<13 else "US" if h<21 else "LATE"
    return {"session":bucket,"utc_hour":h}

# 11) Regime transition detector: disagreement between current regime and prior regime is a warning.
def _v31_transition(item):
    sym=str(item.get("symbol") or "UNKNOWN"); regime=str(item.get("regime") or item.get("market_regime") or "unknown")
    with _V31_LOCK:
        prev=_V31_MEMORY.setdefault("_regime",{}).get(sym); _V31_MEMORY["_regime"][sym]=regime
    return {"transition":bool(prev and prev!=regime),"previous":prev,"current":regime}

# 12) Dead-signal detector: no meaningful movement/evidence means WAIT rather than forced action.
def _v31_dead_signal(item):
    side=_v31_side(item); q=_v31_num(item.get("signal_quality"),0); score=_v31_num(item.get("score"),50)
    dead=side=="WAIT" or q<35 or abs(score-50)<3
    return {"dead":dead,"reason":"insufficient_edge" if dead else "active_edge"}

# 13) Internal prediction market: component probabilities are combined by independent strength.
def _v31_prediction_market(item):
    score=_v31_num(item.get("score"),50)/100; align=_v31_num(item.get("alignment"),50)/100
    side=_v31_side(item)
    probs=[score,align] if side=="LONG" else [1-score,1-align] if side=="SHORT" else [.5]
    return {"probability_proxy":round(100*sum(probs)/len(probs),2),"components":len(probs),"side":side}

# 14) Bayesian updating: conservative Beta posterior from realized central samples.
def _v31_bayes(item):
    sym=str(item.get("symbol") or ""); side=_v31_side(item); wins=losses=0
    try:
        if sym and side in {"LONG","SHORT"}:
            with DB_LOCK, db_conn() as con:
                # central_predictions stores English decision tags (LONG/SHORT), not Persian bias labels.
                row=con.execute(
                    "SELECT SUM(CASE WHEN outcome='WIN' THEN 1 ELSE 0 END), "
                    "SUM(CASE WHEN outcome='LOSS' THEN 1 ELSE 0 END) "
                    "FROM central_predictions WHERE symbol=? AND decision=? AND outcome IN ('WIN','LOSS')",
                    (sym, side),
                ).fetchone()
                wins=int(row[0] or 0); losses=int(row[1] or 0)
    except Exception: pass
    post=(wins+2)/(wins+losses+4)
    return {"wins":wins,"losses":losses,"posterior_pct":round(100*post,2)}

# 15) Uncertainty engine: probability and uncertainty are separate outputs.
def _v31_uncertainty(parts):
    vals=[_v31_num(parts.get("robustness"),50),_v31_num(parts.get("entry_stability"),50),_v31_num(parts.get("evidence_independence"),50)]
    uncertainty=100-sum(vals)/len(vals)
    return {"uncertainty":round(max(0,min(100,uncertainty)),2),"confidence_band":"LOW" if uncertainty<20 else "MEDIUM" if uncertainty<40 else "HIGH"}

# 16) Multi-dimensional confidence vector.
def _v31_confidence(item, parts):
    q=_v31_num(item.get("signal_quality"),0)
    return {"direction":round(abs(_v31_num(item.get("score"),50)-50)*2,1),"structure":q,"entry_quality":parts["entry_stability"],"regime":100 if not parts["transition"] else 45,"robustness":parts["robustness"],"uncertainty":parts["uncertainty"]}

# 17) Explainability: machine-readable WHY / WHY-NOT trail.
def _v31_explain(item, parts):
    why=[]; why_not=[]; side=_v31_side(item)
    if side in {"LONG","SHORT"}: why.append(f"direction={side}")
    if parts["robustness"]>=70: why.append("robust_under_stress")
    if parts["entry_stability"]>=80: why.append("stable_entry")
    if parts["transition"]: why_not.append("regime_transition")
    if parts["counterfactual"]<60: why_not.append("fragile_thesis")
    if parts["uncertainty"]>40: why_not.append("high_uncertainty")
    return {"why":why,"why_not":why_not}

# 18) Self-destruct threshold: invalidate thesis when core assumptions collapse.
def _v31_self_destruct(item, parts):
    trigger=(parts["counterfactual"]<40 or parts["robustness"]<40 or parts["dead"])
    return {"invalidate":bool(trigger),"reason":"core_edge_collapsed" if trigger else "thesis_intact"}

# 19) Data quality gate: missing core values reduce authority rather than being fabricated.
def _v31_data_quality(item):
    keys=("price","rsi","atr","score")
    missing=[k for k in keys if item.get(k) in (None,"","—")]
    score=max(0,100-20*len(missing))
    return {"score":score,"missing":missing,"gate":"PASS" if score>=80 else "DEGRADED" if score>=50 else "FAIL"}

# 20) Research lab: rolling attribution by asset/side from realized central outcomes.
def _v31_research(item):
    out={"samples":0,"wins":0,"losses":0,"win_rate":None}
    try:
        sym=str(item.get("symbol") or "")
        if sym:
            with DB_LOCK, db_conn() as con:
                r=con.execute("SELECT COUNT(*),SUM(CASE WHEN outcome='WIN' THEN 1 ELSE 0 END),SUM(CASE WHEN outcome='LOSS' THEN 1 ELSE 0 END) FROM central_predictions WHERE symbol=? AND outcome!='PENDING'",(sym,)).fetchone()
            n=int(r[0] or 0); w=int(r[1] or 0); l=int(r[2] or 0)
            out={"samples":n,"wins":w,"losses":l,"win_rate":round(100*w/n,2) if n else None}
    except Exception: pass
    return out

# 21) Champion/challenger: keep the current governor authoritative; compare challengers only as audit metrics.
def _v31_champion_challenger(item, parts):
    champion=float(_v31_num(item.get("signal_quality"),0)); challenger=float((parts["robustness"]+parts["entry_stability"]+parts["counterfactual"])/3)
    return {"champion":round(champion,2),"challenger":round(challenger,2),"challenger_wins":bool(challenger>champion),"action":"AUDIT_ONLY"}


def _v31_apply(item):
    """Run all 21 modules. The suite is a safety/audit layer; it never fabricates probabilities."""
    try:
        dna=_v31_signal_dna(item); ev=_v31_evidence_fusion(item); cf=_v31_counterfactual(item); adv=_v31_adversarial(item)
        ent=_v31_entry_stability(item); ex=_v31_exit_intelligence(item); decay=_v31_confidence_decay(item); shock=_v31_shock(item)
        personality=_v31_personality(item); session=_v31_session(item); transition=_v31_transition(item); dead=_v31_dead_signal(item)
        market=_v31_prediction_market(item); bayes=_v31_bayes(item)
        unc=_v31_uncertainty({"robustness":adv["robustness"],"entry_stability":ent["score"],"evidence_independence":ev["independence_score"]*100})
        conf=_v31_confidence(item,{"entry_stability":ent["score"],"robustness":adv["robustness"],"transition":transition["transition"],"uncertainty":unc["uncertainty"]})
        explain=_v31_explain(item,{"robustness":adv["robustness"],"entry_stability":ent["score"],"transition":transition["transition"],"counterfactual":cf["counterfactual_score"],"uncertainty":unc["uncertainty"]})
        sd=_v31_self_destruct(item,{"counterfactual":cf["counterfactual_score"],"robustness":adv["robustness"],"dead":dead["dead"]})
        dq=_v31_data_quality(item); research=_v31_research(item); cc=_v31_champion_challenger(item,{"robustness":adv["robustness"],"entry_stability":ent["score"],"counterfactual":cf["counterfactual_score"]})
        # Only hard safety failures can force WAIT. This does not create a new trade signal.
        original=_v31_side(item); forced_wait=sd["invalidate"] or dq["gate"]=="FAIL" or shock["mode"]=="SHOCK"
        if forced_wait and original in {"LONG","SHORT"}:
            item["decision_tag"]="WAIT"; item["decision"]="WAIT"; item["advanced_override"]="SAFETY_WAIT"
        item["v31_edge_suite"]={"version":V31_EDGE_VERSION,"signal_dna":dna,"evidence_fusion":ev,"counterfactual":cf,"adversarial":adv,"entry_stability":ent,"exit_intelligence":ex,"confidence_decay":decay,"shock":shock,"personality":personality,"session":session,"regime_transition":transition,"dead_signal":dead,"prediction_market":market,"bayesian":bayes,"uncertainty":unc,"confidence_vector":conf,"explainability":explain,"self_destruct":sd,"data_quality":dq,"research_lab":research,"champion_challenger":cc,"safety_wait":forced_wait}
        return item
    except Exception as exc:
        LOGGER.exception("V31 edge suite failed: %s",exc)
        item["v31_edge_suite"]={"version":V31_EDGE_VERSION,"error":str(exc)[:240]}
        return item


# ============================================================
# TITAN V34 — ADAPTIVE TRUST / OPPORTUNITY / CALIBRATION CORE
# ------------------------------------------------------------
# Additive evidence layer. It does not execute trades and does not invent
# probabilities. It learns only from realized outcomes already stored by TITAN.
# Goals:
#   1) distinguish "not enough evidence" from "almost actionable"
#   2) reduce unnecessary WAIT near a coherent edge
#   3) calibrate trust using realized history with Bayesian shrinkage
#   4) adapt evidence weight by symbol/direction without overfitting
#   5) expose a transparent scorecard for performance and audit
# ============================================================
V34_VERSION = "TITAN-V34-ADAPTIVE-TRUST-OPPORTUNITY"
V34_MIN_MARGIN = 0.045
V34_PROMOTE_SCORE = 66.0
V34_MIN_DQ = 50.0
V34_MIN_QUALITY = 46.0
V34_MIN_RR = 1.00
V34_MAX_CONTRADICTION = 0.78
V34_MIN_HISTORY = 12
V34_HISTORY_SHRINK = 10.0


def _v34_history(symbol: str, side: str) -> dict[str, Any]:
    """Outcome history with Bayesian shrinkage; tiny samples never dominate."""
    wins = losses = 0
    try:
        with DB_LOCK, db_conn() as con:
            row = con.execute(
                """SELECT
                     SUM(CASE WHEN outcome='WIN' THEN 1 ELSE 0 END),
                     SUM(CASE WHEN outcome='LOSS' THEN 1 ELSE 0 END)
                   FROM central_predictions
                   WHERE symbol=? AND decision=? AND outcome IN ('WIN','LOSS')""",
                (symbol, side),
            ).fetchone()
            wins = int(row[0] or 0)
            losses = int(row[1] or 0)
    except Exception:
        pass
    n = wins + losses
    # Beta(2,2) prior: stable at small samples and converges toward reality.
    posterior = (wins + 2.0) / (n + 4.0) if n else 0.5
    raw_wr = 100.0 * wins / n if n else 50.0
    return {
        "wins": wins, "losses": losses, "samples": n,
        "raw_win_rate": round(raw_wr, 2),
        "posterior_win_rate": round(100.0 * posterior, 2),
        "reliable": n >= V34_MIN_HISTORY,
    }


def _v34_opportunity(item: dict[str, Any]) -> dict[str, Any]:
    """Score a near-actionable WAIT without pretending it is a profit probability."""
    debate = item.get("deep_consensus_v30") or {}
    long = debate.get("long") or {}
    short = debate.get("short") or {}
    ls = safe_float(long.get("score"), 0.0)
    ss = safe_float(short.get("score"), 0.0)
    margin = ls - ss
    side = "LONG" if margin >= V34_MIN_MARGIN else "SHORT" if margin <= -V34_MIN_MARGIN else "WAIT"
    chosen = long if side == "LONG" else short if side == "SHORT" else {}
    if not chosen:
        return {"version": V34_VERSION, "state": "NO_EDGE", "score": 0.0, "candidate": "WAIT"}

    dq = safe_float(chosen.get("data_quality"), 0.0)
    quality = safe_float(chosen.get("quality"), 0.0)
    rr = safe_float(chosen.get("rr"), 0.0)
    contradiction = safe_float(chosen.get("contradiction"), 1.0)
    support = int(chosen.get("support", 0) or 0)
    oppose = int(chosen.get("oppose", 0) or 0)
    hard = list(chosen.get("hard_blocks") or [])
    history = _v34_history(_normalize_symbol(item.get("symbol") or ""), side)

    # Each component is bounded. This is an evidence score, not win probability.
    margin_score = clamp((abs(margin) - V34_MIN_MARGIN) / 0.14 * 100.0, 0.0, 100.0)
    dq_score = clamp((dq - V34_MIN_DQ) / 35.0 * 100.0, 0.0, 100.0)
    quality_score = clamp((quality - V34_MIN_QUALITY) / 35.0 * 100.0, 0.0, 100.0)
    rr_score = clamp((rr - V34_MIN_RR) / 0.90 * 100.0, 0.0, 100.0)
    support_score = clamp(support * 25.0 - oppose * 15.0, 0.0, 100.0)
    contradiction_score = clamp((V34_MAX_CONTRADICTION - contradiction) / V34_MAX_CONTRADICTION * 100.0, 0.0, 100.0)
    history_score = history["posterior_win_rate"] if history["reliable"] else 50.0

    score = (
        margin_score * 0.25 + quality_score * 0.20 + dq_score * 0.15 +
        support_score * 0.15 + rr_score * 0.10 + contradiction_score * 0.10 +
        history_score * 0.05
    )
    safety_block = (
        bool(hard) or dq < V34_MIN_DQ or quality < V34_MIN_QUALITY or
        rr < V34_MIN_RR or contradiction >= V34_MAX_CONTRADICTION
    )
    promote = side in {"LONG", "SHORT"} and score >= V34_PROMOTE_SCORE and not safety_block
    return {
        "version": V34_VERSION,
        "state": "PROMOTE_EARLY" if promote else "WATCH",
        "candidate": side,
        "score": round(clamp(score, 0.0, 100.0), 1),
        "margin": round(margin, 4),
        "data_quality": round(dq, 1),
        "signal_quality": round(quality, 1),
        "rr": round(rr, 2),
        "support": support,
        "opposition": oppose,
        "contradiction": round(contradiction, 3),
        "history": history,
        "safety_block": safety_block,
        "components": {
            "margin": round(margin_score, 1), "quality": round(quality_score, 1),
            "data": round(dq_score, 1), "support": round(support_score, 1),
            "rr": round(rr_score, 1), "contradiction": round(contradiction_score, 1),
            "history": round(history_score, 1),
        },
        "note": "Evidence score only; not a guaranteed probability of profit.",
    }


def _v34_apply(item: dict[str, Any]) -> dict[str, Any]:
    """Final opportunity layer above the canonical evidence stack."""
    try:
        opp = _v34_opportunity(item)
        item["v34_opportunity"] = opp
        item.setdefault("fusion", {})["v34_opportunity"] = opp
        current = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
        # Only promote a WAIT that is already supported by the existing central
        # debate. Never flip a valid LONG/SHORT and never bypass hard safety blocks.
        if current == "WAIT" and opp.get("state") == "PROMOTE_EARLY":
            decision = str(opp.get("candidate") or "WAIT")
            item["decision_tag"] = decision
            item["decision"] = decision
            item["bias"] = "صعودی" if decision == "LONG" else "نزولی"
            item["entry_mode"] = "EARLY"
            item["decision_state"] = "CENTRAL_V34_EARLY"
            item["signal_tag"] = f"CENTRAL V34 OPPORTUNITY — {decision}"
            # Confidence is increased modestly by evidence quality, never to 100.
            old = safe_float(item.get("decision_confidence"), 50.0)
            boost = min(8.0, max(2.0, (safe_float(opp.get("score"), 66.0) - 60.0) * 0.20))
            item["decision_confidence"] = round(clamp(max(old, 50.0) + boost, 0.0, 96.0), 1)
            item["central_reason_fa"] = "فرصت نزدیک به فعال‌شدن با اجماع شواهد، کیفیت داده و RR معتبر؛ V34 آن را از WAIT به EARLY ارتقا داد."
            item["v34_promoted"] = True
        else:
            item["v34_promoted"] = False
        item["decision_architecture"] = {
            "type": "SINGLE_CENTRAL_GOVERNOR_WITH_ADAPTIVE_EVIDENCE",
            "authoritative_source": TITAN_CENTRAL_VERSION,
            "opportunity_layer": V34_VERSION,
            "final_decision": item.get("decision_tag", "WAIT"),
            "legacy_engines_are_evidence_only": True,
        }
        return item
    except Exception as exc:
        LOGGER.debug("V34 adaptive trust failed: %s", exc)
        item["v34_opportunity"] = {"version": V34_VERSION, "state": "DEGRADED", "score": 0.0}
        item["v34_promoted"] = False
        return item

# ============================================================
# TITAN V35 — CANONICAL LIVE-PRICE / LEVEL SYNCHRONIZATION
# ------------------------------------------------------------
# One authoritative spot snapshot is used for the public dashboard price,
# entry, SL/TP, RR, forecast anchor and live-price metadata. Closed-candle
# indicators remain based on closed OHLCV; only price-dependent outputs are
# re-anchored. No signal is fabricated when a fresh live price is unavailable.
# ============================================================
V35_VERSION = "TITAN-V35-CANONICAL-LIVE-SNAPSHOT"
V35_MAX_LIVE_AGE_SEC = 8.0
V35_REBASE_MAX_AGE_SEC = 12.0


def _v35_get_live_snapshot(symbol: str, max_age: float = V35_MAX_LIVE_AGE_SEC) -> dict[str, Any]:
    """Return the freshest available Binance spot snapshot for one symbol."""
    sym = _normalize_symbol(symbol)
    now = time.time()
    with LIVE_LOCK:
        info = dict(LIVE_PRICES.get(sym) or {})
    px = safe_float(info.get("price"), 0.0)
    ts = safe_float(info.get("ts"), 0.0)
    age = now - ts if ts > 0 else float("inf")
    if px > 0 and age <= float(max_age):
        return {"price": px, "ts": ts, "age_sec": max(0.0, age),
                "source": info.get("source") or "Binance"}

    # The background live engine normally keeps this hot. A direct refresh is
    # the fail-safe for a slow/stopped worker, and is limited to this symbol.
    try:
        fresh = _fetch_live_prices([sym])
        px = safe_float(fresh.get(sym), 0.0)
        if px > 0:
            _register_live_price(sym, px, "REST-direct")
            with LIVE_LOCK:
                info = dict(LIVE_PRICES.get(sym) or {})
            ts = safe_float(info.get("ts"), time.time())
            return {"price": px, "ts": ts,
                    "age_sec": max(0.0, time.time() - ts),
                    "source": info.get("source") or "REST-direct"}
    except Exception as exc:
        LOGGER.debug("V35 direct live snapshot failed %s: %s", sym, exc)

    return {"price": px, "ts": ts, "age_sec": age,
            "source": info.get("source") or "cache", "fresh": False}


def _v35_rebase_price_dependent_outputs(item: dict[str, Any], snapshot: dict[str, Any]) -> dict[str, Any]:
    """Make all public price/entry/exit outputs coherent with one live price."""
    if not item or not snapshot:
        return item
    live = safe_float(snapshot.get("price"), 0.0)
    if live <= 0:
        item["live_sync"] = False
        item["live_sync_reason"] = "fresh_live_price_unavailable"
        return item

    now = time.time()
    old = _v29_num_price(item.get("price_raw") or item.get("price"))
    if old <= 0:
        old = live
    ratio = live / old if old > 0 else 1.0

    item.setdefault("signal_snapshot", {})
    if "price" not in item["signal_snapshot"]:
        item["signal_snapshot"]["price"] = old
        item["signal_snapshot"]["timestamp"] = item.get("scan_timestamp", now)

    item["price_raw"] = live
    item["live_price"] = live
    item["entry_raw"] = live
    item["price"] = smart_format(live)
    item["entry_valid"] = smart_format(live)

    # Directional exits are percentage-rebased from the exact signal snapshot.
    # If a final direction was promoted after the original levels were built,
    # rebuild them from the current price and validate orientation/RR first.
    decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
    if decision in {"LONG", "SHORT"}:
        for key in ("stop_loss", "tp1", "tp2"):
            if key in item:
                item[key] = _v29_shift_price_field(item.get(key), ratio)

        sl = _v29_num_price(item.get("stop_loss"))
        tp1 = _v29_num_price(item.get("tp1"))
        tp2 = _v29_num_price(item.get("tp2"))
        check = _v12_level_integrity(live, sl, tp1, tp2, decision)
        if not check.get("ok"):
            rsl, rtp1, rtp2 = _v12_rebuild_directional_levels(item, decision)
            check2 = _v12_level_integrity(live, rsl, rtp1, rtp2, decision)
            if check2.get("ok"):
                sl, tp1, tp2 = rsl, rtp1, rtp2
                check = check2
                item["level_rebased_by_v35"] = True
            else:
                # Never expose a directional signal with invalid levels.
                item["decision_tag"] = "WAIT"
                item["decision"] = "WAIT"
                item["bias"] = "خنثی"
                item["entry_mode"] = "WAIT"
                item["signal_tag"] = "V35 SAFETY WAIT — LIVE LEVELS INVALID"
                item["level_rebased_by_v35"] = False
                item["live_sync_reason"] = "directional_levels_invalid_after_live_rebase"
                sl = tp1 = tp2 = 0.0
        if sl > 0 and tp1 > 0 and tp2 > 0:
            item["stop_loss_raw"] = float(sl)
            item["tp1_raw"] = float(tp1)
            item["tp2_raw"] = float(tp2)
            item["stop_loss"] = smart_format(sl)
            item["tp1"] = smart_format(tp1)
            item["tp2"] = smart_format(tp2)
            item["rr_tp1"] = check.get("rr1", 0.0)
            item["rr_tp2"] = check.get("rr2", 0.0)
            item["effective_rr_tp1"] = item["rr_tp1"]
            item["effective_rr_tp2"] = item["rr_tp2"]
    else:
        # WAIT has no actionable exit levels. Its entry anchor is always live.
        item["entry_raw"] = live
        item["entry_valid"] = smart_format(live)

    sl = _v29_num_price(item.get("stop_loss"))
    tp1 = _v29_num_price(item.get("tp1"))
    tp2 = _v29_num_price(item.get("tp2"))
    if sl > 0:
        risk = abs(live - sl)
        item["risk_distance_pct"] = round(risk / live * 100.0, 3)
        if risk > 0 and tp1 > 0:
            item["rr_tp1"] = round(abs(tp1 - live) / risk, 3)
            item["effective_rr_tp1"] = item["rr_tp1"]
        if risk > 0 and tp2 > 0:
            item["rr_tp2"] = round(abs(tp2 - live) / risk, 3)
            item["effective_rr_tp2"] = item["rr_tp2"]

    # Keep scenario prices anchored to exactly the same live reference.
    fc = item.get("candle_forecast")
    if isinstance(fc, dict):
        fc["last_price"] = round(live, 8)
        if old > 0 and math.isfinite(ratio) and ratio > 0:
            for candle in fc.get("candles", []) or []:
                if isinstance(candle, dict):
                    for key in ("open", "high", "low", "close", "mid", "band_low", "band_high"):
                        if key in candle:
                            try:
                                candle[key] = round(float(candle[key]) * ratio, 8)
                            except Exception:
                                pass

    age = max(0.0, now - safe_float(snapshot.get("ts"), now))
    item["live_price_source"] = snapshot.get("source") or "Binance"
    item["live_price_ts"] = safe_float(snapshot.get("ts"), now)
    item["live_price_age_sec"] = round(age, 3)
    item["live_sync"] = bool(age <= V35_MAX_LIVE_AGE_SEC)
    item["price_delta_from_scan_pct"] = round((live / old - 1.0) * 100.0, 4) if old > 0 else 0.0
    item["price_sync_version"] = V35_VERSION
    item["price_sync"] = {
        "authoritative_price": live,
        "source": item["live_price_source"],
        "timestamp": item["live_price_ts"],
        "age_sec": item["live_price_age_sec"],
        "entry_anchor": live,
        "levels_rebased": bool(item.get("level_rebased_by_v35", False) or decision in {"LONG", "SHORT"}),
        "single_price_source_for_public_outputs": True,
    }
    return item



# ============================================================
# TITAN V36 — QUANTUM RESONANCE EDGE (magical upgrade layer)
# ------------------------------------------------------------
# Cross-asset resonance, drift-aware confidence decay, and
# multi-horizon agreement score. Analysis-only; never invents
# win probability. Can only demote unsafe signals or modestly
# boost a coherent multi-horizon edge that is already present.
# ============================================================
V36_VERSION = "TITAN-V36-QUANTUM-RESONANCE-EDGE"
V36_DRIFT_KILL_PCT = 1.85
V36_RESONANCE_BOOST_MIN = 0.62
V36_MAX_CONF_BOOST = 6.0
_V36_RESONANCE_CACHE: dict[str, Any] = {"ts": 0.0, "matrix": {}}
_V36_RESONANCE_LOCK = threading.RLock()


def _v36_horizon_agreement(item: dict[str, Any]) -> dict[str, Any]:
    """Score agreement across HTF/MTF/LTF + forecast path + structure."""
    tf = item.get("tf_scores") or item.get("tfs") or {}
    s15 = safe_float(tf.get("15m"), 50.0)
    s1h = safe_float(tf.get("1h"), 50.0)
    s4h = safe_float(tf.get("4h"), 50.0)
    s1d = safe_float(tf.get("1d"), 50.0)
    decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()

    def lean(sc: float) -> float:
        return clamp((sc - 50.0) / 50.0, -1.0, 1.0)

    leans = [lean(s15), lean(s1h), lean(s4h), lean(s1d)]
    fc = item.get("candle_forecast") or {}
    fc_bias = str(fc.get("overall_bias") or "")
    if fc_bias == "صعودی":
        leans.append(0.45)
    elif fc_bias == "نزولی":
        leans.append(-0.45)
    struct = item.get("structure") if isinstance(item.get("structure"), dict) else {}
    sb = str(struct.get("bias") or item.get("structure_bias") or "")
    if sb == "صعودی":
        leans.append(0.40)
    elif sb == "نزولی":
        leans.append(-0.40)

    if not leans:
        return {"agreement": 0.0, "direction": "WAIT", "n": 0}
    mean = sum(leans) / len(leans)
    var = sum((x - mean) ** 2 for x in leans) / max(1, len(leans))
    cohesion = float(clamp(1.0 - (var ** 0.5) * 1.8, 0.0, 1.0))
    magnitude = abs(mean)
    agreement = float(clamp(cohesion * (0.45 + 0.55 * magnitude), 0.0, 1.0))
    direction = "LONG" if mean > 0.08 else "SHORT" if mean < -0.08 else "WAIT"
    aligned = direction == decision if decision in {"LONG", "SHORT"} else False
    return {
        "agreement": round(agreement, 4),
        "mean_lean": round(mean, 4),
        "cohesion": round(cohesion, 4),
        "direction": direction,
        "aligned_with_decision": aligned,
        "n": len(leans),
    }


def _v36_price_drift_gate(item: dict[str, Any]) -> dict[str, Any]:
    """Kill directional signals when live price has run away from the scan snapshot."""
    snap = item.get("signal_snapshot") if isinstance(item.get("signal_snapshot"), dict) else {}
    snap_px = safe_float(snap.get("price"), 0.0)
    live = safe_float(item.get("price_raw") or item.get("live_price"), 0.0)
    decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
    if snap_px <= 0 or live <= 0 or decision not in {"LONG", "SHORT"}:
        return {"drift_pct": 0.0, "kill": False, "reason": ""}
    drift = (live / snap_px - 1.0) * 100.0
    adverse = (decision == "LONG" and drift > V36_DRIFT_KILL_PCT) or (
        decision == "SHORT" and drift < -V36_DRIFT_KILL_PCT
    )
    extreme = abs(drift) > V36_DRIFT_KILL_PCT * 1.6
    kill = bool(adverse or extreme)
    reason = ""
    if adverse:
        reason = f"adverse_drift_{drift:+.2f}%"
    elif extreme:
        reason = f"extreme_drift_{drift:+.2f}%"
    return {"drift_pct": round(drift, 3), "kill": kill, "reason": reason, "snap": snap_px, "live": live}


def _v36_cross_asset_resonance(symbol: str, decision: str, cache_rows: list) -> dict[str, Any]:
    """Soft portfolio resonance: same-side cluster reduces edge quality."""
    if decision not in {"LONG", "SHORT"} or not cache_rows:
        return {"same_side": 0, "penalty": 0.0, "note": ""}
    majors = {"BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "XRP/USDT"}
    sym = _normalize_symbol(symbol)
    same = 0
    for row in cache_rows:
        other = _normalize_symbol(row.get("symbol") or "")
        if other == sym:
            continue
        od = str(row.get("decision_tag") or row.get("decision") or "").upper()
        if od == decision:
            same += 1
    penalty = 0.0
    note = ""
    if same >= 6:
        penalty = 10.0
        note = f"رزونانس سبد: {same} سیگنال هم‌جهت فعال"
    elif same >= 4:
        penalty = 5.0
        note = f"فشار خوشه‌ای: {same} سیگنال هم‌جهت"
    if sym in majors and same >= 3:
        penalty = max(penalty, 4.0)
    return {"same_side": same, "penalty": penalty, "note": note}


def _v36_apply(item: dict[str, Any], cache_rows: Optional[list] = None) -> dict[str, Any]:
    """Quantum Resonance final polish — demote on drift, modest boost on pure agreement."""
    try:
        decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
        agree = _v36_horizon_agreement(item)
        drift = _v36_price_drift_gate(item)
        resonance = _v36_cross_asset_resonance(
            str(item.get("symbol") or ""), decision, list(cache_rows or [])
        )
        killed = False
        boosted = False
        notes: list[str] = []

        if decision in {"LONG", "SHORT"} and drift.get("kill"):
            item["decision_tag"] = "WAIT"
            item["decision"] = "WAIT"
            item["bias"] = "خنثی"
            item["entry_mode"] = "WAIT"
            item["signal_tag"] = "V36 RESONANCE WAIT — PRICE DRIFT"
            item["central_reason_fa"] = (
                f"قیمت از اسنپ‌شات سیگنال بیش از حد فاصله گرفته ({drift.get('reason')}); "
                "سیگنال جهت‌دار باطل شد."
            )
            killed = True
            notes.append(str(drift.get("reason") or "drift_kill"))

        if not killed and decision in {"LONG", "SHORT"}:
            if (
                agree.get("direction") in {"LONG", "SHORT"}
                and agree.get("direction") != decision
                and agree.get("agreement", 0) >= 0.55
            ):
                item["decision_tag"] = "WAIT"
                item["decision"] = "WAIT"
                item["bias"] = "خنثی"
                item["entry_mode"] = "WAIT"
                item["signal_tag"] = "V36 RESONANCE WAIT — HORIZON DISCORD"
                item["central_reason_fa"] = "اجماع افق‌های زمانی با جهت سیگنال در تضاد است."
                killed = True
                notes.append("horizon_discord")
            elif agree.get("aligned_with_decision") and agree.get("agreement", 0) >= V36_RESONANCE_BOOST_MIN:
                conf = safe_float(item.get("decision_confidence"), 50.0)
                boost = min(V36_MAX_CONF_BOOST, (agree["agreement"] - V36_RESONANCE_BOOST_MIN) * 18.0)
                boost = max(0.0, boost - safe_float(resonance.get("penalty"), 0.0) * 0.35)
                if boost >= 1.0:
                    item["decision_confidence"] = round(clamp(conf + boost, 0.0, 96.0), 1)
                    boosted = True
                    notes.append(f"resonance_boost_+{boost:.1f}")
            if resonance.get("penalty", 0) >= 8 and not killed:
                conf = safe_float(item.get("decision_confidence"), 50.0)
                item["decision_confidence"] = round(max(35.0, conf - resonance["penalty"]), 1)
                notes.append(resonance.get("note") or "cluster_pressure")

        item["v36_resonance"] = {
            "version": V36_VERSION,
            "horizon_agreement": agree,
            "price_drift": drift,
            "cross_asset": resonance,
            "killed": killed,
            "boosted": boosted,
            "notes": notes,
        }
        item.setdefault("fusion", {})["v36_resonance"] = item["v36_resonance"]
        arch = item.get("decision_architecture") if isinstance(item.get("decision_architecture"), dict) else {}
        arch = dict(arch)
        arch["resonance_layer"] = V36_VERSION
        arch["final_decision"] = item.get("decision_tag", "WAIT")
        item["decision_architecture"] = arch
        return item
    except Exception as exc:
        LOGGER.debug("V36 resonance failed: %s", exc)
        item["v36_resonance"] = {"version": V36_VERSION, "error": str(exc)[:180]}
        return item



# ---- Public gateways: seal every analysis through Central Governor ----
_CENTRAL_PREV_ANALYZE = analyze_asset
_CENTRAL_PREV_UPDATE = update_cache


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """Sole public analyzer — upstream evidence, Central Governor decides."""
    try:
        base = _CENTRAL_PREV_ANALYZE(symbol, btc_trend)
        if not base:
            return None
        sealed = _central_seal(base)
        sealed = _v31_apply(sealed)
        sealed = _v34_apply(sealed)
        # Final authoritative live snapshot: after every decision layer, re-anchor
        # price/entry/SL/TP/RR/forecast to the same newest spot price.
        snapshot = _v35_get_live_snapshot(symbol)
        sealed = _v35_rebase_price_dependent_outputs(sealed, snapshot)
        # V36 Quantum Resonance: drift kill + multi-horizon agreement + cluster pressure
        try:
            with CACHE_LOCK:
                _rows = list(CACHE.get("data") or [])
        except Exception:
            _rows = []
        sealed = _v36_apply(sealed, _rows)
        # A directional signal is never exposed as "live" when its price source
        # is too stale. This is a data-integrity gate, not a signal generator.
        if sealed.get("decision_tag") in {"LONG", "SHORT"} and not sealed.get("live_sync", False):
            sealed["decision_tag"] = "WAIT"
            sealed["decision"] = "WAIT"
            sealed["bias"] = "خنثی"
            sealed["entry_mode"] = "WAIT"
            sealed["signal_tag"] = "V35 SAFETY WAIT — LIVE PRICE STALE"
            sealed["central_reason_fa"] = "قیمت لحظه‌ای معتبر و تازه برای تأیید نهایی در دسترس نیست؛ سیگنال جهت‌دار صادر نشد."
        try:
            _central_record_prediction(sealed)
        except Exception:
            pass
        return sealed
    except Exception as exc:
        LOGGER.exception("Central analyze failed %s: %s", symbol, exc)
        try:
            if "base" in locals() and base:
                return _central_seal(base)
        except Exception:
            pass
        return None


def update_cache(force: bool = False) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    """Central-owned scan with progress heartbeat + emergency fallback."""
    coins = list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
    total = max(1, len(coins))
    scan_started = time.time()
    with CACHE_LOCK:
        cached_n = len(CACHE.get("data") or [])
        cache_age = time.time() - safe_float(CACHE.get("timestamp"), 0.0)
        cached_data = list(CACHE.get("data") or [])
        cached_summary = CACHE.get("gemini_summary") or ""
        cached_macro = dict(CACHE.get("macro") or {})
    ttl = float(globals().get("MARKET_CACHE_TTL", 40))
    do_force = bool(force) or cached_n <= 0 or cache_age >= ttl

    if not do_force and cached_n > 0:
        _scan_progress_update(
            status="complete", phase="داده از کش", completed=cached_n,
            total=max(total, cached_n), percent=100,
            last_success_at=time.time() - cache_age if cache_age < 1e9 else time.time(),
            message=f"کش تازه · {cached_n} ارز · سن {cache_age:.0f}s", fresh=False,
        )
        return cached_data, cached_summary, cached_macro

    _scan_progress_update(
        status="running", phase="آماده‌سازی داور مرکزی", started_at=scan_started,
        finished_at=0.0, completed=0, total=total, percent=3,
        message=f"داور مرکزی · اسکن {total} ارز…", fresh=False,
    )
    hb_stop = threading.Event()

    def _hb():
        while not hb_stop.wait(1.1):
            try:
                snap = _scan_progress_snapshot()
                if str(snap.get("status") or "") != "running":
                    break
                started = safe_float(snap.get("started_at"), scan_started)
                elapsed = max(0.0, time.time() - started)
                completed = int(snap.get("completed") or 0)
                soft = min(90.0, 4.0 + (elapsed / max(12.0, total * 2.5)) * 78.0 + completed * (70.0 / total))
                if soft > safe_float(snap.get("percent"), 0):
                    _scan_progress_update(percent=round(soft, 1),
                                          message=snap.get("message") or f"تحلیل زنده · {completed}/{total}")
            except Exception:
                break

    threading.Thread(target=_hb, name="titan-progress-hb", daemon=True).start()
    try:
        try:
            _central_evaluate_pending()
        except Exception:
            pass
        try:
            if "v32_evaluate_pending" in globals():
                v32_evaluate_pending()
        except Exception:
            pass

        data, summary, macro = _CENTRAL_PREV_UPDATE(True)
        sealed: list[dict[str, Any]] = []
        n_items = max(1, len(data or []))
        for idx, item in enumerate(data or [], 1):
            try:
                if str(item.get("authority", "")) == TITAN_CENTRAL_VERSION:
                    sealed.append(item)
                else:
                    sealed.append(_central_seal(item))
            except Exception:
                if item:
                    sealed.append(item)
            if idx == n_items or idx % 3 == 0:
                _scan_progress_update(
                    completed=idx, total=max(total, n_items),
                    percent=min(98, 85 + int(12 * idx / n_items)),
                    phase="مهر داور مرکزی", message=f"مهر مرکزی {idx}/{n_items}",
                )
        finished = time.time()
        with CACHE_LOCK:
            CACHE["data"] = sealed
            if sealed:
                CACHE["timestamp"] = finished
                if summary is not None:
                    CACHE["gemini_summary"] = summary
                if macro is not None:
                    CACHE["macro"] = macro
        if sealed:
            _scan_progress_update(
                status="complete", phase="اسکن کامل شد", completed=len(sealed),
                total=max(total, len(sealed)), percent=100, finished_at=finished,
                last_success_at=finished, elapsed_sec=round(finished - scan_started, 1),
                message=f"داور مرکزی · {len(sealed)} ارز · {round(finished - scan_started, 1)}s",
                fresh=True,
            )
            try:
                if "store_forecasts" in globals():
                    store_forecasts(sealed)
            except Exception:
                pass
            return sealed, summary, macro

        emergency = _emergency_live_cards(coins)
        if emergency:
            with CACHE_LOCK:
                CACHE["data"] = emergency
                CACHE["timestamp"] = finished
            _scan_progress_update(
                status="complete", phase="قیمت زنده اضطراری", completed=len(emergency),
                total=max(total, len(emergency)), percent=100, finished_at=finished,
                last_success_at=finished,
                message=f"اسکن کامل ناموفق؛ {len(emergency)} قیمت زنده",
                fresh=False,
            )
            return emergency, summary or "", macro or {}
        if cached_n > 0:
            _scan_progress_update(
                status="complete", phase="بازیابی کش", completed=cached_n,
                total=max(total, cached_n), percent=100, finished_at=finished,
                message=f"نمایش {cached_n} ارز از کش", fresh=False,
            )
            return cached_data, cached_summary, cached_macro
        _scan_progress_update(
            status="failed", phase="اسکن بدون نتیجه", percent=100, finished_at=finished,
            message="نتیجه‌ای برنگشت؛ اسکن بعدی خودکار است", fresh=False,
        )
        return [], summary or "", macro or {}
    except Exception as exc:
        LOGGER.exception("Central update_cache: %s", exc)
        finished = time.time()
        try:
            emergency = _emergency_live_cards(coins)
        except Exception:
            emergency = []
        if emergency:
            with CACHE_LOCK:
                CACHE["data"] = emergency
                CACHE["timestamp"] = finished
            _scan_progress_update(
                status="complete", phase="بازیابی اضطراری", percent=100,
                completed=len(emergency), finished_at=finished,
                message=f"خطا در اسکن · {len(emergency)} قیمت زنده", fresh=False,
            )
            return emergency, "", {}
        _scan_progress_update(
            status="failed", phase="خطای اسکن", percent=100, finished_at=finished,
            message=f"خطا: {str(exc)[:200]}", fresh=False,
        )
        with CACHE_LOCK:
            return list(CACHE.get("data") or []), CACHE.get("gemini_summary") or "", CACHE.get("macro") or {}
    finally:
        hb_stop.set()


# Patch index to never serve blank Android shell
_CENTRAL_PREV_INDEX = index


def index():
    try:
        with CACHE_LOCK:
            n = len(CACHE.get("data") or [])
        if n <= 0:
            try:
                emergency = _emergency_live_cards()
                if emergency:
                    with CACHE_LOCK:
                        if not CACHE.get("data"):
                            CACHE["data"] = emergency
                            CACHE["timestamp"] = time.time()
                    _scan_progress_update(
                        status="running", phase="قیمت زنده موقت", percent=8,
                        message=f"{len(emergency)} ارز · تحلیل کامل در صف",
                        completed=0, total=len(USER_SETTINGS.get("active_coins") or DEFAULT_COINS),
                        started_at=time.time(), fresh=False,
                    )
            except Exception as exc:
                LOGGER.warning("index emergency: %s", exc)
            try:
                threading.Thread(target=lambda: _background_market_refresh(True), name="titan-force-scan", daemon=True).start()
            except Exception:
                pass
        return _CENTRAL_PREV_INDEX()
    except Exception as exc:
        LOGGER.exception("index wrapper: %s", exc)
        return _CENTRAL_PREV_INDEX()


@app.get("/api/central-brain")
def api_central_brain():
    try:
        with DB_LOCK, db_conn() as con:
            pending = int(con.execute("SELECT COUNT(*) FROM central_predictions WHERE outcome='PENDING'").fetchone()[0])
            done = con.execute(
                "SELECT outcome,COUNT(*) FROM central_predictions WHERE outcome!='PENDING' GROUP BY outcome"
            ).fetchall()
            comps = con.execute(
                "SELECT component,samples,wins,losses,reward_sum,penalty_sum,weight FROM central_component_stats ORDER BY component"
            ).fetchall()
        return jsonify({
            "ok": True,
            "version": TITAN_CENTRAL_VERSION,
            "pending": pending,
            "outcomes": {str(r[0]): int(r[1]) for r in done},
            "components": [
                {"component": r[0], "samples": r[1], "wins": r[2], "losses": r[3],
                 "reward": r[4], "penalty": r[5], "weight": r[6]}
                for r in comps
            ],
            "live_weights": dict(_CENTRAL_WEIGHTS),
            "mode": "CENTRAL_GOVERNOR_ONLY",
            "note": "سیگنال‌ها احتمالی هستند و تضمین سود نیست.",
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500


@app.get("/api/v31-edge")
def api_v31_edge():
    """Expose the 21-module Edge Suite without changing the existing dashboard contract."""
    try:
        with CACHE_LOCK:
            rows=list(CACHE.get("data") or [])
        suite=[]
        for item in rows:
            e=item.get("v31_edge_suite") or {}
            suite.append({"symbol":item.get("symbol"),"decision":item.get("decision_tag") or item.get("decision"),
                          "safety_wait":e.get("safety_wait",False),"uncertainty":(e.get("uncertainty") or {}).get("uncertainty"),
                          "robustness":(e.get("adversarial") or {}).get("robustness"),
                          "entry_stability":(e.get("entry_stability") or {}).get("score"),
                          "data_quality":(e.get("data_quality") or {}).get("score"),
                          "explainability":e.get("explainability") or {}})
        return jsonify({"ok":True,"version":V31_EDGE_VERSION,"count":len(suite),"items":suite})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500

@app.get("/api/v36-resonance")
def api_v36_resonance():
    """Dashboard summary of Quantum Resonance Edge state per symbol."""
    try:
        with CACHE_LOCK:
            rows = list(CACHE.get("data") or [])
        items = []
        killed = boosted = 0
        for item in rows:
            r = item.get("v36_resonance") or {}
            ha = r.get("horizon_agreement") or {}
            pd_ = r.get("price_drift") or {}
            ca = r.get("cross_asset") or {}
            if r.get("killed"):
                killed += 1
            if r.get("boosted"):
                boosted += 1
            items.append({
                "symbol": item.get("symbol"),
                "decision": item.get("decision_tag") or item.get("decision"),
                "confidence": item.get("decision_confidence"),
                "agreement": ha.get("agreement"),
                "horizon_direction": ha.get("direction"),
                "aligned": ha.get("aligned_with_decision"),
                "drift_pct": pd_.get("drift_pct"),
                "drift_kill": pd_.get("kill"),
                "same_side_cluster": ca.get("same_side"),
                "cluster_penalty": ca.get("penalty"),
                "killed": bool(r.get("killed")),
                "boosted": bool(r.get("boosted")),
                "notes": r.get("notes") or [],
                "live_sync": item.get("live_sync"),
                "live_age_sec": item.get("live_price_age_sec"),
                "v34": (item.get("v34_opportunity") or {}).get("state"),
            })
        return jsonify({
            "ok": True,
            "version": globals().get("V36_VERSION", "V36"),
            "param_version": TITAN_PARAM_VERSION,
            "count": len(items),
            "killed": killed,
            "boosted": boosted,
            "items": items,
            "note": "رزونانس کوانتومی فقط کیفیت/ایمنی سیگنال را تنظیم می‌کند؛ احتمال برد تضمینی نیست.",
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500


@app.get("/api/edge-lab")
def api_edge_lab():
    try:
        return jsonify(_edge_api_report())
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500


def _central_learner_loop():
    while not LIVE_STOP.is_set():
        try:
            _central_evaluate_pending()
            _central_load_weights()
        except Exception as exc:
            LOGGER.debug("central learner: %s", exc)
        LIVE_STOP.wait(40)


def _shutdown_runtime() -> None:
    """Stop background loops and close reusable worker pools on process exit."""
    LIVE_STOP.set()
    for pool_name in ("_ANALYSIS_POOL", "_KLINE_POOL", "_AI_POOL"):
        pool = globals().get(pool_name)
        if pool is not None:
            try:
                pool.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                try:
                    pool.shutdown(wait=False)
                except Exception:
                    pass
            except Exception:
                pass


import atexit
atexit.register(_shutdown_runtime)


def _open_dashboard_browser() -> None:
    """Open the local dashboard after the HTTP server becomes reachable."""
    try:
        import webbrowser
        url = f"http://127.0.0.1:{PORT}/"
        for _ in range(30):
            try:
                with socket.create_connection(("127.0.0.1", PORT), timeout=0.25):
                    webbrowser.open(url, new=1, autoraise=True)
                    return
            except OSError:
                LIVE_STOP.wait(0.5)
                if LIVE_STOP.is_set():
                    return
    except Exception as exc:
        LOGGER.debug("Dashboard browser launch skipped: %s", exc)


# continuous learner started with main
_CENTRAL_LEARNER_STARTED = False


def _ensure_central_learner():
    global _CENTRAL_LEARNER_STARTED
    if _CENTRAL_LEARNER_STARTED:
        return
    try:
        threading.Thread(target=_central_learner_loop, name="titan-central-learner", daemon=True).start()
        _CENTRAL_LEARNER_STARTED = True
    except Exception:
        pass




# ============================================================
# TITAN SELF-TEST — V35/V36 gate fixtures (no network required)
# Run:  python TITAN_V36_ANDROID_FINAL.py --self-test
# ============================================================

def _titan_self_test() -> int:
    """Return 0 on success, 1 on failure. Offline unit checks for critical gates."""
    failures: list[str] = []

    def check(name: str, cond: bool, detail: str = "") -> None:
        if not cond:
            failures.append(f"FAIL {name}: {detail}")
            print(f"  ✗ {name} — {detail}")
        else:
            print(f"  ✓ {name}")

    print("=" * 60)
    print("TITAN SELF-TEST · V35/V36 gates + helpers")
    print("=" * 60)

    check("clamp_mid", clamp(50, 0, 100) == 50.0)
    check("clamp_hi", clamp(150, 0, 100) == 100.0)
    check("normalize_symbol", _normalize_symbol("btc") == "BTC/USDT")
    check("binance_symbol", _binance_symbol("ETH/USDT") == "ETHUSDT")

    if "_v36_horizon_agreement" in globals():
        longish = {
            "tf_scores": {"15m": 62, "1h": 64, "4h": 68, "1d": 66},
            "decision_tag": "LONG",
            "candle_forecast": {"overall_bias": "صعودی"},
            "structure": {"bias": "صعودی"},
        }
        ag = _v36_horizon_agreement(longish)
        check("v36_agree_long_dir", ag.get("direction") == "LONG", str(ag))
        check("v36_agree_aligned", ag.get("aligned_with_decision") is True, str(ag))
        check("v36_agree_score", safe_float(ag.get("agreement"), 0) > 0.3, str(ag))

        conflict = {
            "tf_scores": {"15m": 30, "1h": 28, "4h": 25, "1d": 22},
            "decision_tag": "LONG",
            "candle_forecast": {"overall_bias": "نزولی"},
            "structure": {"bias": "نزولی"},
        }
        ag2 = _v36_horizon_agreement(conflict)
        check("v36_agree_conflict_short", ag2.get("direction") == "SHORT", str(ag2))

    if "_v36_price_drift_gate" in globals():
        d0 = _v36_price_drift_gate({
            "decision_tag": "LONG", "price_raw": 100.5,
            "signal_snapshot": {"price": 100.0},
        })
        check("v36_drift_safe", d0.get("kill") is False, str(d0))
        d1 = _v36_price_drift_gate({
            "decision_tag": "LONG", "price_raw": 103.0,
            "signal_snapshot": {"price": 100.0},
        })
        check("v36_drift_kill_long", d1.get("kill") is True, str(d1))
        d2 = _v36_price_drift_gate({
            "decision_tag": "SHORT", "price_raw": 97.0,
            "signal_snapshot": {"price": 100.0},
        })
        check("v36_drift_kill_short", d2.get("kill") is True, str(d2))

    if "_v36_cross_asset_resonance" in globals():
        rows = [{"symbol": f"ALT{i}/USDT", "decision_tag": "LONG"} for i in range(7)]
        res = _v36_cross_asset_resonance("BTC/USDT", "LONG", rows)
        check("v36_cluster_penalty", safe_float(res.get("penalty"), 0) >= 5.0, str(res))
        res2 = _v36_cross_asset_resonance("BTC/USDT", "WAIT", rows)
        check("v36_cluster_wait_zero", safe_float(res2.get("penalty"), 0) == 0.0, str(res2))

    if "_v36_apply" in globals():
        item = {
            "symbol": "BTC/USDT", "decision_tag": "LONG", "decision": "LONG",
            "bias": "صعودی", "decision_confidence": 70.0,
            "price_raw": 104.0, "live_price": 104.0,
            "signal_snapshot": {"price": 100.0},
            "tf_scores": {"15m": 60, "1h": 61, "4h": 62, "1d": 63},
            "candle_forecast": {"overall_bias": "صعودی"},
            "structure": {"bias": "صعودی"},
        }
        out = _v36_apply(dict(item), [])
        check("v36_apply_kills_drift", out.get("decision_tag") == "WAIT", str(out.get("v36_resonance")))
        check("v36_apply_has_pack", isinstance(out.get("v36_resonance"), dict))

        item2 = {
            "symbol": "ETH/USDT", "decision_tag": "LONG", "decision": "LONG",
            "bias": "صعودی", "decision_confidence": 70.0,
            "price_raw": 100.2, "live_price": 100.2,
            "signal_snapshot": {"price": 100.0},
            "tf_scores": {"15m": 65, "1h": 66, "4h": 70, "1d": 68},
            "candle_forecast": {"overall_bias": "صعودی"},
            "structure": {"bias": "صعودی"},
        }
        out2 = _v36_apply(dict(item2), [])
        check("v36_apply_keeps_aligned_long", out2.get("decision_tag") == "LONG", str(out2.get("v36_resonance")))

    if "_v35_rebase_price_dependent_outputs" in globals():
        card = {
            "decision_tag": "WAIT", "decision": "WAIT",
            "price_raw": 100.0, "price": "100", "entry_raw": 100.0,
            "candle_forecast": {
                "last_price": 100.0,
                "candles": [{"open": 100, "high": 101, "low": 99, "close": 100.5,
                             "mid": 100.5, "band_low": 99, "band_high": 102}],
            },
        }
        snap = {"price": 110.0, "ts": time.time(), "age_sec": 0.5, "source": "test"}
        rebased = _v35_rebase_price_dependent_outputs(dict(card), snap)
        check("v35_rebase_price", abs(safe_float(rebased.get("price_raw"), 0) - 110.0) < 1e-9)
        check("v35_rebase_live_sync", rebased.get("live_sync") is True)
        check(
            "v35_forecast_anchor",
            abs(safe_float((rebased.get("candle_forecast") or {}).get("last_price"), 0) - 110.0) < 1e-6,
        )

    if "_v12_level_integrity" in globals():
        ok = _v12_level_integrity(100.0, 95.0, 108.0, 115.0, "LONG")
        check("v12_long_levels_ok", bool(ok.get("ok")), str(ok))
        bad = _v12_level_integrity(100.0, 105.0, 108.0, 115.0, "LONG")
        check("v12_long_levels_bad", not bool(bad.get("ok")), str(bad))

    print("-" * 60)
    if failures:
        print(f"SELF-TEST FAILED: {len(failures)} check(s)")
        for f in failures:
            print(" ", f)
        return 1
    print("SELF-TEST PASSED")
    return 0



def run_titan(open_browser: bool = False) -> None:
    """Start the TITAN desktop runtime in a caller-owned thread/process."""
    try:
        _safe_startup_check()
        load_settings()
        reload_keys()
    except Exception as exc:
        LOGGER.exception("Desktop startup preparation failed: %s", exc)
    try:
        start_live_engine()
    except Exception as exc:
        LOGGER.warning("Live engine startup deferred: %s", exc)
    # V29: continuous scan + learning loop is independent of browser refreshes.
    try:
        threading.Thread(target=_v29_auto_loop, name="titan-v29-autonomous", daemon=True).start()
    except Exception as exc:
        LOGGER.warning("Autonomous loop startup failed: %s", exc)
    # Warm disk/memory cache in background so the first browser hit is instant.
    try:
        threading.Thread(target=lambda: _background_market_refresh(False), name="titan-warmup", daemon=True).start()
    except Exception as exc:
        LOGGER.debug("warmup failed: %s", exc)
    try:
        _ensure_central_learner()
    except Exception:
        pass
    if open_browser:
        try:
            threading.Thread(target=_open_dashboard_browser, name="titan-browser", daemon=True).start()
        except Exception:
            pass
    print("=" * 78)
    print("⚡ TITAN V36 ANDROID ENGINE — central governor + quantum resonance edge")
    print(f"📁 Storage: {APP_HOME}")
    print(f"🧠 Authority: {TITAN_CENTRAL_VERSION}")
    print(f"🧠 Param: {TITAN_PARAM_VERSION}")
    print("📱 Android mode: local-only dashboard | storage HARD-LOCKED to AI TAITAN AI")
    print("🛡️ Storage audit: PASS | writable: YES | persistent paths: LOCKED")
    print(f"🔑 Gemini Key: {'FOUND' if GEMINI_API_KEY else 'NOT FOUND'}")
    print(f"🔑 CoinGlass Key: {'FOUND' if COINGLASS_API_KEY else 'NOT FOUND (Binance fallback)'}")
    print(f"🌐 Dashboard: http://127.0.0.1:{PORT}  |  LAN: http://<PHONE-IP>:{PORT}")
    print("📊 Mode: Analysis only — signals are probabilistic, not guarantees")
    print("🔄 Auto-scan / central judge / REAL EDGE / reward-penalty / EDGE LAB: ACTIVE")
    print("🧠 Opportunity policy: EARLY/READY/STRONG — WAIT only on insufficient edge or hard data risk")
    print("📱 Android tuning: soft central governor, watchdog, workers capped, adaptive polling, SQLite temp_store=MEMORY")
    print("🧹 Favicon 500 fix: ACTIVE | browser persistent storage: DISABLED")
    print("=" * 78)
    app.run(host=HOST, port=PORT, threaded=True, debug=False, use_reloader=False)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in {"--self-test", "--test", "self-test"}:
        raise SystemExit(_titan_self_test())
    run_titan(open_browser=True)
