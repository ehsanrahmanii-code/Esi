#!/usr/bin/env bash
set -euo pipefail
./gradlew clean assembleRelease
printf '\nAPK: app/build/outputs/apk/release/app-release.apk\n'
